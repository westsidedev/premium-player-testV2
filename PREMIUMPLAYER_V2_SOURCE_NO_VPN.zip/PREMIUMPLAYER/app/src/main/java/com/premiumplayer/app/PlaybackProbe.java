package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class PlaybackProbe {
        boolean ok;
        boolean hls;
        String url;
        String message;
        String contentType;

        static PlaybackProbe ok(
                String url,
                boolean hls,
                String contentType) {

            PlaybackProbe result = new PlaybackProbe();
            result.ok = true;
            result.url = url;
            result.hls = hls;
            result.contentType = contentType;
            result.message = "OK";
            return result;
        }

        static PlaybackProbe fail(String message) {
            PlaybackProbe result = new PlaybackProbe();
            result.ok = false;
            result.message = message == null ? "Unknown error" : message;
            result.url = "";
            result.contentType = "";
            return result;
        }
    }
