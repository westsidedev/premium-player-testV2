package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class SeriesItem {
    String rawJson = "";
    long importGeneration = 0L;
        String name = "";
        String categoryId = "";
        String seriesId = "";
        String rating = "";
        String year = "";
    long addedAt = 0L;
    long updatedAt = 0L;
        String plot = "";
        String cover = "";
        String cast = "";
        String director = "";
        String genre = "";
        String trailer = "";
        boolean detailsLoaded = false;
        boolean detailsLoading = false;
    }
