package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class MovieSearchResult {
        final ArrayList<MovieItem> items = new ArrayList<MovieItem>();
        int matchCount = 0;
    }
