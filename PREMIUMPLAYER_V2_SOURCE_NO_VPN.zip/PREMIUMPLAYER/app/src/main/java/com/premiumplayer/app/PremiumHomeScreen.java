package com.premiumplayer.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class PremiumHomeScreen {

    interface Host {
        int logoResource();

        void loadHeroArtwork(
                ImageView target);

        void registerHeroViews(
                ImageView image,
                TextView title,
                TextView description);

        void populateContinueWatching(
                LinearLayout parent);

        void populateRecentlyAddedMovies(LinearLayout parent);
        void populateRecentlyAddedSeries(LinearLayout parent);

        void openHome();

        void openLiveTv();

        void openMovies();

        void openSeries();

        void openSportsGuide();

        void openSearch();

        void openSettings();
    }

    private static final int GOLD =
            Color.rgb(205, 174, 104);

    private static final int WHITE =
            Color.WHITE;

    private static final int SILVER =
            Color.rgb(195, 195, 200);

    static View create(
            Activity activity,
            Host host) {

        FrameLayout screen =
                new FrameLayout(activity);

        screen.setBackgroundColor(
                Color.rgb(7, 8, 10));

        ImageView background =
                new ImageView(activity);

        background.setScaleType(
                ImageView.ScaleType.CENTER_CROP);

        background.setBackgroundColor(
                Color.BLACK);

        screen.addView(
                background,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));

        host.loadHeroArtwork(
                background);

        View fullShade =
                new View(activity);

        GradientDrawable fullShadeDrawable =
                new GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{
                                Color.argb(65, 0, 0, 0),
                                Color.argb(125, 0, 0, 0),
                                Color.argb(220, 0, 0, 0)
                        });

        fullShade.setBackground(
                fullShadeDrawable);

        screen.addView(
                fullShade,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));

        ScrollView scroll =
                new ScrollView(activity);

        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);

        LinearLayout root =
                new LinearLayout(activity);

        root.setOrientation(
                LinearLayout.VERTICAL);

        scroll.addView(
                root,
                new ScrollView.LayoutParams(
                        ScrollView.LayoutParams.MATCH_PARENT,
                        ScrollView.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams scrollParams =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT);
        scrollParams.topMargin = dp(activity, 68);
        screen.addView(scroll, scrollParams);
        addTopNavigation(activity, screen, host);

        addHero(
                activity,
                root,
                host,
                background);

        addContinueWatching(
                activity,
                root,
                host);

        return screen;
    }

    private static void addHero(
            Activity activity,
            LinearLayout root,
            Host host,
            ImageView backdrop) {

        final int heroHeight =
                activity.getResources()
                        .getDisplayMetrics()
                        .heightPixels * 35 / 100;

        FrameLayout hero =
                new FrameLayout(activity);

        LinearLayout.LayoutParams heroParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        heroHeight);

        root.addView(
                hero,
                heroParams);

        addHeroText(
                activity,
                hero,
                host,
                backdrop);
    }

    private static void addTopNavigation(
            Activity activity,
            FrameLayout hero,
            Host host) {

        LinearLayout bar =
                new LinearLayout(activity);

        bar.setOrientation(
                LinearLayout.HORIZONTAL);

        bar.setGravity(
                Gravity.CENTER_VERTICAL);

        bar.setPadding(dp(activity, 8), dp(activity, 4),
                dp(activity, 8), dp(activity, 4));
        bar.setBackgroundColor(Color.TRANSPARENT);

        FrameLayout.LayoutParams barParams =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        dp(activity, 68));

        barParams.gravity =
                Gravity.TOP;

        hero.addView(
                bar,
                barParams);

        ImageView logo =
                new ImageView(activity);

        logo.setImageBitmap(TvLogoCleanup.load(activity, host.logoResource()));

        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        float navWidthDp = activity.getResources().getDisplayMetrics().widthPixels
                / activity.getResources().getDisplayMetrics().density;
        boolean compactNav = navWidthDp < 950f;

        LinearLayout.LayoutParams logoParams =
                new LinearLayout.LayoutParams(
                        dp(activity, compactNav ? 68 : 100),
                        dp(activity, 48));

        logoParams.setMargins(0, 0, dp(activity, compactNav ? 4 : 12), 0);

        bar.addView(
                logo,
                logoParams);

        addNavItem(
                activity,
                bar,
                "⌂  Home",
                true,
                host::openHome);

        addNavItem(
                activity,
                bar,
                "▣  Live TV",
                false,
                host::openLiveTv);

        addNavItem(
                activity,
                bar,
                "◉  Movies",
                false,
                host::openMovies);

        addNavItem(
                activity,
                bar,
                "▱  Series",
                false,
                host::openSeries);

        addNavItem(
                activity,
                bar,
                "⚽  Sports Guide",
                false,
                host::openSportsGuide);

        addNavItem(
                activity,
                bar,
                "⌕  Search",
                false,
                host::openSearch);

        addNavItem(
                activity,
                bar,
                "⚙  Settings",
                false,
                host::openSettings);
    }

    private static void addHeroText(
            Activity activity,
            FrameLayout hero,
            Host host,
            ImageView backdrop) {

        LinearLayout info =
                new LinearLayout(activity);

        info.setOrientation(
                LinearLayout.VERTICAL);

        info.setGravity(
                Gravity.CENTER_VERTICAL);

        info.setPadding(
                dp(activity, 42),
                dp(activity, 46),
                dp(activity, 20),
                dp(activity, 8));

        FrameLayout.LayoutParams infoParams =
                new FrameLayout.LayoutParams(
                        dp(activity, 650),
                        FrameLayout.LayoutParams.MATCH_PARENT);

        infoParams.gravity =
                Gravity.LEFT | Gravity.BOTTOM;

        hero.addView(
                info,
                infoParams);


        TextView title =
                text(
                        activity,
                        "PREMIUM PLAYER",
                        34,
                        WHITE,
                        true);

        title.setTypeface(
                Typeface.create(
                        Typeface.DEFAULT,
                        Typeface.BOLD_ITALIC));

        title.setPadding(
                0,
                dp(activity, 8),
                0,
                dp(activity, 6));

        info.addView(
                title);

        TextView description =
                text(
                        activity,
                        "Your movies, series and live television in one premium experience.",
                        15,
                        SILVER,
                        false);

        
        description.setVisibility(View.GONE);
description.setMaxLines(
                3);

        info.addView(
                description);

        host.registerHeroViews(
                backdrop,
                title,
                description);
    }

    private static void addContinueWatching(
            Activity activity,
            LinearLayout root,
            Host host) {

        LinearLayout section =
                new LinearLayout(activity);

        section.setOrientation(
                LinearLayout.VERTICAL);

        section.setPadding(
                dp(activity, 34),
                dp(activity, 8),
                dp(activity, 34),
                dp(activity, 22));

        root.addView(
                section);

        host.populateContinueWatching(
                section);

        host.populateRecentlyAddedMovies(section);
        host.populateRecentlyAddedSeries(section);

    }

    private static void addNavItem(
            Activity activity,
            LinearLayout parent,
            String label,
            boolean selected,
            Runnable action) {

        TextView item =
                text(
                        activity,
                        label,
                        15,
                        WHITE,
                        false);

        item.setGravity(Gravity.CENTER);
        float widthDp = activity.getResources().getDisplayMetrics().widthPixels
                / activity.getResources().getDisplayMetrics().density;
        boolean compact = widthDp < 950f;
        String compactLabel = label.replace("  ", "\n");
        if (label.contains("Sports Guide")) {
            compactLabel = "\u26BD\nSports\nGuide";
        }
        item.setText(compact ? compactLabel : label);
        item.setTextSize(compact ? 10f : 13f);
        item.setMaxLines(compact ? 3 : 1);
        item.setContentDescription(label);

        item.setFocusable(
                true);

        item.setClickable(
                true);

        item.setPadding(dp(activity, 2), dp(activity, 2),
                dp(activity, 2), dp(activity, 2));

        item.setBackground(
                navBackground(
                        selected));

        item.setOnClickListener(
                v -> action.run());

        item.setOnFocusChangeListener(
                (v, focused) ->
                        item.setBackground(
                                navBackground(
                                        focused
                                                || selected)));

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(0, dp(activity, 48), 1f);

        params.setMargins(dp(activity, 1), 0, dp(activity, 1), 0);

        parent.addView(
                item,
                params);
    }

    private static TextView heroButton(
            Activity activity,
            String label,
            boolean gold) {

        TextView button =
                text(
                        activity,
                        label,
                        16,
                        gold
                                ? Color.BLACK
                                : WHITE,
                        true);

        button.setGravity(
                Gravity.CENTER);

        button.setFocusable(
                true);

        button.setClickable(
                true);

        GradientDrawable bg =
                new GradientDrawable();

        bg.setCornerRadius(
                dp(activity, 9));

        bg.setColor(
                gold
                        ? GOLD
                        : Color.argb(
                                210,
                                25,
                                27,
                                31));

        bg.setStroke(
                dp(activity, 1),
                gold
                        ? GOLD
                        : Color.rgb(
                                135,
                                138,
                                145));

        button.setBackground(
                bg);

        return button;
    }

    private static LinearLayout.LayoutParams buttonParams(
            Activity activity) {

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        dp(activity, 170),
                        dp(activity, 48));

        params.setMargins(
                0,
                0,
                dp(activity, 12),
                0);

        return params;
    }

    private static GradientDrawable navBackground(
            boolean selected) {

        GradientDrawable bg =
                new GradientDrawable();

        bg.setCornerRadius(
                14);

        bg.setColor(
                selected
                        ? Color.argb(
                                150,
                                42,
                                34,
                                20)
                        : Color.TRANSPARENT);

        bg.setStroke(
                selected
                        ? 2
                        : 0,
                GOLD);

        return bg;
    }

    private static TextView text(
            Activity activity,
            String value,
            float size,
            int color,
            boolean bold) {

        TextView view =
                new TextView(activity);

        view.setText(
                value);

        view.setTextSize(
                size);

        view.setTextColor(
                color);

        if (bold) {
            view.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD);
        }

        return view;
    }

    private static int dp(
            Activity activity,
            int value) {

        return Math.round(
                value
                        * activity.getResources()
                        .getDisplayMetrics()
                        .density);
    }

    private PremiumHomeScreen() {
    }
}
