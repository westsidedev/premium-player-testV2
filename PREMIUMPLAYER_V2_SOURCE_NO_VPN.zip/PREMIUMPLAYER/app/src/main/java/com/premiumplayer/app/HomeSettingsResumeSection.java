package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class HomeSettingsResumeSection {

    interface Host {
        Button smallButton(String text);
        Drawable background(int fill, int border, int radius);
        boolean isEnabled(int slot);
        void setEnabled(int slot, boolean enabled);
        void refresh();
        void showHome();
        int dp(int value);
        int gold();
        int silver();
        int black();
        int charcoal();
    }

    static void add(Context context, Host host, LinearLayout root) {

        TextView heading = new TextView(context);
        heading.setText("CONTINUE WATCHING BOXES");
        heading.setTextColor(host.gold());
        heading.setTextSize(12);
        heading.setLetterSpacing(0.12f);
        heading.setPadding(0, host.dp(28), 0, host.dp(8));
        root.addView(heading);

        TextView help = new TextView(context);
        help.setText(
                "PREMIUM PLAYER can show the five most recently watched movies or episodes under the main Home tiles. Turn off any positions you do not want to use.");
        help.setTextColor(host.silver());
        help.setTextSize(13);
        help.setPadding(0, 0, 0, host.dp(12));
        root.addView(help);

        for (int slot = 1; slot <= 5; slot++) {
            final int slotNumber = slot;
            boolean enabled = host.isEnabled(slotNumber);

            Button toggle =
                    host.smallButton(
                            "RESUME BOX "
                                    + slotNumber
                                    + (enabled ? "   •   ON" : "   •   OFF"));

            toggle.setTextSize(13);

            toggle.setBackground(
                    host.background(
                            enabled ? Color.rgb(35, 31, 23) : host.charcoal(),
                            enabled ? host.gold() : Color.rgb(55, 55, 58),
                            12));

            toggle.setOnClickListener(v -> {
                host.setEnabled(
                        slotNumber,
                        !host.isEnabled(slotNumber));

                host.refresh();
            });

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            host.dp(50));

            params.setMargins(0, 0, 0, host.dp(8));
            root.addView(toggle, params);
        }

        Button preview = host.smallButton("VIEW HOME SCREEN");
        preview.setBackground(
                host.background(
                        host.gold(),
                        host.gold(),
                        12));
        preview.setTextColor(host.black());
        preview.setOnClickListener(v -> host.showHome());

        LinearLayout.LayoutParams previewParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        previewParams.setMargins(
                0,
                host.dp(14),
                0,
                0);

        root.addView(preview, previewParams);
    }
}
