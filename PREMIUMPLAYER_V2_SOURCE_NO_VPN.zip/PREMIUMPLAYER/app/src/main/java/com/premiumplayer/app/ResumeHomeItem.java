package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class ResumeHomeItem {
        String resumeKey = "";
        String mediaType = "";
        String mediaId = "";
        String title = "";
        String cover = "";
        String extension = "mp4";
        String directSource = "";
        String seriesId = "";
        String seriesName = "";
        String episodeTitle = "";
        int seasonNumber = 0;
        int episodeNumber = 0;
        long position = 0L;
        long duration = 0L;
        long lastWatched = 0L;
    }
