package com.premiumplayer.app;

import android.content.Context;
import android.net.Uri;

import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;

final class PlaybackEngineFactory {

    static final class Result {
        final SimpleExoPlayer player;
        final DefaultTrackSelector trackSelector;
        final MediaSource mediaSource;

        Result(
                SimpleExoPlayer player,
                DefaultTrackSelector trackSelector,
                MediaSource mediaSource) {

            this.player = player;
            this.trackSelector = trackSelector;
            this.mediaSource = mediaSource;
        }
    }

    static Result create(
            Context context,
            String url,
            boolean hls,
            String preferredLanguage) {

        DefaultTrackSelector trackSelector =
                new DefaultTrackSelector(context);

        DefaultTrackSelector.ParametersBuilder parameters =
                trackSelector.buildUponParameters();

        if (preferredLanguage == null
                || preferredLanguage.isEmpty()) {

            parameters.setPreferredAudioLanguage(null);

        } else {

            parameters.setPreferredAudioLanguage(
                    preferredLanguage);
        }

        trackSelector.setParameters(parameters);

        DefaultHttpDataSourceFactory httpFactory =
                new DefaultHttpDataSourceFactory(
                        "VLC/3.0.21 LibVLC/3.0.21",
                        15000,
                        30000,
                        true);

        DefaultDataSourceFactory dataSourceFactory =
                new DefaultDataSourceFactory(
                        context,
                        httpFactory);

        DefaultRenderersFactory renderersFactory =
                new DefaultRenderersFactory(context)
                        .setEnableDecoderFallback(true);

        SimpleExoPlayer player =
                new SimpleExoPlayer.Builder(
                        context,
                        renderersFactory)
                        .setTrackSelector(
                                trackSelector)
                        .build();

        MediaItem mediaItem =
                new MediaItem.Builder()
                        .setUri(
                                Uri.parse(url))
                        .build();

        MediaSource mediaSource;

        if (hls) {

            mediaSource =
                    new HlsMediaSource.Factory(
                            dataSourceFactory)
                            .createMediaSource(
                                    mediaItem);

        } else {

            mediaSource =
                    new ProgressiveMediaSource.Factory(
                            dataSourceFactory)
                            .createMediaSource(
                                    mediaItem);
        }

        return new Result(
                player,
                trackSelector,
                mediaSource);
    }
}
