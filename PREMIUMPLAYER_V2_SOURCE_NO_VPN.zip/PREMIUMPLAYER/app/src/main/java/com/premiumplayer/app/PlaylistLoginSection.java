package com.premiumplayer.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

final class PlaylistLoginSection {

    interface Host {
        SharedPreferences prefs();
        void prepare(EditText view, int inputType, int imeAction);
        void hideKeyboard(EditText view);
        Drawable background(int fill, int border, int radius);
        void tvReady(View view);
        void focus(View view);
        void importXtream(String server, String username, String password);
        void showQr();
        void importUrl(String url);
        void chooseLocal();
        int dp(int value);
        int gold();
        int black();
        int charcoal();
    }

    static void add(Context context, Host host, LinearLayout root) {
        TextView xtreamTitle = new TextView(context);
        xtreamTitle.setText("XTREAM LOGIN");
        xtreamTitle.setTextColor(host.gold());
        xtreamTitle.setTextSize(12);
        xtreamTitle.setLetterSpacing(0.12f);
        root.addView(xtreamTitle);

        EditText serverInput = new EditText(context);
        serverInput.setHint("Server URL or full get.php/player_api.php link");
        serverInput.setHintTextColor(Color.rgb(120, 120, 125));
        serverInput.setTextColor(Color.WHITE);
        serverInput.setTextSize(14);
        serverInput.setSingleLine(true);
        host.prepare(
                serverInput,
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_URI,
                EditorInfo.IME_ACTION_NEXT);
        serverInput.setPadding(host.dp(16), host.dp(12), host.dp(16), host.dp(12));
        serverInput.setBackground(
                host.background(
                        host.charcoal(),
                        Color.rgb(55, 55, 58),
                        14));

        String savedXtreamServer =
                host.prefs()
                        .getString("xtream_server", "");

        serverInput.setText(savedXtreamServer);

        LinearLayout.LayoutParams xtreamFieldParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        xtreamFieldParams.setMargins(0, host.dp(10), 0, host.dp(8));
        root.addView(serverInput, xtreamFieldParams);

        EditText usernameInput = new EditText(context);
        usernameInput.setHint("Username");
        usernameInput.setHintTextColor(Color.rgb(120, 120, 125));
        usernameInput.setTextColor(Color.WHITE);
        usernameInput.setTextSize(14);
        usernameInput.setSingleLine(true);
        host.prepare(
                usernameInput,
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
                EditorInfo.IME_ACTION_NEXT);
        usernameInput.setPadding(host.dp(16), host.dp(12), host.dp(16), host.dp(12));
        usernameInput.setBackground(
                host.background(
                        host.charcoal(),
                        Color.rgb(55, 55, 58),
                        14));

        String savedXtreamUsername =
                host.prefs()
                        .getString("xtream_username", "");

        usernameInput.setText(savedXtreamUsername);
        root.addView(usernameInput, xtreamFieldParams);

        EditText passwordInput = new EditText(context);
        passwordInput.setHint("Password");
        passwordInput.setHintTextColor(Color.rgb(120, 120, 125));
        passwordInput.setTextColor(Color.WHITE);
        passwordInput.setTextSize(14);
        passwordInput.setSingleLine(true);
        host.prepare(
                passwordInput,
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_PASSWORD,
                EditorInfo.IME_ACTION_DONE);
        passwordInput.setPadding(host.dp(16), host.dp(12), host.dp(16), host.dp(12));
        passwordInput.setBackground(
                host.background(
                        host.charcoal(),
                        Color.rgb(55, 55, 58),
                        14));

        String savedXtreamPassword =
                host.prefs()
                        .getString("xtream_password", "");

        passwordInput.setText(savedXtreamPassword);
        root.addView(passwordInput, xtreamFieldParams);

        Button xtreamLogin = new Button(context);
        xtreamLogin.setText("LOGIN WITH XTREAM");
        xtreamLogin.setTextColor(host.black());
        xtreamLogin.setTextSize(13);
        xtreamLogin.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        xtreamLogin.setAllCaps(false);
        xtreamLogin.setBackground(host.background(host.gold(), host.gold(), 14));

        host.tvReady(
                xtreamLogin);

        host.focus(
                xtreamLogin);

        xtreamLogin.setOnClickListener(v -> {
            String server = serverInput.getText().toString().trim();
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString();

            if (server.isEmpty()
                    || username.isEmpty()
                    || password.isEmpty()) {

                Toast.makeText(
                        context,
                        "Enter server URL, username and password.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            host.importXtream(
                    server,
                    username,
                    password);
        });

        passwordInput.setOnEditorActionListener(
                (v, actionId, event) -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        host.hideKeyboard(passwordInput);
                        xtreamLogin.performClick();
                        return true;
                    }
                    return false;
                });

        LinearLayout.LayoutParams xtreamButtonParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(50));

        xtreamButtonParams.setMargins(0, host.dp(2), 0, host.dp(10));
        root.addView(xtreamLogin, xtreamButtonParams);

        Button qrLogin = new Button(context);
        qrLogin.setText("LOGIN WITH PHONE / QR");
        qrLogin.setTextColor(Color.WHITE);
        qrLogin.setTextSize(13);
        qrLogin.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        qrLogin.setAllCaps(false);
        qrLogin.setBackground(
                host.background(
                        host.charcoal(),
                        host.gold(),
                        14));

        host.tvReady(qrLogin);
        host.focus(qrLogin);
        qrLogin.setOnClickListener(v -> host.showQr());

        LinearLayout.LayoutParams qrButtonParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(50));

        qrButtonParams.setMargins(0, 0, 0, host.dp(30));
        root.addView(qrLogin, qrButtonParams);

        TextView urlTitle = new TextView(context);
        urlTitle.setText("M3U URL");
        urlTitle.setTextColor(host.gold());
        urlTitle.setTextSize(12);
        urlTitle.setLetterSpacing(0.12f);
        root.addView(urlTitle);

        EditText urlInput = new EditText(context);
        urlInput.setHint("https://example.com/playlist.m3u");
        urlInput.setHintTextColor(Color.rgb(120, 120, 125));
        urlInput.setTextColor(Color.WHITE);
        urlInput.setTextSize(14);
        urlInput.setSingleLine(true);
        host.prepare(
                urlInput,
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_URI,
                EditorInfo.IME_ACTION_DONE);
        urlInput.setPadding(host.dp(16), host.dp(12), host.dp(16), host.dp(12));
        urlInput.setBackground(
                host.background(
                        host.charcoal(),
                        Color.rgb(55, 55, 58),
                        14));

        LinearLayout.LayoutParams inputParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        inputParams.setMargins(0, host.dp(10), 0, host.dp(10));
        root.addView(urlInput, inputParams);

        Button addUrl = new Button(context);
        addUrl.setText("ADD URL PLAYLIST");
        addUrl.setTextColor(host.black());
        addUrl.setTextSize(13);
        addUrl.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        addUrl.setAllCaps(false);
        addUrl.setBackground(host.background(host.gold(), host.gold(), 14));

        host.tvReady(
                addUrl);

        host.focus(
                addUrl);

        addUrl.setOnClickListener(v -> {
            String url = urlInput.getText().toString().trim();

            if (url.isEmpty()) {
                Toast.makeText(
                        context,
                        "Enter an M3U URL first.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            host.importUrl(url);
        });

        LinearLayout.LayoutParams urlButtonParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(50));

        urlButtonParams.setMargins(0, 0, 0, host.dp(28));
        root.addView(addUrl, urlButtonParams);

        TextView localTitle = new TextView(context);
        localTitle.setText("LOCAL FILE");
        localTitle.setTextColor(host.gold());
        localTitle.setTextSize(12);
        localTitle.setLetterSpacing(0.12f);
        root.addView(localTitle);

        Button localButton = new Button(context);
        localButton.setText("IMPORT LOCAL M3U / M3U8");
        localButton.setTextColor(Color.WHITE);
        localButton.setTextSize(13);
        localButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        localButton.setAllCaps(false);
        localButton.setBackground(
                host.background(
                        host.charcoal(),
                        Color.rgb(65, 65, 70),
                        14));

        host.tvReady(
                localButton);

        host.focus(
                localButton);

        localButton.setOnClickListener(v -> host.chooseLocal());

        LinearLayout.LayoutParams localParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(50));

        localParams.setMargins(0, host.dp(10), 0, 0);
        root.addView(localButton, localParams);

    }
}
