package com.premiumplayer.app;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueSchemaRepair {

    private static void ensureColumn(
            SQLiteDatabase db,
            String table,
            String column,
            String definition) {

        boolean found = false;

        Cursor cursor = db.rawQuery(
                "PRAGMA table_info(" + table + ")", null);

        try {
            while (cursor.moveToNext()) {
                if (column.equalsIgnoreCase(
                        cursor.getString(1))) {
                    found = true;
                    break;
                }
            }
        } finally {
            cursor.close();
        }

        if (!found) {
            db.execSQL("ALTER TABLE " + table
                    + " ADD COLUMN " + column
                    + " " + definition);
        }
    }

    static void ensure(SQLiteDatabase db) {
        ensureColumn(db, "catalogue_movies",
                "import_generation", "INTEGER DEFAULT 0");
        ensureColumn(db, "catalogue_series",
                "import_generation", "INTEGER DEFAULT 0");

        ensureColumn(db, "catalogue_movies",
                "added_at", "INTEGER DEFAULT 0");

        ensureColumn(db, "catalogue_movies",
                "audio_language", "TEXT");

        ensureColumn(db, "catalogue_movies",
                "raw_json", "TEXT");

        ensureColumn(db, "catalogue_series",
                "added_at", "INTEGER DEFAULT 0");

        ensureColumn(db, "catalogue_series", "raw_json", "TEXT");
        ensureColumn(db, "catalogue_series",
                "updated_at", "INTEGER DEFAULT 0");

        db.execSQL(
                "CREATE INDEX IF NOT EXISTS idx_recent_movies "
                + "ON catalogue_movies"
                + "(provider_key, audio_language, added_at DESC)");

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_movies_provider_added "
                + "ON catalogue_movies(provider_key, added_at DESC)");

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_recent_series "
                + "ON catalogue_series"
                + "(provider_key, added_at DESC)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_updated_series "
                + "ON catalogue_series(provider_key, updated_at DESC)");
    }
}
