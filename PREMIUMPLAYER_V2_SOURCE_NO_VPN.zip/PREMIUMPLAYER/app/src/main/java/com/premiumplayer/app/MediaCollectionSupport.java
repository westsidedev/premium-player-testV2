package com.premiumplayer.app;

import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

final class MediaCollectionSupport {

    interface Host {
        String safe(String value);

        String sanitizeExtension(
                String extension);
    }

    static ArrayList<MovieItem> recentMovies(
            ArrayList<ResumeHomeItem> recent,
            Host host) {

        ArrayList<MovieItem> movies =
                new ArrayList<MovieItem>();

        if (recent == null) {
            return movies;
        }

        for (ResumeHomeItem item : recent) {

            if ("MOVIE".equals(item.mediaType) == false) {
                continue;
            }

            MovieItem movie =
                    new MovieItem();

            movie.streamId = item.mediaId;
            movie.name = item.title;
            movie.icon = item.cover;

            movie.extension =
                    host.sanitizeExtension(
                            item.extension);

            movie.directSource =
                    item.directSource;

            movies.add(movie);
        }

        return movies;
    }

    static ArrayList<SeriesItem> recentSeries(
            ArrayList<ResumeHomeItem> recent,
            Host host) {

        LinkedHashMap<String, SeriesItem> unique =
                new LinkedHashMap<String, SeriesItem>();

        if (recent == null) {
            return new ArrayList<SeriesItem>();
        }

        for (ResumeHomeItem item : recent) {

            if ("EPISODE".equals(item.mediaType) == false
                    || host.safe(item.seriesId).isEmpty()) {

                continue;
            }

            if (unique.containsKey(item.seriesId)) {
                continue;
            }

            SeriesItem series =
                    new SeriesItem();

            series.seriesId =
                    item.seriesId;

            series.name =
                    item.seriesName.isEmpty()
                            ? item.title
                            : item.seriesName;

            series.cover =
                    item.cover;

            unique.put(
                    item.seriesId,
                    series);
        }

        return new ArrayList<SeriesItem>(
                unique.values());
    }

    static boolean isMovieFavourite(
            SharedPreferences prefs,
            String id,
            Host host) {

        return prefs.contains(
                "movie_" + host.safe(id));
    }

    static boolean isSeriesFavourite(
            SharedPreferences prefs,
            String id,
            Host host) {

        return prefs.contains(
                "series_" + host.safe(id));
    }

    static void toggleMovieFavourite(
            SharedPreferences prefs,
            MovieItem movie,
            Host host) {

        String key =
                "movie_"
                        + host.safe(
                                movie.streamId);

        SharedPreferences.Editor editor =
                prefs.edit();

        if (prefs.contains(key)) {
            editor.remove(key);

        } else {

            JSONObject object =
                    new JSONObject();

            try {
                object.put(
                        "id",
                        movie.streamId);

                object.put(
                        "name",
                        movie.name);

                object.put(
                        "cover",
                        movie.icon);

                object.put(
                        "extension",
                        movie.extension);

                object.put(
                        "direct",
                        movie.directSource);

                object.put(
                        "year",
                        movie.year);

                object.put(
                        "rating",
                        movie.rating);

            } catch (Exception ignored) {
            }

            editor.putString(
                    key,
                    object.toString());
        }

        editor.apply();
    }

    static void toggleSeriesFavourite(
            SharedPreferences prefs,
            SeriesItem series,
            Host host) {

        String key =
                "series_"
                        + host.safe(
                                series.seriesId);

        SharedPreferences.Editor editor =
                prefs.edit();

        if (prefs.contains(key)) {
            editor.remove(key);

        } else {

            JSONObject object =
                    new JSONObject();

            try {
                object.put("id", series.seriesId);
                object.put("name", series.name);
                object.put("cover", series.cover);
                object.put("year", series.year);
                object.put("rating", series.rating);

            } catch (Exception ignored) {
            }

            editor.putString(
                    key,
                    object.toString());
        }

        editor.apply();
    }

    static ArrayList<MovieItem> favouriteMovies(
            Map<String, ?> all) {

        ArrayList<MovieItem> movies =
                new ArrayList<MovieItem>();

        if (all == null) {
            return movies;
        }

        for (Map.Entry<String, ?> entry
                : all.entrySet()) {

            if (entry.getKey()
                    .startsWith("movie_") == false
                    || (entry.getValue()
                    instanceof String) == false) {

                continue;
            }

            try {
                JSONObject object =
                        new JSONObject(
                                (String) entry.getValue());

                MovieItem movie =
                        new MovieItem();

                movie.streamId =
                        object.optString("id", "");

                movie.name =
                        object.optString("name", "");

                movie.icon =
                        object.optString("cover", "");

                movie.extension =
                        object.optString(
                                "extension",
                                "mp4");

                movie.directSource =
                        object.optString("direct", "");

                movie.year =
                        object.optString("year", "");

                movie.rating =
                        object.optString("rating", "");

                if (movie.streamId.isEmpty() == false) {
                    movies.add(movie);
                }

            } catch (Exception ignored) {
            }
        }

        return movies;
    }

    static ArrayList<SeriesItem> favouriteSeries(
            Map<String, ?> all) {

        ArrayList<SeriesItem> seriesList =
                new ArrayList<SeriesItem>();

        if (all == null) {
            return seriesList;
        }

        for (Map.Entry<String, ?> entry
                : all.entrySet()) {

            if (entry.getKey()
                    .startsWith("series_") == false
                    || (entry.getValue()
                    instanceof String) == false) {

                continue;
            }

            try {
                JSONObject object =
                        new JSONObject(
                                (String) entry.getValue());

                SeriesItem series =
                        new SeriesItem();

                series.seriesId =
                        object.optString("id", "");

                series.name =
                        object.optString("name", "");

                series.cover =
                        object.optString("cover", "");

                series.year =
                        object.optString("year", "");

                series.rating =
                        object.optString("rating", "");

                if (series.seriesId.isEmpty() == false) {
                    seriesList.add(series);
                }

            } catch (Exception ignored) {
            }
        }

        return seriesList;
    }
}
