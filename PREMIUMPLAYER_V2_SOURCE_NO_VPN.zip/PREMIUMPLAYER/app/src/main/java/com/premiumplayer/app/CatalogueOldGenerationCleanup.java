package com.premiumplayer.app;

import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueOldGenerationCleanup {

    private static long count(
            SQLiteDatabase db, String sql, String[] args) {
        return DatabaseUtils.longForQuery(db, sql, args);
    }

    static String execute(SQLiteDatabase db, String providerKey) {
        if (db == null || providerKey == null || providerKey.isEmpty()) {
            throw new IllegalArgumentException("Invalid cleanup context");
        }

        db.beginTransaction();
        try {
            long generation;
            long expectedMovies;
            long expectedSeries;
            String state;

            Cursor cursor = db.rawQuery(
                    "SELECT generation,state,movies_done,series_done "
                    + "FROM catalogue_rebuild_journal "
                    + "WHERE provider_key=?",
                    new String[]{providerKey});
            try {
                if (!cursor.moveToFirst()) {
                    throw new IllegalStateException("Missing rebuild journal");
                }
                generation = cursor.getLong(0);
                state = cursor.getString(1);
                expectedMovies = cursor.getLong(2);
                expectedSeries = cursor.getLong(3);
            } finally {
                cursor.close();
            }

            if (!"VALIDATED".equals(state) || generation <= 0) {
                throw new IllegalStateException("Rebuild not validated");
            }

            String[] current = {
                    providerKey, Long.toString(generation)
            };
            String[] provider = {providerKey};

            long movies = count(db,
                    "SELECT COUNT(*) FROM catalogue_movies "
                    + "WHERE provider_key=? AND import_generation=?",
                    current);

            long series = count(db,
                    "SELECT COUNT(*) FROM catalogue_series "
                    + "WHERE provider_key=? AND import_generation=?",
                    current);

            if (movies == 0 || series == 0
                    || movies != expectedMovies
                    || series != expectedSeries) {
                throw new IllegalStateException(
                        "Current catalogue counts do not match journal");
            }

            long missing = count(db,
                    "SELECT COUNT(*) FROM catalogue_movies "
                    + "WHERE provider_key=? AND import_generation=? "
                    + "AND (raw_json IS NULL OR LENGTH(raw_json)=0)",
                    current);

            missing += count(db,
                    "SELECT COUNT(*) FROM catalogue_series "
                    + "WHERE provider_key=? AND import_generation=? "
                    + "AND (raw_json IS NULL OR LENGTH(raw_json)=0)",
                    current);

            if (missing != 0) {
                throw new IllegalStateException("Current metadata incomplete");
            }

            long totalMovies = count(db,
                    "SELECT COUNT(*) FROM catalogue_movies WHERE provider_key=?",
                    provider);
            long totalSeries = count(db,
                    "SELECT COUNT(*) FROM catalogue_series WHERE provider_key=?",
                    provider);

            long oldMovies = totalMovies - movies;
            long oldSeries = totalSeries - series;

            // Strict limit: expected obsolete rows are only 3 and 5.
            if (oldMovies < 0 || oldSeries < 0
                    || oldMovies > 100 || oldSeries > 100) {
                throw new IllegalStateException(
                        "Unexpected obsolete counts: movies="
                        + oldMovies + ", series=" + oldSeries);
            }

            String condition =
                    "provider_key=? AND (import_generation IS NULL "
                    + "OR import_generation<>CAST(? AS INTEGER))";

            int deletedMovies = db.delete(
                    "catalogue_movies", condition, current);
            int deletedSeries = db.delete(
                    "catalogue_series", condition, current);

            if (deletedMovies != oldMovies
                    || deletedSeries != oldSeries) {
                throw new IllegalStateException(
                        "Deletion count mismatch; rolling back");
            }

            long remainingMovies = count(db,
                    "SELECT COUNT(*) FROM catalogue_movies WHERE provider_key=?",
                    provider);
            long remainingSeries = count(db,
                    "SELECT COUNT(*) FROM catalogue_series WHERE provider_key=?",
                    provider);

            if (remainingMovies != movies || remainingSeries != series) {
                throw new IllegalStateException(
                        "Final counts incorrect; rolling back");
            }

            db.setTransactionSuccessful();

            return "Old movies removed: " + deletedMovies
                    + "\nOld series removed: " + deletedSeries
                    + "\n\nMovies retained: " + remainingMovies
                    + "\nSeries retained: " + remainingSeries
                    + "\n\nValidated catalogue preserved.";
        } finally {
            db.endTransaction();
        }
    }
}
