package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class HomeSettingsTilesStartupSection {

    interface Host {
        Button smallButton(String text);
        void showEditHome();
        String startupDestination();
        String startupLabel(String destination);
        void addStartupButton(
                LinearLayout root,
                String label,
                String destination);
        int dp(int value);
        int gold();
        int silver();
    }

    static void add(Context context, Host host, LinearLayout root) {

        TextView tileHeading = new TextView(context);
        tileHeading.setText("HOME TILES");
        tileHeading.setTextColor(host.gold());
        tileHeading.setTextSize(12);
        tileHeading.setLetterSpacing(0.12f);
        tileHeading.setPadding(0, host.dp(28), 0, host.dp(8));
        root.addView(tileHeading);

        TextView tileHelp = new TextView(context);
        tileHelp.setText(
                "Choose the order of your five main Home tiles and hide the sections you do not use. Settings always remains available.");
        tileHelp.setTextColor(host.silver());
        tileHelp.setTextSize(13);
        tileHelp.setPadding(0, 0, 0, host.dp(12));
        root.addView(tileHelp);

        Button customiseHome =
                host.smallButton("CUSTOMISE HOME TILES");

        customiseHome.setTextSize(13);
        customiseHome.setOnClickListener(v -> host.showEditHome());

        LinearLayout.LayoutParams customiseParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        customiseParams.setMargins(0, 0, 0, host.dp(10));
        root.addView(customiseHome, customiseParams);

        TextView startupHeading = new TextView(context);
        startupHeading.setText("STARTUP SCREEN");
        startupHeading.setTextColor(host.gold());
        startupHeading.setTextSize(12);
        startupHeading.setLetterSpacing(0.12f);
        startupHeading.setPadding(0, host.dp(20), 0, host.dp(8));
        root.addView(startupHeading);

        TextView startupHelp = new TextView(context);
        startupHelp.setText(
                "Choose what this playlist opens to when PREMIUM PLAYER starts.");
        startupHelp.setTextColor(host.silver());
        startupHelp.setTextSize(13);
        startupHelp.setPadding(0, 0, 0, host.dp(8));
        root.addView(startupHelp);

        TextView startupCurrent = new TextView(context);
        startupCurrent.setText(
                "Current: "
                        + host.startupLabel(
                                host.startupDestination()));
        startupCurrent.setTextColor(Color.WHITE);
        startupCurrent.setTextSize(15);
        startupCurrent.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);
        startupCurrent.setPadding(0, 0, 0, host.dp(10));
        root.addView(startupCurrent);

        host.addStartupButton(root, "HOME", "HOME");
        host.addStartupButton(
                root,
                "LAST LIVE CHANNEL",
                "LAST LIVE CHANNEL");
        host.addStartupButton(root, "LIVE TV", "LIVE TV");
        host.addStartupButton(
                root,
                "SPORTS GUIDE",
                "SPORTS GUIDE");
        host.addStartupButton(root, "MOVIES", "MOVIES");
        host.addStartupButton(root, "SERIES", "SERIES");
    }
}
