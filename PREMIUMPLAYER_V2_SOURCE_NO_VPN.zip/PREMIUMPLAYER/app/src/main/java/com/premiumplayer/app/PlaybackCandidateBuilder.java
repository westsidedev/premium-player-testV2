package com.premiumplayer.app;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

final class PlaybackCandidateBuilder {

    static void build(
            ArrayList<String> out,
            String directSource,
            String mediaType,
            boolean xtreamSource,
            String streamId,
            String selectedStreamUrl,
            String apiServer,
            String streamServer,
            String username,
            String password,
            String allowedFormats) {

        out.clear();

        add(out, directSource);

        if ("LIVE".equals(mediaType)
                && xtreamSource
                && streamId != null
                && !streamId.isEmpty()) {

            try {
                addXtreamCandidates(
                        out,
                        streamId,
                        apiServer,
                        streamServer,
                        username,
                        password,
                        allowedFormats);
            } catch (Exception ignored) {
            }
        }

        add(out, selectedStreamUrl);
    }

    private static void addXtreamCandidates(
            ArrayList<String> out,
            String streamId,
            String apiServer,
            String streamServer,
            String username,
            String password,
            String allowedFormats)
            throws Exception {

        boolean prefersM3u8 =
                allowedFormats != null
                        && allowedFormats
                        .toLowerCase(Locale.US)
                        .contains("m3u8");

        if (prefersM3u8) {
            add(out, liveUrl(
                    streamServer,
                    username,
                    password,
                    streamId,
                    "m3u8"));
        }

        add(out, liveUrl(
                streamServer,
                username,
                password,
                streamId,
                "ts"));

        if (!prefersM3u8) {
            add(out, liveUrl(
                    streamServer,
                    username,
                    password,
                    streamId,
                    "m3u8"));
        }

        if (!apiServer.equals(streamServer)) {

            if (prefersM3u8) {
                add(out, liveUrl(
                        apiServer,
                        username,
                        password,
                        streamId,
                        "m3u8"));
            }

            add(out, liveUrl(
                    apiServer,
                    username,
                    password,
                    streamId,
                    "ts"));

            if (!prefersM3u8) {
                add(out, liveUrl(
                        apiServer,
                        username,
                        password,
                        streamId,
                        "m3u8"));
            }
        }

        String userPath =
                encode(username);

        String passPath =
                encode(password);

        add(
                out,
                streamServer
                        + "/"
                        + userPath
                        + "/"
                        + passPath
                        + "/"
                        + streamId);
    }

    private static String liveUrl(
            String server,
            String username,
            String password,
            String streamId,
            String extension)
            throws Exception {

        return server
                + "/live/"
                + encode(username)
                + "/"
                + encode(password)
                + "/"
                + streamId
                + "."
                + extension;
    }

    private static String encode(
            String value)
            throws Exception {

        return URLEncoder.encode(
                value == null ? "" : value,
                "UTF-8")
                .replace("+", "%20");
    }

    static void add(
            ArrayList<String> out,
            String candidate) {

        if (candidate == null) {
            return;
        }

        String value =
                candidate.trim();

        if (value.isEmpty()) {
            return;
        }

        if (!out.contains(value)) {
            out.add(value);
        }
    }
}
