package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class Channel {

        String name = "";
        String url = "";
        String tvgId = "";
        String tvgName = "";
        String logo = "";
        String group = "OTHER";
        String streamId = "";
        String directSource = "";
        String now = "";
        String next = "";

        Channel() {
        }

        Channel(
                String name,
                String url,
                String tvgId,
                String tvgName,
                String group,
                String now,
                String next) {

            this.name = name;
            this.url = url;
            this.tvgId = tvgId;
            this.tvgName = tvgName;
            this.group = group;
            this.now = now;
            this.next = next;
        }

        String key() {
            if (url != null
                    && !url.trim().isEmpty()) {
                return url;
            }

            return name == null
                    ? ""
                    : name;
        }
    }
