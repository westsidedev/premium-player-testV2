package com.premiumplayer.app;

import android.content.Context;
import android.net.Uri;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Embedded WireGuard controller for PREMIUM PLAYER.
 *
 * The official WireGuard Android tunnel library provides the VpnService and
 * wireguard-go engine. This class deliberately routes only this application
 * through the tunnel by injecting IncludedApplications into the configuration.
 */
public final class EmbeddedWireGuardManager {

    public interface Callback {
        void onComplete(boolean success, String message);
    }

    private static final String ASSET_CONFIG = "proton_wireguard.conf";
    private static final String PRIVATE_CONFIG = "proton_wireguard.conf";
    private static final String PLACEHOLDER_MARKER = "REPLACE_WITH_YOUR_PROTON_WIREGUARD_CONFIG";

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final PremiumTunnel tunnel = new PremiumTunnel();

    private volatile GoBackend backend;
    private volatile boolean connecting;
    private volatile boolean disconnecting;
    private volatile Tunnel.State state = Tunnel.State.DOWN;
    private volatile String lastError = "";

    public EmbeddedWireGuardManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean isConfigured() {
        try {
            String text = readEffectiveConfigText();
            return text != null
                    && text.contains("[Interface]")
                    && text.contains("[Peer]")
                    && !text.contains(PLACEHOLDER_MARKER);
        } catch (Exception ignored) {
            return false;
        }
    }

    public boolean isConnected() {
        try {
            GoBackend currentBackend = backend;
            if (currentBackend != null) {
                state = currentBackend.getState(tunnel);
            }
        } catch (Exception ignored) {
        }
        return state == Tunnel.State.UP;
    }

    public boolean isBusy() {
        return connecting || disconnecting;
    }

    public String getLastError() {
        return lastError == null ? "" : lastError;
    }

    public void connectAsync(Callback callback) {
        if (connecting) {
            complete(callback, false, "VPN connection is already in progress.");
            return;
        }

        if (isConnected()) {
            complete(callback, true, "VPN already connected.");
            return;
        }

        connecting = true;
        executor.execute(() -> {
            try {
                String original = readEffectiveConfigText();
                if (original == null || original.trim().isEmpty()) {
                    throw new IllegalStateException("No Proton WireGuard configuration is installed.");
                }
                if (original.contains(PLACEHOLDER_MARKER)) {
                    throw new IllegalStateException("Replace proton_wireguard.conf with your Proton WireGuard configuration first.");
                }

                String splitTunnelConfig = injectIncludedApplication(original, context.getPackageName());
                Config config = Config.parse(new ByteArrayInputStream(
                        splitTunnelConfig.getBytes(StandardCharsets.UTF_8)));

                GoBackend currentBackend = backend;
                if (currentBackend == null) {
                    currentBackend = new GoBackend(context);
                    backend = currentBackend;
                }

                Tunnel.State newState = currentBackend.setState(tunnel, Tunnel.State.UP, config);
                state = newState;
                lastError = "";
                complete(callback, newState == Tunnel.State.UP,
                        newState == Tunnel.State.UP ? "WireGuard connected." : "WireGuard did not reach the connected state.");

            } catch (Throwable error) {
                state = Tunnel.State.DOWN;
                lastError = safeMessage(error);
                complete(callback, false, lastError);
            } finally {
                connecting = false;
            }
        });
    }

    public void disconnectAsync(Callback callback) {
        if (disconnecting) {
            complete(callback, false, "VPN disconnection is already in progress.");
            return;
        }

        disconnecting = true;
        executor.execute(() -> {
            try {
                GoBackend currentBackend = backend;
                if (currentBackend != null) {
                    currentBackend.setState(tunnel, Tunnel.State.DOWN, null);
                }
                state = Tunnel.State.DOWN;
                lastError = "";
                complete(callback, true, "WireGuard disconnected.");
            } catch (Throwable error) {
                lastError = safeMessage(error);
                complete(callback, false, lastError);
            } finally {
                disconnecting = false;
            }
        });
    }

    public boolean installPrivateConfig(Uri uri) {
        if (uri == null) {
            return false;
        }

        InputStream input = null;
        FileOutputStream output = null;
        try {
            input = context.getContentResolver().openInputStream(uri);
            if (input == null) {
                return false;
            }

            ByteArrayOutputStream memory = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) > 0) {
                memory.write(buffer, 0, count);
            }

            String text = new String(memory.toByteArray(), StandardCharsets.UTF_8);
            if (!text.contains("[Interface]") || !text.contains("[Peer]")) {
                return false;
            }

            File file = new File(context.getFilesDir(), PRIVATE_CONFIG);
            output = new FileOutputStream(file, false);
            output.write(text.getBytes(StandardCharsets.UTF_8));
            output.flush();
            return true;
        } catch (Exception ignored) {
            return false;
        } finally {
            try {
                if (input != null) input.close();
            } catch (Exception ignored) {
            }
            try {
                if (output != null) output.close();
            } catch (Exception ignored) {
            }
        }
    }

    public boolean hasPrivateConfig() {
        File file = new File(context.getFilesDir(), PRIVATE_CONFIG);
        return file.isFile() && file.length() > 0;
    }

    public void removePrivateConfig() {
        try {
            File file = new File(context.getFilesDir(), PRIVATE_CONFIG);
            if (file.exists()) {
                //noinspection ResultOfMethodCallIgnored
                file.delete();
            }
        } catch (Exception ignored) {
        }
    }

    private String readEffectiveConfigText() throws Exception {
        File privateFile = new File(context.getFilesDir(), PRIVATE_CONFIG);
        InputStream input;
        if (privateFile.isFile() && privateFile.length() > 0) {
            input = new FileInputStream(privateFile);
        } else {
            input = context.getAssets().open(ASSET_CONFIG);
        }

        try {
            ByteArrayOutputStream memory = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) > 0) {
                memory.write(buffer, 0, count);
            }
            return new String(memory.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            try {
                input.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static String injectIncludedApplication(String config, String packageName) {
        String[] lines = config.split("\\r?\\n", -1);
        StringBuilder output = new StringBuilder(config.length() + 96);
        boolean injected = false;

        for (String line : lines) {
            String trimmed = line.trim();
            String lower = trimmed.toLowerCase(Locale.ENGLISH);

            // We own split tunnelling. Remove any app-list directives from the
            // downloaded config so an old/custom profile cannot override it.
            if (lower.startsWith("includedapplications")
                    || lower.startsWith("excludedapplications")) {
                continue;
            }

            output.append(line).append('\n');
            if (!injected && "[interface]".equals(lower)) {
                output.append("IncludedApplications = ")
                        .append(packageName)
                        .append('\n');
                injected = true;
            }
        }

        if (!injected) {
            throw new IllegalArgumentException("WireGuard config has no [Interface] section.");
        }

        return output.toString();
    }

    private static void complete(Callback callback, boolean success, String message) {
        if (callback != null) {
            callback.onComplete(success, message == null ? "" : message);
        }
    }

    private static String safeMessage(Throwable error) {
        if (error == null) {
            return "Unknown WireGuard error";
        }
        String message = error.getMessage();
        if (message == null || message.trim().isEmpty()) {
            message = error.getClass().getSimpleName();
        }
        return message;
    }

    private final class PremiumTunnel implements Tunnel {
        @Override
        public String getName() {
            return "premiumvpn";
        }

        @Override
        public void onStateChange(State newState) {
            state = newState == null ? State.DOWN : newState;
        }
    }
}
