package com.premiumplayer.app;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.exoplayer2.ui.PlayerView;

final class PlayerFullscreenLayout {

    static void apply(
            Activity activity,
            LinearLayout screen,
            PlayerView playerView) {

        if (screen == null || playerView == null) {
            return;
        }

        for (int i = 0; i < screen.getChildCount(); i++) {
            View child = screen.getChildAt(i);

            if (child != playerView) {
                child.setVisibility(View.GONE);
            }
        }

        screen.setPadding(0, 0, 0, 0);

        playerView.setLayoutParams(
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT));

        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);

        hideSystemBars(activity);
        playerView.requestLayout();
    }

    static void restore(
            Activity activity,
            LinearLayout screen,
            PlayerView playerView,
            int left,
            int top,
            int right,
            int bottom,
            int playerHeight,
            int barColor) {

        if (screen == null || playerView == null) {
            showSystemBars(activity, barColor);
            return;
        }

        for (int i = 0; i < screen.getChildCount(); i++) {
            screen.getChildAt(i)
                    .setVisibility(View.VISIBLE);
        }

        screen.setPadding(
                left,
                top,
                right,
                bottom);

        playerView.setLayoutParams(
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        playerHeight));

        playerView.requestLayout();

        showSystemBars(
                activity,
                barColor);
    }

    static void hideSystemBars(
            Activity activity) {

        activity.getWindow()
                .getDecorView()
                .setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    static void showSystemBars(
            Activity activity,
            int barColor) {

        activity.getWindow()
                .getDecorView()
                .setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        activity.getWindow().setStatusBarColor(barColor);
        activity.getWindow().setNavigationBarColor(barColor);
    }
}
