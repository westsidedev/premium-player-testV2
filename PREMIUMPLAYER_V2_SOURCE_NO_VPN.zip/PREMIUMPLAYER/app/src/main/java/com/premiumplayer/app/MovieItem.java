package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class MovieItem {
    String rawJson = "";
    long importGeneration = 0L;
        String name = "";
        String categoryId = "";
        String streamId = "";
        String extension = "mp4";
        String directSource = "";
        String rating = "";
        String year = "";
    long addedAt = 0L;
        String icon = "";
        String plot = "";
        String cast = "";
        String director = "";
        String genre = "";
        String trailer = "";
        String duration = "";
        boolean detailsLoaded = false;
        boolean detailsLoading = false;
    }
