package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class HomeSettingsThemeSection {

    interface Host {
        String currentTheme();
        Button smallButton(String text);
        Drawable background(int fill, int border, int radius);
        void selectTheme(String theme);
        int dp(int value);
        int gold();
        int silver();
        int charcoal();
    }

    static void add(Context context, Host host, LinearLayout root) {

        TextView heading = new TextView(context);
        heading.setText("COLOUR THEME");
        heading.setTextColor(host.gold());
        heading.setTextSize(12);
        heading.setLetterSpacing(0.12f);
        heading.setPadding(0, host.dp(22), 0, host.dp(8));
        root.addView(heading);

        TextView help = new TextView(context);
        help.setText("Changes the accent colour used throughout PREMIUM PLAYER.");
        help.setTextColor(host.silver());
        help.setTextSize(13);
        help.setPadding(0, 0, 0, host.dp(12));
        root.addView(help);

        String[] themes = {"GOLD", "BLUE", "RED", "GREEN", "PURPLE"};
        String current = host.currentTheme();

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row);

        for (String theme : themes) {
            Button button = host.smallButton(theme);
            button.setTextSize(11);

            boolean selected = theme.equals(current);

            button.setBackground(
                    host.background(
                            selected ? Color.rgb(35, 31, 23) : host.charcoal(),
                            selected ? host.gold() : Color.rgb(55, 55, 58),
                            12));

            button.setOnClickListener(v -> host.selectTheme(theme));

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            0,
                            host.dp(48),
                            1f);

            params.setMargins(0, 0, host.dp(7), 0);
            row.addView(button, params);
        }
    }
}
