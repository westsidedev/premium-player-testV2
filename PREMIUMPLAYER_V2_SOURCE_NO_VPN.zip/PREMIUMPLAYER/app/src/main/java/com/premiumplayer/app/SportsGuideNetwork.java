package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashSet;

final class SportsGuideNetwork {

    interface Callback {
        void done(JSONArray data, String error);
    }

    private SportsGuideNetwork() {}

    static void fetchFilters(
            String base, String key, String playlist,
            Callback callback) {

        String endpoint = base
                + "/sports-guide?playlist_key="
                + encode(playlist)
                + "&days=10&view=filters";

        get(endpoint, key, "sports", callback);
    }

    static void fetchEvents(
            String base, String key, String playlist,
            boolean custom,
            HashSet<String> sports,
            HashSet<String> comps,
            Callback callback) {

        StringBuilder endpoint = new StringBuilder(
                base + "/sports-guide?playlist_key="
                        + encode(playlist) + "&days=7");

        if (custom) {
            String s = SportsGuideSupport.joinSet(sports);
            String c = SportsGuideSupport.joinSet(comps);

            if (!s.isEmpty())
                endpoint.append("&sports=").append(encode(s));

            if (!c.isEmpty())
                endpoint.append("&competitions=").append(encode(c));
        }

        get(endpoint.toString(), key, "events", callback);
    }

    private static void get(
            String endpoint, String key,
            String arrayName, Callback callback) {

        new Thread(() -> {
            HttpURLConnection con = null;

            try {
                con = (HttpURLConnection)
                        new URL(endpoint).openConnection();

                con.setRequestMethod("GET");
                con.setConnectTimeout(8000);
                con.setReadTimeout(12000);
                con.setRequestProperty("apikey", key);
                con.setRequestProperty("Accept", "application/json");

                int code = con.getResponseCode();

                if (code < 200 || code >= 300)
                    throw new Exception("Server " + code);

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(con.getInputStream()));

                StringBuilder body = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null)
                    body.append(line);

                reader.close();

                JSONArray data = new JSONObject(
                        body.toString()).optJSONArray(arrayName);

                if (data == null) data = new JSONArray();

                callback.done(data, null);

            } catch (Exception e) {
                callback.done(
                        new JSONArray(),
                        e.getMessage() == null
                                ? "Unavailable"
                                : e.getMessage());
            } finally {
                if (con != null) con.disconnect();
            }
        }).start();
    }

    private static String encode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
