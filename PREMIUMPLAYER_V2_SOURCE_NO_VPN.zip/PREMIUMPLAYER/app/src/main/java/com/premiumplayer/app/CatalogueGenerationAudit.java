package com.premiumplayer.app;

import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueGenerationAudit {

    private static long count(
            SQLiteDatabase db,
            String table,
            String condition,
            String[] args) {

        return DatabaseUtils.longForQuery(
                db,
                "SELECT COUNT(*) FROM " + table
                        + " WHERE provider_key=? AND "
                        + condition,
                args);
    }

    static String report(
            SQLiteDatabase db,
            String providerKey) {

        Cursor cursor = db.rawQuery(
                "SELECT generation,state,movies_done,series_done "
                        + "FROM catalogue_rebuild_journal "
                        + "WHERE provider_key=?",
                new String[]{providerKey});

        long generation;
        long expectedMovies;
        long expectedSeries;
        String state;

        try {
            if (!cursor.moveToFirst()) {
                return "No rebuild journal found.";
            }

            generation = cursor.getLong(0);
            state = cursor.getString(1);
            expectedMovies = cursor.getLong(2);
            expectedSeries = cursor.getLong(3);
        } finally {
            cursor.close();
        }

        String[] args = {
                providerKey,
                Long.toString(generation)
        };

        long movies = count(
                db, "catalogue_movies",
                "import_generation=?", args);

        long series = count(
                db, "catalogue_series",
                "import_generation=?", args);

        long oldMovies = count(
                db, "catalogue_movies",
                "COALESCE(import_generation,0)<>?", args);

        long oldSeries = count(
                db, "catalogue_series",
                "COALESCE(import_generation,0)<>?", args);

        long missingJson = count(
                db, "catalogue_movies",
                "import_generation=? AND "
                        + "(raw_json IS NULL OR LENGTH(raw_json)=0)",
                args);

        missingJson += count(
                db, "catalogue_series",
                "import_generation=? AND "
                        + "(raw_json IS NULL OR LENGTH(raw_json)=0)",
                args);

        boolean countsMatch =
                movies == expectedMovies
                && series == expectedSeries;

        boolean ready =
                "VALIDATED".equals(state)
                && countsMatch
                && movies > 0
                && series > 0
                && missingJson == 0;

        return "Journal: " + state
                + "\nCurrent movies: " + movies
                + "\nOlder movies: " + oldMovies
                + "\n\nCurrent series: " + series
                + "\nOlder series: " + oldSeries
                + "\n\nMissing JSON: " + missingJson
                + "\nJournal counts match: "
                + (countsMatch ? "YES" : "NO")
                + "\n\nCleanup review: "
                + (ready ? "READY" : "NOT READY")
                + "\n\nNo records deleted.";
    }
}
