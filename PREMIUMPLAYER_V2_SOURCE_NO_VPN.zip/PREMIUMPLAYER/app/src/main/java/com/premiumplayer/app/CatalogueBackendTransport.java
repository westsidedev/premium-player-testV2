package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

final class CatalogueBackendTransport {

    static JSONObject postEnrichmentBatch(
            String baseUrl,
            String publishableKey,
            String providerKey,
            JSONArray items)
            throws Exception {

        HttpURLConnection connection =
                null;

        try {

            URL url =
                    new URL(
                            baseUrl
                                    + "/catalogue-ingest-enrich");

            connection =
                    (HttpURLConnection)
                            url.openConnection();

            connection.setRequestMethod(
                    "POST");

            connection.setConnectTimeout(
                    12000);

            connection.setReadTimeout(
                    45000);

            connection.setDoOutput(
                    true);

            connection.setRequestProperty(
                    "Content-Type",
                    "application/json");

            connection.setRequestProperty(
                    "apikey",
                    publishableKey);

            JSONObject body =
                    new JSONObject();

            body.put(
                    "items",
                    items);

            body.put(
                    "source_key",
                    "pp-"
                            + providerKey
                            + "-"
                            + providerKey
                            + "-v1");

            OutputStream output =
                    connection.getOutputStream();

            output.write(
                    body.toString()
                            .getBytes(
                                    "UTF-8"));

            output.flush();
            output.close();

            int code =
                    connection.getResponseCode();

            InputStream input =
                    code >= 200
                            && code < 300
                            ? connection.getInputStream()
                            : connection.getErrorStream();

            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    input,
                                    "UTF-8"));

            StringBuilder text =
                    new StringBuilder();

            String line;

            while ((line = reader.readLine())
                    != null) {

                text.append(
                        line);
            }

            reader.close();

            if (code < 200
                    || code >= 300) {

                throw new Exception(
                        "Cast backend HTTP "
                                + code);
            }

            return new JSONObject(
                    text.toString());

        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
