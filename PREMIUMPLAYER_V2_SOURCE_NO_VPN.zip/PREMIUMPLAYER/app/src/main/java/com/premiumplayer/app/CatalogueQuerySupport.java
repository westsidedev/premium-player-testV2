package com.premiumplayer.app;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

final class CatalogueQuerySupport {

    interface Host {
        SQLiteDatabase readableDatabase();

        String providerKey();

        String normalize(
                String value);
    }

    private static String table(
            String mediaType) {

        return "MOVIES".equals(mediaType)
                ? "catalogue_movies"
                : "catalogue_series";
    }

    private static String[] columns(
            String mediaType) {

        if ("MOVIES".equals(mediaType)) {

            return new String[]{
                    "stream_id",
                    "name",
                    "category_id",
                    "extension",
                    "direct_source",
                    "rating",
                    "year",
                    "icon",
                    "plot",
                    "cast",
                    "director",
                    "genre",
                    "trailer",
                    "duration"
            };
        }

        return new String[]{
                "series_id",
                "name",
                "category_id",
                "rating",
                "year",
                "cover",
                "plot",
                "cast",
                "director",
                "genre",
                "trailer"
        };
    }

    static int count(
            String mediaType,
            String categoryId,
            String query,
            Host host) {

        Cursor cursor = null;

        try {
            SQLiteDatabase db =
                    host.readableDatabase();

            StringBuilder sql =
                    new StringBuilder();

            sql.append("SELECT COUNT(*) FROM ")
                    .append(table(mediaType))
                    .append(" WHERE provider_key=?");

            ArrayList<String> args =
                    new ArrayList<String>();

            args.add(
                    host.providerKey());

            if (categoryId != null
                    && categoryId.isEmpty() == false) {

                sql.append(
                        " AND category_id=?");

                args.add(
                        categoryId);
            }

            String normalized =
                    host.normalize(
                            query);

            if (normalized.isEmpty() == false) {

                sql.append(
                        " AND normalized_name LIKE ?");

                args.add(
                        "%"
                                + normalized
                                + "%");
            }

            cursor =
                    db.rawQuery(
                            sql.toString(),
                            args.toArray(
                                    new String[
                                            args.size()]));

            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }

        } catch (Exception ignored) {

        } finally {

            if (cursor != null) {
                cursor.close();
            }
        }

        return 0;
    }

    static Cursor query(
            String mediaType,
            String categoryId,
            String query,
            Host host) {

        SQLiteDatabase db =
                host.readableDatabase();

        StringBuilder selection =
                new StringBuilder(
                        "provider_key=?");

        ArrayList<String> args =
                new ArrayList<String>();

        args.add(
                host.providerKey());

        if (categoryId != null
                && categoryId.isEmpty() == false) {

            selection.append(
                    " AND category_id=?");

            args.add(
                    categoryId);
        }

        String normalized =
                host.normalize(
                        query);

        if (normalized.isEmpty() == false) {

            selection.append(
                    " AND normalized_name LIKE ?");

            args.add(
                    "%"
                            + normalized
                            + "%");
        }

        return db.query(
                table(mediaType),
                columns(mediaType),
                selection.toString(),
                args.toArray(
                        new String[
                                args.size()]),
                null,
                null,
                "name COLLATE NOCASE ASC");
    }
}
