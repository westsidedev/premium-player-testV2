package com.premiumplayer.app;

import android.util.JsonReader;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

final class XtreamJsonArrayTransport {

    interface ItemReader {
        void read(JsonReader reader)
                throws Exception;
    }

    static void stream(
            String requestUrl,
            ItemReader itemReader)
            throws Exception {

        String currentUrl =
                requestUrl;

        for (int redirectCount = 0;
             redirectCount < 6;
             redirectCount++) {

            HttpURLConnection connection =
                    null;

            JsonReader reader =
                    null;

            try {

                URL url =
                        new URL(currentUrl);

                connection =
                        (HttpURLConnection)
                                url.openConnection();

                connection.setConnectTimeout(
                        20000);

                connection.setReadTimeout(
                        60000);

                connection.setInstanceFollowRedirects(
                        false);

                connection.setRequestMethod(
                        "GET");

                connection.setUseCaches(
                        false);

                connection.setRequestProperty(
                        "User-Agent",
                        "VLC/3.0.21 LibVLC/3.0.21");

                connection.setRequestProperty(
                        "Accept",
                        "application/json, text/plain, */*");

                connection.setRequestProperty(
                        "Accept-Encoding",
                        "identity");

                connection.setRequestProperty(
                        "Connection",
                        "close");

                int status =
                        connection.getResponseCode();

                if (status == HttpURLConnection.HTTP_MOVED_PERM
                        || status == HttpURLConnection.HTTP_MOVED_TEMP
                        || status == HttpURLConnection.HTTP_SEE_OTHER
                        || status == 307
                        || status == 308) {

                    String location =
                            connection.getHeaderField(
                                    "Location");

                    if (location == null
                            || location.trim().isEmpty()) {

                        throw new Exception(
                                "Server redirected without a destination.");
                    }

                    currentUrl =
                            new URL(
                                    url,
                                    location)
                                    .toString();

                    continue;
                }

                if (status < 200
                        || status >= 300) {

                    throw new Exception(
                            "HTTP " + status);
                }

                reader =
                        new JsonReader(
                                new InputStreamReader(
                                        connection.getInputStream(),
                                        "UTF-8"));

                reader.beginArray();

                while (reader.hasNext()) {
                    itemReader.read(
                            reader);
                }

                reader.endArray();

                return;

            } finally {

                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception ignored) {
                    }
                }

                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        throw new Exception(
                "Too many redirects.");
    }
}
