package com.premiumplayer.app;

import android.widget.TextView;

import com.google.android.exoplayer2.ui.PlayerView;

final class LiveTvPreviewController {

    interface Host {
        void releasePlayer();
        void setLiveBrowserMode(boolean enabled);
        void select(Channel channel);

        void prepareState(
                PlayerView playerView,
                TextView title,
                TextView now,
                TextView next,
                TextView status);

        String selectedChannel();
        String selectedNow();
        String selectedGroup();
        String selectedNext();

        boolean xtreamEpgAvailable();
        Channel findSelectedChannel();

        void loadShortEpg(
                Channel channel,
                TextView now,
                TextView next);

        void buildPlaybackCandidates();
        boolean hasPlaybackCandidates();
        void resetPlaybackCandidateIndex();

        String preferredAudioLanguage();
        void playCurrentCandidate(String language);
    }

    static void start(
            Host host,
            Channel channel,
            PlayerView playerView,
            TextView previewTitle,
            TextView previewNow,
            TextView previewNext,
            TextView previewStatus) {

        if (channel == null || playerView == null) {
            return;
        }

        host.releasePlayer();
        host.setLiveBrowserMode(true);
        host.select(channel);

        host.prepareState(
                playerView,
                previewTitle,
                previewNow,
                previewNext,
                previewStatus);

        previewTitle.setText(host.selectedChannel());

        previewNow.setText(
                host.selectedNow().isEmpty()
                        ? host.selectedGroup()
                        : "NOW  " + host.selectedNow());

        previewNext.setText(
                host.selectedNext().isEmpty()
                        ? "EPG loading..."
                        : "NEXT  " + host.selectedNext());

        previewStatus.setText("Tuning...");

        if (host.xtreamEpgAvailable()) {

            Channel selected =
                    host.findSelectedChannel();

            if (selected != null) {
                host.loadShortEpg(
                        selected,
                        previewNow,
                        previewNext);
            }
        }

        host.buildPlaybackCandidates();

        if (!host.hasPlaybackCandidates()) {
            previewStatus.setText(
                    "No playable stream URL is available.");
            return;
        }

        host.resetPlaybackCandidateIndex();

        host.playCurrentCandidate(
                host.preferredAudioLanguage());
    }
}
