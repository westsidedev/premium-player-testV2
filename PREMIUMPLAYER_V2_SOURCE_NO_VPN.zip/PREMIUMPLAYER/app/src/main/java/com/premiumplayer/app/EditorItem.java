package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class EditorItem {
        String id = "";
        String name = "";

        EditorItem(
                String id,
                String name) {
            this.id = id == null ? "" : id;
            this.name = name == null ? "" : name;
        }
    }
