package com.premiumplayer.app;

import android.app.Activity;
import android.app.AlertDialog;

final class PlaybackResumeChoice {

    interface Host {
        boolean isLive();
        String resumeKey();

        long savedPosition(
                String key);

        String title();

        String formatTime(
                long position);

        void clearResume(
                String key);

        void setStartPosition(
                long position);

        void play(
                String preferredLanguage);
    }

    static void start(
            Activity activity,
            Host host,
            String preferredLanguage) {

        String key =
                host.resumeKey();

        if (host.isLive()
                || key == null
                || key.isEmpty()) {

            host.setStartPosition(0L);
            host.play(preferredLanguage);
            return;
        }

        final long savedPosition =
                host.savedPosition(key);

        if (savedPosition < 30000L) {

            host.setStartPosition(0L);
            host.play(preferredLanguage);
            return;
        }

        AlertDialog dialog =
                new AlertDialog.Builder(activity)
                        .setTitle("Resume watching?")
                        .setMessage(
                                "Continue "
                                        + host.title()
                                        + " from "
                                        + host.formatTime(
                                                savedPosition)
                                        + "?")

                        .setPositiveButton(
                                "RESUME",
                                (d, which) -> {

                                    host.setStartPosition(
                                            savedPosition);

                                    host.play(
                                            preferredLanguage);
                                })

                        .setNegativeButton(
                                "START OVER",
                                (d, which) -> {

                                    host.clearResume(
                                            key);

                                    host.setStartPosition(
                                            0L);

                                    host.play(
                                            preferredLanguage);
                                })

                        .setCancelable(false)
                        .create();

        dialog.setOnShowListener(
                d -> {

                    if (dialog.getButton(
                            AlertDialog.BUTTON_POSITIVE)
                            != null) {

                        dialog.getButton(
                                AlertDialog.BUTTON_POSITIVE)
                                .requestFocus();
                    }
                });

        dialog.show();
    }
}
