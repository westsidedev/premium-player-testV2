package com.premiumplayer.app;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;
import java.util.Iterator;
import java.util.TreeSet;

final class CatalogueDifferenceSample {

    private static final class SampleComplete extends Exception {}

    private static String differingFields(
            String previous, String incoming) throws Exception {

        JSONObject a = new JSONObject(previous);
        JSONObject b = new JSONObject(incoming);

        TreeSet<String> keys = new TreeSet<>();
        Iterator<String> it = a.keys();
        while (it.hasNext()) keys.add(it.next());
        it = b.keys();
        while (it.hasNext()) keys.add(it.next());

        StringBuilder result = new StringBuilder();
        int differences = 0;

        for (String key : keys) {
            boolean different = !a.has(key) || !b.has(key);

            if (!different) {
                String x = new JSONObject()
                        .put("value", a.opt(key)).toString();
                String y = new JSONObject()
                        .put("value", b.opt(key)).toString();

                different = !CatalogueJsonEquivalence
                        .equivalent(x, y);
            }

            if (different) {
                differences++;
                if (differences <= 8) {
                    if (result.length() > 0) result.append(", ");
                    result.append(key);
                }
            }
        }

        if (differences > 8) result.append(", ...");
        return result.toString();
    }

    static String scan(SQLiteDatabase db,
            String providerKey, String url,
            boolean movies) throws Exception {

        final String table = movies
                ? "catalogue_movies" : "catalogue_series";

        final String idField = movies
                ? "stream_id" : "series_id";

        final int[] counts = new int[6];
        // Seen, new, changed, identical, representation-only

        final StringBuilder examples = new StringBuilder();

        try {
            XtreamJsonArrayTransport.stream(url, reader -> {
                if (counts[0] >= 10) {
                    throw new SampleComplete();
                }

                String incoming = ProviderRawJson.capture(reader);
                JSONObject object = new JSONObject(incoming);
                String id = object.optString(idField, "");

                counts[0]++;

                if (id.isEmpty() || "null".equals(id)) {
                    return;
                }

                Cursor cursor = db.query(
                        table, new String[]{"raw_json"},
                        "pk=? AND provider_key=?",
                        new String[]{providerKey + "|" + id, providerKey},
                        null, null, null);

                try {
                    if (!cursor.moveToFirst()) {
                        counts[1]++;
                        return;
                    }

                    String previous = cursor.getString(0);

                    if (incoming.equals(previous)) {
                        counts[3]++;
                    } else if (previous != null
                            && CatalogueJsonEquivalence.equivalent(
                                    previous, incoming)) {
                        counts[4]++;
                    } else if (previous != null
                            && CatalogueRefreshDiff.onlyListingPositionChanged(
                                    previous, incoming)) {
                        counts[5]++;
                    } else {
                        counts[2]++;

                        if (counts[2] <= 3) {
                            examples.append("\nExample ")
                                    .append(counts[2])
                                    .append(": ")
                                    .append(previous == null
                                            ? "Stored JSON missing"
                                            : differingFields(previous, incoming));
                        }
                    }
                } finally {
                    cursor.close();
                }
            });
        } catch (SampleComplete expected) {
            // Transport closes the connection after 10 records.
        }

        return (movies ? "MOVIES" : "SERIES")
                + "\nSampled: " + counts[0]
                + "\nNew: " + counts[1]
                + "\nChanged: " + counts[2]
                + "\nIdentical: " + counts[3]
                + "\nRepresentation-only: " + counts[4]
                + "\nListing position only: " + counts[5]
                + "\nDiffering field names:"
                + examples.toString();
    }
}
