package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

final class SportsGuideUi {

    interface ImageLoader {
        void load(ImageView image, String url);
    }

    private SportsGuideUi() {}

    static View badge(
            Context context,
            String name,
            String imageUrl,
            int gold,
            ImageLoader loader) {

        String url = imageUrl == null ? "" : imageUrl.trim();

        if (!url.isEmpty()) {
            ImageView image = new ImageView(context);
            image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            image.setPadding(dp(context,3), dp(context,3),
                    dp(context,3), dp(context,3));

            image.setBackground(background(
                    context,
                    Color.rgb(29,29,32),
                    Color.rgb(68,68,74),
                    50));

            loader.load(image, url);
            return image;
        }

        TextView initials = new TextView(context);
        initials.setText(SportsGuideSupport.initials(name));
        initials.setTextColor(Color.WHITE);
        initials.setTextSize(13);
        initials.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        initials.setGravity(Gravity.CENTER);

        initials.setBackground(background(
                context,
                Color.rgb(37,37,42),
                gold,
                50));

        return initials;
    }

    static LinearLayout team(
            Context context,
            String name,
            String logoUrl,
            int gold,
            ImageLoader loader) {

        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER_HORIZONTAL);

        View badge = badge(
                context, name, logoUrl, gold, loader);

        block.addView(
                badge,
                new LinearLayout.LayoutParams(
                        dp(context,46),
                        dp(context,46)));

        TextView team = new TextView(context);
        team.setText(name == null ? "" : name);
        team.setTextColor(Color.WHITE);
        team.setTextSize(10);
        team.setGravity(Gravity.CENTER);
        team.setMaxLines(2);
        team.setPadding(
                dp(context,2),
                dp(context,4),
                dp(context,2),
                0);

        block.addView(
                team,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(context,34)));

        return block;
    }

    private static GradientDrawable background(
            Context context,
            int fill,
            int border,
            int radius) {

        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(context,radius));
        d.setStroke(dp(context,1), border);
        return d;
    }

    private static int dp(Context context, int value) {
        return (int) (
                value * context.getResources()
                        .getDisplayMetrics().density);
    }
}
