package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

final class MediaCategoryLoader {

    interface Host {
        String downloadCategories(
                String action)
                throws Exception;
    }

    static ArrayList<MediaCategory> load(
            String mediaType,
            Host host)
            throws Exception {

        String action =
                "MOVIES".equals(mediaType)
                        ? "get_vod_categories"
                        : "get_series_categories";

        String text =
                host.downloadCategories(
                        action);

        JSONArray array =
                new JSONArray(text);

        ArrayList<MediaCategory> categories =
                new ArrayList<MediaCategory>();

        for (int i = 0;
             i < array.length();
             i++) {

            JSONObject item =
                    array.optJSONObject(i);

            if (item == null) {
                continue;
            }

            MediaCategory category =
                    new MediaCategory();

            category.id =
                    item.optString(
                            "category_id",
                            "");

            category.name =
                    item.optString(
                            "category_name",
                            "OTHER");

            if (category.id.isEmpty() == false) {
                categories.add(
                        category);
            }
        }

        return categories;
    }
}
