package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

final class SportsGuideRenderer {

    interface Host {
        int dp(int value);
        View badge(String name, String url, int size);
        LinearLayout team(String name, String url);
        Drawable background(int fill, int border, int radius);
        void load(ImageView image, String url);
        void open(JSONObject event);
        void focus(View view, int radius);
    }

    static void render(Context context, int gold, int silver, int charcoal, Host host, LinearLayout container, TextView status, JSONArray events) {
        container.removeAllViews();
        if (events == null || events.length() == 0) {
            status.setText("No upcoming matching sports events yet. PREMIUM PLAYER is refreshing the EPG in the background.");
            return;
        }

        int liveCount = 0;
        for (int i = 0; i < events.length(); i++) {
            JSONObject event = events.optJSONObject(i);
            if (event != null && event.optBoolean("is_live", false)) liveCount++;
        }
        status.setText(events.length() + " events" + (liveCount > 0 ? "   •   " + liveCount + " LIVE" : ""));

        HashMap<String, ArrayList<JSONObject>> byDate = new HashMap<String, ArrayList<JSONObject>>();
        SimpleDateFormat keyFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        for (int i = 0; i < events.length(); i++) {
            JSONObject event = events.optJSONObject(i);
            if (event == null) continue;
            String key = keyFormat.format(new Date(event.optLong("start_at", 0L) * 1000L));
            ArrayList<JSONObject> list = byDate.get(key);
            if (list == null) {
                list = new ArrayList<JSONObject>();
                byDate.put(key, list);
            }
            list.add(event);
        }

        ArrayList<String> dates = new ArrayList<String>(byDate.keySet());
        Collections.sort(dates);
        SimpleDateFormat displayDate = new SimpleDateFormat("EEE  dd MMM yyyy", Locale.getDefault());
        SimpleDateFormat displayTime = new SimpleDateFormat("HH:mm", Locale.getDefault());

        for (String dateKey : dates) {
            ArrayList<JSONObject> day = byDate.get(dateKey);
            if (day == null || day.isEmpty()) continue;

            TextView dateTitle = new TextView(context);
            long firstStart = day.get(0).optLong("start_at", 0L);
            dateTitle.setText(displayDate.format(new Date(firstStart * 1000L)));
            dateTitle.setTextColor(Color.WHITE);
            dateTitle.setTextSize(18);
            dateTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            dateTitle.setPadding(0, host.dp(14), 0, host.dp(8));
            container.addView(dateTitle);

            HorizontalScrollView horizontal = new HorizontalScrollView(context);
            horizontal.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(context);
            row.setOrientation(LinearLayout.HORIZONTAL);
            horizontal.addView(row);
            container.addView(horizontal, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, host.dp(252)));

            for (JSONObject event : day) {
                final JSONObject selectedEvent = event;
                LinearLayout card = new LinearLayout(context);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(10));
                card.setClickable(true);
                card.setFocusable(true);
                card.setBackground(host.background(charcoal, Color.rgb(60, 60, 65), 14));

                LinearLayout topBar = new LinearLayout(context);
                topBar.setOrientation(LinearLayout.HORIZONTAL);
                topBar.setGravity(Gravity.CENTER_VERTICAL);

                String competitionLogo = event.optString("competition_logo", "");
                if (!competitionLogo.isEmpty()) {
                    View leagueBadge = host.badge(event.optString("competition", "SP"), competitionLogo, 25);
                    LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(host.dp(25), host.dp(25));
                    logoParams.setMargins(0, 0, host.dp(7), 0);
                    topBar.addView(leagueBadge, logoParams);
                }

                TextView competition = new TextView(context);
                String comp = event.optString("competition", "");
                competition.setText(comp.isEmpty()
                        ? event.optString("sport", "Sport").replace("_", " ").toUpperCase(Locale.getDefault())
                        : comp);
                competition.setTextColor(gold);
                competition.setTextSize(10);
                competition.setSingleLine(true);
                topBar.addView(competition, new LinearLayout.LayoutParams(0, host.dp(28), 1f));

                boolean isLive = event.optBoolean("is_live", false);
                String statusText = event.optString("status_text", "");
                if (isLive) {
                    TextView live = new TextView(context);
                    live.setText("● LIVE");
                    live.setTextColor(Color.WHITE);
                    live.setTextSize(10);
                    live.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                    live.setGravity(Gravity.CENTER);
                    live.setPadding(host.dp(8), 0, host.dp(8), 0);
                    live.setBackground(host.background(Color.rgb(170, 28, 28), Color.rgb(220, 70, 70), 10));
                    topBar.addView(live, new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT, host.dp(25)));
                } else if (statusText.startsWith("Starts in")) {
                    TextView soon = new TextView(context);
                    soon.setText(statusText);
                    soon.setTextColor(Color.WHITE);
                    soon.setTextSize(9);
                    soon.setGravity(Gravity.CENTER);
                    soon.setPadding(host.dp(7), 0, host.dp(7), 0);
                    soon.setBackground(host.background(Color.rgb(48, 48, 54), Color.rgb(85, 85, 92), 10));
                    topBar.addView(soon, new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT, host.dp(25)));
                }
                card.addView(topBar, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, host.dp(30)));

                String artwork = event.optString("event_artwork", "");
                if (!artwork.isEmpty()) {
                    ImageView banner = new ImageView(context);
                    banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    banner.setBackgroundColor(Color.rgb(25, 25, 28));
                    host.load(banner, artwork);
                    LinearLayout.LayoutParams bannerParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, host.dp(58));
                    bannerParams.setMargins(0, host.dp(5), 0, host.dp(5));
                    card.addView(banner, bannerParams);
                }

                String homeTeam = event.optString("home_team", "");
                String awayTeam = event.optString("away_team", "");
                String homeLogo = event.optString("home_team_logo", "");
                String awayLogo = event.optString("away_team_logo", "");
                String fallbackLogo = event.optString("fallback_logo", "");

                LinearLayout eventRow = new LinearLayout(context);
                eventRow.setOrientation(LinearLayout.HORIZONTAL);
                eventRow.setGravity(Gravity.CENTER_VERTICAL);

                boolean hasTeams = !homeTeam.isEmpty() && !awayTeam.isEmpty();
                if (hasTeams) {
                    LinearLayout home = host.team(homeTeam, homeLogo);
                    eventRow.addView(home, new LinearLayout.LayoutParams(host.dp(82), host.dp(86)));
                } else if (!fallbackLogo.isEmpty()) {
                    View fallback = host.badge(event.optString("sport", "SP"), fallbackLogo, 46);
                    LinearLayout.LayoutParams fallbackParams = new LinearLayout.LayoutParams(host.dp(46), host.dp(46));
                    fallbackParams.setMargins(0, 0, host.dp(10), 0);
                    eventRow.addView(fallback, fallbackParams);
                }

                TextView title = new TextView(context);
                title.setText(hasTeams
                        ? homeTeam + "\nvs\n" + awayTeam
                        : event.optString("title", "Sporting event"));
                title.setTextColor(Color.WHITE);
                title.setTextSize(hasTeams ? 12 : 15);
                title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                title.setGravity(Gravity.CENTER);
                title.setMaxLines(hasTeams ? 3 : 4);
                title.setPadding(host.dp(6), host.dp(4), host.dp(6), host.dp(4));
                eventRow.addView(title, new LinearLayout.LayoutParams(0, host.dp(86), 1f));

                if (hasTeams) {
                    LinearLayout away = host.team(awayTeam, awayLogo);
                    eventRow.addView(away, new LinearLayout.LayoutParams(host.dp(82), host.dp(86)));
                }
                card.addView(eventRow, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

                TextView time = new TextView(context);
                long start = event.optLong("start_at", 0L);
                JSONArray channels = event.optJSONArray("channels");
                int channelCount = channels == null ? 0 : channels.length();
                String bottom = isLive ? "LIVE NOW" : displayTime.format(new Date(start * 1000L));
                if (channelCount > 1) bottom += "   •   " + channelCount + " feeds";
                time.setText(bottom);
                time.setTextColor(isLive ? Color.WHITE : silver);
                time.setTextSize(11);
                time.setTypeface(Typeface.DEFAULT, isLive ? Typeface.BOLD : Typeface.NORMAL);
                card.addView(time);

                card.setOnClickListener(v -> host.open(selectedEvent));
                host.focus(card, 14);
                LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(host.dp(330), host.dp(236));
                cardParams.setMargins(0, 0, host.dp(12), 0);
                row.addView(card, cardParams);
            }
        }

        TextView source = new TextView(context);
        source.setText("Sports artwork metadata: provider EPG / TheSportsDB where available");
        source.setTextColor(Color.rgb(115, 115, 120));
        source.setTextSize(9);
        source.setPadding(0, host.dp(12), 0, 0);
        container.addView(source);
    }
}
