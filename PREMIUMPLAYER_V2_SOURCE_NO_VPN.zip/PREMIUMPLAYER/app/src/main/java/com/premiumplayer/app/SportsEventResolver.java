package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class SportsEventResolver {

    private SportsEventResolver() {}

    static Channel find(
            JSONArray sources,
            ArrayList<Channel> active) {

        if (sources == null || active == null)
            return null;

        for (int i = 0; i < sources.length(); i++) {
            JSONObject source = sources.optJSONObject(i);
            if (source == null) continue;

            String streamId =
                    source.optString("stream_id", "");

            String channelName =
                    source.optString("channel_name", "");

            for (Channel channel : active) {
                String candidateId = safe(channel.streamId);

                if (candidateId.isEmpty())
                    candidateId = streamId(channel.url);

                if (!streamId.isEmpty()
                        && streamId.equals(candidateId))
                    return channel;

                if (!channelName.isEmpty()
                        && channelName.equalsIgnoreCase(
                                safe(channel.name)))
                    return channel;
            }
        }

        return null;
    }

    private static String streamId(String url) {
        if (url == null) return "";

        Matcher m = Pattern.compile(
                "/([0-9]+)\\.(?:ts|m3u8)(?:\\?.*)?$",
                Pattern.CASE_INSENSITIVE)
                .matcher(url);

        return m.find() ? m.group(1) : "";
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }
}
