package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class EpisodeItem {
        String id = "";
        String title = "";
        String extension = "mp4";
        String directSource = "";
        int seasonNumber = 0;
        int episodeNumber = 0;
    }
