package com.premiumplayer.app;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueDetailStore {

    static void createTable(SQLiteDatabase db) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS catalogue_details (" +
            "provider_key TEXT NOT NULL, " +
            "media_type TEXT NOT NULL, " +
            "media_id TEXT NOT NULL, " +
            "raw_json TEXT NOT NULL, " +
            "fetched_at_ms INTEGER NOT NULL, " +
            "PRIMARY KEY(provider_key, media_type, media_id))"
        );
    }

    static void save(
            SQLiteDatabase db,
            String providerKey,
            String mediaType,
            String mediaId,
            String rawJson) {

        if (db == null || providerKey == null ||
                mediaType == null || mediaId == null ||
                mediaId.isEmpty() || rawJson == null ||
                rawJson.isEmpty()) {
            return;
        }

        ContentValues values = new ContentValues();
        values.put("provider_key", providerKey);
        values.put("media_type", mediaType);
        values.put("media_id", mediaId);
        values.put("raw_json", rawJson);
        values.put("fetched_at_ms",
                System.currentTimeMillis());

        long result = db.insertWithOnConflict(
                "catalogue_details",
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE);

        if (result < 0) {
            throw new IllegalStateException(
                    "Catalogue detail storage failed");
        }
    }
}
