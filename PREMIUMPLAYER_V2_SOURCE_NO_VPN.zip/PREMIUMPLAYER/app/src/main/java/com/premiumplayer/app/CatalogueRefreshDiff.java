package com.premiumplayer.app;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueRefreshDiff {

    static final int UNCHANGED = 0;
    static final int NEW = 1;
    static final int CHANGED = 2;
    static final int REPRESENTATION_ONLY = 3;
    static final int LIST_POSITION_ONLY = 4;
    static boolean onlyListingPositionChanged(
            String previousJson, String incomingJson) {
        try {
            org.json.JSONObject previous =
                    new org.json.JSONObject(previousJson);
            org.json.JSONObject incoming =
                    new org.json.JSONObject(incomingJson);

            if (!previous.has("num") && !incoming.has("num")) {
                return false;
            }

            previous.remove("num");
            incoming.remove("num");

            return CatalogueJsonEquivalence.equivalent(
                    previous.toString(), incoming.toString());
        } catch (Exception ignored) {
            return false;
        }
    }



    static int compare(
            SQLiteDatabase db,
            boolean movies,
            String providerKey,
            String mediaId,
            String incomingJson) {

        if (db == null
                || providerKey == null
                || providerKey.isEmpty()
                || mediaId == null
                || mediaId.isEmpty()
                || incomingJson == null
                || incomingJson.isEmpty()) {
            throw new IllegalArgumentException(
                    "Invalid catalogue refresh record");
        }

        String table = movies
                ? "catalogue_movies"
                : "catalogue_series";

        String pk = providerKey + "|" + mediaId;

        Cursor cursor = db.query(
                table,
                new String[]{"raw_json"},
                "pk=? AND provider_key=?",
                new String[]{pk, providerKey},
                null, null, null);

        try {
            if (!cursor.moveToFirst()) {
                return NEW;
            }

            String previousJson = cursor.getString(0);

            if (incomingJson.equals(previousJson)) {
                return UNCHANGED;
            }

            if (CatalogueJsonEquivalence.equivalent(previousJson, incomingJson)) {
                return REPRESENTATION_ONLY;
            }

            if (onlyListingPositionChanged(previousJson, incomingJson)) {
                return LIST_POSITION_ONLY;
            }
            return CHANGED;
        } finally {
            cursor.close();
        }
    }
}
