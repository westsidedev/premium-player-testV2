package com.premiumplayer.app;

import java.util.ArrayList;

final class LiveTvSelection {

    interface Host {
        ArrayList<Channel> channels();

        String selectedStreamUrl();
        String selectedChannel();
        String safe(String value);

        String extractStreamId(String url);

        void applySelection(
                Channel channel,
                String streamId);

        void saveLastChannelKey(String key);
        void saveSelectedLiveChannel();
    }

    static Channel findSelected(Host host) {

        ArrayList<Channel> channels =
                host.channels();

        for (Channel channel : channels) {

            if (!host.selectedStreamUrl().isEmpty()
                    && host.selectedStreamUrl().equals(
                            host.safe(channel.url))) {

                return channel;
            }
        }

        for (Channel channel : channels) {

            if (host.selectedChannel().equals(
                    host.safe(channel.name))) {

                return channel;
            }
        }

        return channels.isEmpty()
                ? null
                : channels.get(0);
    }

    static void ensureSelected(Host host) {

        Channel channel =
                findSelected(host);

        if (channel != null) {
            select(host, channel);
        }
    }

    static void select(
            Host host,
            Channel channel) {

        if (channel == null) {
            return;
        }

        String streamId =
                host.safe(channel.streamId);

        if (streamId.isEmpty()) {
            streamId =
                    host.extractStreamId(
                            host.safe(channel.url));
        }

        host.applySelection(
                channel,
                streamId);

        host.saveLastChannelKey(
                channel.key());

        host.saveSelectedLiveChannel();
    }
}
