package com.premiumplayer.app;

import android.util.JsonReader;
import android.util.JsonWriter;
import android.util.JsonToken;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;

final class ProviderRawJson {

    static String capture(JsonReader reader)
            throws IOException {
        StringWriter output = new StringWriter();
        JsonWriter writer = new JsonWriter(output);
        copy(reader, writer);
        writer.flush();
        return output.toString();
    }

    private static void copy(
            JsonReader reader,
            JsonWriter writer) throws IOException {

        JsonToken token = reader.peek();

        switch (token) {
            case BEGIN_OBJECT:
                reader.beginObject();
                writer.beginObject();
                while (reader.hasNext()) {
                    writer.name(reader.nextName());
                    copy(reader, writer);
                }
                reader.endObject();
                writer.endObject();
                break;
            case BEGIN_ARRAY:
                reader.beginArray();
                writer.beginArray();
                while (reader.hasNext()) {
                    copy(reader, writer);
                }
                reader.endArray();
                writer.endArray();
                break;

            case STRING:
                writer.value(reader.nextString());
                break;

            case NUMBER:
                writer.value(new BigDecimal(
                        reader.nextString()));
                break;

            case BOOLEAN:
                writer.value(reader.nextBoolean());
                break;

            case NULL:
                reader.nextNull();
                writer.nullValue();
                break;

            default:
                throw new IOException(
                        "Unexpected JSON token: " + token);
        }
    }
}
