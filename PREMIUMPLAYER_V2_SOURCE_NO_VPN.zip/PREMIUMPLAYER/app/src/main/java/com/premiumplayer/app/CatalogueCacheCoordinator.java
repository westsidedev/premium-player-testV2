package com.premiumplayer.app;

import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

final class CatalogueCacheCoordinator {

    interface Host {

        SQLiteDatabase writableDatabase();

        String providerKey();

        void upsertMovie(
                SQLiteDatabase db,
                String providerKey,
                MovieItem movie);

        void upsertSeries(
                SQLiteDatabase db,
                String providerKey,
                SeriesItem series);

        void enrichVisible(
                String mediaType,
                ArrayList<MovieItem> movies,
                ArrayList<SeriesItem> series);
    }

    static void cacheAsync(
            final String mediaType,
            final ArrayList<MovieItem> movies,
            final ArrayList<SeriesItem> series,
            final Host host) {

        new Thread(() -> {

            try {
                SQLiteDatabase db =
                        host.writableDatabase();

                String providerKey =
                        host.providerKey();

                db.beginTransaction();

                try {

                    if ("MOVIES".equals(mediaType)) {

                        if (movies != null) {
                            for (MovieItem movie : movies) {

                                host.upsertMovie(
                                        db,
                                        providerKey,
                                        movie);
                            }
                        }

                    } else {

                        if (series != null) {
                            for (SeriesItem item : series) {

                                host.upsertSeries(
                                        db,
                                        providerKey,
                                        item);
                            }
                        }
                    }

                    db.setTransactionSuccessful();

                } finally {

                    if (db.inTransaction()) {
                        db.endTransaction();
                    }
                }

            } catch (Exception ignored) {
            }

            int visibleCount =
                    "MOVIES".equals(mediaType)
                            ? (movies == null
                            ? 0
                            : movies.size())
                            : (series == null
                            ? 0
                            : series.size());

            if (visibleCount <= 250) {

                host.enrichVisible(
                        mediaType,
                        movies,
                        series);
            }

        }).start();
    }
}
