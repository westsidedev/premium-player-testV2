package com.premiumplayer.app;

import android.os.Handler;

final class EmbeddedVpnHealthCoordinator {

    interface Host {

        boolean wantsVpn();

        boolean autoReconnect();

        boolean connected();

        boolean managerReady();

        boolean managerBusy();

        boolean managerConfigured();

        boolean permissionGranted();

        void connect();

        boolean playbackBlockEnabled();

        boolean hasPlayer();

        boolean playerIsPlaying();

        void setPlayerPlaying(
                boolean playing);

        boolean playbackPausedByVpn();

        void setPlaybackPausedByVpn(
                boolean paused);

        void setPlaybackStatus(
                String text);
    }

    static Runnable start(
            final Handler handler,
            final Runnable existing,
            final Host host) {

        if (existing != null) {
            handler.removeCallbacks(
                    existing);
        }

        final Runnable[] holder =
                new Runnable[1];

        holder[0] =
                new Runnable() {

                    @Override
                    public void run() {

                        try {
                            boolean wantsVpn =
                                    host.wantsVpn();

                            boolean connected =
                                    host.connected();

                            if (wantsVpn
                                    && host.autoReconnect()
                                    && connected == false
                                    && host.managerReady()
                                    && host.managerBusy() == false
                                    && host.managerConfigured()
                                    && host.permissionGranted()) {

                                host.connect();
                            }

                            if (wantsVpn
                                    && host.playbackBlockEnabled()
                                    && host.hasPlayer()) {

                                if (connected == false
                                        && host.playerIsPlaying()) {

                                    host.setPlayerPlaying(
                                            false);

                                    host.setPlaybackPausedByVpn(
                                            true);

                                    host.setPlaybackStatus(
                                            "VPN connection lost. Playback paused while WireGuard reconnects...");

                                } else if (connected
                                        && host.playbackPausedByVpn()) {

                                    host.setPlaybackPausedByVpn(
                                            false);

                                    host.setPlayerPlaying(
                                            true);

                                    host.setPlaybackStatus(
                                            "VPN restored. Playback resumed.");
                                }

                            } else {

                                host.setPlaybackPausedByVpn(
                                        false);
                            }

                        } catch (Exception ignored) {
                        }

                        handler.postDelayed(
                                holder[0],
                                5000L);
                    }
                };

        handler.postDelayed(
                holder[0],
                1800L);

        return holder[0];
    }
}
