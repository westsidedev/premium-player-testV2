package com.premiumplayer.app;

import android.content.Context;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class SettingsVpnSection {

    interface Host {
        Button smallButton(String text);
        void showVpn();
        int dp(int value);
        int gold();
        int silver();
    }

    static void add(Context context, Host host, LinearLayout root) {

        TextView vpnSection = new TextView(context);
        vpnSection.setText("VPN");
        vpnSection.setTextColor(host.gold());
        vpnSection.setTextSize(12);
        vpnSection.setLetterSpacing(0.12f);
        vpnSection.setPadding(
                0,
                host.dp(26),
                0,
                host.dp(10));

        root.addView(vpnSection);

        TextView vpnHelp = new TextView(context);
        vpnHelp.setText(
                "Embedded Proton WireGuard. PREMIUM PLAYER creates and controls "
                        + "its own VPN tunnel; no separate VPN app is required.");
        vpnHelp.setTextColor(host.silver());
        vpnHelp.setTextSize(13);
        vpnHelp.setPadding(
                0,
                0,
                0,
                host.dp(12));

        root.addView(vpnHelp);

        Button vpnButton =
                host.smallButton("VPN / WIREGUARD");

        vpnButton.setTextSize(13);
        vpnButton.setOnClickListener(v -> host.showVpn());

        LinearLayout.LayoutParams vpnParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        vpnParams.setMargins(
                0,
                0,
                0,
                host.dp(9));

        root.addView(vpnButton, vpnParams);
    }
}
