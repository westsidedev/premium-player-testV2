package com.premiumplayer.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class PlaylistStatusSection {

    interface Host {
        int channelCount();
        SharedPreferences prefs();
        Button smallButton(String text);
        LinearLayout.LayoutParams weightedButtonParams();
        Drawable background(int fill, int border, int radius);
        void openLiveTv();
        void refreshXtream();
        void refreshUrl();
        void removePlaylist();
        int dp(int value);
        int silver();
        int charcoal();
    }

    static void add(
            Context context,
            Host host,
            LinearLayout root) {
        if (host.channelCount() > 0) {
            LinearLayout statusCard = new LinearLayout(context);
            statusCard.setOrientation(LinearLayout.VERTICAL);
            statusCard.setPadding(host.dp(16), host.dp(16), host.dp(16), host.dp(16));
            statusCard.setBackground(
                    host.background(
                            host.charcoal(),
                            Color.rgb(52, 52, 56),
                            14));

            String playlistName =
                    host.prefs()
                            .getString("playlist_name", "Imported Playlist");

            String sourceType =
                    host.prefs()
                            .getString("playlist_source_type", "LOCAL");

            TextView playlistTitle = new TextView(context);
            playlistTitle.setText(playlistName);
            playlistTitle.setTextColor(Color.WHITE);
            playlistTitle.setTextSize(18);
            playlistTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            statusCard.addView(playlistTitle);

            TextView count = new TextView(context);
            count.setText(
                    host.channelCount()
                            + " channels  |  "
                            + sourceType);
            count.setTextColor(host.silver());
            count.setTextSize(13);
            count.setPadding(0, host.dp(6), 0, host.dp(12));
            statusCard.addView(count);

            LinearLayout actions = new LinearLayout(context);
            actions.setOrientation(LinearLayout.HORIZONTAL);

            Button open = host.smallButton("OPEN");
            open.setOnClickListener(v -> host.openLiveTv());
            actions.addView(open, host.weightedButtonParams());

            if (sourceType.equals("URL") || sourceType.equals("XTREAM")) {
                Button refresh = host.smallButton("REFRESH");
                refresh.setOnClickListener(v -> {
                    if (sourceType.equals("XTREAM")) {
                        host.refreshXtream();
                    } else {
                        host.refreshUrl();
                    }
                });
                actions.addView(refresh, host.weightedButtonParams());
            }

            Button remove = host.smallButton("REMOVE");
            remove.setOnClickListener(v -> host.removePlaylist());
            actions.addView(remove, host.weightedButtonParams());


            statusCard.addView(actions);

            LinearLayout.LayoutParams statusParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);

            statusParams.setMargins(0, 0, 0, host.dp(22));
            root.addView(statusCard, statusParams);
        }

    }
}
