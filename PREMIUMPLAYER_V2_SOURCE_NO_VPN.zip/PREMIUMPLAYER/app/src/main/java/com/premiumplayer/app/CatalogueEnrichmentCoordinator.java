package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

final class CatalogueEnrichmentCoordinator {

    interface Host {

        MovieItem copyMovie(
                MovieItem movie);

        SeriesItem copySeries(
                SeriesItem series);

        JSONObject moviePayload(
                MovieItem movie)
                throws Exception;

        JSONObject seriesPayload(
                SeriesItem series)
                throws Exception;

        JSONObject postBatch(
                JSONArray batch)
                throws Exception;

        void applyResponse(
                String mediaType,
                JSONObject response)
                throws Exception;
    }

    static void enrichAsync(
            final String mediaType,
            ArrayList<MovieItem> movies,
            ArrayList<SeriesItem> seriesList,
            final int batchSize,
            final Host host) {

        final ArrayList<MovieItem> movieCopies =
                new ArrayList<MovieItem>();

        final ArrayList<SeriesItem> seriesCopies =
                new ArrayList<SeriesItem>();

        if (movies != null) {

            for (MovieItem movie : movies) {

                movieCopies.add(
                        host.copyMovie(
                                movie));
            }
        }

        if (seriesList != null) {

            for (SeriesItem series : seriesList) {

                seriesCopies.add(
                        host.copySeries(
                                series));
            }
        }

        new Thread(() -> {

            try {
                JSONArray batch =
                        new JSONArray();

                if ("MOVIES".equals(mediaType)) {

                    for (MovieItem movie
                            : movieCopies) {

                        batch.put(
                                host.moviePayload(
                                        movie));

                        if (batch.length()
                                >= batchSize) {

                            JSONObject response =
                                    host.postBatch(
                                            batch);

                            host.applyResponse(
                                    mediaType,
                                    response);

                            batch =
                                    new JSONArray();
                        }
                    }

                } else {

                    for (SeriesItem series
                            : seriesCopies) {

                        batch.put(
                                host.seriesPayload(
                                        series));

                        if (batch.length()
                                >= batchSize) {

                            JSONObject response =
                                    host.postBatch(
                                            batch);

                            host.applyResponse(
                                    mediaType,
                                    response);

                            batch =
                                    new JSONArray();
                        }
                    }
                }

                if (batch.length() > 0) {

                    JSONObject response =
                            host.postBatch(
                                    batch);

                    host.applyResponse(
                            mediaType,
                            response);
                }

            } catch (Exception ignored) {
            }

        }).start();
    }
}
