package com.premiumplayer.app;

final class PlaybackReleaseCoordinator {

    interface Host {
        void saveResumePosition();
        void stopResumeSaving();

        boolean isFullScreen();
        void restoreWindowLayout();
        void setFullScreen(boolean value);

        void restoreOrientation();
        void showSystemBars();
        void setKeepAwake(boolean keepAwake);

        void releaseEngine();
    }

    static void release(
            Host host) {

        host.saveResumePosition();
        host.stopResumeSaving();

        

        host.setFullScreen(false);

        host.restoreOrientation();
        host.showSystemBars();
        host.setKeepAwake(false);

        host.releaseEngine();
    }
}
