package com.premiumplayer.app;

import android.widget.TextView;

import java.util.ArrayList;

final class LiveTvEpgPresentation {

    interface Host {
        String selectedChannel();
        String safe(String value);

        void setSelectedProgramme(
                String now,
                String next);
    }

    static void apply(
            Host host,
            Channel channel,
            ArrayList<EpgEntry> entries,
            String error,
            TextView programme,
            TextView nextProgramme,
            TextView cardNow,
            TextView cardNext) {

        if (error != null
                || entries == null
                || entries.isEmpty()) {

            showUnavailable(
                    host,
                    channel,
                    programme,
                    nextProgramme,
                    cardNext);

            return;
        }

        int nowIndex = 0;

        for (int i = 0;
             i < entries.size();
             i++) {

            if (entries.get(i).nowPlaying) {
                nowIndex = i;
                break;
            }
        }

        EpgEntry now =
                entries.get(nowIndex);

        EpgEntry next =
                nowIndex + 1 < entries.size()
                        ? entries.get(nowIndex + 1)
                        : null;

        channel.now =
                host.safe(now.title);

        channel.next =
                next == null
                        ? ""
                        : host.safe(next.title);

        if (channel.name.equals(
                host.selectedChannel())) {

            host.setSelectedProgramme(
                    channel.now,
                    channel.next);

            if (programme != null) {
                programme.setText(
                        "NOW  " + channel.now);
            }

            if (nextProgramme != null) {
                nextProgramme.setText(
                        channel.next.isEmpty()
                                ? "NEXT  No further listing"
                                : "NEXT  " + channel.next);
            }
        }

        if (cardNow != null) {
            cardNow.setText(
                    "NOW  " + channel.now);
        }

        if (cardNext != null) {
            cardNext.setText(
                    channel.next.isEmpty()
                            ? "NEXT  No further listing"
                            : "NEXT  " + channel.next);
        }
    }

    private static void showUnavailable(
            Host host,
            Channel channel,
            TextView programme,
            TextView nextProgramme,
            TextView cardNext) {

        if (programme != null
                && channel.name.equals(
                        host.selectedChannel())) {

            programme.setText(
                    host.safe(channel.group));
        }

        if (nextProgramme != null
                && channel.name.equals(
                        host.selectedChannel())) {

            nextProgramme.setText(
                    "EPG unavailable");
        }

        if (cardNext != null) {
            cardNext.setText(
                    "EPG unavailable");
        }
    }
}
