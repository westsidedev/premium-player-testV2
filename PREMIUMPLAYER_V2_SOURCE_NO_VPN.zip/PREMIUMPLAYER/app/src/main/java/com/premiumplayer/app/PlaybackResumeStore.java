package com.premiumplayer.app;

import android.content.SharedPreferences;

import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;

final class PlaybackResumeStore {

    interface Host {
        SimpleExoPlayer player();
        String resumeKey();
        boolean isLive();
        SharedPreferences prefs();
        String title();

        void clear(String key);
    }

    static void save(
            Host host) {

        SimpleExoPlayer player =
                host.player();

        String key =
                host.resumeKey();

        if (player == null
                || key == null
                || key.isEmpty()
                || host.isLive()) {
            return;
        }

        try {
            long position =
                    player.getCurrentPosition();

            long duration =
                    player.getDuration();

            if (player.getPlaybackState()
                    == Player.STATE_ENDED) {

                host.clear(key);
                return;
            }

            boolean nearEnd =
                    duration > 0L
                            && duration != C.TIME_UNSET
                            && (duration - position < 60000L
                            || position >= (long) (duration * 0.95d));

            if (nearEnd) {
                host.clear(key);
                return;
            }

            if (position < 30000L) {
                return;
            }

            host.prefs()
                    .edit()
                    .putLong(
                            key + "_position",
                            position)
                    .putLong(
                            key + "_duration",
                            duration > 0L
                                    && duration != C.TIME_UNSET
                                    ? duration
                                    : 0L)
                    .putString(
                            key + "_title",
                            safe(host.title()))
                    .putLong(
                            key + "_last_watched",
                            System.currentTimeMillis())
                    .apply();

        } catch (Exception ignored) {
        }
    }

    private static String safe(
            String value) {

        return value == null
                ? ""
                : value;
    }
}
