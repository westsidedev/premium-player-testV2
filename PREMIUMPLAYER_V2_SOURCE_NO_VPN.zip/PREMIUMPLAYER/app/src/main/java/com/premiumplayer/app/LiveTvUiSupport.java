package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

final class LiveTvUiSupport {

    interface Host {
        int dp(int value);
        int gold();
        int charcoal();
        void tvReady(View view);
        Drawable background(int fill, int border, int radius);
        String safe(String value);
    }

    static LinearLayout.LayoutParams listParams(
            Host host,
            int height) {

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        height);

        params.setMargins(
                0,
                0,
                0,
                host.dp(5));

        return params;
    }

    static TextView categoryItem(
            Context context,
            Host host,
            String category,
            boolean selected) {

        TextView item = new TextView(context);

        item.setText(category);
        item.setTextColor(Color.WHITE);
        item.setTextSize(13);
        item.setGravity(Gravity.CENTER_VERTICAL);

        item.setPadding(
                host.dp(12),
                host.dp(7),
                host.dp(10),
                host.dp(7));

        item.setTag(category);
        host.tvReady(item);

        item.setBackground(
                host.background(
                        selected
                                ? Color.rgb(35, 31, 23)
                                : host.charcoal(),
                        selected
                                ? host.gold()
                                : Color.rgb(52, 52, 56),
                        10));

        return item;
    }

    static void updateCategoryHighlight(
            Host host,
            LinearLayout container,
            String selectedCategory) {

        for (int i = 0;
             i < container.getChildCount();
             i++) {

            View child = container.getChildAt(i);

            boolean selected =
                    selectedCategory.equals(
                            host.safe(
                                    String.valueOf(
                                            child.getTag())));

            child.setBackground(
                    host.background(
                            selected
                                    ? Color.rgb(35, 31, 23)
                                    : host.charcoal(),
                            selected
                                    ? host.gold()
                                    : Color.rgb(52, 52, 56),
                            10));
        }
    }
}
