package com.premiumplayer.app;

import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import java.util.HashSet;

final class CatalogueRefreshCommit {

    interface Guard {
        void check() throws Exception;
    }

    interface Writer {
        void write(
                CatalogueRefreshBatch.Entry entry,
                long generation) throws Exception;
    }

    static final class Result {
        long newMovies;
        long changedMovies;
        long newSeries;
        long changedSeries;
        long totalMovies;
        long totalSeries;

        String summary() {
            return "New movies: " + newMovies
                    + "\nUpdated movies: " + changedMovies
                    + "\nNew series: " + newSeries
                    + "\nUpdated series: " + changedSeries
                    + "\n\nTotal movies: " + totalMovies
                    + "\nTotal series: " + totalSeries
                    + "\n\nChanges committed successfully.";
        }
    }

    private static long count(
            SQLiteDatabase db,
            String table,
            String providerKey,
            long generation) {

        return DatabaseUtils.longForQuery(db,
                "SELECT COUNT(*) FROM " + table
                + " WHERE provider_key=? AND import_generation=?",
                new String[]{providerKey, Long.toString(generation)});
    }

    static Result apply(
            SQLiteDatabase db,
            String providerKey,
            CatalogueRefreshBatch batch,
            Guard guard,
            Writer writer) throws Exception {

        if (db == null || db.isReadOnly()
                || providerKey == null || providerKey.isEmpty()
                || batch == null || guard == null || writer == null
                || batch.entries.size() > 500) {
            throw new IllegalArgumentException(
                    "Invalid refresh transaction");
        }

        guard.check();

        if (db.inTransaction()) {
            throw new IllegalStateException(
                    "Another database transaction is active");
        }

        Result result = new Result();

        db.beginTransaction();

        try {
            Cursor journal = db.rawQuery(
                    "SELECT generation,state,movies_done,series_done "
                    + "FROM catalogue_rebuild_journal "
                    + "WHERE provider_key=?",
                    new String[]{providerKey});

            long generation;
            long expectedMovies;
            long expectedSeries;
            String state;

            try {
                if (!journal.moveToFirst()) {
                    throw new IllegalStateException(
                            "Validated rebuild journal missing");
                }

                generation = journal.getLong(0);
                state = journal.getString(1);
                expectedMovies = journal.getLong(2);
                expectedSeries = journal.getLong(3);
            } finally {
                journal.close();
            }

            if (!"VALIDATED".equals(state) || generation <= 0L) {
                throw new IllegalStateException(
                        "Catalogue not in validated state");
            }

            if (count(db, "catalogue_movies",
                    providerKey, generation) != expectedMovies
                    || count(db, "catalogue_series",
                    providerKey, generation) != expectedSeries) {
                throw new IllegalStateException(
                        "Catalogue counts changed since validation");
            }

            HashSet<String> seen = new HashSet<>();

            for (CatalogueRefreshBatch.Entry entry : batch.entries) {
                guard.check();

                String table = entry.movie
                        ? "catalogue_movies" : "catalogue_series";

                String identity = (entry.movie ? "M:" : "S:")
                        + entry.id;

                if (!seen.add(identity)) {
                    throw new IllegalStateException(
                            "Duplicate refresh record");
                }

                int classification = CatalogueRefreshDiff.compare(
                        db, entry.movie, providerKey,
                        entry.id, entry.json);

                boolean isNew =
                        classification == CatalogueRefreshDiff.NEW;

                if (isNew != entry.isNew) {
                    throw new IllegalStateException(
                            "Catalogue changed during refresh preparation");
                }

                if (classification != CatalogueRefreshDiff.NEW
                        && classification != CatalogueRefreshDiff.CHANGED) {
                    throw new IllegalStateException(
                            "Staged record no longer requires updating");
                }

                if (!isNew) {
                    long existingGeneration =
                            DatabaseUtils.longForQuery(
                                    db,
                                    "SELECT COALESCE(import_generation,0)"
                                    + " FROM " + table
                                    + " WHERE pk=? AND provider_key=?",
                                    new String[]{
                                            providerKey + "|" + entry.id,
                                            providerKey
                                    });

                    if (existingGeneration != generation) {
                        throw new IllegalStateException(
                                "Existing record generation mismatch");
                    }
                }

                writer.write(entry, isNew ? generation : 0L);

                if (entry.movie) {
                    if (isNew) result.newMovies++;
                    else result.changedMovies++;
                } else {
                    if (isNew) result.newSeries++;
                    else result.changedSeries++;
                }
            }

            guard.check();

            result.totalMovies = count(
                    db, "catalogue_movies", providerKey, generation);
            result.totalSeries = count(
                    db, "catalogue_series", providerKey, generation);

            if (result.totalMovies != expectedMovies + result.newMovies
                    || result.totalSeries != expectedSeries + result.newSeries) {
                throw new IllegalStateException(
                        "Refresh totals do not match expected counts");
            }

            CatalogueRebuildJournal.progress(
                    db, providerKey, generation, "VALIDATED",
                    result.totalMovies, result.totalSeries);

            db.setTransactionSuccessful();

        } finally {
            db.endTransaction();
        }

        return result;
    }
}
