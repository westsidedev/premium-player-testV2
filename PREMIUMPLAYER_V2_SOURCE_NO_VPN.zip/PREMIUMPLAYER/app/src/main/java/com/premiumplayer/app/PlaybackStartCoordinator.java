package com.premiumplayer.app;

import android.content.Context;

import com.google.android.exoplayer2.SimpleExoPlayer;

final class PlaybackStartCoordinator {

    interface Host {
        void releasePlayer();
        void setKeepAwake(boolean keepAwake);

        void bindEngine(
                PlaybackEngineFactory.Result engine);

        void attachEvents(
                SimpleExoPlayer player,
                PlaybackProbe probe,
                String preferredLanguage);

        long resumeStartPosition();

        int candidateIndex();
        int candidateCount();
        void incrementCandidateIndex();

        void retry(String preferredLanguage);

        void setStatus(String text);
        String errorMessage(Exception error);
    }

    static void start(
            Context context,
            Host host,
            PlaybackProbe probe,
            String preferredLanguage) {

        try {
            host.releasePlayer();
            host.setKeepAwake(true);

            PlaybackEngineFactory.Result engine =
                    PlaybackEngineFactory.create(
                            context,
                            probe.url,
                            probe.hls,
                            preferredLanguage);

            host.bindEngine(engine);

            host.attachEvents(
                    engine.player,
                    probe,
                    preferredLanguage);

            engine.player.setMediaSource(
                    engine.mediaSource);

            engine.player.prepare();

            long resumePosition =
                    host.resumeStartPosition();

            if (resumePosition >= 30000L) {
                engine.player.seekTo(
                        resumePosition);
            }

            engine.player.setPlayWhenReady(true);

        } catch (Exception error) {

            if (host.candidateIndex() + 1
                    < host.candidateCount()) {

                host.incrementCandidateIndex();

                host.retry(
                        preferredLanguage);

            } else {

                host.setKeepAwake(false);

                host.setStatus(
                        "Could not start player: "
                                + host.errorMessage(error));
            }
        }
    }
}
