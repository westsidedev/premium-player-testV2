package com.premiumplayer.app;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

final class ProviderCatalogueFullSync {

    private ProviderCatalogueFullSync() {
    }

    static void sync(
            SQLiteDatabase db,
            String providerKey,
            String backendBaseUrl,
            String publishableKey)
            throws Exception {

        if (db == null
                || providerKey == null
                || providerKey.trim().isEmpty()) {
            return;
        }

        String sourceKey =
                "pp-"
                        + providerKey
                        + "-"
                        + providerKey
                        + "-v1";

        if (hasRows(db, "catalogue_movies", providerKey)) {
            syncType(
                    db,
                    providerKey,
                    sourceKey,
                    "movie",
                    backendBaseUrl,
                    publishableKey);
        }

        if (hasRows(db, "catalogue_series", providerKey)) {
            syncType(
                    db,
                    providerKey,
                    sourceKey,
                    "series",
                    backendBaseUrl,
                    publishableKey);
        }
    }

    static boolean hasInventory(
            SQLiteDatabase db,
            String providerKey) {

        return hasRows(db, "catalogue_movies", providerKey)
                || hasRows(db, "catalogue_series", providerKey);
    }

    private static boolean hasRows(
            SQLiteDatabase db,
            String table,
            String providerKey) {

        Cursor cursor = null;

        try {
            cursor = db.rawQuery(
                    "SELECT 1 FROM " + table
                            + " WHERE provider_key=? LIMIT 1",
                    new String[]{providerKey});

            return cursor.moveToFirst();

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static void syncType(
            SQLiteDatabase db,
            String providerKey,
            String sourceKey,
            String mediaType,
            String backendBaseUrl,
            String publishableKey)
            throws Exception {

        JSONObject start =
                new JSONObject();

        start.put(
                "mode",
                "start");

        start.put(
                "source_key",
                sourceKey);

        start.put(
                "media_type",
                mediaType);

        JSONObject startResponse =
                post(
                        backendBaseUrl,
                        publishableKey,
                        start);

        String syncToken =
                startResponse.optString(
                        "sync_token",
                        "");

        if (syncToken.isEmpty()) {
            throw new Exception(
                    "No sync token returned");
        }

        Cursor cursor =
                null;

        try {

            if ("movie".equals(mediaType)) {

                cursor =
                        db.query(
                                "catalogue_movies",
                                new String[]{
                                        "stream_id",
                                        "name",
                                        "year",
                                        "category_id",
                                        "icon",
                                        "extension"
                                },
                                "provider_key=?",
                                new String[]{
                                        providerKey
                                },
                                null,
                                null,
                                null);

            } else {

                cursor =
                        db.query(
                                "catalogue_series",
                                new String[]{
                                        "series_id",
                                        "name",
                                        "year",
                                        "category_id",
                                        "cover"
                                },
                                "provider_key=?",
                                new String[]{
                                        providerKey
                                },
                                null,
                                null,
                                null);
            }

            JSONArray batch =
                    new JSONArray();

            while (cursor != null
                    && cursor.moveToNext()) {

                String id =
                        safe(
                                cursor.getString(0));

                String title =
                        safe(
                                cursor.getString(1));

                if (id.isEmpty()
                        || title.isEmpty()) {
                    continue;
                }

                JSONObject item =
                        new JSONObject();

                item.put(
                        "provider_item_id",
                        id);

                item.put(
                        "provider_title",
                        title);

                item.put(
                        "year",
                        safe(cursor.getString(2)));

                item.put(
                        "category_id",
                        safe(cursor.getString(3)));

                item.put(
                        "cover",
                        safe(cursor.getString(4)));

                if ("movie".equals(mediaType)) {

                    item.put(
                            "container_extension",
                            safe(cursor.getString(5)));
                }

                batch.put(
                        item);

                if (batch.length() >= 500) {

                    sendBatch(
                            backendBaseUrl,
                            publishableKey,
                            sourceKey,
                            syncToken,
                            batch);

                    batch =
                            new JSONArray();
                }
            }

            if (batch.length() > 0) {

                sendBatch(
                        backendBaseUrl,
                        publishableKey,
                        sourceKey,
                        syncToken,
                        batch);
            }

        } finally {

            if (cursor != null) {
                cursor.close();
            }
        }

        JSONObject finish =
                new JSONObject();

        finish.put(
                "mode",
                "finish");

        finish.put(
                "source_key",
                sourceKey);

        finish.put(
                "sync_token",
                syncToken);

        post(
                backendBaseUrl,
                publishableKey,
                finish);
    }

    private static void sendBatch(
            String backendBaseUrl,
            String publishableKey,
            String sourceKey,
            String syncToken,
            JSONArray items)
            throws Exception {

        JSONObject body =
                new JSONObject();

        body.put(
                "mode",
                "batch");

        body.put(
                "source_key",
                sourceKey);

        body.put(
                "sync_token",
                syncToken);

        body.put(
                "items",
                items);

        post(
                backendBaseUrl,
                publishableKey,
                body);
    }

    private static JSONObject post(
            String backendBaseUrl,
            String publishableKey,
            JSONObject body)
            throws Exception {

        HttpURLConnection connection =
                null;

        try {

            URL url =
                    new URL(
                            backendBaseUrl
                                    + "/catalogue-full-sync");

            connection =
                    (HttpURLConnection)
                            url.openConnection();

            connection.setRequestMethod(
                    "POST");

            connection.setConnectTimeout(
                    15000);

            connection.setReadTimeout(
                    45000);

            connection.setDoOutput(
                    true);

            connection.setRequestProperty(
                    "Content-Type",
                    "application/json");

            connection.setRequestProperty(
                    "apikey",
                    publishableKey);

            OutputStream output =
                    connection.getOutputStream();

            output.write(
                    body.toString()
                            .getBytes("UTF-8"));

            output.flush();
            output.close();

            int code =
                    connection.getResponseCode();

            InputStream input =
                    code >= 200 && code < 300
                            ? connection.getInputStream()
                            : connection.getErrorStream();

            StringBuilder response =
                    new StringBuilder();

            if (input != null) {

                BufferedReader reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        input,
                                        "UTF-8"));

                String line;

                while ((line = reader.readLine())
                        != null) {

                    response.append(
                            line);
                }

                reader.close();
            }

            if (code < 200
                    || code >= 300) {

                throw new Exception(
                        "catalogue-full-sync HTTP "
                                + code
                                + " "
                                + response);
            }

            return response.length() == 0
                    ? new JSONObject()
                    : new JSONObject(
                            response.toString());

        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private static String safe(
            String value) {

        return value == null
                ? ""
                : value.trim();
    }
}
