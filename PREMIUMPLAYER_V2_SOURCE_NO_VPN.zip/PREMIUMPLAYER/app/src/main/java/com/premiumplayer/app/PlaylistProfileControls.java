package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

final class PlaylistProfileControls {

    interface Host {
        String activeId();
        String createProfile();
        void switchProfile(String id);
        String profileName(String id);
        void setProfileName(String id, String name);
        ArrayList<String> profileIds();
        void deleteActive();
        Button smallButton(String text);
        Drawable background(int fill, int border, int radius);
        void showPlaylists();
        int dp(int value);
        int gold();
        int black();
        int charcoal();
    }

    static void add(
            Context context,
            Host host,
            LinearLayout root) {
        Button addProfile = host.smallButton("+  ADD NEW PLAYLIST");
        addProfile.setBackground(host.background(host.gold(), host.gold(), 12));
        addProfile.setTextColor(host.black());
        addProfile.setOnClickListener(v -> {
            String newId = host.createProfile();
            host.switchProfile(newId);
        });
        LinearLayout.LayoutParams addProfileParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, host.dp(50));
        addProfileParams.setMargins(0, 0, 0, host.dp(12));
        root.addView(addProfile, addProfileParams);

        EditText profileNameInput = new EditText(context);
        profileNameInput.setHint("Custom playlist name / username");
        profileNameInput.setHintTextColor(Color.rgb(120, 120, 125));
        profileNameInput.setTextColor(Color.WHITE);
        profileNameInput.setText(host.profileName(host.activeId()));
        profileNameInput.setSingleLine(true);
        profileNameInput.setPadding(host.dp(14), host.dp(10), host.dp(14), host.dp(10));
        profileNameInput.setBackground(host.background(host.charcoal(), Color.rgb(55, 55, 58), 12));
        root.addView(profileNameInput,
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, host.dp(50)));

        Button saveProfileName = host.smallButton("SAVE PLAYLIST NAME");
        saveProfileName.setOnClickListener(v -> {
            String newName = profileNameInput.getText().toString().trim();
            if (newName.isEmpty()) {
                Toast.makeText(context, "Enter a playlist name first.", Toast.LENGTH_SHORT).show();
                return;
            }
            host.setProfileName(host.activeId(), newName);
            Toast.makeText(context, "Playlist name saved.", Toast.LENGTH_SHORT).show();
            host.showPlaylists();
        });
        LinearLayout.LayoutParams saveNameParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, host.dp(48));
        saveNameParams.setMargins(0, host.dp(7), 0, host.dp(20));
        root.addView(saveProfileName, saveNameParams);

        if (host.profileIds().size() > 1) {
            Button deleteActiveProfile = host.smallButton("DELETE ACTIVE PLAYLIST PROFILE");
            deleteActiveProfile.setOnClickListener(v -> host.deleteActive());
            LinearLayout.LayoutParams deleteActiveParams =
                    new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, host.dp(48));
            deleteActiveParams.setMargins(0, 0, 0, host.dp(20));
            root.addView(deleteActiveProfile, deleteActiveParams);
        }

    }
}
