package com.premiumplayer.app;

import android.content.Context;
import android.view.View;

import com.google.android.exoplayer2.ui.PlayerView;

final class LiveTvTransportControls {

    interface Host {
        boolean isLive();
        void switchChannel(int direction);
    }

    static void configure(
            Context context,
            Host host,
            PlayerView playerView) {

        if (playerView == null || !host.isLive()) {
            return;
        }

        playerView.post(() -> {

            View previous =
                    findControl(
                            context,
                            playerView,
                            "exo_prev");

            View rewind =
                    findControl(
                            context,
                            playerView,
                            "exo_rew");

            View fastForward =
                    findControl(
                            context,
                            playerView,
                            "exo_ffwd");

            View next =
                    findControl(
                            context,
                            playerView,
                            "exo_next");

            if (previous != null) {

                previous.setVisibility(View.VISIBLE);
                previous.setEnabled(true);
                previous.setClickable(true);
                previous.setFocusable(true);

                previous.setContentDescription(
                        "Previous channel");

                previous.setOnClickListener(
                        v -> host.switchChannel(-1));

                if (rewind != null) {
                    rewind.setVisibility(View.GONE);
                }

            } else if (rewind != null) {

                rewind.setVisibility(View.VISIBLE);
                rewind.setEnabled(true);
                rewind.setClickable(true);
                rewind.setFocusable(true);

                rewind.setContentDescription(
                        "Previous channel");

                rewind.setOnClickListener(
                        v -> host.switchChannel(-1));
            }

            if (next != null) {

                next.setVisibility(View.VISIBLE);
                next.setEnabled(true);
                next.setClickable(true);
                next.setFocusable(true);

                next.setContentDescription(
                        "Next channel");

                next.setOnClickListener(
                        v -> host.switchChannel(1));

                if (fastForward != null) {
                    fastForward.setVisibility(View.GONE);
                }

            } else if (fastForward != null) {

                fastForward.setVisibility(View.VISIBLE);
                fastForward.setEnabled(true);
                fastForward.setClickable(true);
                fastForward.setFocusable(true);

                fastForward.setContentDescription(
                        "Next channel");

                fastForward.setOnClickListener(
                        v -> host.switchChannel(1));
            }
        });
    }

    private static View findControl(
            Context context,
            PlayerView playerView,
            String resourceName) {

        if (playerView == null
                || resourceName == null
                || resourceName.isEmpty()) {
            return null;
        }

        int resourceId =
                context.getResources()
                        .getIdentifier(
                                resourceName,
                                "id",
                                context.getPackageName());

        if (resourceId == 0) {
            return null;
        }

        return playerView.findViewById(
                resourceId);
    }
}
