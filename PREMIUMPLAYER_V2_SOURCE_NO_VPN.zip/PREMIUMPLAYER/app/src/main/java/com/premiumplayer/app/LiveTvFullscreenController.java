package com.premiumplayer.app;

final class LiveTvFullscreenController {

    interface Host {
        void setLiveBrowserMode(boolean enabled);
        void showPlayerScreen();

        boolean hasActivePlayerScreen();

        void postToPlayerScreen(
                Runnable action,
                long delayMs);

        boolean shouldEnterFullscreen();
        void enterFullscreen();
    }

    static void open(Host host) {

        host.setLiveBrowserMode(false);
        host.showPlayerScreen();

        if (!host.hasActivePlayerScreen()) {
            return;
        }

        host.postToPlayerScreen(
                () -> {
                    if (host.shouldEnterFullscreen()) {
                        host.enterFullscreen();
                    }
                },
                120);
    }
}
