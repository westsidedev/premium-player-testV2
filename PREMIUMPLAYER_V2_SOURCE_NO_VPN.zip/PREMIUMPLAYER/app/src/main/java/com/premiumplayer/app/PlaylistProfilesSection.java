package com.premiumplayer.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

final class PlaylistProfilesSection {

    interface Host {
        String activeId();
        ArrayList<String> profileIds();
        String profileName(String id);
        SharedPreferences prefs(String id);
        Button smallButton(String text);
        Drawable background(int fill, int border, int radius);
        void switchProfile(String id);
        int dp(int value);
        int gold();
        int silver();
        int charcoal();
    }

    static void add(
            Context context,
            Host host,
            LinearLayout root) {
        TextView profilesHeading = new TextView(context);
        profilesHeading.setText("PLAYLIST PROFILES");
        profilesHeading.setTextColor(host.gold());
        profilesHeading.setTextSize(12);
        profilesHeading.setLetterSpacing(0.12f);
        profilesHeading.setPadding(0, 0, 0, host.dp(10));
        root.addView(profilesHeading);

        ArrayList<String> profileIds = host.profileIds();
        for (String profileId : profileIds) {
            final String targetProfileId = profileId;
            boolean active = profileId.equals(host.activeId());

            LinearLayout profileCard = new LinearLayout(context);
            profileCard.setOrientation(LinearLayout.HORIZONTAL);
            profileCard.setGravity(Gravity.CENTER_VERTICAL);
            profileCard.setPadding(host.dp(14), host.dp(10), host.dp(10), host.dp(10));
            profileCard.setBackground(host.background(
                    active ? Color.rgb(35, 31, 23) : host.charcoal(),
                    active ? host.gold() : Color.rgb(55, 55, 58),
                    12));

            LinearLayout profileText = new LinearLayout(context);
            profileText.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams profileTextParams =
                    new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

            TextView profileName = new TextView(context);
            profileName.setText(host.profileName(profileId) + (active ? "   •   ACTIVE" : ""));
            profileName.setTextColor(Color.WHITE);
            profileName.setTextSize(15);
            profileName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            profileText.addView(profileName);

            String source = host.prefs(profileId).getString("playlist_source_type", "EMPTY");
            TextView profileInfo = new TextView(context);
            profileInfo.setText(source == null || source.trim().isEmpty() ? "EMPTY" : source);
            profileInfo.setTextColor(host.silver());
            profileInfo.setTextSize(11);
            profileInfo.setPadding(0, host.dp(3), 0, 0);
            profileText.addView(profileInfo);
            profileCard.addView(profileText, profileTextParams);

            Button switchButton = host.smallButton(active ? "SELECTED" : "SWITCH");
            switchButton.setEnabled(!active);
            switchButton.setOnClickListener(v -> host.switchProfile(targetProfileId));
            LinearLayout.LayoutParams switchParams = new LinearLayout.LayoutParams(host.dp(108), host.dp(44));
            profileCard.addView(switchButton, switchParams);

            LinearLayout.LayoutParams profileCardParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);
            profileCardParams.setMargins(0, 0, 0, host.dp(8));
            root.addView(profileCard, profileCardParams);
        }

    }
}
