package com.premiumplayer.app;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

final class VpnPublicIpLookup {

    interface Callback {
        void onResult(
                String ip,
                String error);
    }

    interface Host {

        void runUi(
                Runnable action);

        String errorMessage(
                Exception error);
    }

    static void fetch(
            final Host host,
            final Callback callback) {

        new Thread(
                () -> {

                    String ip = null;
                    String error = null;

                    String[] endpoints = {
                            "https://api.ipify.org",
                            "https://icanhazip.com"
                    };

                    for (String endpoint : endpoints) {

                        HttpURLConnection connection =
                                null;

                        try {

                            URL url =
                                    new URL(endpoint);

                            connection =
                                    (HttpURLConnection)
                                            url.openConnection();

                            connection.setConnectTimeout(
                                    7000);

                            connection.setReadTimeout(
                                    7000);

                            connection.setRequestProperty(
                                    "User-Agent",
                                    "PREMIUM-PLAYER");

                            BufferedReader reader =
                                    new BufferedReader(
                                            new InputStreamReader(
                                                    connection
                                                            .getInputStream()));

                            String line =
                                    reader.readLine();

                            reader.close();

                            if (line != null
                                    && line.trim()
                                    .isEmpty() == false) {

                                ip =
                                        line.trim();

                                break;
                            }

                        } catch (Exception e) {

                            error =
                                    host.errorMessage(
                                            e);

                        } finally {

                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                    }

                    final String resultIp =
                            ip;

                    final String resultError =
                            ip == null
                                    ? (error == null
                                    ? "No IP response"
                                    : error)
                                    : null;

                    host.runUi(
                            () ->
                                    callback.onResult(
                                            resultIp,
                                            resultError));
                })
                .start();
    }
}
