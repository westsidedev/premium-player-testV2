package com.premiumplayer.app;

import android.database.Cursor;

final class MediaItemMapper {

    static MovieItem copyMovie(
            MovieItem source) {

        MovieItem copy =
                new MovieItem();

        if (source == null) {
            return copy;
        }

        copy.name =
                source.name;
        copy.rawJson = source.rawJson;
        copy.importGeneration = source.importGeneration;

        copy.categoryId =
                source.categoryId;

        copy.streamId =
                source.streamId;

        copy.extension =
                source.extension;

        copy.directSource =
                source.directSource;

        copy.rating =
                source.rating;

        copy.year =
                source.year;
        copy.addedAt = source.addedAt;

        copy.icon =
                source.icon;

        copy.plot =
                source.plot;

        copy.cast =
                source.cast;

        copy.director =
                source.director;

        copy.genre =
                source.genre;

        copy.trailer =
                source.trailer;

        copy.duration =
                source.duration;

        copy.detailsLoaded =
                source.detailsLoaded;

        copy.detailsLoading =
                false;

        return copy;
    }

    static SeriesItem copySeries(
            SeriesItem source) {

        SeriesItem copy =
                new SeriesItem();

        if (source == null) {
            return copy;
        }

        copy.name =
                source.name;
        copy.rawJson = source.rawJson;
        copy.importGeneration = source.importGeneration;

        copy.categoryId =
                source.categoryId;

        copy.seriesId =
                source.seriesId;

        copy.rating =
                source.rating;

        copy.year =
                source.year;
        copy.addedAt = source.addedAt;
        copy.updatedAt = source.updatedAt;

        copy.plot =
                source.plot;

        copy.cover =
                source.cover;

        copy.cast =
                source.cast;

        copy.director =
                source.director;

        copy.genre =
                source.genre;

        copy.trailer =
                source.trailer;

        copy.detailsLoaded =
                source.detailsLoaded;

        copy.detailsLoading =
                false;

        return copy;
    }

    interface CursorHost {
        String sanitizeExtension(
                String extension);
    }

    static MovieItem movieFromCursor(
            Cursor cursor,
            CursorHost host) {

        MovieItem movie =
                new MovieItem();

        if (cursor == null) {
            return movie;
        }

        movie.streamId =
                cursor.getString(0);

        movie.name =
                cursor.getString(1);

        movie.categoryId =
                cursor.getString(2);

        movie.extension =
                host.sanitizeExtension(
                        cursor.getString(3));

        movie.directSource =
                cursor.getString(4);

        movie.rating =
                cursor.getString(5);

        movie.year =
                cursor.getString(6);

        movie.icon =
                cursor.getString(7);

        movie.plot =
                cursor.getString(8);

        movie.cast =
                cursor.getString(9);

        movie.director =
                cursor.getString(10);

        movie.genre =
                cursor.getString(11);

        movie.trailer =
                cursor.getString(12);

        movie.duration =
                cursor.getString(13);

        return movie;
    }

    static SeriesItem seriesFromCursor(
            Cursor cursor) {

        SeriesItem series =
                new SeriesItem();

        if (cursor == null) {
            return series;
        }

        series.seriesId =
                cursor.getString(0);

        series.name =
                cursor.getString(1);

        series.categoryId =
                cursor.getString(2);

        series.rating =
                cursor.getString(3);

        series.year =
                cursor.getString(4);

        series.cover =
                cursor.getString(5);

        series.plot =
                cursor.getString(6);

        series.cast =
                cursor.getString(7);

        series.director =
                cursor.getString(8);

        series.genre =
                cursor.getString(9);

        series.trailer =
                cursor.getString(10);

        return series;
    }
}
