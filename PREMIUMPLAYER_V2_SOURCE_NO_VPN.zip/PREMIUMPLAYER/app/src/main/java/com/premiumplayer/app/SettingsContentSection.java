package com.premiumplayer.app;

import android.content.Context;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class SettingsContentSection {

    interface Host {
        Button smallButton(String text);
        void showChannelEditor();
        void showCategoryManager(String type);
        int dp(int value);
        int gold();
        int silver();
    }

    static void add(Context context, Host host, LinearLayout root) {

        TextView manageSection = new TextView(context);
        manageSection.setText("CONTENT MANAGEMENT");
        manageSection.setTextColor(host.gold());
        manageSection.setTextSize(12);
        manageSection.setLetterSpacing(0.12f);
        manageSection.setPadding(
                0,
                host.dp(26),
                0,
                host.dp(10));

        root.addView(manageSection);

        TextView manageHelp = new TextView(context);
        manageHelp.setText(
                "Choose which provider categories and channels appear, "
                        + "and move your favourites to the top. "
                        + "Press OK on an item to check or uncheck it.");
        manageHelp.setTextColor(host.silver());
        manageHelp.setTextSize(13);
        manageHelp.setPadding(
                0,
                0,
                0,
                host.dp(14));

        root.addView(manageHelp);

        String[][] managers = {
                {"LIVE TV CATEGORIES", "LIVE"},
                {"CHANNEL EDITOR", "CHANNELS"},
                {"MOVIE CATEGORIES", "MOVIES"},
                {"SERIES CATEGORIES", "SERIES"}
        };

        for (String[] manager : managers) {

            Button manageButton =
                    host.smallButton(manager[0]);

            manageButton.setTextSize(13);

            final String managerType =
                    manager[1];

            manageButton.setOnClickListener(v -> {
                if (managerType.equals("CHANNELS")) {
                    host.showChannelEditor();
                } else {
                    host.showCategoryManager(managerType);
                }
            });

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            host.dp(52));

            params.setMargins(
                    0,
                    0,
                    0,
                    host.dp(9));

            root.addView(
                    manageButton,
                    params);
        }
    }
}
