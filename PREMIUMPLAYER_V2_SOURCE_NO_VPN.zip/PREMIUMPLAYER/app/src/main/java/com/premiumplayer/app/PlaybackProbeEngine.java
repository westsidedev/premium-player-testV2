package com.premiumplayer.app;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

final class PlaybackProbeEngine {

    static PlaybackProbe probe(
            String candidate) {

        String current =
                candidate;

        for (int redirectCount = 0;
             redirectCount < 6;
             redirectCount++) {

            HttpURLConnection connection =
                    null;

            try {
                URL url =
                        new URL(current);

                connection =
                        (HttpURLConnection)
                                url.openConnection();

                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setRequestMethod("GET");
                connection.setUseCaches(false);

                connection.setRequestProperty(
                        "User-Agent",
                        "VLC/3.0.21 LibVLC/3.0.21");

                connection.setRequestProperty(
                        "Accept",
                        "*/*");

                connection.setRequestProperty(
                        "Connection",
                        "close");

                int status =
                        connection.getResponseCode();

                if (status == HttpURLConnection.HTTP_MOVED_PERM
                        || status == HttpURLConnection.HTTP_MOVED_TEMP
                        || status == HttpURLConnection.HTTP_SEE_OTHER
                        || status == 307
                        || status == 308) {

                    String location =
                            connection.getHeaderField(
                                    "Location");

                    if (location == null
                            || location.trim().isEmpty()) {

                        return PlaybackProbe.fail(
                                "HTTP "
                                        + status
                                        + " redirect without Location");
                    }

                    current =
                            new URL(
                                    url,
                                    location)
                                    .toString();

                    continue;
                }

                if (status < 200
                        || status >= 300) {

                    return PlaybackProbe.fail(
                            "HTTP " + status);
                }

                String contentType =
                        safe(
                                connection.getContentType())
                                .toLowerCase(
                                        Locale.US);

                InputStream input =
                        connection.getInputStream();

                byte[] sample =
                        new byte[512];

                int read =
                        input.read(sample);

                input.close();

                String firstText = "";

                if (read > 0) {
                    try {
                        firstText =
                                new String(
                                        sample,
                                        0,
                                        read,
                                        "UTF-8")
                                        .trim();

                    } catch (Exception ignored) {
                    }
                }

                boolean looksHls =
                        contentType.contains("mpegurl")
                                || contentType.contains("m3u8")
                                || current
                                .toLowerCase(Locale.US)
                                .contains(".m3u8")
                                || firstText.startsWith("#EXTM3U");

                boolean looksHtml =
                        contentType.contains("text/html")
                                || firstText.startsWith("<html")
                                || firstText.startsWith("<!DOCTYPE html")
                                || firstText.startsWith("<!doctype html");

                if (looksHtml) {
                    return PlaybackProbe.fail(
                            "HTTP 200 but server returned HTML instead of video");
                }

                return PlaybackProbe.ok(
                        current,
                        looksHls,
                        contentType.isEmpty()
                                ? "unknown content type"
                                : contentType);

            } catch (Exception e) {

                return PlaybackProbe.fail(
                        errorMessage(e));

            } finally {

                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        return PlaybackProbe.fail(
                "Too many redirects");
    }

    private static String safe(
            String value) {

        return value == null
                ? ""
                : value;
    }

    private static String errorMessage(
            Exception error) {

        if (error == null) {
            return "Unknown error";
        }

        String message =
                error.getMessage();

        if (message == null
                || message.trim().isEmpty()) {

            return error
                    .getClass()
                    .getSimpleName();
        }

        return message;
    }
}
