package com.premiumplayer.app;

import android.content.Intent;

final class EmbeddedVpnConnectionCoordinator {

    interface Completion {
        void complete(
                boolean success,
                String message);
    }

    interface Host {

        void ensureManager();

        boolean isConfigured();

        Intent preparePermission();

        void setPendingAction(
                Runnable action);

        void launchPermission(
                Intent permission)
                throws Exception;

        void connect(
                Completion completion);

        void runUi(
                Runnable action);

        void setEnabled(
                boolean enabled);

        void showMessage(
                String message);

        String errorMessage(
                Exception error);
    }

    static void connect(
            final boolean showErrors,
            final Runnable onConnected,
            final Host host) {

        host.ensureManager();

        if (host.isConfigured() == false) {

            if (showErrors) {
                host.showMessage(
                        "No Proton WireGuard config is installed yet. "
                                + "Import a .conf or replace "
                                + "assets/proton_wireguard.conf.");
            }

            return;
        }

        Intent permission =
                host.preparePermission();

        if (permission != null) {

            host.setPendingAction(
                    onConnected);

            try {
                host.launchPermission(
                        permission);

            } catch (Exception error) {

                if (showErrors) {
                    host.showMessage(
                            "Could not open Android VPN permission: "
                                    + host.errorMessage(
                                    error));
                }
            }

            return;
        }

        host.connect(
                (success, message) ->
                        host.runUi(
                                () -> {

                                    if (success) {

                                        host.setEnabled(
                                                true);

                                        if (onConnected != null) {
                                            onConnected.run();
                                        }

                                    } else if (showErrors) {

                                        host.showMessage(
                                                "WireGuard connection failed: "
                                                        + message);
                                    }
                                }));
    }
}
