package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

final class MediaCategoryFallbackParser {

    interface Host {
        String download(String url)
                throws Exception;

        String safe(String value);

        String sanitizeExtension(
                String extension);

        String firstNonEmpty(
                String... values);
    }

    static void loadMovies(
            String url,
            String categoryId,
            ArrayList<MovieItem> movies,
            Host host)
            throws Exception {

        JSONArray array =
                new JSONArray(
                        host.download(url));

        for (int i = 0;
             i < array.length();
             i++) {

            JSONObject item =
                    array.optJSONObject(i);

            if (item == null) {
                continue;
            }

            MovieItem movie =
                    new MovieItem();

            movie.name =
                    item.optString(
                            "name",
                            "Movie");

            movie.categoryId =
                    host.safe(categoryId).isEmpty() == false
                            ? categoryId
                            : item.optString(
                                    "category_id",
                                    "");

            Object streamValue =
                    item.opt("stream_id");

            movie.streamId =
                    streamValue == null
                            ? ""
                            : String.valueOf(
                                    streamValue);

            movie.extension =
                    host.sanitizeExtension(
                            item.optString(
                                    "container_extension",
                                    "mp4"));

            movie.directSource =
                    item.optString(
                            "direct_source",
                            "");

            movie.rating =
                    item.optString(
                            "rating",
                            "");

            movie.year =
                    item.optString(
                            "year",
                            "");

            movie.icon =
                    host.firstNonEmpty(
                            item.optString(
                                    "stream_icon",
                                    ""),
                            item.optString(
                                    "movie_image",
                                    ""),
                            item.optString(
                                    "cover_big",
                                    ""));

            movie.plot =
                    host.firstNonEmpty(
                            item.optString(
                                    "plot",
                                    ""),
                            item.optString(
                                    "description",
                                    ""));

            movie.cast =
                    host.firstNonEmpty(
                            item.optString(
                                    "cast",
                                    ""),
                            item.optString(
                                    "actors",
                                    ""));

            movie.director =
                    item.optString(
                            "director",
                            "");

            movie.genre =
                    item.optString(
                            "genre",
                            "");

            movie.trailer =
                    item.optString(
                            "youtube_trailer",
                            "");

            if (host.safe(movie.streamId).isEmpty() == false
                    && "null".equals(movie.streamId) == false) {

                movies.add(movie);
            }
        }
    }

    static void loadSeries(
            String url,
            String categoryId,
            ArrayList<SeriesItem> seriesList,
            Host host)
            throws Exception {

        JSONArray array =
                new JSONArray(
                        host.download(url));

        for (int i = 0;
             i < array.length();
             i++) {

            JSONObject item =
                    array.optJSONObject(i);

            if (item == null) {
                continue;
            }

            SeriesItem series =
                    new SeriesItem();

            series.name =
                    item.optString(
                            "name",
                            "Series");

            series.categoryId =
                    host.safe(categoryId).isEmpty() == false
                            ? categoryId
                            : item.optString(
                                    "category_id",
                                    "");

            Object seriesValue =
                    item.opt("series_id");

            series.seriesId =
                    seriesValue == null
                            ? ""
                            : String.valueOf(
                                    seriesValue);

            series.rating =
                    item.optString(
                            "rating",
                            "");

            series.year =
                    host.firstNonEmpty(
                            item.optString(
                                    "year",
                                    ""),
                            item.optString(
                                    "releaseDate",
                                    ""));

            series.cover =
                    host.firstNonEmpty(
                            item.optString(
                                    "cover",
                                    ""),
                            item.optString(
                                    "cover_big",
                                    ""),
                            item.optString(
                                    "stream_icon",
                                    ""));

            series.plot =
                    host.firstNonEmpty(
                            item.optString(
                                    "plot",
                                    ""),
                            item.optString(
                                    "description",
                                    ""));

            series.cast =
                    host.firstNonEmpty(
                            item.optString(
                                    "cast",
                                    ""),
                            item.optString(
                                    "actors",
                                    ""));

            series.director =
                    item.optString(
                            "director",
                            "");

            series.genre =
                    item.optString(
                            "genre",
                            "");

            series.trailer =
                    item.optString(
                            "youtube_trailer",
                            "");

            if (host.safe(series.seriesId).isEmpty() == false
                    && "null".equals(series.seriesId) == false) {

                seriesList.add(series);
            }
        }
    }
}
