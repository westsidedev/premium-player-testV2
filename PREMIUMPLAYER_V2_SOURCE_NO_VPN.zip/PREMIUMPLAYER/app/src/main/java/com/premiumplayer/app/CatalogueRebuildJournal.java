package com.premiumplayer.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueRebuildJournal {

    private static final String TABLE =
            "catalogue_rebuild_journal";

    static void ensure(SQLiteDatabase db) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS " + TABLE + " (" +
            "provider_key TEXT PRIMARY KEY," +
            "generation INTEGER NOT NULL," +
            "state TEXT NOT NULL," +
            "movies_done INTEGER NOT NULL DEFAULT 0," +
            "series_done INTEGER NOT NULL DEFAULT 0," +
            "updated_at_ms INTEGER NOT NULL," +
            "error_type TEXT NOT NULL DEFAULT '')");
    }

    static long start(SQLiteDatabase db, String providerKey) {
        if (providerKey == null || providerKey.isEmpty()) {
            throw new IllegalArgumentException("Missing provider key");
        }

        ensure(db);

        long previous = 0L;
        Cursor c = db.rawQuery(
                "SELECT generation FROM " + TABLE +
                " WHERE provider_key=?",
                new String[]{providerKey});

        try {
            if (c.moveToFirst()) previous = c.getLong(0);
        } finally {
            c.close();
        }

        long generation = Math.max(
                System.currentTimeMillis(), previous + 1L);

        ContentValues v = new ContentValues();
        v.put("provider_key", providerKey);
        v.put("generation", generation);
        v.put("state", "MOVIES");
        v.put("movies_done", 0);
        v.put("series_done", 0);
        v.put("updated_at_ms", System.currentTimeMillis());
        v.put("error_type", "");

        if (db.insertWithOnConflict(
                TABLE, null, v,
                SQLiteDatabase.CONFLICT_REPLACE) < 0L) {
            throw new IllegalStateException(
                    "Cannot start catalogue journal");
        }

        return generation;
    }

    static void progress(
            SQLiteDatabase db,
            String providerKey,
            long generation,
            String state,
            long movies,
            long series) {

        ContentValues v = new ContentValues();
        v.put("state", state);
        if (movies >= 0L) v.put("movies_done", movies);
        if (series >= 0L) v.put("series_done", series);
        v.put("updated_at_ms", System.currentTimeMillis());

        int changed = db.update(
                TABLE, v,
                "provider_key=? AND generation=?",
                new String[]{
                        providerKey,
                        Long.toString(generation)
                });

        if (changed != 1) {
            throw new IllegalStateException(
                    "Catalogue journal generation mismatch");
        }
    }

    static void failed(
            SQLiteDatabase db,
            String providerKey,
            long generation,
            Exception error) {

        ContentValues v = new ContentValues();
        v.put("state", "FAILED");
        v.put("updated_at_ms", System.currentTimeMillis());
        v.put("error_type",
                error == null ? "Unknown"
                        : error.getClass().getSimpleName());

        db.update(TABLE, v,
                "provider_key=? AND generation=?",
                new String[]{
                        providerKey,
                        Long.toString(generation)
                });
    }
}
