package com.premiumplayer.app;

import android.content.Context;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class SettingsTopSection {

    interface Host {
        Button smallButton(String text);
        void showHomeSettings();
        void showSportsSettings();
        int dp(int value);
        int gold();
        int silver();
    }

    static void add(Context context, Host host, LinearLayout root) {

        TextView homeSection = new TextView(context);
        homeSection.setText("HOME SCREEN");
        homeSection.setTextColor(host.gold());
        homeSection.setTextSize(12);
        homeSection.setLetterSpacing(0.12f);
        homeSection.setPadding(0, host.dp(24), 0, host.dp(8));
        root.addView(homeSection);

        TextView homeHelp = new TextView(context);
        homeHelp.setText(
                "Choose the app colour theme and control which Continue Watching boxes appear beneath the main Home tiles.");
        homeHelp.setTextColor(host.silver());
        homeHelp.setTextSize(13);
        homeHelp.setPadding(0, 0, 0, host.dp(12));
        root.addView(homeHelp);

        Button homeSettings = host.smallButton("HOME SCREEN SETTINGS");
        homeSettings.setTextSize(13);
        homeSettings.setOnClickListener(v -> host.showHomeSettings());

        LinearLayout.LayoutParams homeParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        homeParams.setMargins(0, 0, 0, host.dp(8));
        root.addView(homeSettings, homeParams);

        TextView sportsSection = new TextView(context);
        sportsSection.setText("SPORTS");
        sportsSection.setTextColor(host.gold());
        sportsSection.setTextSize(12);
        sportsSection.setLetterSpacing(0.12f);
        sportsSection.setPadding(0, host.dp(24), 0, host.dp(8));
        root.addView(sportsSection);

        TextView sportsHelp = new TextView(context);
        sportsHelp.setText(
                "Choose whole sports or only specific leagues and competitions for the Sports Guide.");
        sportsHelp.setTextColor(host.silver());
        sportsHelp.setTextSize(13);
        sportsHelp.setPadding(0, 0, 0, host.dp(12));
        root.addView(sportsHelp);

        Button sportsSettings = host.smallButton("SPORTS PREFERENCES");
        sportsSettings.setTextSize(13);
        sportsSettings.setOnClickListener(v -> host.showSportsSettings());

        LinearLayout.LayoutParams sportsParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        sportsParams.setMargins(0, 0, 0, host.dp(8));
        root.addView(sportsSettings, sportsParams);
    }
}
