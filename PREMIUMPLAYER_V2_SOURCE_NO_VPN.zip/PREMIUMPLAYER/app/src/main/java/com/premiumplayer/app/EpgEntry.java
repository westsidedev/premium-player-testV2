package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class EpgEntry {
        String title = "";
        String description = "";
        String category = "";
        String startText = "";
        String endText = "";
        long startTimestamp = 0L;
        long endTimestamp = 0L;
        boolean nowPlaying = false;
    }
