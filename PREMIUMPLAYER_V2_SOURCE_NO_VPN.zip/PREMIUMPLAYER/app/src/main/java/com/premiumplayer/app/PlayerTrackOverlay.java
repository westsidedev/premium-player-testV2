package com.premiumplayer.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.exoplayer2.ui.PlayerView;

final class PlayerTrackOverlay {

    interface Host {
        int dp(int value);

        GradientDrawable background(
                int fill,
                int stroke,
                int radius);

        void prepareButton(
                TextView button);

        void addFocusStyle(
                TextView button,
                int radius);

        void showAudioTracks();
        void showSubtitleTracks();
    }

    static void attach(
            PlayerView playerView,
            Host host,
            int gold) {

        if (playerView == null) {
            return;
        }

        FrameLayout overlay =
                playerView.getOverlayFrameLayout();

        if (overlay == null) {
            return;
        }

        LinearLayout controls =
                new LinearLayout(
                        playerView.getContext());

        controls.setOrientation(
                LinearLayout.HORIZONTAL);

        controls.setGravity(
                Gravity.CENTER);

        TextView audioButton =
                createButton(
                        playerView,
                        host,
                        gold,
                        "♪ AUDIO");

        TextView subtitleButton =
                createButton(
                        playerView,
                        host,
                        gold,
                        "CC");

        LinearLayout.LayoutParams audioParams =
                new LinearLayout.LayoutParams(
                        host.dp(86),
                        host.dp(42));

        audioParams.setMargins(
                0,
                0,
                host.dp(6),
                0);

        controls.addView(
                audioButton,
                audioParams);

        controls.addView(
                subtitleButton,
                new LinearLayout.LayoutParams(
                        host.dp(58),
                        host.dp(42)));

        FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT);

        params.gravity =
                Gravity.TOP | Gravity.END;

        params.setMargins(
                host.dp(8),
                host.dp(8),
                host.dp(8),
                host.dp(8));

        overlay.addView(
                controls,
                params);

        controls.setVisibility(
                playerView.isControllerVisible()
                        ? View.VISIBLE
                        : View.GONE);

        playerView.setControllerVisibilityListener(
                visibility ->
                        controls.setVisibility(
                                visibility == View.VISIBLE
                                        ? View.VISIBLE
                                        : View.GONE));

        audioButton.setOnClickListener(
                v -> host.showAudioTracks());

        subtitleButton.setOnClickListener(
                v -> host.showSubtitleTracks());
    }

    private static TextView createButton(
            PlayerView playerView,
            Host host,
            int gold,
            String text) {

        TextView button =
                new TextView(
                        playerView.getContext());

        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(12);

        button.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        button.setGravity(
                Gravity.CENTER);

        host.prepareButton(
                button);

        button.setPadding(
                host.dp(6),
                host.dp(6),
                host.dp(6),
                host.dp(6));

        button.setBackground(
                host.background(
                        Color.rgb(38, 38, 42),
                        gold,
                        10));

        host.addFocusStyle(
                button,
                10);

        return button;
    }
}
