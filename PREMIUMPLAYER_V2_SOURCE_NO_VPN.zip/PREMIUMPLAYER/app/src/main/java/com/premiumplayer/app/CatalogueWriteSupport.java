package com.premiumplayer.app;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueWriteSupport {

    interface Host {
        String safe(String value);

        String normalize(String value);

        String sanitizeExtension(
                String extension);
    }

    static void upsertMovie(
            SQLiteDatabase db,
            String providerKey,
            MovieItem movie,
            boolean castScanned,
            Host host) {

        if (db == null
                || movie == null
                || host.safe(movie.streamId)
                .isEmpty()) {

            return;
        }

        String pk =
                providerKey
                        + "|"
                        + movie.streamId;

        ContentValues insert =
                new ContentValues();

        insert.put("pk", pk);
        insert.put(
                "provider_key",
                providerKey);

        insert.put(
                "stream_id",
                host.safe(
                        movie.streamId));

        insert.put(
                "cast_scanned",
                castScanned ? 1 : 0);

        db.insertWithOnConflict(
                "catalogue_movies",
                null,
                insert,
                SQLiteDatabase.CONFLICT_IGNORE);

        ContentValues values =
                new ContentValues();
        if (movie.rawJson != null && !movie.rawJson.isEmpty()) {
            values.put("raw_json", movie.rawJson);
        }
        if (movie.importGeneration > 0L) {
            values.put("import_generation", movie.importGeneration);
        }

        if (movie.addedAt > 0L) {
            values.put("added_at", movie.addedAt);
        }

        values.put(
                "category_id",
                host.safe(movie.categoryId));

        values.put(
                "name",
                host.safe(movie.name));

        values.put(
                "normalized_name",
                host.normalize(movie.name));

        values.put(
                "extension",
                host.sanitizeExtension(
                        movie.extension));

        values.put(
                "direct_source",
                host.safe(movie.directSource));

        values.put(
                "rating",
                host.safe(movie.rating));

        values.put(
                "year",
                host.safe(movie.year));

        values.put(
                "icon",
                host.safe(movie.icon));

        values.put(
                "plot",
                host.safe(movie.plot));

        values.put(
                "cast",
                host.safe(movie.cast));

        values.put(
                "normalized_cast",
                host.normalize(movie.cast));

        values.put(
                "director",
                host.safe(movie.director));

        values.put(
                "genre",
                host.safe(movie.genre));

        values.put(
                "trailer",
                host.safe(movie.trailer));

        values.put(
                "duration",
                host.safe(movie.duration));

        db.update(
                "catalogue_movies",
                values,
                "pk=?",
                new String[]{pk});

        if (castScanned) {

            ContentValues scanned =
                    new ContentValues();

            scanned.put(
                    "cast_scanned",
                    1);

            db.update(
                    "catalogue_movies",
                    scanned,
                    "pk=?",
                    new String[]{pk});
        }
    }

    static void upsertSeries(
            SQLiteDatabase db,
            String providerKey,
            SeriesItem series,
            Host host) {

        if (db == null
                || series == null
                || host.safe(series.seriesId)
                .isEmpty()) {

            return;
        }

        String pk =
                providerKey
                        + "|"
                        + series.seriesId;

        ContentValues values =
                new ContentValues();
        if (series.rawJson != null && !series.rawJson.isEmpty()) {
            values.put("raw_json", series.rawJson);
        }
        if (series.importGeneration > 0L) {
            values.put("import_generation", series.importGeneration);
        }

        if (series.addedAt > 0L) {
            values.put("added_at", series.addedAt);
        }
        if (series.updatedAt > 0L) {
            values.put("updated_at", series.updatedAt);
        }

        values.put("pk", pk);

        values.put(
                "provider_key",
                providerKey);

        values.put(
                "series_id",
                host.safe(series.seriesId));

        values.put(
                "category_id",
                host.safe(series.categoryId));

        values.put(
                "name",
                host.safe(series.name));

        values.put(
                "normalized_name",
                host.normalize(series.name));

        values.put(
                "rating",
                host.safe(series.rating));

        values.put(
                "year",
                host.safe(series.year));

        values.put(
                "cover",
                host.safe(series.cover));

        values.put(
                "plot",
                host.safe(series.plot));

        values.put(
                "cast",
                host.safe(series.cast));

        values.put(
                "normalized_cast",
                host.normalize(series.cast));

        values.put(
                "director",
                host.safe(series.director));

        values.put(
                "genre",
                host.safe(series.genre));

        values.put(
                "trailer",
                host.safe(series.trailer));

        long inserted = db.insertWithOnConflict(
                "catalogue_series", null, values,
                SQLiteDatabase.CONFLICT_IGNORE);

        if (inserted < 0L) {
            db.update("catalogue_series", values,
                    "pk=?", new String[]{pk});
        }
    }
}
