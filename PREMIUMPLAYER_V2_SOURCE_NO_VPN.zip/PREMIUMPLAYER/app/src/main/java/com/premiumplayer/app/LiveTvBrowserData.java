package com.premiumplayer.app;

import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

final class LiveTvBrowserData {

    interface Host {
        ArrayList<Channel> channels();
        void select(Channel channel);

        String safe(String value);

        HashSet<String> hiddenCategories();
        ArrayList<String> topCategoryOrder();

        boolean hasImportedChannels();
        String selectedNow();
        String selectedNext();
        String selectedGroup();
    }

    static void restoreLastChannel(
            Host host,
            String key) {

        if (key == null || key.isEmpty()) {
            return;
        }

        for (Channel channel : host.channels()) {
            if (key.equals(channel.key())) {
                host.select(channel);
                return;
            }
        }
    }

    static void updateProgrammeLabel(
            Host host,
            TextView programme) {

        if (host.hasImportedChannels()
                && host.selectedNow().isEmpty()) {

            programme.setText(host.selectedGroup());

        } else {

            programme.setText(
                    "NOW  " + host.selectedNow());
        }
    }

    static void updateNextLabel(
            Host host,
            TextView nextProgramme) {

        if (host.hasImportedChannels()
                && host.selectedNext().isEmpty()) {

            nextProgramme.setText("EPG not loaded");

        } else {

            nextProgramme.setText(
                    "NEXT  " + host.selectedNext());
        }
    }

    static ArrayList<String> categoryNames(
            Host host) {

        ArrayList<String> categories =
                new ArrayList<String>();

        categories.add("ALL");

        LinkedHashSet<String> unique =
                new LinkedHashSet<String>();

        HashSet<String> hidden =
                host.hiddenCategories();

        for (Channel channel : host.channels()) {

            String group =
                    host.safe(channel.group).trim();

            if (!group.isEmpty()
                    && !hidden.contains(group)) {

                unique.add(group);
            }
        }

        ArrayList<String> topOrder =
                host.topCategoryOrder();

        for (String id : topOrder) {

            if (unique.remove(id)) {
                categories.add(id);
            }
        }

        categories.addAll(unique);
        categories.add("FAVOURITES");

        return categories;
    }
}
