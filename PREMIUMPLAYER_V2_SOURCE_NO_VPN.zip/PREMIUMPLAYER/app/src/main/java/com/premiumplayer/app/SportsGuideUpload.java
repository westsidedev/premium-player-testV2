package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class SportsGuideUpload {

    private SportsGuideUpload() {}

    static void postChannels(
            String base, String apiKey, String playlistKey,
            ArrayList<Channel> channels,
            Runnable completion) {

        new Thread(() -> {
            try {
                int offset = 0;

                while (offset < channels.size()) {
                    JSONArray batch = new JSONArray();
                    int end = Math.min(offset + 400, channels.size());

                    for (int i = offset; i < end; i++) {
                        Channel c = channels.get(i);
                        JSONObject item = new JSONObject();

                        item.put("channel_key", c.key());
                        item.put("channel_name", safe(c.name));
                        item.put("channel_group", safe(c.group));

                        String id = safe(c.streamId);
                        if (id.isEmpty()) id = streamId(c.url);

                        item.put("stream_id", id);
                        item.put("channel_logo", safe(c.logo));
                        batch.put(item);
                    }

                    JSONObject body = new JSONObject();
                    body.put("playlist_key", playlistKey);
                    body.put("channels", batch);

                    HttpURLConnection con = (HttpURLConnection)
                            new URL(base + "/sports-guide").openConnection();

                    try {
                        con.setRequestMethod("POST");
                        con.setDoOutput(true);
                        con.setConnectTimeout(8000);
                        con.setReadTimeout(15000);
                        con.setRequestProperty("apikey", apiKey);
                        con.setRequestProperty("Content-Type", "application/json");

                        OutputStreamWriter writer =
                                new OutputStreamWriter(con.getOutputStream(), "UTF-8");

                        writer.write(body.toString());
                        writer.close();

                        int code = con.getResponseCode();
                        if (code < 200 || code >= 300) break;

                    } finally {
                        con.disconnect();
                    }

                    offset = end;
                }
            } catch (Exception ignored) {}

            if (completion != null) completion.run();
        }).start();
    }

    private static String streamId(String url) {
        if (url == null) return "";

        Matcher m = Pattern.compile(
                "/([0-9]+)\\.(?:ts|m3u8)(?:\\?.*)?$",
                Pattern.CASE_INSENSITIVE).matcher(url);

        return m.find() ? m.group(1) : "";
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    static void postEvents(
            String base, String apiKey, String playlistKey,
            JSONArray events, Runnable completion) {

        new Thread(() -> {
            try {
                int offset = 0;

                while (offset < events.length()) {
                    JSONArray batch = new JSONArray();
                    int end = Math.min(offset + 400, events.length());

                    for (int i = offset; i < end; i++)
                        batch.put(events.get(i));

                    JSONObject body = new JSONObject();
                    body.put("playlist_key", playlistKey);
                    body.put("events", batch);

                    HttpURLConnection con = (HttpURLConnection)
                            new URL(base + "/sports-guide").openConnection();

                    try {
                        con.setRequestMethod("POST");
                        con.setDoOutput(true);
                        con.setConnectTimeout(8000);
                        con.setReadTimeout(15000);
                        con.setRequestProperty("apikey", apiKey);
                        con.setRequestProperty("Content-Type", "application/json");

                        OutputStreamWriter writer =
                                new OutputStreamWriter(con.getOutputStream(), "UTF-8");

                        writer.write(body.toString());
                        writer.close();

                        int code = con.getResponseCode();
                        if (code < 200 || code >= 300) break;

                    } finally {
                        con.disconnect();
                    }

                    offset = end;
                }
            } catch (Exception ignored) {}

            if (completion != null) completion.run();
        }).start();
    }
}
