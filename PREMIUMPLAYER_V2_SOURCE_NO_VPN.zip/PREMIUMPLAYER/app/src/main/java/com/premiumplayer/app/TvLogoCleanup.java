package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

final class TvLogoCleanup {
    private static Bitmap cached;

    static synchronized Bitmap load(Context context, int id) {
        if (cached != null) return cached;

        Bitmap original =
                BitmapFactory.decodeResource(
                        context.getResources(), id);
        if (original == null) return null;

        int w = original.getWidth();
        int h = original.getHeight();
        int[] pixels = new int[w * h];
        original.getPixels(pixels, 0, w, 0, 0, w, h);

        int[] queue = new int[w * h];
        boolean[] seen = new boolean[w * h];
        int head = 0, tail = 0;

        for (int x = 0; x < w; x++) {
            tail = add(x, pixels, queue, seen, tail);
            tail = add((h - 1) * w + x,
                    pixels, queue, seen, tail);
        }

        for (int y = 0; y < h; y++) {
            tail = add(y * w, pixels, queue, seen, tail);
            tail = add(y * w + w - 1,
                    pixels, queue, seen, tail);
        }
        while (head < tail) {
            int p = queue[head++];
            pixels[p] = Color.TRANSPARENT;
            int x = p % w;

            if (x > 0)
                tail = add(p - 1, pixels, queue, seen, tail);
            if (x < w - 1)
                tail = add(p + 1, pixels, queue, seen, tail);
            if (p >= w)
                tail = add(p - w, pixels, queue, seen, tail);
            if (p < (h - 1) * w)
                tail = add(p + w, pixels, queue, seen, tail);
        }

        int left = w, top = h, right = -1, bottom = -1;

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (Color.alpha(pixels[y * w + x]) == 0)
                    continue;
                left = Math.min(left, x);
                right = Math.max(right, x);
                top = Math.min(top, y);
                bottom = Math.max(bottom, y);
            }
        }

        if (right < left) return original;

        Bitmap full = Bitmap.createBitmap(
                pixels, w, h, Bitmap.Config.ARGB_8888);

        cached = Bitmap.createBitmap(
                full, left, top,
                right - left + 1, bottom - top + 1);

        return cached;
    }

    private static int add(int i, int[] pixels,
            int[] queue, boolean[] seen, int tail) {

        if (seen[i]) return tail;

        int p = pixels[i];
        if (Color.alpha(p) == 0 ||
                Color.red(p) > 40 ||
                Color.green(p) > 40 ||
                Color.blue(p) > 40)
            return tail;

        seen[i] = true;
        queue[tail++] = i;
        return tail;
    }
}
