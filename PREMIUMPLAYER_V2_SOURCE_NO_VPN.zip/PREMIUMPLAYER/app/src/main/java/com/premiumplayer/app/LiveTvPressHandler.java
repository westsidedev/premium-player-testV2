package com.premiumplayer.app;

import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.exoplayer2.ui.PlayerView;

final class LiveTvPressHandler {

    interface Host {
        String lastKey();
        long lastPressedAt();

        void setLastKey(String key);
        void setLastPressedAt(long time);

        long doublePressWindow();

        void select(Channel channel);
        void updateHighlight(LinearLayout container);
        void openFullscreen();

        void startPreview(
                Channel channel,
                PlayerView playerView,
                TextView title,
                TextView now,
                TextView next,
                TextView status);
    }

    static void handle(
            Host host,
            Channel channel,
            LinearLayout container,
            PlayerView playerView,
            TextView title,
            TextView nowText,
            TextView nextText,
            TextView status) {

        if (channel == null) {
            return;
        }

        String key = channel.key();
        boolean sameChannel = key != null
                && !key.isEmpty()
                && key.equals(host.lastKey());

        host.setLastKey(key);
        host.select(channel);
        host.updateHighlight(container);

        if (sameChannel) {
            host.openFullscreen();
        } else {
            host.startPreview(channel, playerView, title,
                    nowText, nextText, status);
        }
    }
}
