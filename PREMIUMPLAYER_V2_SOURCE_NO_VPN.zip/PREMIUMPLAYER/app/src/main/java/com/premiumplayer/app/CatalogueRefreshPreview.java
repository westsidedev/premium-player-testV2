package com.premiumplayer.app;

import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;

final class CatalogueRefreshPreview {

    interface Guard {
        void check() throws Exception;
    }

    interface Progress {
        void update(String type, long seen);
    }

    static final class Stats {
        long seen;
        long added;
        long changed;
        long unchanged;
        long representationOnly;
        long listingOnly;
        long invalid;

        String report(String type) {
            return type
                    + "\nProvider records: " + seen
                    + "\nNew: " + added
                    + "\nChanged: " + changed
                    + "\nUnchanged: " + unchanged
                    + "\nSame data, different JSON: " + representationOnly
                    + "\nListing position only: " + listingOnly
                    + "\nInvalid IDs: " + invalid;
        }
    }

    static Stats scan(
            SQLiteDatabase db,
            String providerKey,
            String type,
            String url,
            Guard guard,
            Progress progress) throws Exception {

        if (!"MOVIES".equals(type)
                && !"SERIES".equals(type)) {
            throw new IllegalArgumentException("Invalid media type");
        }

        final boolean movies = "MOVIES".equals(type);
        final Stats stats = new Stats();

        XtreamJsonArrayTransport.stream(url, reader -> {
            guard.check();

            String rawJson = ProviderRawJson.capture(reader);
            JSONObject object = new JSONObject(rawJson);

            String id = object.optString(
                    movies ? "stream_id" : "series_id", "");

            stats.seen++;

            if (id.isEmpty() || "null".equals(id)) {
                stats.invalid++;
            } else {
                int result = CatalogueRefreshDiff.compare(
                        db, movies, providerKey, id, rawJson);

                if (result == CatalogueRefreshDiff.NEW) {
                    stats.added++;
                } else if (result == CatalogueRefreshDiff.CHANGED) {
                    stats.changed++;
                } else if (result == CatalogueRefreshDiff.LIST_POSITION_ONLY) {
                    stats.listingOnly++;
                } else if (result == CatalogueRefreshDiff.REPRESENTATION_ONLY) {
                    stats.representationOnly++;
                } else {
                    stats.unchanged++;
                }
            }

            if (stats.seen % 2000L == 0L) {
                progress.update(type, stats.seen);
            }
        });

        return stats;
    }
}
