package com.premiumplayer.app;

import org.json.JSONObject;

final class MediaDetailLoader {

    interface Host {
        String download(
                String action,
                String key,
                String value)
                throws Exception;

        String firstNonEmpty(
                String... values);
    }

    static void loadMovie(
            MovieItem movie,
            Host host)
            throws Exception {

        String text =
                host.download(
                        "get_vod_info",
                        "vod_id",
                        movie.streamId);

        JSONObject object =
                new JSONObject(text);

        JSONObject info =
                object.optJSONObject(
                        "info");

        if (info == null) {
            info = object;
        }

        movie.icon =
                host.firstNonEmpty(
                        info.optString("movie_image", ""),
                        info.optString("cover_big", ""),
                        info.optString("stream_icon", ""),
                        movie.icon);

        movie.plot =
                host.firstNonEmpty(
                        info.optString("plot", ""),
                        info.optString("description", ""),
                        movie.plot);

        movie.cast =
                host.firstNonEmpty(
                        info.optString("cast", ""),
                        info.optString("actors", ""),
                        movie.cast);

        movie.director =
                host.firstNonEmpty(
                        info.optString("director", ""),
                        movie.director);

        movie.genre =
                host.firstNonEmpty(
                        info.optString("genre", ""),
                        movie.genre);

        movie.trailer =
                host.firstNonEmpty(
                        info.optString("youtube_trailer", ""),
                        movie.trailer);

        movie.rating =
                host.firstNonEmpty(
                        info.optString("rating", ""),
                        movie.rating);

        movie.year =
                host.firstNonEmpty(
                        info.optString("releasedate", ""),
                        info.optString("release_date", ""),
                        info.optString("year", ""),
                        movie.year);

        movie.duration =
                host.firstNonEmpty(
                        info.optString("duration", ""),
                        movie.duration);

        movie.detailsLoaded =
                true;
    }

    static void loadSeries(
            SeriesItem series,
            Host host)
            throws Exception {

        String text =
                host.download(
                        "get_series_info",
                        "series_id",
                        series.seriesId);

        JSONObject object =
                new JSONObject(text);

        JSONObject info =
                object.optJSONObject(
                        "info");

        if (info == null) {
            info = object;
        }

        series.cover =
                host.firstNonEmpty(
                        info.optString("cover", ""),
                        info.optString("cover_big", ""),
                        info.optString("movie_image", ""),
                        series.cover);

        series.plot =
                host.firstNonEmpty(
                        info.optString("plot", ""),
                        info.optString("description", ""),
                        series.plot);

        series.cast =
                host.firstNonEmpty(
                        info.optString("cast", ""),
                        info.optString("actors", ""),
                        series.cast);

        series.director =
                host.firstNonEmpty(
                        info.optString("director", ""),
                        series.director);

        series.genre =
                host.firstNonEmpty(
                        info.optString("genre", ""),
                        series.genre);

        series.trailer =
                host.firstNonEmpty(
                        info.optString("youtube_trailer", ""),
                        series.trailer);

        series.rating =
                host.firstNonEmpty(
                        info.optString("rating", ""),
                        series.rating);

        series.year =
                host.firstNonEmpty(
                        info.optString("releaseDate", ""),
                        info.optString("releasedate", ""),
                        info.optString("year", ""),
                        series.year);

        series.detailsLoaded =
                true;
    }
}
