package com.premiumplayer.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class MediaBrowserLayout {

    interface Host {
        int dp(int value);

        TextView createBackText();

        EditText createSearchBox(
                String hint);

        void prepareRemote(
                TextView view);

        GradientDrawable background(
                int fill,
                int stroke,
                int radius);
    }

    static final class Result {
        final LinearLayout screen;
        final TextView back;
        final EditText search;
        final TextView searchAll;
        final LinearLayout leftPane;
        final LinearLayout categoryList;
        final LinearLayout rightPane;

        Result(
                LinearLayout screen,
                TextView back,
                EditText search,
                TextView searchAll,
                LinearLayout leftPane,
                LinearLayout categoryList,
                LinearLayout rightPane) {

            this.screen = screen;
            this.back = back;
            this.search = search;
            this.searchAll = searchAll;
            this.leftPane = leftPane;
            this.categoryList = categoryList;
            this.rightPane = rightPane;
        }
    }

    static Result build(
            Activity activity,
            String mediaType,
            Host host,
            int black,
            int gold) {

        LinearLayout screen =
                new LinearLayout(activity);

        screen.setOrientation(
                LinearLayout.VERTICAL);

        screen.setPadding(
                host.dp(12),
                host.dp(10),
                host.dp(12),
                host.dp(12));

        screen.setBackgroundColor(
                black);

        LinearLayout topBar =
                new LinearLayout(activity);

        topBar.setOrientation(
                LinearLayout.HORIZONTAL);

        topBar.setGravity(
                Gravity.CENTER_VERTICAL);

        TextView back =
                host.createBackText();

        back.setText(
                "<  HOME");

        back.setPadding(
                host.dp(8),
                0,
                host.dp(10),
                0);

        back.setGravity(
                Gravity.CENTER_VERTICAL);

        topBar.addView(
                back,
                new LinearLayout.LayoutParams(
                        0,
                        host.dp(50),
                        0.17f));

        TextView pageTitle =
                new TextView(activity);

        pageTitle.setText(
                mediaType);

        pageTitle.setTextColor(
                Color.WHITE);

        pageTitle.setTextSize(
                22);

        pageTitle.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        pageTitle.setGravity(
                Gravity.CENTER_VERTICAL);

        topBar.addView(
                pageTitle,
                new LinearLayout.LayoutParams(
                        0,
                        host.dp(50),
                        0.18f));

        EditText search =
                host.createSearchBox(
                        "MOVIES".equals(mediaType)
                                ? "Search movies"
                                : "Search series");

        LinearLayout.LayoutParams searchParams =
                new LinearLayout.LayoutParams(
                        0,
                        host.dp(50),
                        0.45f);

        searchParams.setMargins(
                host.dp(8),
                0,
                host.dp(8),
                0);

        topBar.addView(
                search,
                searchParams);

        TextView searchAll =
                new TextView(activity);

        searchAll.setText(
                "⌕  SEARCH ALL");

        searchAll.setTextColor(
                black);

        searchAll.setTextSize(
                12);

        searchAll.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        searchAll.setGravity(
                Gravity.CENTER);

        host.prepareRemote(
                searchAll);

        searchAll.setBackground(
                host.background(
                        gold,
                        gold,
                        10));

        topBar.addView(
                searchAll,
                new LinearLayout.LayoutParams(
                        0,
                        host.dp(50),
                        0.20f));

        screen.addView(
                topBar);

        LinearLayout browser =
                new LinearLayout(activity);

        browser.setOrientation(
                LinearLayout.HORIZONTAL);

        LinearLayout.LayoutParams browserParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f);

        browserParams.setMargins(
                0,
                host.dp(8),
                0,
                0);

        screen.addView(
                browser,
                browserParams);

        LinearLayout leftPane =
                new LinearLayout(activity);

        leftPane.setOrientation(
                LinearLayout.VERTICAL);

        leftPane.setPadding(
                host.dp(8),
                host.dp(8),
                host.dp(8),
                host.dp(8));

        leftPane.setBackground(
                host.background(
                        Color.rgb(15, 15, 17),
                        Color.rgb(45, 45, 48),
                        12));

        // Give category names enough room on smaller phone screens,
        // while retaining the 25/75 split on Android TV.
        final boolean compactScreen =
                activity.getResources().getConfiguration().screenWidthDp < 600;
        final float categoryWeight = compactScreen ? 1.4f : 1f;
        final float contentWeight = compactScreen ? 2.6f : 3f;

        LinearLayout.LayoutParams leftParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        categoryWeight);

        leftParams.setMargins(
                0,
                0,
                host.dp(8),
                0);

        browser.addView(
                leftPane,
                leftParams);

        TextView categoryHeading =
                new TextView(activity);

        categoryHeading.setText(
                "CATEGORIES");

        categoryHeading.setTextColor(
                gold);

        categoryHeading.setTextSize(
                12);

        categoryHeading.setLetterSpacing(
                0.12f);

        categoryHeading.setPadding(
                host.dp(8),
                host.dp(4),
                host.dp(8),
                host.dp(8));

        leftPane.addView(
                categoryHeading);

        ScrollView categoryScroll =
                new ScrollView(activity);

        // Long provider category lists remain visibly scrollable.
        categoryScroll.setFillViewport(true);
        categoryScroll.setVerticalScrollBarEnabled(true);
        categoryScroll.setSmoothScrollingEnabled(true);

        LinearLayout categoryList =
                new LinearLayout(activity);

        categoryList.setOrientation(
                LinearLayout.VERTICAL);

        categoryScroll.addView(
                categoryList);

        leftPane.addView(
                categoryScroll,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        LinearLayout rightPane =
                new LinearLayout(activity);

        rightPane.setOrientation(
                LinearLayout.VERTICAL);

        rightPane.setPadding(
                host.dp(10),
                host.dp(8),
                host.dp(8),
                host.dp(8));

        rightPane.setBackground(
                host.background(
                        Color.rgb(12, 12, 13),
                        Color.rgb(42, 42, 45),
                        12));

        browser.addView(
                rightPane,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        contentWeight));

        return new Result(
                screen,
                back,
                search,
                searchAll,
                leftPane,
                categoryList,
                rightPane);
    }
}
