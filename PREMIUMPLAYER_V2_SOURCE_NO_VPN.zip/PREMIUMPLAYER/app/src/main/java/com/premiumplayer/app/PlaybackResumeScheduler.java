package com.premiumplayer.app;

import android.os.Handler;

final class PlaybackResumeScheduler {

    interface Host {
        void savePosition();
        boolean shouldContinue();
    }

    static Runnable start(
            Handler handler,
            Runnable existing,
            Host host) {

        if (existing != null) {
            handler.removeCallbacks(
                    existing);
        }

        if (host.shouldContinue() == false) {
            return null;
        }

        Runnable runnable =
                new Runnable() {

                    @Override
                    public void run() {

                        host.savePosition();

                        if (host.shouldContinue()) {
                            handler.postDelayed(
                                    this,
                                    10000L);
                        }
                    }
                };

        handler.postDelayed(
                runnable,
                10000L);

        return runnable;
    }

    static Runnable stop(
            Handler handler,
            Runnable existing) {

        if (existing != null) {
            handler.removeCallbacks(
                    existing);
        }

        return null;
    }
}
