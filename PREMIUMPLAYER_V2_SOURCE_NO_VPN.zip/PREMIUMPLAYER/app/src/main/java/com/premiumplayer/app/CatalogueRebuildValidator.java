package com.premiumplayer.app;

import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueRebuildValidator {

    static final class Result {
        long movies;
        long series;
        long movieDates;
        long seriesUpdates;
        long movieEnglish;
        long seriesEnglish;
        long missingRawJson;
        boolean acceptable;

        String summary() {
            return "Movies: " + movies
                    + " (dated: " + movieDates
                    + ", English: " + movieEnglish + ")"
                    + "\nSeries: " + series
                    + " (updated: " + seriesUpdates
                    + ", English: " + seriesEnglish + ")"
                    + "\nMissing JSON: " + missingRawJson
                    + "\nValidation: "
                    + (acceptable ? "PASS" : "REVIEW REQUIRED");
        }
    }

    private static long count(
            SQLiteDatabase db,
            String table,
            String condition,
            String[] args) {

        return DatabaseUtils.longForQuery(
                db,
                "SELECT COUNT(*) FROM " + table
                        + " WHERE provider_key=?"
                        + " AND import_generation=? "
                        + condition,
                args);
    }

    static Result verify(
            SQLiteDatabase db,
            String providerKey,
            long generation,
            long previousMovies,
            long previousSeries) {

        if (db == null || providerKey == null
                || generation <= 0L) {
            throw new IllegalArgumentException(
                    "Invalid rebuild verification context");
        }

        String[] args = {
                providerKey,
                Long.toString(generation)
        };

        Result result = new Result();

        result.movies = count(
                db, "catalogue_movies", "", args);

        result.series = count(
                db, "catalogue_series", "", args);

        result.movieDates = count(
                db, "catalogue_movies",
                "AND added_at>0", args);

        result.seriesUpdates = count(
                db, "catalogue_series",
                "AND updated_at>0", args);

        result.movieEnglish = count(
                db, "catalogue_movies",
                "AND name LIKE 'EN - %'", args);

        result.seriesEnglish = count(
                db, "catalogue_series",
                "AND name LIKE 'EN - %'", args);

        result.missingRawJson =
                count(db, "catalogue_movies",
                        "AND (raw_json IS NULL OR LENGTH(raw_json)=0)",
                        args)
                + count(db, "catalogue_series",
                        "AND (raw_json IS NULL OR LENGTH(raw_json)=0)",
                        args);

        boolean sufficientMovies =
                result.movies > 0
                && (previousMovies == 0
                || result.movies >= previousMovies * 9 / 10);

        boolean sufficientSeries =
                result.series > 0
                && (previousSeries == 0
                || result.series >= previousSeries * 9 / 10);

        result.acceptable =
                sufficientMovies
                && sufficientSeries
                && result.missingRawJson == 0
                && result.movieDates > 0
                && result.seriesUpdates > 0;

        return result;
    }
}
