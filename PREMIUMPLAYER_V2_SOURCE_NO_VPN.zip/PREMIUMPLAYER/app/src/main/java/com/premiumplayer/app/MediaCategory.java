package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class MediaCategory {
        String id = "";
        String name = "";
    }
