package com.premiumplayer.app;

import android.util.JsonReader;

import java.util.ArrayList;

final class MediaCategoryProviderLoader {

    interface ItemReader {
        void read(JsonReader reader)
                throws Exception;
    }

    interface Host {
        String buildUrl(
                String action,
                String categoryId) throws Exception;

        void stream(
                String url,
                ItemReader reader)
                throws Exception;

        MovieItem readMovie(
                JsonReader reader)
                throws Exception;

        SeriesItem readSeries(
                JsonReader reader)
                throws Exception;

        String safe(String value);

        void movieFallback(
                String url,
                String categoryId,
                ArrayList<MovieItem> movies)
                throws Exception;

        void seriesFallback(
                String url,
                String categoryId,
                ArrayList<SeriesItem> series)
                throws Exception;
    }

    static final class Result {
        final ArrayList<MovieItem> movies;
        final ArrayList<SeriesItem> series;

        Result(
                ArrayList<MovieItem> movies,
                ArrayList<SeriesItem> series) {

            this.movies = movies;
            this.series = series;
        }
    }

    static Result load(
            String mediaType,
            String categoryId,
            Host host)
            throws Exception {

        ArrayList<MovieItem> movies =
                new ArrayList<MovieItem>();

        ArrayList<SeriesItem> seriesList =
                new ArrayList<SeriesItem>();

        String action =
                "MOVIES".equals(mediaType)
                        ? "get_vod_streams"
                        : "get_series";

        String url =
                host.buildUrl(
                        action,
                        categoryId);

        host.stream(
                url,
                reader -> {

                    if ("MOVIES".equals(mediaType)) {

                        MovieItem movie =
                                host.readMovie(
                                        reader);

                        if (host.safe(movie.streamId)
                                .isEmpty() == false
                                && "null".equals(
                                        movie.streamId) == false) {

                            if (host.safe(movie.categoryId)
                                    .isEmpty()) {

                                movie.categoryId =
                                        categoryId;
                            }

                            movies.add(movie);
                        }

                    } else {

                        SeriesItem series =
                                host.readSeries(
                                        reader);

                        if (host.safe(series.seriesId)
                                .isEmpty() == false
                                && "null".equals(
                                        series.seriesId) == false) {

                            if (host.safe(series.categoryId)
                                    .isEmpty()) {

                                series.categoryId =
                                        categoryId;
                            }

                            seriesList.add(series);
                        }
                    }
                });

        if ("MOVIES".equals(mediaType)
                && movies.isEmpty()) {

            host.movieFallback(
                    url,
                    categoryId,
                    movies);

        } else if ("SERIES".equals(mediaType)
                && seriesList.isEmpty()) {

            host.seriesFallback(
                    url,
                    categoryId,
                    seriesList);
        }

        return new Result(
                movies,
                seriesList);
    }
}
