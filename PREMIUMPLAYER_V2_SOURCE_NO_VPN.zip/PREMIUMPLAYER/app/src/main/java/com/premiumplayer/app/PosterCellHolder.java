package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class PosterCellHolder {
        ImageView poster;
        TextView title;
    }
