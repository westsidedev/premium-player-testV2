package com.premiumplayer.app;

final class PlaybackCandidateRunner {

    interface Host {
        boolean shouldBlockForVpn();
        boolean vpnConnected();

        void connectVpn(Runnable onConnected);

        int candidateIndex();
        int candidateCount();
        String candidateAt(int index);

        void incrementCandidateIndex();

        void releasePlayer();
        void setKeepAwake(boolean keepAwake);
        void setStatus(String text);

        PlaybackProbe probe(String candidate);

        void runOnUiThread(Runnable runnable);

        void startProbed(
                PlaybackProbe probe,
                String preferredLanguage);
    }

    static void play(
            Host host,
            String preferredLanguage) {

        if (host.shouldBlockForVpn()
                && host.vpnConnected() == false) {

            host.setStatus(
                    "Waiting for PREMIUM PLAYER VPN before playback...");

            host.connectVpn(
                    () -> play(
                            host,
                            preferredLanguage));

            return;
        }

        int index =
                host.candidateIndex();

        int count =
                host.candidateCount();

        if (index < 0 || index >= count) {

            host.setStatus(
                    "Playback failed for every source. "
                            + "If this channel plays in another app, "
                            + "use the diagnostics shown here to identify "
                            + "the provider response.");

            return;
        }

        host.releasePlayer();

        final String candidate =
                host.candidateAt(index);

        host.setStatus(
                "Testing source "
                        + (index + 1)
                        + " of "
                        + count
                        + "...");

        new Thread(() -> {

            PlaybackProbe probe =
                    host.probe(candidate);

            host.runOnUiThread(() -> {

                if (probe.ok) {

                    host.startProbed(
                            probe,
                            preferredLanguage);

                    return;
                }

                int failedIndex =
                        host.candidateIndex();

                host.setStatus(
                        "Source "
                                + (failedIndex + 1)
                                + " failed: "
                                + probe.message);

                if (failedIndex + 1
                        < host.candidateCount()) {

                    host.incrementCandidateIndex();

                    play(
                            host,
                            preferredLanguage);

                } else {

                    host.setKeepAwake(false);

                    host.setStatus(
                            "Playback failed. Last source response: "
                                    + probe.message);
                }
            });
        }).start();
    }
}
