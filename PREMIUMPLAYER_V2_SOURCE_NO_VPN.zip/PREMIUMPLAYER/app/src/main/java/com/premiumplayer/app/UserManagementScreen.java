package com.premiumplayer.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class UserManagementScreen {

    interface Host {
        SharedPreferences prefs();
        int liveChannelCount();
        int dp(int value);
        int black();
        int gold();
        int silver();
        int charcoal();
        TextView createBackText();
        Drawable makeBackground(int fill, int border, int radius);
        void showHome();
        void showPlaylists();
        void showSettings();
        void makeTvRemoteReady(View view);
        void addTvFocusScale(View view);
        void setContentView(View view);
    }

    static void show(Context context, Host host) {

        ScrollView scrollView =
                new ScrollView(context);

        scrollView.setBackgroundColor(
                host.black());

        LinearLayout root =
                new LinearLayout(context);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                host.dp(20),
                host.dp(24),
                host.dp(20),
                host.dp(30));

        scrollView.addView(root);

        TextView back =
                host.createBackText();

        back.setOnClickListener(
                v -> host.showHome());

        root.addView(back);

        TextView heading =
                new TextView(context);

        heading.setText(
                "USER MANAGEMENT");

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(30);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        root.addView(
                heading);

        TextView help =
                new TextView(context);

        help.setText(
                "Manage the current playlist account and player preferences.");

        help.setTextColor(
                host.silver());

        help.setTextSize(14);

        help.setPadding(
                0,
                host.dp(8),
                0,
                host.dp(20));

        root.addView(help);

        String playlistName =
                host.prefs()
                        .getString(
                                "playlist_name",
                                "No playlist loaded");

        String sourceType =
                host.prefs()
                        .getString(
                                "playlist_source_type",
                                "");

        LinearLayout accountCard =
                new LinearLayout(context);

        accountCard.setOrientation(
                LinearLayout.VERTICAL);

        accountCard.setPadding(
                host.dp(18),
                host.dp(18),
                host.dp(18),
                host.dp(18));

        accountCard.setBackground(
                host.makeBackground(
                        host.charcoal(),
                        Color.rgb(
                                54,
                                54,
                                58),
                        16));

        TextView accountLabel =
                new TextView(context);

        accountLabel.setText(
                "CURRENT USER");

        accountLabel.setTextColor(
                host.gold());

        accountLabel.setTextSize(11);

        accountLabel.setLetterSpacing(
                0.12f);

        accountCard.addView(
                accountLabel);

        TextView accountName =
                new TextView(context);

        accountName.setText(
                playlistName);

        accountName.setTextColor(
                Color.WHITE);

        accountName.setTextSize(19);

        accountName.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        accountName.setPadding(
                0,
                host.dp(7),
                0,
                0);

        accountCard.addView(
                accountName);

        TextView accountInfo =
                new TextView(context);

        String infoText =
                host.liveChannelCount() > 0
                        ? host.liveChannelCount()
                                + " live channels"
                        : "No live channels loaded";

        if (!sourceType.isEmpty()) {
            infoText +=
                    "   •   "
                            + sourceType;
        }

        accountInfo.setText(
                infoText);

        accountInfo.setTextColor(
                host.silver());

        accountInfo.setTextSize(12);

        accountInfo.setPadding(
                0,
                host.dp(6),
                0,
                0);

        accountCard.addView(
                accountInfo);

        LinearLayout.LayoutParams accountParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);

        accountParams.setMargins(
                0,
                0,
                0,
                host.dp(18));

        root.addView(
                accountCard,
                accountParams);

        Button playlistsButton =
                new Button(context);

        playlistsButton.setText(
                "MANAGE PLAYLISTS");

        playlistsButton.setTextColor(
                host.black());

        playlistsButton.setTextSize(13);

        playlistsButton.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        playlistsButton.setAllCaps(
                false);

        playlistsButton.setBackground(
                host.makeBackground(
                        host.gold(),
                        host.gold(),
                        14));

        playlistsButton.setOnClickListener(
                v -> host.showPlaylists());

        host.makeTvRemoteReady(
                playlistsButton);

        host.addTvFocusScale(
                playlistsButton);

        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        buttonParams.setMargins(
                0,
                0,
                0,
                host.dp(10));

        root.addView(
                playlistsButton,
                buttonParams);

        Button settingsButton =
                new Button(context);

        settingsButton.setText(
                "PLAYER SETTINGS");

        settingsButton.setTextColor(
                Color.WHITE);

        settingsButton.setTextSize(13);

        settingsButton.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        settingsButton.setAllCaps(
                false);

        settingsButton.setBackground(
                host.makeBackground(
                        host.charcoal(),
                        Color.rgb(
                                60,
                                60,
                                64),
                        14));

        settingsButton.setOnClickListener(
                v -> host.showSettings());

        host.makeTvRemoteReady(
                settingsButton);

        host.addTvFocusScale(
                settingsButton);

        LinearLayout.LayoutParams settingsParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(52));

        root.addView(
                settingsButton,
                settingsParams);

        host.setContentView(
                scrollView);

        playlistsButton.post(
                () -> playlistsButton.requestFocus());
    }

}
