package com.premiumplayer.app;

import android.content.SharedPreferences;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;

final class SportsGuideSupport {

    static HashSet<String> csvSet(SharedPreferences p, String key) {
        HashSet<String> out = new HashSet<String>();
        String raw = p.getString(key, "");
        if (raw == null || raw.trim().isEmpty()) return out;
        for (String v : raw.split(",")) {
            String c = v.trim();
            if (!c.isEmpty()) out.add(c);
        }
        return out;
    }

    static String joinSet(HashSet<String> values) {
        ArrayList<String> sorted = new ArrayList<String>(values);
        Collections.sort(sorted);
        StringBuilder out = new StringBuilder();
        for (String v : sorted) {
            if (out.length() > 0) out.append(",");
            out.append(v);
        }
        return out.toString();
    }

    static boolean customMode(SharedPreferences p) {
        return "CUSTOM".equals(
                p.getString("sports_pref_mode", "ALL"));
    }

    static void savePrefs(
            SharedPreferences p,
            HashSet<String> sports,
            HashSet<String> competitions) {

        p.edit()
                .putString("sports_pref_mode", "CUSTOM")
                .putString("sports_pref_all_sports", joinSet(sports))
                .putString("sports_pref_competitions", joinSet(competitions))
                .apply();
    }

    static String initials(String name) {
        String clean = safe(name).trim();
        if (clean.isEmpty()) return "SP";

        StringBuilder out = new StringBuilder();

        for (String part : clean.split("\\s+")) {
            if (part.isEmpty()) continue;
            char c = part.charAt(0);
            if (Character.isLetterOrDigit(c))
                out.append(Character.toUpperCase(c));
            if (out.length() >= 2) break;
        }

        return out.length() == 0 ? "SP" : out.toString();
    }

    static boolean isSportsChannel(Channel channel) {
        String text = normalize(
                safe(channel.name) + " "
                + safe(channel.group) + " "
                + safe(channel.tvgName));

        String[] words = {
                "sport","sports","football","soccer",
                "premierleague","championsleague",
                "eurosport","espn","skysports","bein","dazn",
                "nba","nfl","nhl","mlb","ufc","boxing",
                "f1","formula1","motogp","tennis",
                "golf","rugby","cricket"
        };

        for (String word : words) {
            if (text.contains(normalize(word))) return true;
        }

        return false;
    }

    private static String normalize(String value) {
        if (value == null || value.isEmpty()) return "";

        String d = Normalizer.normalize(
                value, Normalizer.Form.NFD)
                .toLowerCase(Locale.US);

        StringBuilder out = new StringBuilder();

        for (int i = 0; i < d.length(); i++) {
            char c = d.charAt(i);
            int type = Character.getType(c);

            if (type == Character.NON_SPACING_MARK
                    || type == Character.COMBINING_SPACING_MARK
                    || type == Character.ENCLOSING_MARK)
                continue;

            if (Character.isLetterOrDigit(c)) out.append(c);
        }

        return out.toString();
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }
}
