package com.premiumplayer.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.exoplayer2.ui.PlayerView;

import java.util.Locale;

final class PlayerScreenLayout {

    interface Host {
        int dp(int value);

        GradientDrawable background(
                int fill,
                int stroke,
                int radius);

        void attachTrackControls(
                PlayerView playerView);

        void goBack(
                String mediaType);

        void enterFullscreen();

        String audioLanguageName(
                String language);
    }

    static final class Views {
        LinearLayout screen;
        PlayerView playerView;
        TextView nowText;
        TextView nextText;
        TextView status;
    }

    static Views create(
            Activity activity,
            Host host,
            String mediaType,
            String channel,
            String group,
            String now,
            String next,
            String extension,
            String preferredLanguage,
            int black,
            int gold,
            int silver) {

        Views result =
                new Views();

        LinearLayout screen =
                new LinearLayout(activity);

        screen.setOrientation(
                LinearLayout.VERTICAL);

        screen.setPadding(
                host.dp(16),
                host.dp(18),
                host.dp(16),
                host.dp(24));

        screen.setBackgroundColor(
                black);

        TextView back =
                new TextView(activity);

        if ("MOVIE".equals(mediaType)) {
            back.setText("<  MOVIES");
        } else if ("EPISODE".equals(mediaType)) {
            back.setText("<  SERIES");
        } else {
            back.setText("<  LIVE TV");
        }

        back.setOnClickListener(
                v -> host.goBack(mediaType));

        back.setTextColor(gold);
        back.setTextSize(16);
        back.setClickable(true);
        back.setFocusable(true);

        back.setPadding(
                0,
                0,
                0,
                host.dp(14));

        screen.addView(back);

        PlayerView playerView =
                new PlayerView(activity);

        playerView.setUseController(true);
        playerView.setBackgroundColor(
                Color.BLACK);

        LinearLayout.LayoutParams playerParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(230));

        screen.addView(
                playerView,
                playerParams);

        host.attachTrackControls(
                playerView);

        TextView title =
                new TextView(activity);

        title.setText(channel);
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        title.setPadding(
                0,
                host.dp(16),
                0,
                host.dp(4));

        screen.addView(title);

        TextView nowText =
                new TextView(activity);

        if ("LIVE".equals(mediaType)) {

            nowText.setText(
                    now == null || now.isEmpty()
                            ? group
                            : "NOW  " + now);

        } else if ("MOVIE".equals(mediaType)) {

            nowText.setText("Movie");

        } else {

            nowText.setText(
                    now == null || now.isEmpty()
                            ? "Episode"
                            : now);
        }

        nowText.setTextColor(silver);
        nowText.setTextSize(14);

        screen.addView(nowText);

        TextView nextText =
                new TextView(activity);

        if ("LIVE".equals(mediaType)) {

            nextText.setText(
                    next == null || next.isEmpty()
                            ? "EPG loading..."
                            : "NEXT  " + next);

        } else {

            nextText.setText(
                    extension == null || extension.isEmpty()
                            ? ""
                            : extension.toUpperCase(Locale.US));
        }

        nextText.setTextColor(
                Color.rgb(
                        135,
                        135,
                        140));

        nextText.setTextSize(12);

        nextText.setPadding(
                0,
                host.dp(4),
                0,
                host.dp(10));

        screen.addView(nextText);

        TextView audioInfo =
                new TextView(activity);

        audioInfo.setText(
                "Preferred audio: "
                        + host.audioLanguageName(
                                preferredLanguage));

        audioInfo.setTextColor(gold);
        audioInfo.setTextSize(12);

        audioInfo.setPadding(
                0,
                host.dp(4),
                0,
                host.dp(8));

        screen.addView(audioInfo);

        TextView fullScreenButton =
                new TextView(activity);

        fullScreenButton.setText(
                "⛶  FULL SCREEN");

        fullScreenButton.setTextColor(gold);
        fullScreenButton.setTextSize(14);

        fullScreenButton.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        fullScreenButton.setGravity(
                Gravity.CENTER);

        fullScreenButton.setClickable(true);
        fullScreenButton.setFocusable(true);

        fullScreenButton.setPadding(
                host.dp(12),
                host.dp(12),
                host.dp(12),
                host.dp(12));

        fullScreenButton.setBackground(
                host.background(
                        Color.rgb(24, 24, 26),
                        Color.rgb(70, 65, 52),
                        12));

        LinearLayout.LayoutParams fullParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        host.dp(48));

        fullParams.setMargins(
                0,
                host.dp(4),
                0,
                host.dp(8));

        screen.addView(
                fullScreenButton,
                fullParams);

        fullScreenButton.setOnClickListener(
                v -> host.enterFullscreen());

        playerView.setOnLongClickListener(
                v -> {
                    host.enterFullscreen();
                    return true;
                });

        TextView status =
                new TextView(activity);

        status.setTextColor(silver);
        status.setTextSize(12);

        status.setPadding(
                0,
                host.dp(4),
                0,
                0);

        screen.addView(status);

        PlayerFullscreenLayout.apply(activity, screen, playerView);
        result.screen = screen;
        result.playerView = playerView;
        result.nowText = nowText;
        result.nextText = nextText;
        result.status = status;

        return result;
    }
}
