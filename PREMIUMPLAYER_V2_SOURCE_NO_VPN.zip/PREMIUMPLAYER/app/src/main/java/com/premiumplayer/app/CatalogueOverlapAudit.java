package com.premiumplayer.app;

import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

final class CatalogueOverlapAudit {

    private static long sharedIds(
            SQLiteDatabase db,
            String table,
            String idColumn,
            String providerKey,
            long generation) {

        String sql =
                "SELECT COUNT(*) FROM ("
                + "SELECT " + idColumn
                + " FROM " + table
                + " WHERE provider_key=?"
                + " GROUP BY " + idColumn
                + " HAVING SUM(CASE WHEN import_generation=?"
                + " THEN 1 ELSE 0 END)>0"
                + " AND SUM(CASE WHEN"
                + " COALESCE(import_generation,0)<>?"
                + " THEN 1 ELSE 0 END)>0)";

        String g = Long.toString(generation);

        return DatabaseUtils.longForQuery(
                db, sql,
                new String[]{providerKey, g, g});
    }

    static String report(
            SQLiteDatabase db,
            String providerKey,
            long generation) {

        long movies = sharedIds(
                db, "catalogue_movies",
                "stream_id", providerKey, generation);

        long series = sharedIds(
                db, "catalogue_series",
                "series_id", providerKey, generation);

        return "\n\nIDs in both generations:"
                + "\nMovies: " + movies
                + "\nSeries: " + series;
    }
}
