package com.premiumplayer.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.JsonReader;
import android.util.JsonToken;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.MappingTrackSelector;
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.ui.TrackSelectionDialogBuilder;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URLDecoder;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private int GOLD = Color.rgb(205, 174, 104);
    private int BLACK = Color.rgb(10, 10, 11);
    private int CHARCOAL = Color.rgb(24, 24, 26);
    private int SILVER = Color.rgb(190, 190, 195);

    private static final int PICK_M3U_FILE = 4101;
    private static final int VPN_PERMISSION_REQUEST = 4202;
    private static final int PICK_WIREGUARD_CONFIG = 4203;
    private static final int MAX_CHANNEL_CARDS = 80;
    private static final String BUILD_LABEL = "BUILD 0.53.4.2 POSTER FOCUS FIX";
    private static final String GLOBAL_PREFS = "premium_player_global";
    private static final String PROFILE_PREFS_PREFIX = "premium_player_profile_";
    private static final String LEGACY_PREFS = "premium_player";
    private static final String PLAYLIST_FILE_PREFIX = "premium_playlist_";
    private static final String CATALOGUE_DB_PREFIX = "premium_catalogue_";
    private static final String CAST_INDEX_FILE = "premium_cast_index.jsonl";
    private static final String CAST_SCANNED_FILE = "premium_cast_scanned.txt";
    private static final int CAST_INDEX_BATCH_SIZE = 20;
    private static final String CAST_BACKEND_BASE_URL = "https://suouvnvtibawqcdimfqb.supabase.co/functions/v1";
    private static final String SUPABASE_REST_BASE_URL = "https://suouvnvtibawqcdimfqb.supabase.co/rest/v1";
    private static final String CAST_BACKEND_PUBLISHABLE_KEY = "sb_publishable_Qbt02WgwSh56h7NntS_gmw_Kk74j5Ld";
    private static final int CAST_BACKEND_BATCH_SIZE = 20;
    private static final int CAST_BACKEND_CACHE_PULL_BATCH_SIZE = 25;
    private static final long CAST_LOCAL_PULL_MAX_AGE_MS = 30L * 60L * 1000L;
    private static final long CAST_BACKEND_SYNC_MAX_AGE_MS = 24L * 60L * 60L * 1000L;
    private static final int 
    CATALOGUE_DB_VERSION = 8;

    private static final long CATALOGUE_SYNC_MAX_AGE_MS = 6L * 60L * 60L * 1000L;
    private static final long DEFAULT_HOME_ARTWORK_ROTATION_MS = 15L * 1000L;

    private final Handler homeArtworkHandler =
            new Handler(Looper.getMainLooper());
    private Runnable homeArtworkRotationRunnable;
    private int homeArtworkGeneration = 0;

    private boolean onHomeScreen = true;
    private String activePlaylistId = "default";

    private final HashSet<String> favouriteChannels = new HashSet<String>();
    private final HashSet<String> hiddenHomeSections = new HashSet<String>();
    private final ArrayList<String> homeOrder = new ArrayList<String>();
    private final ArrayList<Channel> importedChannels = new ArrayList<Channel>();

    private String selectedChannel = "NEWS 24";
    private String selectedNow = "Morning News";
    private String selectedNext = "World Report";
    private String selectedGroup = "NEWS";
    private String selectedStreamUrl = "";
    private String selectedStreamId = "";
    private String selectedDirectSource = "";
    private String selectedContainerExtension = "";
    private String selectedMediaType = "LIVE";
    private String selectedReturnScreen = "LIVE";
    private String activeLiveFilter = "ALL";
    private int mediaCategoryLoadToken = 0;
    private int mediaDetailLoadToken = 0;
    private final HashMap<String, Bitmap> posterCache = new HashMap<String, Bitmap>();
    private final ExecutorService posterImageExecutor =
            Executors.newFixedThreadPool(4);
    private final Object castIndexLock = new Object();
    private boolean castIndexUpdating = false;
    private boolean globalMediaSearchRunning = false;
    private final Object catalogueDbLock = new Object();
    private final ExecutorService catalogueExecutor =
            Executors.newSingleThreadExecutor();
    private CatalogueDbHelper catalogueDbHelper;
    private boolean movieCatalogueSyncing = false;
    private boolean seriesCatalogueSyncing = false;
    private volatile boolean backendMovieIndexRunning = false;
    private volatile boolean backendSeriesIndexRunning = false;
    private GridView activeMediaGridView;
    private MediaGridAdapter activeMediaAdapter;
    private String activeMediaCategoryId = "";

    private GridLayout activeMediaBrowseGrid;
    private TextView activeMediaBrowseCount;
    private final ArrayList<MovieItem> activeBrowseMovies =
            new ArrayList<MovieItem>();
    private final ArrayList<SeriesItem> activeBrowseSeries =
            new ArrayList<SeriesItem>();
    private String activeMediaBrowseType = "";
    private String lastMovieCategoryId = "";
    private String lastSeriesCategoryId = "";
    private boolean liveBrowserMode = false;
    private PlayerView livePreviewPlayerView;
    private TextView livePreviewTitle;
    private TextView livePreviewNow;
    private TextView livePreviewNext;
    private TextView livePreviewStatus;
    private long lastLiveChannelPressAt = 0L;
    private String lastLiveChannelPressKey = "";
    private static final long LIVE_DOUBLE_OK_WINDOW_MS = 550L;

    private final ArrayList<String> playbackCandidates = new ArrayList<String>();
    private int playbackCandidateIndex = 0;
    private PlayerView activePlayerView;
    private TextView activePlaybackStatus;
    private boolean playerFullScreen = false;
    private LinearLayout activePlayerScreen;

    private SimpleExoPlayer exoPlayer;
    private DefaultTrackSelector activeTrackSelector;

    private View lastTvFocusedView;
    private ViewTreeObserver.OnGlobalFocusChangeListener tvFocusListener;
    private SeriesItem activeEpisodeSeries;
    private final ArrayList<EpisodeItem> activeSeriesEpisodes =
            new ArrayList<EpisodeItem>();
    private int activeEpisodeIndex = -1;

    private String currentResumeKey = "";
    private long playbackStartPositionMs = 0L;
    private boolean handlingPlaybackEnd = false;

    private final Handler resumeHandler =
            new Handler(Looper.getMainLooper());
    private Runnable resumeSaveRunnable;

    // Build 0.41: in-app WireGuard. No external VPN application is required.
    private EmbeddedWireGuardManager embeddedVpn;
    private final Handler vpnHealthHandler = new Handler(Looper.getMainLooper());
    private Runnable vpnHealthRunnable;
    private Runnable pendingVpnConnectedAction;
    private boolean playbackPausedByVpn = false;

    private volatile ServerSocket qrPairingServerSocket;
    private volatile boolean qrPairingActive = false;
    private String qrPairingToken = "";
    private long qrPairingExpiresAt = 0L;
    private static final long QR_PAIRING_WINDOW_MS = 5 * 60 * 1000L;


    private final String[] defaultHomeOrder = {
            "LIVE TV",
            "MOVIES",
            "SERIES",
            "SPORTS GUIDE",
            "SETTINGS"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        initializePlaylistProfiles();
        loadVisualTheme();

        Window window = getWindow();
        window.setStatusBarColor(BLACK);
        window.setNavigationBarColor(BLACK);

        loadFavourites();
        loadHomeLayout();
        loadSavedPlaylist();
        loadSelectedLiveChannel();

        // Build 0.38: schedule a real daily background discovery pass.
        // IPTV credentials remain on-device; the worker only sends metadata
        // for newly discovered stream IDs to the shared cast backend.
        DailyCastSyncJobService.schedule(this);
        new Thread(() -> DailyCastSyncJobService.seedKnownIdsFromCatalogue(getApplicationContext()), "premium-catalogue-seed").start();

        // Build 0.39: pull completed shared cast metadata back into the
        // local SQLite catalogue without re-querying the IPTV provider.
        new Handler(Looper.getMainLooper()).postDelayed(
                () -> pullCompletedCastCacheAsync(false),
                1200L);

        embeddedVpn = new EmbeddedWireGuardManager(getApplicationContext());
        startEmbeddedVpnHealthMonitor();

        showStartupDestination();
        installTvFocusHighlighter();
    }

    // ---------------------------------------------------------------------
    // PLAYLIST PROFILES (Build 0.42)
    // ---------------------------------------------------------------------

    private android.content.SharedPreferences globalPrefs() {
        return getSharedPreferences(GLOBAL_PREFS, MODE_PRIVATE);
    }

    private android.content.SharedPreferences prefsForPlaylist(String playlistId) {
        String id = sanitizePlaylistId(playlistId);
        if (id.isEmpty()) id = "default";
        return getSharedPreferences(PROFILE_PREFS_PREFIX + id, MODE_PRIVATE);
    }

    private android.content.SharedPreferences playlistPrefs() {
        return prefsForPlaylist(activePlaylistId);
    }

    private android.content.SharedPreferences resumePrefs() {
        return getSharedPreferences(
                "premium_player_resume_" + sanitizePlaylistId(activePlaylistId),
                MODE_PRIVATE);
    }

    private String sanitizePlaylistId(String value) {
        String cleaned = value == null ? "" : value.replaceAll("[^A-Za-z0-9_-]", "");
        return cleaned.isEmpty() ? "default" : cleaned;
    }

    private String playlistFileName() {
        return PLAYLIST_FILE_PREFIX + sanitizePlaylistId(activePlaylistId) + ".m3u";
    }

    private String catalogueDbName() {
        return CATALOGUE_DB_PREFIX + sanitizePlaylistId(activePlaylistId) + ".db";
    }

    private ArrayList<String> getPlaylistProfileIds() {
        ArrayList<String> ids = new ArrayList<String>();
        String raw = globalPrefs().getString("playlist_ids", "default");
        if (raw != null) {
            for (String part : raw.split("\\|")) {
                String id = sanitizePlaylistId(part);
                if (!id.isEmpty() && !ids.contains(id)) ids.add(id);
            }
        }
        if (ids.isEmpty()) ids.add("default");
        return ids;
    }

    private void savePlaylistProfileIds(ArrayList<String> ids) {
        StringBuilder value = new StringBuilder();
        for (String id : ids) {
            if (id == null || id.trim().isEmpty()) continue;
            if (value.length() > 0) value.append("|");
            value.append(sanitizePlaylistId(id));
        }
        if (value.length() == 0) value.append("default");
        globalPrefs().edit().putString("playlist_ids", value.toString()).apply();
    }

    private String getPlaylistProfileName(String id) {
        android.content.SharedPreferences prefs = prefsForPlaylist(id);
        String name = prefs.getString("profile_display_name", "");
        if (name == null || name.trim().isEmpty()) {
            name = prefs.getString("playlist_name", "");
        }
        if (name == null || name.trim().isEmpty()) {
            ArrayList<String> ids = getPlaylistProfileIds();
            int index = ids.indexOf(sanitizePlaylistId(id));
            name = "Playlist " + (index >= 0 ? index + 1 : 1);
        }
        return name.trim();
    }

    private void setPlaylistProfileName(String id, String name) {
        String cleaned = name == null ? "" : name.trim();
        if (cleaned.isEmpty()) return;
        prefsForPlaylist(id).edit().putString("profile_display_name", cleaned).apply();
    }

    private void copySharedPreferences(
            android.content.SharedPreferences source,
            android.content.SharedPreferences target) {
        android.content.SharedPreferences.Editor editor = target.edit();
        for (java.util.Map.Entry<String, ?> entry : source.getAll().entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof String) editor.putString(key, (String) value);
            else if (value instanceof Boolean) editor.putBoolean(key, (Boolean) value);
            else if (value instanceof Integer) editor.putInt(key, (Integer) value);
            else if (value instanceof Long) editor.putLong(key, (Long) value);
            else if (value instanceof Float) editor.putFloat(key, (Float) value);
            else if (value instanceof java.util.Set) {
                try {
                    @SuppressWarnings("unchecked")
                    java.util.Set<String> set = (java.util.Set<String>) value;
                    editor.putStringSet(key, new HashSet<String>(set));
                } catch (Exception ignored) {
                }
            }
        }
        editor.apply();
    }

    private void initializePlaylistProfiles() {
        android.content.SharedPreferences global = globalPrefs();
        boolean migrated = global.getBoolean("profiles_migrated_042", false);

        if (!migrated) {
            String id = "default";
            android.content.SharedPreferences legacy =
                    getSharedPreferences(LEGACY_PREFS, MODE_PRIVATE);
            android.content.SharedPreferences profile = prefsForPlaylist(id);

            if (!legacy.getAll().isEmpty() && profile.getAll().isEmpty()) {
                copySharedPreferences(legacy, profile);
            }

            android.content.SharedPreferences oldResume =
                    getSharedPreferences("premium_player_resume", MODE_PRIVATE);
            android.content.SharedPreferences newResume =
                    getSharedPreferences("premium_player_resume_" + id, MODE_PRIVATE);
            if (!oldResume.getAll().isEmpty() && newResume.getAll().isEmpty()) {
                copySharedPreferences(oldResume, newResume);
            }

            android.content.SharedPreferences oldMediaFavourites =
                    getSharedPreferences("premium_media_favourites", MODE_PRIVATE);
            android.content.SharedPreferences newMediaFavourites =
                    getSharedPreferences("premium_media_favourites_" + id, MODE_PRIVATE);
            if (!oldMediaFavourites.getAll().isEmpty() && newMediaFavourites.getAll().isEmpty()) {
                copySharedPreferences(oldMediaFavourites, newMediaFavourites);
            }

            String display = profile.getString("profile_display_name", "");
            if (display == null || display.trim().isEmpty()) {
                String existingName = profile.getString("playlist_name", "Playlist 1");
                profile.edit().putString(
                        "profile_display_name",
                        existingName == null || existingName.trim().isEmpty()
                                ? "Playlist 1"
                                : existingName.trim()).apply();
            }

            File oldPlaylist = new File(getFilesDir(), "premium_playlist.m3u");
            File newPlaylist = new File(getFilesDir(), PLAYLIST_FILE_PREFIX + id + ".m3u");
            if (oldPlaylist.exists() && !newPlaylist.exists()) {
                oldPlaylist.renameTo(newPlaylist);
            }

            File oldDb = getDatabasePath("premium_catalogue.db");
            File newDb = getDatabasePath(CATALOGUE_DB_PREFIX + id + ".db");
            if (oldDb != null && oldDb.exists() && newDb != null && !newDb.exists()) {
                oldDb.renameTo(newDb);
                File oldWal = new File(oldDb.getAbsolutePath() + "-wal");
                File newWal = new File(newDb.getAbsolutePath() + "-wal");
                if (oldWal.exists() && !newWal.exists()) oldWal.renameTo(newWal);
                File oldShm = new File(oldDb.getAbsolutePath() + "-shm");
                File newShm = new File(newDb.getAbsolutePath() + "-shm");
                if (oldShm.exists() && !newShm.exists()) oldShm.renameTo(newShm);
            }

            global.edit()
                    .putString("playlist_ids", id)
                    .putString("active_playlist_id", id)
                    .putBoolean("profiles_migrated_042", true)
                    .apply();
        }

        ArrayList<String> ids = getPlaylistProfileIds();
        String savedActive = sanitizePlaylistId(global.getString("active_playlist_id", ids.get(0)));
        activePlaylistId = ids.contains(savedActive) ? savedActive : ids.get(0);
        global.edit().putString("active_playlist_id", activePlaylistId).apply();
    }

    private String createPlaylistProfile() {
        ArrayList<String> ids = getPlaylistProfileIds();
        String id = "p" + Long.toString(System.currentTimeMillis(), 36);
        while (ids.contains(id)) id += "x";
        ids.add(id);
        savePlaylistProfileIds(ids);
        setPlaylistProfileName(id, "Playlist " + ids.size());
        return id;
    }

    private void switchPlaylistProfile(String playlistId) {
        String id = sanitizePlaylistId(playlistId);
        if (!getPlaylistProfileIds().contains(id)) return;

        releasePlayer();
        closeActiveMediaAdapter();
        if (catalogueDbHelper != null) {
            try { catalogueDbHelper.close(); } catch (Exception ignored) {}
            catalogueDbHelper = null;
        }

        activePlaylistId = id;
        globalPrefs().edit().putString("active_playlist_id", id).apply();
        importedChannels.clear();
        favouriteChannels.clear();
        posterCache.clear();
        lastMovieCategoryId = "";
        lastSeriesCategoryId = "";
        activeMediaCategoryId = "";

        loadVisualTheme();
        loadFavourites();
        loadHomeLayout();
        loadSavedPlaylist();
        loadSelectedLiveChannel();

        new Thread(() -> DailyCastSyncJobService.seedKnownIdsFromCatalogue(getApplicationContext()), "premium-catalogue-seed").start();
        pullCompletedCastCacheAsync(false);
        showPlaylists();
    }

    private void deleteActivePlaylistProfile() {
        ArrayList<String> ids = getPlaylistProfileIds();

        if (ids.size() <= 1) {
            importedChannels.clear();
            deleteFile(playlistFileName());
            playlistPrefs().edit().clear().putString("profile_display_name", "Playlist 1").apply();
            resumePrefs().edit().clear().apply();
            mediaFavouritePrefs().edit().clear().apply();
            resetSelectedLiveChannel();
            loadVisualTheme();
            showPlaylists();
            return;
        }

        String deleting = activePlaylistId;
        if (catalogueDbHelper != null) {
            try { catalogueDbHelper.close(); } catch (Exception ignored) {}
            catalogueDbHelper = null;
        }
        deleteFile(playlistFileName());
        prefsForPlaylist(deleting).edit().clear().apply();
        getSharedPreferences("premium_player_resume_" + deleting, MODE_PRIVATE).edit().clear().apply();
        getSharedPreferences("premium_media_favourites_" + deleting, MODE_PRIVATE).edit().clear().apply();
        try { deleteDatabase(CATALOGUE_DB_PREFIX + deleting + ".db"); } catch (Exception ignored) {}

        ids.remove(deleting);
        savePlaylistProfileIds(ids);
        switchPlaylistProfile(ids.get(0));
    }

    private void saveSelectedLiveChannel() {
        if (!"LIVE".equals(selectedMediaType)) return;
        playlistPrefs().edit()
                .putString("last_live_name", safe(selectedChannel))
                .putString("last_live_group", safe(selectedGroup))
                .putString("last_live_url", safe(selectedStreamUrl))
                .putString("last_live_stream_id", safe(selectedStreamId))
                .putString("last_live_direct", safe(selectedDirectSource))
                .putString("last_live_now", safe(selectedNow))
                .putString("last_live_next", safe(selectedNext))
                .apply();
    }

    private void loadSelectedLiveChannel() {
        android.content.SharedPreferences prefs = playlistPrefs();
        String name = prefs.getString("last_live_name", "");
        if (name == null || name.trim().isEmpty()) {
            String legacyKey = prefs.getString("last_live_channel_key", "");
            if (legacyKey != null && !legacyKey.trim().isEmpty()) {
                for (Channel channel : importedChannels) {
                    if (legacyKey.equals(channel.key())) {
                        selectChannelInternal(channel);
                        return;
                    }
                }
            }
            resetSelectedLiveChannel();
            return;
        }
        selectedChannel = name;
        selectedGroup = prefs.getString("last_live_group", "");
        selectedStreamUrl = prefs.getString("last_live_url", "");
        selectedStreamId = prefs.getString("last_live_stream_id", "");
        selectedDirectSource = prefs.getString("last_live_direct", "");
        selectedNow = prefs.getString("last_live_now", "");
        selectedNext = prefs.getString("last_live_next", "");
        selectedContainerExtension = "";
        selectedMediaType = "LIVE";
        selectedReturnScreen = "LIVE";
    }

    private void resetSelectedLiveChannel() {
        selectedChannel = importedChannels.isEmpty() ? "NEWS 24" : importedChannels.get(0).name;
        selectedNow = importedChannels.isEmpty() ? "Morning News" : safe(importedChannels.get(0).now);
        selectedNext = importedChannels.isEmpty() ? "World Report" : safe(importedChannels.get(0).next);
        selectedGroup = importedChannels.isEmpty() ? "NEWS" : safe(importedChannels.get(0).group);
        selectedStreamUrl = importedChannels.isEmpty() ? "" : safe(importedChannels.get(0).url);
        selectedStreamId = importedChannels.isEmpty() ? "" : safe(importedChannels.get(0).streamId);
        selectedDirectSource = importedChannels.isEmpty() ? "" : safe(importedChannels.get(0).directSource);
        selectedContainerExtension = "";
        selectedMediaType = "LIVE";
        selectedReturnScreen = "LIVE";
    }

    // ---------------------------------------------------------------------
    // SAVED SETTINGS
    // ---------------------------------------------------------------------

    private void loadVisualTheme() {
        String theme =
                playlistPrefs()
                        .getString("home_colour_theme", "GOLD");

        if ("BLUE".equals(theme)) {
            GOLD = Color.rgb(67, 150, 235);
        } else if ("RED".equals(theme)) {
            GOLD = Color.rgb(229, 72, 77);
        } else if ("GREEN".equals(theme)) {
            GOLD = Color.rgb(72, 190, 126);
        } else if ("PURPLE".equals(theme)) {
            GOLD = Color.rgb(161, 105, 224);
        } else {
            GOLD = Color.rgb(205, 174, 104);
        }
    }

    private String getVisualThemeName() {
        return playlistPrefs()
                .getString("home_colour_theme", "GOLD");
    }

    private boolean isHomeResumeSlotEnabled(int slot) {
        return playlistPrefs()
                .getBoolean("home_resume_slot_" + slot, true);
    }

    private void setHomeResumeSlotEnabled(int slot, boolean enabled) {
        playlistPrefs()
                .edit()
                .putBoolean("home_resume_slot_" + slot, enabled)
                .apply();
    }

    private void loadFavourites() {
        HashSet<String> saved = new HashSet<String>(
                playlistPrefs()
                        .getStringSet("favourites", new HashSet<String>()));

        favouriteChannels.clear();
        favouriteChannels.addAll(saved);
    }

    private void saveFavourites() {
        playlistPrefs()
                .edit()
                .putStringSet(
                        "favourites",
                        new HashSet<String>(favouriteChannels))
                .apply();
    }

    private void loadHomeLayout() {
        String savedOrder =
                playlistPrefs()
                        .getString("home_order", "");

        homeOrder.clear();

        if (savedOrder == null || savedOrder.trim().isEmpty()) {
            for (String item : defaultHomeOrder) {
                homeOrder.add(item);
            }
        } else {
            String[] savedItems = savedOrder.split("\\|");

            for (String item : savedItems) {
                if (!item.trim().isEmpty()) {
                    homeOrder.add(item);
                }
            }

            for (String defaultItem : defaultHomeOrder) {
                if (!homeOrder.contains(defaultItem)) {
                    homeOrder.add(defaultItem);
                }
            }
        }

        HashSet<String> hidden = new HashSet<String>(
                playlistPrefs()
                        .getStringSet(
                                "hidden_home_sections",
                                new HashSet<String>()));

        hiddenHomeSections.clear();
        hiddenHomeSections.addAll(hidden);
        normalizeV053HomeLayout();
    }

    private void saveHomeLayout() {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < homeOrder.size(); i++) {
            if (i > 0) {
                builder.append("|");
            }

            builder.append(homeOrder.get(i));
        }

        playlistPrefs()
                .edit()
                .putString("home_order", builder.toString())
                .putStringSet(
                        "hidden_home_sections",
                        new HashSet<String>(hiddenHomeSections))
                .apply();
    }

    private void restoreDefaultHomeLayout() {
        homeOrder.clear();

        for (String item : defaultHomeOrder) {
            homeOrder.add(item);
        }

        hiddenHomeSections.clear();
        saveHomeLayout();
        showEditHome();
    }

    // ---------------------------------------------------------------------
    // HOME
    // ---------------------------------------------------------------------

    private boolean isV053HomeTile(String title) {
        return "LIVE TV".equals(title)
                || "MOVIES".equals(title)
                || "SERIES".equals(title)
                || "SPORTS GUIDE".equals(title)
                || "SETTINGS".equals(title);
    }

    private void normalizeV053HomeLayout() {
        ArrayList<String> cleaned = new ArrayList<String>();

        for (String raw : homeOrder) {
            String title = "USER MANAGEMENT".equals(raw)
                    ? "SETTINGS"
                    : raw;

            if (isV053HomeTile(title)
                    && !cleaned.contains(title)) {
                cleaned.add(title);
            }
        }

        for (String title : defaultHomeOrder) {
            if (!cleaned.contains(title)) {
                cleaned.add(title);
            }
        }

        homeOrder.clear();
        homeOrder.addAll(cleaned);

        HashSet<String> cleanedHidden =
                new HashSet<String>();

        for (String raw : hiddenHomeSections) {
            String title = "USER MANAGEMENT".equals(raw)
                    ? "SETTINGS"
                    : raw;

            if (isV053HomeTile(title)
                    && !"SETTINGS".equals(title)) {
                cleanedHidden.add(title);
            }
        }

        hiddenHomeSections.clear();
        hiddenHomeSections.addAll(cleanedHidden);
        saveHomeLayout();
    }

    private void addConfiguredHomeTile(
            LinearLayout tileRow,
            String title) {

        if ("LIVE TV".equals(title)) {
            addHorizontalHomeTile(
                    tileRow,
                    "LIVE TV",
                    importedChannels.size() > 0
                            ? importedChannels.size()
                            + " channels"
                            : "Watch live channels",
                    () -> showLiveTv("ALL"));
            return;
        }

        if ("MOVIES".equals(title)) {
            addHorizontalHomeTile(
                    tileRow,
                    "MOVIES",
                    "Browse your movie library",
                    this::showMovies);
            return;
        }

        if ("SERIES".equals(title)) {
            addHorizontalHomeTile(
                    tileRow,
                    "SERIES",
                    "Browse seasons and episodes",
                    this::showSeries);
            return;
        }

        if ("SPORTS GUIDE".equals(title)) {
            addHorizontalHomeTile(
                    tileRow,
                    "SPORTS GUIDE",
                    "Fixtures, teams and playable sports",
                    this::showSportsGuide);
            return;
        }

        if ("SETTINGS".equals(title)) {
            addHorizontalHomeTile(
                    tileRow,
                    "SETTINGS",
                    "Accounts, playlists and player settings",
                    this::showUserManagement);
        }
    }

    private String getStartupDestination() {
        return playlistPrefs()
                .getString(
                        "startup_destination",
                        "HOME");
    }

    private void setStartupDestination(
            String destination) {

        playlistPrefs()
                .edit()
                .putString(
                        "startup_destination",
                        safe(destination))
                .apply();
    }

    private String getStartupDestinationLabel(
            String destination) {

        if ("LAST LIVE CHANNEL".equals(destination)) {
            return "LAST LIVE CHANNEL";
        }

        if ("LIVE TV".equals(destination)) {
            return "LIVE TV";
        }

        if ("SPORTS GUIDE".equals(destination)) {
            return "SPORTS GUIDE";
        }

        if ("MOVIES".equals(destination)) {
            return "MOVIES";
        }

        if ("SERIES".equals(destination)) {
            return "SERIES";
        }

        return "HOME";
    }

    private void showStartupDestination() {
        String destination =
                getStartupDestination();

        if ("LAST LIVE CHANNEL".equals(destination)) {
            boolean hasSavedLive =
                    !safe(selectedStreamUrl).isEmpty()
                            || !safe(selectedStreamId).isEmpty()
                            || !safe(selectedDirectSource).isEmpty();

            if (hasSavedLive) {
                selectedMediaType = "LIVE";
                selectedReturnScreen = "LIVE";
                showPlayerScreen();
            } else {
                showLiveTv("ALL");
            }
            return;
        }

        if ("LIVE TV".equals(destination)) {
            showLiveTv("ALL");
            return;
        }

        if ("SPORTS GUIDE".equals(destination)) {
            showSportsGuide();
            return;
        }

        if ("MOVIES".equals(destination)) {
            showMovies();
            return;
        }

        if ("SERIES".equals(destination)) {
            showSeries();
            return;
        }

        showHome();
    }

    private void addStartupDestinationButton(
            LinearLayout root,
            String label,
            String destination) {

        boolean selected =
                destination.equals(
                        getStartupDestination());

        Button button =
                makeSmallButton(
                        label
                                + (selected
                                ? "   â¢   SELECTED"
                                : ""));

        button.setTextSize(13);
        button.setBackground(
                makeBackground(
                        selected
                                ? Color.rgb(35, 31, 23)
                                : CHARCOAL,
                        selected
                                ? GOLD
                                : Color.rgb(55, 55, 58),
                        12));

        button.setOnClickListener(v -> {
            setStartupDestination(
                    destination);
            showHomeScreenSettings();
        });

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(50));

        params.setMargins(
                0,
                0,
                0,
                dp(8));

        root.addView(
                button,
                params);
    }

    private ImageView premiumHomeHeroImage;
    private TextView premiumHomeHeroTitle;
    private TextView premiumHomeHeroDescription;

    private int premiumHomeHeroRequestId = 0;

    private String premiumHomeBackdropValue(
            JSONObject source) {

        if (source == null) {
            return "";
        }

        String[] keys = {
                "backdrop_path",
                "backdrop",
                "backdrop_url",
                "background"
        };

        for (String key : keys) {

            Object value =
                    source.opt(key);

            if (value instanceof JSONArray) {

                JSONArray array =
                        (JSONArray) value;

                if (array.length() > 0) {
                    String result =
                            safe(array.optString(0, ""));

                    if (result.isEmpty() == false) {
                        return result;
                    }
                }

            } else if (value != null
                    && value != JSONObject.NULL) {

                String result =
                        safe(String.valueOf(value));

                if (result.isEmpty() == false) {
                    return result;
                }
            }
        }

        return "";
    }

    private String normalizePremiumHomeBackdrop(
            String value) {

        String result =
                safe(value).trim();

        if (result.isEmpty()) {
            return "";
        }

        if (result.startsWith("//")) {
            return "https:" + result;
        }

        if (result.startsWith("/")) {
            return "https://image.tmdb.org/t/p/w1280"
                    + result;
        }

        return result;
    }

    private void loadPremiumHomeBackdropAsync(
            final ResumeHomeItem item,
            final int requestId) {
        final String requestPlaylistId = activePlaylistId;
        final String requestProviderKey = getCatalogueProviderKey();
        final String requestType = "MOVIE".equals(item.mediaType)
                ? "MOVIE" : "EPISODE".equals(item.mediaType)
                ? "SERIES" : "";
        final String requestIdValue = "MOVIE".equals(requestType)
                ? safe(item.mediaId) : "SERIES".equals(requestType)
                ? safe(item.seriesId) : "";
        final String requestUrl;
        try {
            requestUrl = requestIdValue.isEmpty() ? ""
                : "MOVIE".equals(requestType)
                ? buildXtreamApiUrl("get_vod_info", "vod_id", requestIdValue)
                : buildXtreamApiUrl("get_series_info", "series_id", requestIdValue);
        } catch (Exception urlError) {
            android.util.Log.w("PREMIUM_PLAYER", "Home URL creation failed", urlError);
            return;
        }


        new Thread(
                () -> {

                    String backdrop =
                            "";

                    try {

                        String text =
                                "";

                        if ("MOVIE".equals(item.mediaType)
                                && safe(item.mediaId).isEmpty() == false) {

                            text =
                                    downloadPlaylistText(
                                            requestUrl);

                        } else if ("EPISODE".equals(item.mediaType)
                                && safe(item.seriesId).isEmpty() == false) {

                            text =
                                    downloadPlaylistText(
                                            requestUrl);
                        }

                        if (text.isEmpty() == false) {

                            JSONObject root =
                                    new JSONObject(text);

                            try {
                                if (!requestType.isEmpty()
                                        && !requestIdValue.isEmpty()
                                        && requestPlaylistId.equals(activePlaylistId)
                                        && getPlaylistProfileIds().contains(requestPlaylistId)
                                        && requestProviderKey.equals(getCatalogueProviderKey())) {
                                    CatalogueDbHelper requestDb =
                                            new CatalogueDbHelper(
                                                    getApplicationContext(),
                                                    CATALOGUE_DB_PREFIX
                                                            + sanitizePlaylistId(requestPlaylistId)
                                                            + ".db");
                                    try {
                                        CatalogueDetailStore.save(
                                                requestDb.getWritableDatabase(),
                                                requestProviderKey,
                                                requestType,
                                                requestIdValue,
                                                text);
                                    } finally {
                                        requestDb.close();
                                    }
                                }
                            } catch (Exception cacheError) {
                                android.util.Log.w("PREMIUM_PLAYER",
                                        "Home metadata storage failed", cacheError);
                            }


                            JSONObject info =
                                    root.optJSONObject(
                                            "info");

                            JSONObject movieData =
                                    root.optJSONObject(
                                            "movie_data");

                            backdrop =
                                    firstNonEmpty(
                                            premiumHomeBackdropValue(info),
                                            premiumHomeBackdropValue(movieData),
                                            premiumHomeBackdropValue(root));
                        }

                    } catch (Exception ignored) {
                    }

                    final String finalBackdrop =
                            normalizePremiumHomeBackdrop(
                                    backdrop);

                    if (finalBackdrop.isEmpty()) {
                        return;
                    }

                    runOnUiThread(
                            () -> {

                                if (requestId
                                        != premiumHomeHeroRequestId
                                        || premiumHomeHeroImage == null) {
                                    return;
                                }

                                loadPosterImage(
                                        premiumHomeHeroImage,
                                        finalBackdrop);
                            });
                })
                .start();
    }

    private void updatePremiumHomeHero(
            ResumeHomeItem item) {

        if (item == null
                || premiumHomeHeroImage == null) {
            return;
        }

        String title =
                safe(item.title);

        if (title.isEmpty()) {
            title =
                    safe(item.seriesName);
        }

        premiumHomeHeroTitle.setText(
                title.isEmpty()
                        ? "PREMIUM PLAYER"
                        : title);

        String description;

        if ("EPISODE".equals(
                item.mediaType)) {

            description =
                    safe(item.seriesName);

            if (description.isEmpty()) {
                description =
                        "Continue watching series";
            }

        } else {

            description =
                    "Continue watching movie";
        }

        if (item.duration > 0L) {

            long remaining =
                    Math.max(
                            0L,
                            item.duration
                                    - item.position);

            description +=
                    "   •   "
                            + formatPlaybackTime(
                            remaining)
                            + " left";
        }

        premiumHomeHeroDescription.setText(
                description);

        final int heroRequestId =
                ++premiumHomeHeroRequestId;

        String cover =
                safe(item.cover);

        if (cover.isEmpty() == false) {

            loadPosterImage(
                    premiumHomeHeroImage,
                    cover);

        } else {

            loadResumeCoverAsyncV051(
                    premiumHomeHeroImage,
                    item);
        }

        loadPremiumHomeBackdropAsync(
                item,
                heroRequestId);
    }

    private static class PremiumTrendingItem {
        MovieItem movie;
        String title = "";
        String year = "";
        String rating = "";
        String poster = "";
        String backdrop = "";
    }

    private volatile boolean localDateRefillStarted = false;

    private void refreshLocalDatesOnce() {
        if (localDateRefillStarted) return;

        final String providerKey = getCatalogueProviderKey();
        if (safe(providerKey).isEmpty()) return;

        final android.content.SharedPreferences prefs =
                playlistPrefs();
        final String marker =
                "pp_date_refill_test_v1_" + providerKey;

        if (prefs.getBoolean(marker, false)) return;
        localDateRefillStarted = true;

        new Thread(() -> {
            try {
                SQLiteDatabase db =
                        getCatalogueDbHelper().getWritableDatabase();
                final long[] totals = new long[6];

                for (int i = 0; i < 2; i++) {
                    final int offset = i * 3;
                    final boolean movies = i == 0;
                    String action = movies
                            ? "get_vod_streams" : "get_series";
                    String table = movies
                            ? "catalogue_movies" : "catalogue_series";
                    String url =
                            buildXtreamApiUrl(action, null, null);

                    android.database.sqlite.SQLiteStatement stmt =
                            db.compileStatement(
                                    "UPDATE " + table
                                    + " SET added_at=?"
                                    + " WHERE pk=? AND added_at=0");

                    try {
                        streamJsonArray(url, reader -> {
                            totals[offset]++;

                            String id;
                            long added;

                            if (movies) {
                                MovieItem m =
                                        readMovieItemFromStream(reader);
                                id = m.streamId;
                                added = m.addedAt;
                            } else {
                                SeriesItem s =
                                        readSeriesItemFromStream(reader);
                                id = s.seriesId;
                                added = s.addedAt;
                            }

                            if (added <= 0L
                                    || safe(id).isEmpty()) return;

                            totals[offset + 1]++;
                            stmt.clearBindings();
                            stmt.bindLong(1, added);
                            stmt.bindString(2, providerKey + "|" + id);
                            totals[offset + 2] +=
                                    stmt.executeUpdateDelete();
                        });
                    } finally {
                        stmt.close();
                    }
                    android.util.Log.i(
                            "PP_RECENT_BACKFILL",
                            action + " scanned=" + totals[offset]
                            + " dated=" + totals[offset + 1]
                            + " updated=" + totals[offset + 2]);
                }

                prefs.edit().putBoolean(marker, true).apply();

                runOnUiThread(() -> {
                    if (onHomeScreen) showHome();
                });

            } catch (Exception e) {
                android.util.Log.e(
                        "PP_RECENT_BACKFILL",
                        "Provider refresh failed", e);
            } finally {
                localDateRefillStarted = false;
            }
        }).start();
    }

    private void populateLocalRecentlyAdded(
            final LinearLayout parent,
            final boolean movies) {

        final String key = getCatalogueProviderKey();

        new Thread(() -> {
            ArrayList<MovieItem> films = new ArrayList<>();
            ArrayList<SeriesItem> shows = new ArrayList<>();
            Cursor cursor = null;

            try {
                SQLiteDatabase db =
                        getCatalogueDbHelper().getReadableDatabase();

                String sql = movies
                        ? "SELECT stream_id,name,extension,direct_source,icon "
                        + "FROM catalogue_movies WHERE provider_key=? "
                        + "AND added_at>0 AND name LIKE 'EN - %' "
                        + "ORDER BY added_at DESC LIMIT 24"
                        : "SELECT series_id,name,cover "
                        + "FROM catalogue_series WHERE provider_key=? "
                        + "AND updated_at>0 AND name LIKE 'EN - %' "
                        + "ORDER BY updated_at DESC LIMIT 24";

                cursor = db.rawQuery(sql, new String[]{key});

                while (cursor.moveToNext()) {
                    if (movies) {
                        MovieItem m = new MovieItem();
                        m.streamId = cursor.getString(0);
                        m.name = cursor.getString(1);
                        m.extension = cursor.getString(2);
                        m.directSource = cursor.getString(3);
                        m.icon = cursor.getString(4);
                        films.add(m);
                    } else {
                        SeriesItem s = new SeriesItem();
                        s.seriesId = cursor.getString(0);
                        s.name = cursor.getString(1);
                        s.cover = cursor.getString(2);
                        shows.add(s);
                    }
                }
            } catch (Exception error) {
                android.util.Log.e("PP_RECENT", "Catalogue query failed", error);
            } finally {
                if (cursor != null) cursor.close();
            }

            runOnUiThread(() -> {
                if (!onHomeScreen) return;
                TextView heading = new TextView(this);
                heading.setText(movies
                        ? "Recently Added Movies"
                        : "Recently Updated Series");
                heading.setTextColor(Color.WHITE);
                heading.setTextSize(22);
                heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                heading.setPadding(0, dp(22), 0, dp(12));
                parent.addView(heading);

                int count = movies ? films.size() : shows.size();

                if (count == 0) {
                    TextView empty = new TextView(this);
                    empty.setText("No recently added titles available.");
                    empty.setTextColor(SILVER);
                    empty.setPadding(0, dp(8), 0, dp(18));
                    parent.addView(empty);
                    return;
                }

                android.widget.HorizontalScrollView scroll =
                        new android.widget.HorizontalScrollView(this);
                scroll.setHorizontalScrollBarEnabled(false);

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);

                for (int i = 0; i < count; i++) {
                    final MovieItem m = movies ? films.get(i) : null;
                    final SeriesItem s = movies ? null : shows.get(i);

                    LinearLayout card = new LinearLayout(this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setFocusable(true);

                    LinearLayout.LayoutParams cardParams =
                            new LinearLayout.LayoutParams(
                                    dp(160),
                                    LinearLayout.LayoutParams.WRAP_CONTENT);
                    cardParams.setMargins(0, 0, dp(14), 0);

                    ImageView poster = new ImageView(this);
                    poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    poster.setBackgroundColor(Color.DKGRAY);
                    card.addView(poster,
                            new LinearLayout.LayoutParams(
                                    dp(160), dp(220)));

                    String artwork = movies ? safe(m.icon) : safe(s.cover);
                    if (!artwork.isEmpty()) {
                        loadPosterImage(poster, artwork);
                    }
                    TextView title = new TextView(this);
                    title.setText(movies ? m.name : s.name);
                    title.setTextColor(Color.WHITE);
                    title.setTextSize(13);
                    title.setMaxLines(2);
                    title.setPadding(0, dp(7), 0, dp(5));
                    card.addView(title);

                    card.setOnClickListener(v -> {
                        if (movies) {
                            playMovie(m);
                        } else {
                            showSeriesDetails(s);
                        }
                    });

                    addFocusStyle(card, 14);
                    row.addView(card, cardParams);
                }

                scroll.addView(row);
                parent.addView(scroll);
            });
        }).start();
    }

    // Local catalogue recommendations. This is NOT cross-device trending:
    // ratings are stored in the on-device SQLite catalogue.
    private void populatePremiumTrendingThisWeek(final LinearLayout parent) {
        final String providerKey = getCatalogueProviderKey();
        new Thread(() -> {
            final ArrayList<PremiumTrendingItem> results = new ArrayList<>();
            Cursor cursor = null;
            try {
                SQLiteDatabase db = getCatalogueDbHelper().getReadableDatabase();
                cursor = db.rawQuery(
                        "SELECT stream_id,name,extension,direct_source,icon,year,rating "
                        + "FROM catalogue_movies WHERE provider_key=? "
                        + "AND name LIKE 'EN - %' AND CAST(rating AS REAL)>0 "
                        + "ORDER BY CAST(rating AS REAL) DESC, name ASC LIMIT 12",
                        new String[]{providerKey});
                while (cursor.moveToNext()) {
                    MovieItem movie = new MovieItem();
                    movie.streamId = cursor.getString(0);
                    movie.name = cursor.getString(1);
                    movie.extension = cursor.getString(2);
                    movie.directSource = cursor.getString(3);
                    movie.icon = cursor.getString(4);
                    PremiumTrendingItem item = new PremiumTrendingItem();
                    item.movie = movie;
                    item.title = movie.name;
                    item.poster = movie.icon;
                    item.year = cursor.getString(5);
                    item.rating = cursor.getString(6);
                    results.add(item);
                }
                // Fill partially rated catalogues from recently added local titles.
                // Keep rated entries first, without duplicates or backend calls.
                if (results.size() < 12) {
                    java.util.HashSet<String> seenIds = new java.util.HashSet<>();
                    for (PremiumTrendingItem existing : results) {
                        if (existing.movie != null && existing.movie.streamId != null) {
                            seenIds.add(existing.movie.streamId);
                        }
                    }
                    cursor.close();
                    cursor = null;
                    cursor = db.rawQuery(
                            "SELECT stream_id,name,extension,direct_source,icon,year,rating "
                            + "FROM catalogue_movies WHERE provider_key=? "
                            + "AND name LIKE 'EN - %' "
                            + "ORDER BY added_at DESC, name COLLATE NOCASE ASC LIMIT 12",
                            new String[]{providerKey});
                    while (cursor.moveToNext() && results.size() < 12) {
                        String streamId = cursor.getString(0);
                        if (streamId == null || !seenIds.add(streamId)) continue;
                        MovieItem movie = new MovieItem();
                        movie.streamId = streamId;
                        movie.name = cursor.getString(1);
                        movie.extension = cursor.getString(2);
                        movie.directSource = cursor.getString(3);
                        movie.icon = cursor.getString(4);
                        PremiumTrendingItem item = new PremiumTrendingItem();
                        item.movie = movie;
                        item.title = movie.name;
                        item.poster = movie.icon;
                        item.year = cursor.getString(5);
                        item.rating = cursor.getString(6);
                        results.add(item);
                    }
                }
            } catch (Exception error) {
                android.util.Log.e("PP_HOME", "Local recommendations query failed", error);
            } finally {
                if (cursor != null) cursor.close();
            }
            runOnUiThread(() -> {
                if (!onHomeScreen || parent.getParent() == null) return;
                TextView heading = new TextView(this);
                if (results.isEmpty()) return;
                heading.setText("Discover From Your Library");
                heading.setTextColor(Color.WHITE);
                heading.setTextSize(17);
                heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                heading.setPadding(0, dp(14), 0, dp(10));
                parent.addView(heading);
                HorizontalScrollView scroll = new HorizontalScrollView(this);
                scroll.setHorizontalScrollBarEnabled(false);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                scroll.addView(row);
                for (PremiumTrendingItem item : results) {
                    addPremiumTrendingCard(row, item);
                }
                parent.addView(scroll, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(132)));
            });
        }).start();
    }

    private void addPremiumTrendingCard(
            LinearLayout row,
            final PremiumTrendingItem item) {

        FrameLayout card =
                new FrameLayout(this);

        makeTvRemoteReady(card);

        card.setBackground(
                makeBackground(
                        Color.rgb(20, 21, 24),
                        Color.rgb(70, 70, 75),
                        12));

        ImageView artwork =
                new ImageView(this);

        artwork.setScaleType(
                ImageView.ScaleType.CENTER_CROP);

        card.addView(
                artwork,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));

        String imageUrl =
                firstNonEmpty(
                        item.backdrop,
                        item.poster,
                        (item.movie == null ? "" : item.movie.icon));

        if (!imageUrl.isEmpty()) {
            loadPosterImage(
                    artwork,
                    imageUrl);
        }

        TextView title =
                new TextView(this);

        title.setText(item.title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(12);
        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        title.setGravity(
                Gravity.BOTTOM);

        title.setPadding(
                dp(10),
                0,
                dp(10),
                dp(8));

        title.setBackgroundColor(
                Color.argb(
                        145,
                        0,
                        0,
                        0));

        card.addView(
                title,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        dp(42),
                        Gravity.BOTTOM));

        card.setOnClickListener(
                v -> {
                    if (item.movie != null) {
                        showMovieDetails(item.movie);
                    } else {
                        Toast.makeText(
                                this,
                                "Not available in your current playlist.",
                                Toast.LENGTH_SHORT)
                                .show();
                    }
                });

        card.setOnFocusChangeListener(
                (view, focused) -> {

                    view.setBackground(
                            makeBackground(
                                    focused
                                            ? Color.rgb(38, 31, 20)
                                            : Color.rgb(20, 21, 24),
                                    focused
                                            ? GOLD
                                            : Color.rgb(70, 70, 75),
                                    12));

                    view.setScaleX(
                            focused ? 1.035f : 1f);

                    view.setScaleY(
                            focused ? 1.035f : 1f);

                    if (focused) {

                        ++premiumHomeHeroRequestId;

                        if (premiumHomeHeroTitle != null) {
                            premiumHomeHeroTitle.setText(
                                    item.title);
                        }

                        String hero =
                                firstNonEmpty(
                                        item.backdrop,
                                        item.poster,
                                        (item.movie == null ? "" : item.movie.icon));

                        if (!hero.isEmpty()
                                && premiumHomeHeroImage != null) {

                            loadPosterImage(
                                    premiumHomeHeroImage,
                                    hero);
                        }
                    }
                });

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        dp(248),
                        dp(116));

        params.setMargins(
                0,
                0,
                dp(12),
                0);

        row.addView(
                card,
                params);
    }

    private PremiumHomeScreen.Host premiumHomeHost(
            final int artworkGeneration) {

        return new PremiumHomeScreen.Host() {

            public int logoResource() {
                return R.drawable.premium_player_tv_emblem;
            }

            public void loadHeroArtwork(
                    ImageView target) {

                target.setImageDrawable(null);
            }

            public void registerHeroViews(
                    ImageView image,
                    TextView title,
                    TextView description) {

                premiumHomeHeroImage = image;
                premiumHomeHeroTitle = title;
                premiumHomeHeroDescription = description;

                ArrayList<ResumeHomeItem> recent =
                        getRecentResumeItems();

                if (recent.isEmpty() == false) {
                    updatePremiumHomeHero(
                            recent.get(0));
                }
            }

            public void populateContinueWatching(
                    LinearLayout parent) {

                addHomeResumeSection(
                        parent);
            }

            public void populateRecentlyAddedMovies(LinearLayout parent) {
                populateLocalRecentlyAdded(parent, true);
            }

            public void populateRecentlyAddedSeries(LinearLayout parent) {
                populateLocalRecentlyAdded(parent, false);
            }

            public void populateTrendingThisWeek(
                    LinearLayout parent) {

                populatePremiumTrendingThisWeek(
                        parent);
            }

            public void openHome() {
                showHome();
            }

            public void openLiveTv() {
                showLiveTv("ALL");
            }

            public void openMovies() {
                showMovies();
            }

            public void openSeries() {
                showSeries();
            }

            public void openSportsGuide() {
                showSportsGuide();
            }

            public void openSearch() {
                showGlobalMediaSearch(
                        "MOVIES");
            }

            public void openSettings() {
                showSettings();
            }
        };
    }

    private boolean providerCatalogueFullSyncStarted =
            false;

    private int providerCatalogueFullSyncRetryCount =
            0;

    private void maybeSyncProviderCatalogueInventoryInBackground() {

        if (providerCatalogueFullSyncStarted) {
            return;
        }

        final String providerKey =
                getCatalogueProviderKey();

        if (safe(providerKey).isEmpty()) {
            return;
        }

        new Thread(
                () -> {

                    try {

                        SQLiteDatabase db =
                                getCatalogueDbHelper()
                                        .getReadableDatabase();

                        if (!ProviderCatalogueFullSync.hasInventory(
                                db,
                                providerKey)) {

                            if (providerCatalogueFullSyncRetryCount < 12) {

                                providerCatalogueFullSyncRetryCount++;

                                runOnUiThread(
                                        () -> new android.os.Handler()
                                                .postDelayed(
                                                        () -> maybeSyncProviderCatalogueInventoryInBackground(),
                                                        5000));
                            }

                            return;
                        }

                        providerCatalogueFullSyncStarted =
                                true;

                        ProviderCatalogueFullSync.sync(
                                db,
                                providerKey,
                                CAST_BACKEND_BASE_URL,
                                CAST_BACKEND_PUBLISHABLE_KEY);

                        runOnUiThread(
                                () -> {

                                    if (onHomeScreen) {
                                        showHome();
                                    }
                                });

                    } catch (Exception ignored) {

                        providerCatalogueFullSyncStarted =
                                false;
                    }
                })
                .start();
    }

    private void showHome() {
        refreshLocalDatesOnce();

        releasePlayer();
        closeActiveMediaAdapter();

        onHomeScreen =
                true;

        maybeSyncSportsGuideInBackground();

        stopHomeArtworkRotation();

        final int artworkGeneration =
                ++homeArtworkGeneration;

        View premiumHome =
                PremiumHomeScreen.create(
                        this,
                        premiumHomeHost(
                                artworkGeneration));

        setContentView(
                premiumHome);
    }

    private void stopHomeArtworkRotation() {
        if (homeArtworkRotationRunnable != null) {
            homeArtworkHandler.removeCallbacks(homeArtworkRotationRunnable);
            homeArtworkRotationRunnable = null;
        }
    }

    private void fetchHomeArtworkAsync(
            final ImageView target,
            final int generation) {

        new Thread(() -> {
            HttpURLConnection connection = null;

            try {
                URL url =
                        new URL(
                                CAST_BACKEND_BASE_URL
                                        + "/home-posters");

                connection =
                        (HttpURLConnection)
                                url.openConnection();

                connection.setRequestMethod("GET");
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty(
                        "apikey",
                        CAST_BACKEND_PUBLISHABLE_KEY);
                connection.setRequestProperty(
                        "Accept",
                        "application/json");

                int code = connection.getResponseCode();

                if (code < 200 || code >= 300) {
                    return;
                }

                java.io.BufferedReader br =
                        new java.io.BufferedReader(
                                new java.io.InputStreamReader(
                                        connection.getInputStream()));

                StringBuilder body =
                        new StringBuilder();

                String line;

                while ((line = br.readLine()) != null) {
                    body.append(line);
                }

                br.close();

                JSONObject root =
                        new JSONObject(
                                body.toString());

                JSONArray array =
                        root.optJSONArray("posters");

                if (array == null) {
                    return;
                }

                int rotationSeconds =
                        root.optInt(
                                "rotation_seconds",
                                15);

                rotationSeconds =
                        Math.max(
                                5,
                                Math.min(
                                        rotationSeconds,
                                        120));

                final long rotationMs =
                        rotationSeconds * 1000L;

                final ArrayList<String> urls =
                        new ArrayList<String>();

                for (int i = 0; i < array.length(); i++) {
                    JSONObject item =
                            array.optJSONObject(i);

                    String poster =
                            item == null
                                    ? ""
                                    : item.optString(
                                            "poster_url",
                                            "");

                    if (!poster.isEmpty()) {
                        urls.add(poster);
                    }
                }

                runOnUiThread(() -> {
                    if (!onHomeScreen
                            || generation != homeArtworkGeneration
                            || target.getParent() == null
                            || urls.isEmpty()) {
                        return;
                    }

                    startHomeArtworkRotation(
                            target,
                            urls,
                            rotationMs,
                            generation);
                });

            } catch (Exception ignored) {
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void startHomeArtworkRotation(
            final ImageView target,
            final ArrayList<String> urls,
            final long rotationMs,
            final int generation) {

        stopHomeArtworkRotation();

        if (urls == null || urls.isEmpty()) {
            return;
        }

        target.setAlpha(0.22f);

        loadPosterImage(
                target,
                urls.get(0));

        if (urls.size() < 2) {
            return;
        }

        homeArtworkRotationRunnable =
                new Runnable() {
                    private int nextIndex = 1;

                    @Override
                    public void run() {

                        if (!onHomeScreen
                                || generation != homeArtworkGeneration
                                || target.getParent() == null) {
                            return;
                        }

                        String nextPoster =
                                urls.get(nextIndex);

                        nextIndex =
                                (nextIndex + 1)
                                        % urls.size();

                        target.animate()
                                .alpha(0.11f)
                                .setDuration(220L)
                                .withEndAction(() -> {

                                    if (!onHomeScreen
                                            || generation != homeArtworkGeneration
                                            || target.getParent() == null) {
                                        return;
                                    }

                                    loadPosterImage(
                                            target,
                                            nextPoster);

                                    target.animate()
                                            .alpha(0.22f)
                                            .setDuration(650L)
                                            .start();
                                })
                                .start();

                        homeArtworkHandler.postDelayed(
                                this,
                                rotationMs);
                    }
                };

        homeArtworkHandler.postDelayed(
                homeArtworkRotationRunnable,
                Math.max(
                        DEFAULT_HOME_ARTWORK_ROTATION_MS,
                        rotationMs));
    }

    private class HomeIconView extends View {
        private final String iconTitle;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        HomeIconView(String title) {
            super(MainActivity.this);
            iconTitle = safe(title).toUpperCase(Locale.US);
            setFocusable(false);
            setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        }

        @Override
        protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.50f;
            float cy = h * 0.48f;
            float s = Math.min(w, h);

            paint.setColor(GOLD);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(2f, s * 0.055f));
            paint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            paint.setStrokeJoin(android.graphics.Paint.Join.ROUND);

            if (iconTitle.contains("LIVE")) {
                android.graphics.RectF tv = new android.graphics.RectF(w * .14f, h * .16f, w * .86f, h * .70f);
                canvas.drawRoundRect(tv, s * .07f, s * .07f, paint);
                canvas.drawLine(w * .34f, h * .82f, w * .44f, h * .70f, paint);
                canvas.drawLine(w * .66f, h * .82f, w * .56f, h * .70f, paint);
                canvas.drawLine(w * .32f, h * .82f, w * .68f, h * .82f, paint);
            } else if (iconTitle.contains("MOVIE")) {
                android.graphics.RectF body = new android.graphics.RectF(w * .18f, h * .32f, w * .84f, h * .78f);
                canvas.drawRoundRect(body, s * .05f, s * .05f, paint);
                canvas.save();
                canvas.rotate(-9f, cx, h * .27f);
                android.graphics.RectF clap = new android.graphics.RectF(w * .17f, h * .18f, w * .84f, h * .34f);
                canvas.drawRoundRect(clap, s * .035f, s * .035f, paint);
                for (int i = 0; i < 4; i++) {
                    float x = w * (.25f + i * .16f);
                    canvas.drawLine(x, h * .19f, x + w * .07f, h * .33f, paint);
                }
                canvas.restore();
            } else if (iconTitle.contains("SERIES")) {
                android.graphics.RectF rear = new android.graphics.RectF(w * .28f, h * .13f, w * .88f, h * .62f);
                android.graphics.RectF front = new android.graphics.RectF(w * .12f, h * .30f, w * .72f, h * .79f);
                canvas.drawRoundRect(rear, s * .055f, s * .055f, paint);
                canvas.drawRoundRect(front, s * .055f, s * .055f, paint);
                canvas.drawLine(w * .22f, h * .68f, w * .60f, h * .68f, paint);
            } else if (iconTitle.contains("SPORT")) {
                float left = w * .50f;
                float top = h * .21f;
                float right = w * .84f;
                float bottom = h * .77f;
                float backX = w * .93f;
                float backTop = h * .31f;
                float backBottom = h * .82f;

                // Traditional football goal: rectangular front frame with visible net depth.
                canvas.drawLine(left, top, right, top, paint);
                canvas.drawLine(left, top, left, bottom, paint);
                canvas.drawLine(right, top, right, bottom, paint);
                canvas.drawLine(left, bottom, right, bottom, paint);
                canvas.drawLine(right, top, backX, backTop, paint);
                canvas.drawLine(right, bottom, backX, backBottom, paint);
                canvas.drawLine(backX, backTop, backX, backBottom, paint);

                paint.setStrokeWidth(Math.max(1.3f, s * .024f));
                for (int i = 1; i <= 3; i++) {
                    float x = left + (right - left) * i / 4f;
                    canvas.drawLine(x, top, x + w * .05f, bottom, paint);
                }
                for (int i = 1; i <= 2; i++) {
                    float y = top + (bottom - top) * i / 3f;
                    canvas.drawLine(left, y, backX, y + h * .045f, paint);
                }

                // Ball flying toward the net.
                paint.setStyle(android.graphics.Paint.Style.FILL);
                canvas.drawCircle(w * .34f, h * .50f, s * .085f, paint);
                paint.setStyle(android.graphics.Paint.Style.STROKE);
                paint.setStrokeWidth(Math.max(2f, s * .045f));

                // Three slightly curved slipstream lines, all moving in the same direction.
                android.graphics.Path trail1 = new android.graphics.Path();
                trail1.moveTo(w * .04f, h * .34f);
                trail1.quadTo(w * .17f, h * .35f, w * .27f, h * .43f);
                canvas.drawPath(trail1, paint);

                android.graphics.Path trail2 = new android.graphics.Path();
                trail2.moveTo(w * .03f, h * .49f);
                trail2.quadTo(w * .16f, h * .48f, w * .26f, h * .49f);
                canvas.drawPath(trail2, paint);

                android.graphics.Path trail3 = new android.graphics.Path();
                trail3.moveTo(w * .05f, h * .65f);
                trail3.quadTo(w * .18f, h * .62f, w * .28f, h * .57f);
                canvas.drawPath(trail3, paint);
            } else {
                float r1 = s * .27f;
                float r2 = s * .12f;
                canvas.drawCircle(cx, cy, r1, paint);
                canvas.drawCircle(cx, cy, r2, paint);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI * 2d * i / 8d;
                    float x1 = cx + (float) Math.cos(a) * r1;
                    float y1 = cy + (float) Math.sin(a) * r1;
                    float x2 = cx + (float) Math.cos(a) * (r1 + s * .12f);
                    float y2 = cy + (float) Math.sin(a) * (r1 + s * .12f);
                    canvas.drawLine(x1, y1, x2, y2, paint);
                }
            }
        }
    }

    private void addHorizontalHomeTile(
            LinearLayout row,
            String title,
            String description,
            Runnable action) {

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(12), dp(18), dp(14));
        makeTvRemoteReady(card);
        card.setBackground(makeBackground(CHARCOAL, Color.rgb(54, 54, 58), 18));

        HomeIconView icon = new HomeIconView(title);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(58), dp(52));
        iconParams.setMargins(0, 0, 0, dp(4));
        card.addView(icon, iconParams);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(17);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setMaxLines(2);
        card.addView(titleView);

        TextView descriptionView = new TextView(this);
        descriptionView.setText(description);
        descriptionView.setTextColor(SILVER);
        descriptionView.setTextSize(11);
        descriptionView.setPadding(0, dp(6), 0, 0);
        descriptionView.setMaxLines(2);
        card.addView(descriptionView);

        card.setOnClickListener(v -> {
            if (action != null) action.run();
        });

        card.setOnFocusChangeListener((view, focused) -> {
            if (focused) {
                view.setBackground(makeBackground(Color.rgb(34, 31, 24), GOLD, 18));
                view.setScaleX(1.03f);
                view.setScaleY(1.03f);
            } else {
                view.setBackground(makeBackground(CHARCOAL, Color.rgb(54, 54, 58), 18));
                view.setScaleX(1f);
                view.setScaleY(1f);
            }
        });

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(220), dp(172));
        params.setMargins(0, 0, dp(12), 0);
        row.addView(card, params);
    }
    private void addHomeResumeSection(LinearLayout root) {
        ArrayList<ResumeHomeItem> recent = getRecentResumeItems();

        boolean anySlotEnabled = false;
        for (int slot = 1; slot <= 5; slot++) {
            if (isHomeResumeSlotEnabled(slot)) {
                anySlotEnabled = true;
                break;
            }
        }

        if (!anySlotEnabled || recent.isEmpty()) {
            return;
        }

        TextView heading = new TextView(this);
        heading.setText("CONTINUE WATCHING");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(17);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setPadding(0, dp(18), 0, dp(10));
        root.addView(heading);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(false);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(row);

        int recentIndex = 0;
        for (int slot = 1; slot <= 5 && recentIndex < recent.size(); slot++) {
            ResumeHomeItem item = recent.get(recentIndex);
            recentIndex++;

            if (!isHomeResumeSlotEnabled(slot)) {
                continue;
            }

            addResumeHomeCard(row, item);
        }

        if (row.getChildCount() > 0) {
            root.addView(
                    scroll,
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(128)));
        }
    }

    private void addResumeHomeCard(
            LinearLayout row,
            ResumeHomeItem item) {

        FrameLayout card =
                new FrameLayout(this);

        makeTvRemoteReady(card);

        card.setBackground(
                makeBackground(
                        CHARCOAL,
                        Color.rgb(64, 64, 68),
                        14));

        LinearLayout content =
                new LinearLayout(this);

        content.setOrientation(
                LinearLayout.HORIZONTAL);

        content.setGravity(
                Gravity.CENTER_VERTICAL);

        card.addView(
                content,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout coverFrame =
                new FrameLayout(this);

        ImageView cover =
                new ImageView(this);

        cover.setScaleType(
                ImageView.ScaleType.CENTER_CROP);

        cover.setBackgroundColor(
                Color.rgb(25, 25, 28));

        coverFrame.addView(
                cover,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));

        if (!safe(item.cover).isEmpty()) {
            loadPosterImage(
                    cover,
                    item.cover);
        } else {
            loadResumeCoverAsyncV051(
                    cover,
                    item);
        }

        content.addView(
                coverFrame,
                new LinearLayout.LayoutParams(
                        dp(112),
                        LinearLayout.LayoutParams.MATCH_PARENT));

        LinearLayout info =
                new LinearLayout(this);

        info.setOrientation(
                LinearLayout.VERTICAL);

        info.setGravity(
                Gravity.CENTER_VERTICAL);

        info.setPadding(
                dp(12),
                dp(8),
                dp(10),
                dp(10));

        content.addView(
                info,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1f));

        TextView title =
                new TextView(this);

        title.setText(
                item.title);

        title.setTextColor(
                Color.WHITE);

        title.setTextSize(
                13);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        title.setMaxLines(
                2);

        info.addView(
                title);

        TextView meta =
                new TextView(this);

        String typeText;

        if ("EPISODE".equals(item.mediaType)) {
            typeText =
                    safe(item.seriesName);

            if (typeText.isEmpty()) {
                typeText = "Series";
            }
        } else {
            typeText = "Movie";
        }

        long remainingMs =
                item.duration > 0L
                        ? Math.max(
                        0L,
                        item.duration - item.position)
                        : 0L;

        if (remainingMs > 0L) {
            typeText +=
                    "  •  "
                            + formatPlaybackTime(
                            remainingMs)
                            + " left";
        }

        meta.setText(
                typeText);

        meta.setTextColor(
                SILVER);

        meta.setTextSize(
                10);

        meta.setMaxLines(
                1);

        meta.setPadding(
                0,
                dp(5),
                0,
                0);

        info.addView(
                meta);

        View progressTrack =
                new View(this);

        progressTrack.setBackgroundColor(
                Color.rgb(75, 75, 80));

        FrameLayout.LayoutParams trackParams =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        dp(4),
                        Gravity.BOTTOM);

        trackParams.setMargins(
                dp(8),
                0,
                dp(8),
                dp(6));

        card.addView(
                progressTrack,
                trackParams);

        float ratio =
                0f;

        if (item.duration > 0L) {
            ratio =
                    Math.max(
                            0f,
                            Math.min(
                                    1f,
                                    (float) item.position
                                            / (float) item.duration));
        }

        View watched =
                new View(this);

        watched.setBackgroundColor(
                GOLD);

        FrameLayout.LayoutParams watchedParams =
                new FrameLayout.LayoutParams(
                        0,
                        dp(4),
                        Gravity.BOTTOM | Gravity.LEFT);

        watchedParams.setMargins(
                dp(8),
                0,
                0,
                dp(6));

        card.addView(
                watched,
                watchedParams);

        final float finalRatio =
                ratio;

        progressTrack.post(
                () -> {

                    int usable =
                            Math.max(
                                    0,
                                    progressTrack.getWidth());

                    FrameLayout.LayoutParams lp =
                            (FrameLayout.LayoutParams)
                                    watched.getLayoutParams();

                    lp.width =
                            Math.max(
                                    0,
                                    Math.round(
                                            usable * finalRatio));

                    watched.setLayoutParams(
                            lp);
                });

        card.setOnClickListener(
                v -> resumeFromHomeItem(
                        item));

        card.setOnFocusChangeListener(
                (view, focused) -> {

                    view.setBackground(
                            makeBackground(
                                    focused
                                            ? Color.rgb(37, 32, 22)
                                            : CHARCOAL,
                                    focused
                                            ? GOLD
                                            : Color.rgb(64, 64, 68),
                                    14));

                    view.setScaleX(
                            focused ? 1.025f : 1f);

                    view.setScaleY(
                            focused ? 1.025f : 1f);

                    if (focused) {
                        updatePremiumHomeHero(
                                item);
                    }
                });

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        dp(280),
                        dp(104));

        params.setMargins(
                0,
                0,
                dp(12),
                0);

        row.addView(
                card,
                params);
    }

    private ArrayList<ResumeHomeItem> getRecentResumeItems() {
        ArrayList<ResumeHomeItem> items = new ArrayList<ResumeHomeItem>();
        android.content.SharedPreferences prefs =
                resumePrefs();

        Map<String, ?> all = prefs.getAll();
        HashSet<String> resumeKeys = new HashSet<String>();

        for (String key : all.keySet()) {
            if (key != null && key.endsWith("_position")) {
                resumeKeys.add(key.substring(0, key.length() - "_position".length()));
            }
        }

        for (String key : resumeKeys) {
            long position = prefs.getLong(key + "_position", 0L);
            if (position < 30000L) {
                continue;
            }

            ResumeHomeItem item = new ResumeHomeItem();
            item.resumeKey = key;
            item.position = position;
            item.duration = prefs.getLong(key + "_duration", 0L);
            item.lastWatched = prefs.getLong(key + "_last_watched", 0L);
            item.mediaType = safe(prefs.getString(key + "_media_type", ""));
            item.mediaId = safe(prefs.getString(key + "_media_id", ""));
            item.title = safe(prefs.getString(key + "_title", ""));
            item.cover = safe(prefs.getString(key + "_cover", ""));
            item.extension = safe(prefs.getString(key + "_extension", "mp4"));
            item.directSource = safe(prefs.getString(key + "_direct_source", ""));
            item.seriesId = safe(prefs.getString(key + "_series_id", ""));
            item.seriesName = safe(prefs.getString(key + "_series_name", ""));
            item.episodeTitle = safe(prefs.getString(key + "_episode_title", ""));
            item.seasonNumber = prefs.getInt(key + "_season", 0);
            item.episodeNumber = prefs.getInt(key + "_episode", 0);

            // ANR TEST: repairResumeHomeItem(item);
            // ANR TEST: rehydrateResumeHomeItemV051(item);

            if (item.title.isEmpty()) {
                continue;
            }

            items.add(item);
        }

        Collections.sort(
                items,
                (a, b) -> Long.compare(b.lastWatched, a.lastWatched));

        return items;
    }

    private void repairResumeHomeItem(ResumeHomeItem item) {
        if (item == null || safe(item.resumeKey).isEmpty()) {
            return;
        }

        String key = safe(item.resumeKey);

        if (safe(item.mediaType).isEmpty()) {
            if (key.startsWith("resume_MOVIE_")) {
                item.mediaType = "MOVIE";
            } else if (key.startsWith("resume_EPISODE_")) {
                item.mediaType = "EPISODE";
            }
        }

        if (safe(item.mediaId).isEmpty()) {
            if (key.startsWith("resume_MOVIE_")) {
                item.mediaId = key.substring("resume_MOVIE_".length());
                item.mediaType = "MOVIE";
            } else if (key.startsWith("resume_EPISODE_")) {
                item.mediaId = key.substring("resume_EPISODE_".length());
                item.mediaType = "EPISODE";
            }
        }

        Cursor cursor = null;
        try {
            SQLiteDatabase db = getCatalogueDbHelper().getReadableDatabase();

            if ("MOVIE".equals(item.mediaType)
                    && !safe(item.mediaId).isEmpty()) {

                cursor = db.query(
                        "catalogue_movies",
                        new String[]{"name", "extension", "direct_source", "icon"},
                        "provider_key=? AND stream_id=?",
                        new String[]{getCatalogueProviderKey(), item.mediaId},
                        null,
                        null,
                        null,
                        "1");

                if (cursor.moveToFirst()) {
                    if (safe(item.title).isEmpty()) item.title = safe(cursor.getString(0));
                    if (safe(item.extension).isEmpty()) item.extension = sanitizeMediaExtension(cursor.getString(1));
                    if (safe(item.directSource).isEmpty()) item.directSource = safe(cursor.getString(2));
                    if (safe(item.cover).isEmpty()) item.cover = safe(cursor.getString(3));
                }

            } else if ("EPISODE".equals(item.mediaType)
                    && !safe(item.seriesId).isEmpty()) {

                cursor = db.query(
                        "catalogue_series",
                        new String[]{"name", "cover"},
                        "provider_key=? AND series_id=?",
                        new String[]{getCatalogueProviderKey(), item.seriesId},
                        null,
                        null,
                        null,
                        "1");

                if (cursor.moveToFirst()) {
                    if (safe(item.seriesName).isEmpty()) item.seriesName = safe(cursor.getString(0));
                    if (safe(item.cover).isEmpty()) item.cover = safe(cursor.getString(1));
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        if (safe(item.extension).isEmpty()) {
            item.extension = "mp4";
        }

        resumePrefs()
                .edit()
                .putString(key + "_media_type", safe(item.mediaType))
                .putString(key + "_media_id", safe(item.mediaId))
                .putString(key + "_title", safe(item.title))
                .putString(key + "_cover", safe(item.cover))
                .putString(key + "_extension", safe(item.extension))
                .putString(key + "_direct_source", safe(item.directSource))
                .putString(key + "_series_id", safe(item.seriesId))
                .putString(key + "_series_name", safe(item.seriesName))
                .putString(key + "_episode_title", safe(item.episodeTitle))
                .putInt(key + "_season", item.seasonNumber)
                .putInt(key + "_episode", item.episodeNumber)
                .apply();
    }

    private void rehydrateResumeHomeItemV051(ResumeHomeItem item) {
        if (item == null) return;

        try {
            if ("MOVIE".equals(item.mediaType)) {
                MovieItem movie = findResumeMovieInCatalogueV051(item.mediaId, item.title);
                if (movie != null) {
                    item.mediaId = firstNonEmpty(item.mediaId, movie.streamId);
                    item.title = firstNonEmpty(movie.name, item.title);
                    item.cover = firstNonEmpty(movie.icon, item.cover);
                    item.extension = firstNonEmpty(movie.extension, item.extension);
                    item.directSource = firstNonEmpty(movie.directSource, item.directSource);
                }
            } else if ("EPISODE".equals(item.mediaType)) {
                String seriesName = firstNonEmpty(item.seriesName, resumeSeriesNameFromTitleV051(item.title));
                SeriesItem series = findResumeSeriesInCatalogueV051(item.seriesId, seriesName);
                if (series != null) {
                    item.seriesId = firstNonEmpty(series.seriesId, item.seriesId);
                    item.seriesName = firstNonEmpty(series.name, seriesName);
                    item.cover = firstNonEmpty(series.cover, item.cover);
                }
            }

            persistResumeHomeItemV051(item);
        } catch (Exception ignored) {
        }
    }

    private String resumeSeriesNameFromTitleV051(String title) {
        String value = safe(title).trim();
        int marker = value.lastIndexOf(" - S");
        return marker > 0 ? value.substring(0, marker).trim() : value;
    }

    private MovieItem findResumeMovieInCatalogueV051(String streamId, String title) {
        Cursor cursor = null;
        try {
            SQLiteDatabase db = getCatalogueDbHelper().getReadableDatabase();
            String providerKey = getCatalogueProviderKey();
            if (!safe(streamId).isEmpty()) {
                cursor = db.query(
                        "catalogue_movies",
                        new String[]{"stream_id", "name", "extension", "direct_source", "icon"},
                        "provider_key=? AND stream_id=?",
                        new String[]{providerKey, streamId},
                        null, null, null, "1");
            }
            if ((cursor == null || !cursor.moveToFirst()) && !safe(title).isEmpty()) {
                if (cursor != null) cursor.close();
                cursor = db.query(
                        "catalogue_movies",
                        new String[]{"stream_id", "name", "extension", "direct_source", "icon"},
                        "provider_key=? AND normalized_name=?",
                        new String[]{providerKey, normalizeSearchText(title)},
                        null, null, null, "1");
                if (!cursor.moveToFirst()) return null;
            } else if (cursor == null) {
                return null;
            }

            MovieItem movie = new MovieItem();
            movie.streamId = safe(cursor.getString(0));
            movie.name = safe(cursor.getString(1));
            movie.extension = sanitizeMediaExtension(cursor.getString(2));
            movie.directSource = safe(cursor.getString(3));
            movie.icon = safe(cursor.getString(4));
            return movie;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private SeriesItem findResumeSeriesInCatalogueV051(String seriesId, String seriesName) {
        Cursor cursor = null;
        try {
            SQLiteDatabase db = getCatalogueDbHelper().getReadableDatabase();
            String providerKey = getCatalogueProviderKey();
            if (!safe(seriesId).isEmpty()) {
                cursor = db.query(
                        "catalogue_series",
                        new String[]{"series_id", "name", "cover"},
                        "provider_key=? AND series_id=?",
                        new String[]{providerKey, seriesId},
                        null, null, null, "1");
            }
            if ((cursor == null || !cursor.moveToFirst()) && !safe(seriesName).isEmpty()) {
                if (cursor != null) cursor.close();
                cursor = db.query(
                        "catalogue_series",
                        new String[]{"series_id", "name", "cover"},
                        "provider_key=? AND normalized_name=?",
                        new String[]{providerKey, normalizeSearchText(seriesName)},
                        null, null, null, "1");
                if (!cursor.moveToFirst()) return null;
            } else if (cursor == null) {
                return null;
            }

            SeriesItem series = new SeriesItem();
            series.seriesId = safe(cursor.getString(0));
            series.name = safe(cursor.getString(1));
            series.cover = safe(cursor.getString(2));
            return series;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void persistResumeHomeItemV051(ResumeHomeItem item) {
        if (item == null || safe(item.resumeKey).isEmpty()) return;
        resumePrefs().edit()
                .putString(item.resumeKey + "_media_type", safe(item.mediaType))
                .putString(item.resumeKey + "_media_id", safe(item.mediaId))
                .putString(item.resumeKey + "_title", safe(item.title))
                .putString(item.resumeKey + "_cover", safe(item.cover))
                .putString(item.resumeKey + "_extension", safe(item.extension))
                .putString(item.resumeKey + "_direct_source", safe(item.directSource))
                .putString(item.resumeKey + "_series_id", safe(item.seriesId))
                .putString(item.resumeKey + "_series_name", safe(item.seriesName))
                .apply();
    }

    private void loadResumeCoverAsyncV051(ImageView imageView, ResumeHomeItem item) {
        if (imageView == null || item == null || !safe(item.cover).isEmpty()) return;

        new Thread(() -> {
            String coverUrl = "";
            try {
                if ("MOVIE".equals(item.mediaType) && !safe(item.mediaId).isEmpty()) {
                    String text = downloadPlaylistText(
                            buildXtreamApiUrl("get_vod_info", "vod_id", item.mediaId));
                    JSONObject root = new JSONObject(text);
                    JSONObject movieData = root.optJSONObject("movie_data");
                    JSONObject info = root.optJSONObject("info");
                    coverUrl = firstNonEmpty(
                            movieData == null ? "" : movieData.optString("stream_icon", ""),
                            info == null ? "" : info.optString("movie_image", ""),
                            info == null ? "" : info.optString("cover_big", ""),
                            info == null ? "" : info.optString("stream_icon", ""));
                } else if ("EPISODE".equals(item.mediaType) && !safe(item.seriesId).isEmpty()) {
                    String text = downloadPlaylistText(
                            buildXtreamApiUrl("get_series_info", "series_id", item.seriesId));
                    JSONObject root = new JSONObject(text);
                    JSONObject info = root.optJSONObject("info");
                    coverUrl = firstNonEmpty(
                            info == null ? "" : info.optString("cover", ""),
                            info == null ? "" : info.optString("cover_big", ""),
                            info == null ? "" : info.optString("movie_image", ""));
                }
            } catch (Exception ignored) {
            }

            final String finalCover = safe(coverUrl);
            if (finalCover.isEmpty()) return;

            item.cover = finalCover;
            persistResumeHomeItemV051(item);
            runOnUiThread(() -> loadPosterImage(imageView, finalCover));
        }).start();
    }

    private void addResumeMediaFallbackCandidatesV051() {
        if (!("MOVIE".equals(selectedMediaType) || "EPISODE".equals(selectedMediaType))) return;
        if (!isXtreamSource() || safe(selectedStreamId).isEmpty()) return;

        try {
            android.content.SharedPreferences prefs = playlistPrefs();
            String apiServer = normalizeXtreamServer(prefs.getString("xtream_server", ""));
            String streamServer = normalizeXtreamServer(
                    prefs.getString("xtream_stream_server", apiServer));
            String username = prefs.getString("xtream_username", "");
            String password = prefs.getString("xtream_password", "");
            String mediaPath = "MOVIE".equals(selectedMediaType) ? "movie" : "series";

            java.util.LinkedHashSet<String> extensions = new java.util.LinkedHashSet<String>();
            extensions.add(sanitizeMediaExtension(selectedContainerExtension));
            extensions.add("mp4");
            extensions.add("mkv");
            extensions.add("ts");
            extensions.add("avi");

            addXtreamMediaServerCandidatesV051(
                    streamServer, mediaPath, username, password, selectedStreamId, extensions);

            if (!apiServer.equals(streamServer)) {
                addXtreamMediaServerCandidatesV051(
                        apiServer, mediaPath, username, password, selectedStreamId, extensions);
            }
        } catch (Exception ignored) {
        }
    }

    private void addXtreamMediaServerCandidatesV051(
            String server,
            String mediaPath,
            String username,
            String password,
            String streamId,
            java.util.LinkedHashSet<String> extensions) throws Exception {

        if (safe(server).isEmpty()) return;
        String userPath = URLEncoder.encode(username, "UTF-8").replace("+", "%20");
        String passPath = URLEncoder.encode(password, "UTF-8").replace("+", "%20");

        for (String extension : extensions) {
            if (safe(extension).isEmpty()) continue;
            addPlaybackCandidate(
                    server + "/" + mediaPath + "/" + userPath + "/" + passPath
                            + "/" + streamId + "." + extension);
        }
    }

    private void saveResumeIdentityForMovie(MovieItem movie) {
        if (movie == null || safe(movie.streamId).isEmpty()) {
            return;
        }

        String key = buildResumeKey("MOVIE", movie.streamId);
        resumePrefs()
                .edit()
                .putString(key + "_media_type", "MOVIE")
                .putString(key + "_media_id", safe(movie.streamId))
                .putString(key + "_title", safe(movie.name))
                .putString(key + "_cover", safe(movie.icon))
                .putString(key + "_extension", safe(movie.extension))
                .putString(key + "_direct_source", safe(movie.directSource))
                .apply();
    }

    private void saveResumeIdentityForEpisode(
            SeriesItem series,
            EpisodeItem episode) {

        if (series == null
                || episode == null
                || safe(episode.id).isEmpty()) {
            return;
        }

        String key = buildResumeKey("EPISODE", episode.id);
        String displayTitle =
                safe(series.name)
                        + " - S"
                        + episode.seasonNumber
                        + " E"
                        + episode.episodeNumber;

        resumePrefs()
                .edit()
                .putString(key + "_media_type", "EPISODE")
                .putString(key + "_media_id", safe(episode.id))
                .putString(key + "_title", displayTitle)
                .putString(key + "_cover", safe(series.cover))
                .putString(key + "_extension", safe(episode.extension))
                .putString(key + "_direct_source", safe(episode.directSource))
                .putString(key + "_series_id", safe(series.seriesId))
                .putString(key + "_series_name", safe(series.name))
                .putString(key + "_episode_title", safe(episode.title))
                .putInt(key + "_season", episode.seasonNumber)
                .putInt(key + "_episode", episode.episodeNumber)
                .apply();
    }

    private void resumeFromHomeItem(ResumeHomeItem item) {
        if (item != null) {
            // ANR TEST: rehydrateResumeHomeItemV051(item);
        }

        if (item == null || safe(item.mediaId).isEmpty()) {
            return;
        }

        if ("MOVIE".equals(item.mediaType)) {
            MovieItem movie = new MovieItem();
            movie.streamId = item.mediaId;
            movie.name = item.title;
            movie.icon = item.cover;
            movie.extension = sanitizeMediaExtension(item.extension);
            movie.directSource = item.directSource;
            playMovie(movie);
            return;
        }

        if ("EPISODE".equals(item.mediaType)) {
            SeriesItem series = new SeriesItem();
            series.seriesId = item.seriesId;
            series.name = item.seriesName.isEmpty() ? item.title : item.seriesName;
            series.cover = item.cover;

            EpisodeItem episode = new EpisodeItem();
            episode.id = item.mediaId;
            episode.title = item.episodeTitle;
            episode.extension = sanitizeMediaExtension(item.extension);
            episode.directSource = item.directSource;
            episode.seasonNumber = item.seasonNumber;
            episode.episodeNumber = item.episodeNumber;

            playEpisode(series, episode);
        }
    }

    // ---------------------------------------------------------------------
    // HOME EDIT MODE
    // ---------------------------------------------------------------------

    private void showEditHome() {
        releasePlayer();
        onHomeScreen = false;

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        scrollView.addView(root);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText("EDIT HOME");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        TextView help = new TextView(this);
        help.setText("Move sections, hide them, or restore the default layout.");
        help.setTextColor(SILVER);
        help.setTextSize(14);
        help.setPadding(0, dp(8), 0, dp(20));
        root.addView(help);

        for (int i = 0; i < homeOrder.size(); i++) {
            final int index = i;
            final String title = homeOrder.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(14), dp(13), dp(14), dp(13));
            row.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(52, 52, 56),
                            14));

            TextView label = new TextView(this);
            label.setText(title);
            label.setTextColor(
                    hiddenHomeSections.contains(title)
                            ? Color.rgb(115, 115, 120)
                            : Color.WHITE);
            label.setTextSize(16);
            label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            row.addView(label);

            LinearLayout controls = new LinearLayout(this);
            controls.setOrientation(LinearLayout.HORIZONTAL);
            controls.setPadding(0, dp(10), 0, 0);

            Button up = makeSmallButton("UP");
            Button down = makeSmallButton("DOWN");
            Button toggle = makeSmallButton(
                    hiddenHomeSections.contains(title)
                            ? "SHOW"
                            : "HIDE");

            if ("SETTINGS".equals(title)) {
                toggle.setText("ALWAYS SHOWN");
                toggle.setEnabled(false);
            }

            up.setEnabled(index > 0);
            down.setEnabled(index < homeOrder.size() - 1);

            up.setOnClickListener(v -> {
                if (index > 0) {
                    Collections.swap(homeOrder, index, index - 1);
                    saveHomeLayout();
                    showEditHome();
                }
            });

            down.setOnClickListener(v -> {
                if (index < homeOrder.size() - 1) {
                    Collections.swap(homeOrder, index, index + 1);
                    saveHomeLayout();
                    showEditHome();
                }
            });

            toggle.setOnClickListener(v -> {
                if (hiddenHomeSections.contains(title)) {
                    hiddenHomeSections.remove(title);
                } else {
                    hiddenHomeSections.add(title);
                }

                saveHomeLayout();
                showEditHome();
            });

            controls.addView(up, weightedButtonParams());
            controls.addView(down, weightedButtonParams());
            controls.addView(toggle, weightedButtonParams());

            row.addView(controls);

            LinearLayout.LayoutParams rowParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);

            rowParams.setMargins(0, 0, 0, dp(10));
            root.addView(row, rowParams);
        }

        Button restore = new Button(this);
        restore.setText("RESTORE DEFAULT");
        restore.setTextColor(BLACK);
        restore.setTextSize(13);
        restore.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        restore.setAllCaps(false);
        restore.setBackground(makeBackground(GOLD, GOLD, 14));
        restore.setOnClickListener(v -> restoreDefaultHomeLayout());

        LinearLayout.LayoutParams restoreParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(50));

        restoreParams.setMargins(0, dp(12), 0, 0);
        root.addView(restore, restoreParams);

        setContentView(scrollView);
    }

    private Button makeSmallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setBackground(
                makeBackground(
                        Color.rgb(32, 32, 35),
                        Color.rgb(65, 65, 70),
                        10));

        makeTvRemoteReady(
                button);

        addTvFocusScale(
                button);

        return button;
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        0,
                        dp(46),
                        1f);

        params.setMargins(dp(3), 0, dp(3), 0);
        return params;
    }

    // ---------------------------------------------------------------------
    // SECTION ROUTING
    // ---------------------------------------------------------------------

    private void showSportsGuide() {
        releasePlayer();
        onHomeScreen = false;

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scrollView.addView(root);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText("SPORTS GUIDE");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        TextView help = new TextView(this);
        help.setText("Live and upcoming sports from your EPG, with team badges and event artwork where available. Select an event to tune directly to the matching channel.");
        help.setTextColor(SILVER);
        help.setTextSize(13);
        help.setPadding(0, dp(8), 0, dp(12));
        root.addView(help);

        Button preferences = makeSmallButton("SPORTS PREFERENCES");
        preferences.setTextSize(13);
        preferences.setOnClickListener(v -> showSportsPreferences());
        LinearLayout.LayoutParams prefParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        prefParams.setMargins(0, 0, 0, dp(16));
        root.addView(preferences, prefParams);

        TextView status = new TextView(this);
        status.setText("Loading sports guide...");
        status.setTextColor(SILVER);
        status.setTextSize(13);
        status.setPadding(0, dp(4), 0, dp(12));
        root.addView(status);

        LinearLayout guideContainer = new LinearLayout(this);
        guideContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(guideContainer);
        setContentView(scrollView);

        loadSportsGuideFromServer(guideContainer, status);
        syncSportsGuideFromEpg(() -> {
            if (!isFinishing()) loadSportsGuideFromServer(guideContainer, status);
        });
    }

    private String sportsGuidePlaylistKey() {
        try {
            android.content.SharedPreferences p = playlistPrefs();
            String identity = safe(p.getString("xtream_server", "")) + "|"
                    + safe(p.getString("xtream_username", "")) + "|"
                    + sanitizePlaylistId(activePlaylistId);
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(identity.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) hex.append(String.format(Locale.US, "%02x", b & 0xff));
            return hex.substring(0, Math.min(40, hex.length()));
        } catch (Exception ignored) {
            return sanitizePlaylistId(activePlaylistId);
        }
    }

    private HashSet<String> sportsCsvSet(String key) {
        return SportsGuideSupport.csvSet(playlistPrefs(), key);
    }

    private boolean isSportsCustomMode() {
        return SportsGuideSupport.customMode(playlistPrefs());
    }

    private void saveSportsPreferenceSets(HashSet<String> sports, HashSet<String> competitions) {
        SportsGuideSupport.savePrefs(playlistPrefs(), sports, competitions);
    }

    private void showSportsPreferences() {
        releasePlayer();
        onHomeScreen = false;
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scrollView.addView(root);

        TextView back = createBackText();
        back.setText("<  SETTINGS");
        back.setOnClickListener(v -> showSettings());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText("SPORTS PREFERENCES");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        TextView help = new TextView(this);
        help.setText("Choose whole sports or only the leagues and competitions you actually watch. The list comes from your current EPG.");
        help.setTextColor(SILVER);
        help.setTextSize(13);
        help.setPadding(0, dp(8), 0, dp(14));
        root.addView(help);

        Button allButton = makeSmallButton(isSportsCustomMode()
                ? "SHOW ALL SPORTS & COMPETITIONS"
                : "✓ ALL SPORTS & COMPETITIONS");
        allButton.setTextSize(13);
        allButton.setOnClickListener(v -> {
            playlistPrefs().edit()
                    .putString("sports_pref_mode", "ALL")
                    .remove("sports_pref_all_sports")
                    .remove("sports_pref_competitions")
                    .apply();
            showSportsPreferences();
        });
        LinearLayout.LayoutParams allParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        allParams.setMargins(0, 0, 0, dp(14));
        root.addView(allButton, allParams);

        TextView loading = new TextView(this);
        loading.setText("Loading competitions from the EPG...");
        loading.setTextColor(SILVER);
        loading.setTextSize(13);
        root.addView(loading);

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.VERTICAL);
        root.addView(filters);
        setContentView(scrollView);

        fetchSportsFilters((sports, error) -> {
            loading.setVisibility(View.GONE);
            if (error != null || sports.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("No competition list is cached yet. Open Sports Guide once to sync the EPG, then return here.");
                empty.setTextColor(SILVER);
                empty.setTextSize(13);
                empty.setPadding(dp(10), dp(18), dp(10), dp(18));
                filters.addView(empty);
                return;
            }

            HashSet<String> allSports = sportsCsvSet("sports_pref_all_sports");
            HashSet<String> competitions = sportsCsvSet("sports_pref_competitions");

            for (int i = 0; i < sports.length(); i++) {
                JSONObject sport = sports.optJSONObject(i);
                if (sport == null) continue;
                final String sportKey = sport.optString("key", "");
                final String sportLabel = sport.optString("label", sportKey);
                JSONArray comps = sport.optJSONArray("competitions");

                TextView title = new TextView(this);
                title.setText(sportLabel.toUpperCase(Locale.getDefault()));
                title.setTextColor(GOLD);
                title.setTextSize(15);
                title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                title.setPadding(0, dp(18), 0, dp(8));
                filters.addView(title);

                Button wholeSport = makeSmallButton((allSports.contains(sportKey) ? "✓ " : "")
                        + "ALL " + sportLabel.toUpperCase(Locale.getDefault()));
                wholeSport.setTextSize(13);
                wholeSport.setOnClickListener(v -> {
                    HashSet<String> selectedSports = sportsCsvSet("sports_pref_all_sports");
                    HashSet<String> selectedComps = sportsCsvSet("sports_pref_competitions");
                    if (selectedSports.contains(sportKey)) {
                        selectedSports.remove(sportKey);
                    } else {
                        selectedSports.add(sportKey);
                        ArrayList<String> remove = new ArrayList<String>();
                        for (String k : selectedComps) if (k.startsWith(sportKey + ":")) remove.add(k);
                        selectedComps.removeAll(remove);
                    }
                    saveSportsPreferenceSets(selectedSports, selectedComps);
                    showSportsPreferences();
                });
                LinearLayout.LayoutParams sportParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
                sportParams.setMargins(0, 0, 0, dp(7));
                filters.addView(wholeSport, sportParams);

                if (comps == null) continue;
                for (int c = 0; c < comps.length(); c++) {
                    JSONObject comp = comps.optJSONObject(c);
                    if (comp == null) continue;
                    final String compKey = comp.optString("key", "");
                    final String compLabel = comp.optString("label", compKey);
                    final int count = comp.optInt("count", 0);
                    Button compButton = makeSmallButton((competitions.contains(compKey) ? "✓ " : "")
                            + compLabel + "   •   " + count);
                    compButton.setTextSize(12);
                    compButton.setOnClickListener(v -> {
                        HashSet<String> selectedSports = sportsCsvSet("sports_pref_all_sports");
                        HashSet<String> selectedComps = sportsCsvSet("sports_pref_competitions");
                        selectedSports.remove(sportKey);
                        if (selectedComps.contains(compKey)) selectedComps.remove(compKey);
                        else selectedComps.add(compKey);
                        saveSportsPreferenceSets(selectedSports, selectedComps);
                        showSportsPreferences();
                    });
                    LinearLayout.LayoutParams compParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, dp(45));
                    compParams.setMargins(dp(18), 0, 0, dp(6));
                    filters.addView(compButton, compParams);
                }
            }
        });
    }

    private interface SportsFiltersCallback {
        void onResult(JSONArray sports, String error);
    }

    private void fetchSportsFilters(SportsFiltersCallback callback) {
        SportsGuideNetwork.fetchFilters(CAST_BACKEND_BASE_URL, CAST_BACKEND_PUBLISHABLE_KEY,
                sportsGuidePlaylistKey(), (sports, error) ->
                runOnUiThread(() -> callback.onResult(sports, error)));
    }

    private void loadSportsGuideFromServer(LinearLayout container, TextView status) {
        boolean custom = isSportsCustomMode();
        HashSet<String> sports = sportsCsvSet("sports_pref_all_sports");
        HashSet<String> comps = sportsCsvSet("sports_pref_competitions");
        if (custom && sports.isEmpty() && comps.isEmpty()) {
            container.removeAllViews();
            status.setText("No sports or competitions selected.");
            return;
        }
        status.setText("Loading upcoming events...");
        SportsGuideNetwork.fetchEvents(CAST_BACKEND_BASE_URL, CAST_BACKEND_PUBLISHABLE_KEY,
                sportsGuidePlaylistKey(), custom, sports, comps, (events, error) ->
                runOnUiThread(() -> {
                    if (error != null) status.setText("Sports guide unavailable: " + error);
                    else renderSportsGuideEvents(container, status, events);
                }));
    }

    private View createSportsBadge(String name, String imageUrl, int sizeDp) {
        return SportsGuideUi.badge(
                this,
                name,
                imageUrl,
                GOLD,
                (image, url) -> loadPosterImage(image, url));
    }
    private LinearLayout createSportsTeamBlock(String name, String logoUrl) {
        return SportsGuideUi.team(
                this,
                name,
                logoUrl,
                GOLD,
                (image, url) -> loadPosterImage(image, url));
    }
    private void renderSportsGuideEvents(LinearLayout container, TextView status, JSONArray events) {
        SportsGuideRenderer.render(
                this, GOLD, SILVER, CHARCOAL,
                new SportsGuideRenderer.Host() {
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public View badge(String n, String u, int s) { return createSportsBadge(n, u, s); }
                    public LinearLayout team(String n, String u) { return createSportsTeamBlock(n, u); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public void load(ImageView i, String u) { loadPosterImage(i, u); }
                    public void open(JSONObject e) { openSportsEvent(e); }
                    public void focus(View v, int r) { addFocusStyle(v, r); }
                },
                container, status, events);
    }
    private void openSportsEvent(JSONObject event) {
        JSONArray channels = event.optJSONArray("channels");
        if (channels == null || channels.length() == 0) {
            Toast.makeText(this, "No matching live channel is available.", Toast.LENGTH_SHORT).show();
            return;
        }
        Channel chosen = SportsEventResolver.find(
                channels,
                getActiveChannels());
        if (chosen == null) {
            Toast.makeText(this, "This event is no longer available in the current playlist.", Toast.LENGTH_SHORT).show();
            return;
        }
        selectChannelInternal(chosen);
        showPlayerScreen();
    }
    private void maybeSyncSportsGuideInBackground() {
        long now = System.currentTimeMillis();
        long last = playlistPrefs().getLong("sports_last_sync_ms", 0L);
        if (now - last < 2L * 60L * 60L * 1000L) return;
        playlistPrefs().edit().putLong("sports_last_sync_ms", now).apply();
        syncSportsGuideFromEpg(null);
    }

    private void postSportsChannelInventory(
            ArrayList<Channel> sportsChannels,
            Runnable completion) {
        SportsGuideUpload.postChannels(
                CAST_BACKEND_BASE_URL,
                CAST_BACKEND_PUBLISHABLE_KEY,
                sportsGuidePlaylistKey(),
                sportsChannels,
                () -> {
                    if (completion != null) {
                        runOnUiThread(completion);
                    }
                });
    }
    private void syncSportsGuideFromEpg(Runnable completion) {
        ArrayList<Channel> sportsChannels = new ArrayList<Channel>();

        for (Channel channel : getActiveChannels()) {
            if (isSportsChannel(channel)) {
                sportsChannels.add(channel);
            }
        }

        if (sportsChannels.isEmpty()) {
            if (completion != null) completion.run();
            return;
        }

        // First upload every sanitized sports-channel identity. Official fixture
        // data on the server can then map Liverpool v Arsenal (etc.) to a
        // playable provider channel even when the provider EPG is incomplete.
        postSportsChannelInventory(
                sportsChannels,
                () -> startSportsEpgScan(sportsChannels, completion));
    }

    private void startSportsEpgScan(
            ArrayList<Channel> sportsChannels,
            Runnable completion) {
        SportsGuideEpgSync.start(
                sportsChannels,
                (channel, limit, callback) ->
                        fetchShortEpg(
                                channel,
                                limit,
                                (entries, error) ->
                                        callback.result(entries, error)),
                (events, done) ->
                        postSportsEvents(events, done),
                completion);
    }
    private void postSportsEvents(JSONArray events, Runnable completion) {
        SportsGuideUpload.postEvents(
                CAST_BACKEND_BASE_URL,
                CAST_BACKEND_PUBLISHABLE_KEY,
                sportsGuidePlaylistKey(),
                events,
                () -> {
                    if (completion != null) {
                        runOnUiThread(completion);
                    }
                });
    }
    private boolean isSportsChannel(Channel channel) {
        return SportsGuideSupport.isSportsChannel(channel);
    }

    private void showUserManagement() {
        releasePlayer();
        onHomeScreen = false;
        UserManagementScreen.show(
                this,
                new UserManagementScreen.Host() {
                    public android.content.SharedPreferences prefs() { return playlistPrefs(); }
                    public int liveChannelCount() { return importedChannels.size(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int black() { return BLACK; }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                    public int charcoal() { return CHARCOAL; }
                    public TextView createBackText() { return MainActivity.this.createBackText(); }
                    public android.graphics.drawable.Drawable makeBackground(int f, int b, int r) { return MainActivity.this.makeBackground(f, b, r); }
                    public void showHome() { MainActivity.this.showHome(); }
                    public void showPlaylists() { MainActivity.this.showPlaylists(); }
                    public void showSettings() { MainActivity.this.showSettings(); }
                    public void makeTvRemoteReady(View v) { MainActivity.this.makeTvRemoteReady(v); }
                    public void addTvFocusScale(View v) { MainActivity.this.addTvFocusScale(v); }
                    public void setContentView(View v) { MainActivity.this.setContentView(v); }
                });
    }
    private void showSection(String title) {
        if (title.equals("LIVE TV")) {
            showLiveTv("ALL");
            return;
        }

        if (title.equals("FAVOURITES")) {
            showLiveTv("FAVOURITES");
            return;
        }

        if (title.equals("PLAYLISTS")) {
            showPlaylists();
            return;
        }

        if (title.equals("MOVIES")) {
            showMovies();
            return;
        }

        if (title.equals("SERIES")) {
            showSeries();
            return;
        }

        if (title.equals("TV GUIDE")) {
            showTvGuide();
            return;
        }

        if (title.equals("SETTINGS")) {
            showSettings();
            return;
        }

        releasePlayer();
        onHomeScreen = false;

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20), dp(30), dp(20), dp(30));
        screen.setBackgroundColor(BLACK);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        screen.addView(back);

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        screen.addView(heading);

        TextView message = new TextView(this);
        message.setText("This section is ready for the next development stage.");
        message.setTextColor(SILVER);
        message.setTextSize(16);
        message.setPadding(0, dp(12), 0, 0);
        screen.addView(message);

        setContentView(screen);
    }

    private TextView createBackText() {
        TextView back = new TextView(this);
        back.setText("<  HOME");
        back.setTextColor(GOLD);
        back.setTextSize(16);
        back.setPadding(0, 0, 0, dp(24));
        makeTvRemoteReady(
                back);

        return back;
    }

    // ---------------------------------------------------------------------
    // PLAYLISTS
    // ---------------------------------------------------------------------

    private void showPlaylists() {
        releasePlayer();
        onHomeScreen = false;

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        scrollView.addView(root);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText("PLAYLISTS");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        TextView help = new TextView(this);
        help.setText(
                "Add and switch between multiple Xtream or M3U/M3U8 playlists. Each profile keeps its own favourites, Continue Watching, appearance and last selected channel.");
        help.setTextColor(SILVER);
        help.setTextSize(14);
        help.setPadding(0, dp(8), 0, dp(22));
        root.addView(help);


        PlaylistProfilesSection.add(
                this,
                new PlaylistProfilesSection.Host() {
                    public String activeId() { return activePlaylistId; }
                    public ArrayList<String> profileIds() { return getPlaylistProfileIds(); }
                    public String profileName(String id) { return getPlaylistProfileName(id); }
                    public android.content.SharedPreferences prefs(String id) { return prefsForPlaylist(id); }
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public void switchProfile(String id) { switchPlaylistProfile(id); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                    public int charcoal() { return CHARCOAL; }
                },
                root);
        PlaylistProfileControls.add(
                this,
                new PlaylistProfileControls.Host() {
                    public String activeId() { return activePlaylistId; }
                    public String createProfile() { return createPlaylistProfile(); }
                    public void switchProfile(String id) { switchPlaylistProfile(id); }
                    public String profileName(String id) { return getPlaylistProfileName(id); }
                    public void setProfileName(String id, String name) { setPlaylistProfileName(id, name); }
                    public java.util.ArrayList<String> profileIds() { return getPlaylistProfileIds(); }
                    public void deleteActive() { deleteActivePlaylistProfile(); }
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public void showPlaylists() { MainActivity.this.showPlaylists(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int black() { return BLACK; }
                    public int charcoal() { return CHARCOAL; }
                },
                root);
        PlaylistStatusSection.add(
                this,
                new PlaylistStatusSection.Host() {
                    public int channelCount() { return importedChannels.size(); }
                    public android.content.SharedPreferences prefs() { return playlistPrefs(); }
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public LinearLayout.LayoutParams weightedButtonParams() { return MainActivity.this.weightedButtonParams(); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public void openLiveTv() { showLiveTv("ALL"); }
                    public void refreshXtream() { refreshXtreamPlaylist(); }
                    public void refreshUrl() { refreshUrlPlaylist(); }
                    public void removePlaylist() { MainActivity.this.removePlaylist(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int silver() { return SILVER; }
                    public int charcoal() { return CHARCOAL; }
                },
                root);
        PlaylistLoginSection.add(
                this,
                new PlaylistLoginSection.Host() {
                    public android.content.SharedPreferences prefs() { return playlistPrefs(); }
                    public void prepare(EditText v, int t, int a) { prepareTvTextInput(v, t, a); }
                    public void hideKeyboard(EditText v) { hideTvKeyboard(v); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public void tvReady(View v) { makeTvRemoteReady(v); }
                    public void focus(View v) { addTvFocusScale(v); }
                    public void importXtream(String s, String u, String p) { importXtreamPlaylist(s, u, p); }
                    public void showQr() { showQrXtreamLogin(); }
                    public void importUrl(String u) { importPlaylistFromUrl(u); }
                    public void chooseLocal() { chooseLocalPlaylist(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int black() { return BLACK; }
                    public int charcoal() { return CHARCOAL; }
                },
                root);
        setContentView(scrollView);
    }

    private void importXtreamPlaylist(
            String server,
            String username,
            String password) {

        String cleanedServer = normalizeXtreamServer(server);

        Toast.makeText(
                this,
                "Connecting to Xtream server...",
                Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            try {
                String encodedUser =
                        URLEncoder.encode(
                                username,
                                "UTF-8");

                String encodedPassword =
                        URLEncoder.encode(
                                password,
                                "UTF-8");

                String workingServer =
                        cleanedServer;

                String authUrl =
                        workingServer
                                + "/player_api.php?username="
                                + encodedUser
                                + "&password="
                                + encodedPassword;

                String authText;

                try {
                    authText =
                            downloadPlaylistText(
                                    authUrl);
                } catch (Exception firstError) {
                    String alternateServer =
                            alternateXtreamProtocol(
                                    workingServer);

                    if (alternateServer.equals(
                            workingServer)) {
                        throw firstError;
                    }

                    String alternateAuthUrl =
                            alternateServer
                                    + "/player_api.php?username="
                                    + encodedUser
                                    + "&password="
                                    + encodedPassword;

                    try {
                        authText =
                                downloadPlaylistText(
                                        alternateAuthUrl);

                        workingServer =
                                alternateServer;

                        authUrl =
                                alternateAuthUrl;

                    } catch (Exception secondError) {
                        throw new Exception(
                                "Could not find the Xtream API endpoint. "
                                        + firstError.getMessage()
                                        + " | "
                                        + secondError.getMessage());
                    }
                }

                JSONObject authObject =
                        new JSONObject(authText);

                JSONObject userInfo =
                        authObject.optJSONObject(
                                "user_info");

                JSONObject serverInfo =
                        authObject.optJSONObject(
                                "server_info");

                final String streamServer =
                        buildXtreamStreamingServer(
                                workingServer,
                                serverInfo);

                if (userInfo == null) {
                    throw new Exception(
                            "Server did not return Xtream user information.");
                }

                String authValue =
                        String.valueOf(
                                userInfo.opt(
                                        "auth"));

                String status =
                        userInfo.optString(
                                "status",
                                "");

                boolean authenticated =
                        "1".equals(authValue)
                                || "Active".equalsIgnoreCase(status);

                if (!authenticated) {
                    throw new Exception(
                            "Xtream login rejected. Check username/password.");
                }

                StringBuilder allowedFormatsBuilder =
                        new StringBuilder();

                JSONArray allowedFormats =
                        userInfo.optJSONArray(
                                "allowed_output_formats");

                if (allowedFormats != null) {
                    for (int i = 0;
                         i < allowedFormats.length();
                         i++) {

                        if (i > 0) {
                            allowedFormatsBuilder.append(",");
                        }

                        allowedFormatsBuilder.append(
                                allowedFormats.optString(i, ""));
                    }
                }

                final String allowedFormatsCsv =
                        allowedFormatsBuilder.toString();

                String categoriesUrl =
                        authUrl
                                + "&action=get_live_categories";

                String streamsUrl =
                        authUrl
                                + "&action=get_live_streams";

                String categoriesText =
                        downloadPlaylistText(
                                categoriesUrl);

                String streamsText =
                        downloadPlaylistText(
                                streamsUrl);

                JSONArray categoriesArray =
                        new JSONArray(
                                categoriesText);

                JSONArray streamsArray =
                        new JSONArray(
                                streamsText);

                java.util.HashMap<String, String> categoryMap =
                        new java.util.HashMap<String, String>();

                for (int i = 0;
                     i < categoriesArray.length();
                     i++) {

                    JSONObject category =
                            categoriesArray.getJSONObject(i);

                    String id =
                            category.optString(
                                    "category_id",
                                    "");

                    String name =
                            category.optString(
                                    "category_name",
                                    "OTHER");

                    categoryMap.put(
                            id,
                            name);
                }

                ArrayList<Channel> parsed =
                        new ArrayList<Channel>();

                StringBuilder m3u =
                        new StringBuilder();

                m3u.append("#EXTM3U\n");

                for (int i = 0;
                     i < streamsArray.length();
                     i++) {

                    JSONObject stream =
                            streamsArray.getJSONObject(i);

                    String name =
                            stream.optString(
                                    "name",
                                    "Channel");

                    String streamId =
                            String.valueOf(
                                    stream.opt(
                                            "stream_id"));

                    String categoryId =
                            String.valueOf(
                                    stream.opt(
                                            "category_id"));

                    String group =
                            categoryMap.containsKey(categoryId)
                                    ? categoryMap.get(categoryId)
                                    : "OTHER";

                    String logo =
                            stream.optString(
                                    "stream_icon",
                                    "");

                    String epgId =
                            stream.optString(
                                    "epg_channel_id",
                                    "");

                    String directSource =
                            stream.optString(
                                    "direct_source",
                                    "");

                    String streamUrl =
                            buildXtreamStreamUrl(
                                    streamServer,
                                    username,
                                    password,
                                    streamId);

                    Channel channel =
                            new Channel();

                    channel.name = name;
                    channel.url = streamUrl;
                    channel.tvgId = epgId;
                    channel.tvgName = name;
                    channel.logo = logo;
                    channel.group = group;
                    channel.streamId = streamId;
                    channel.directSource = directSource;
                    channel.now = "";
                    channel.next = "";

                    parsed.add(channel);

                    m3u.append("#EXTINF:-1");

                    if (!epgId.isEmpty()) {
                        m3u.append(" tvg-id=\"")
                                .append(escapeM3u(epgId))
                                .append("\"");
                    }

                    m3u.append(" tvg-name=\"")
                            .append(escapeM3u(name))
                            .append("\"");

                    if (!logo.isEmpty()) {
                        m3u.append(" tvg-logo=\"")
                                .append(escapeM3u(logo))
                                .append("\"");
                    }

                    m3u.append(" group-title=\"")
                            .append(escapeM3u(group))
                            .append("\",")
                            .append(name)
                            .append("\n")
                            .append(streamUrl)
                            .append("\n");
                }

                if (parsed.size() == 0) {
                    throw new Exception(
                            "Xtream login succeeded, but no live channels were returned.");
                }

                savePlaylistText(
                        m3u.toString());

                importedChannels.clear();
                importedChannels.addAll(parsed);

                playlistPrefs()
                        .edit()
                        .putString(
                                "playlist_name",
                                "Xtream Live TV")
                        .putString(
                                "playlist_source_type",
                                "XTREAM")
                        .putString(
                                "xtream_server",
                                workingServer)
                        .putString(
                                "xtream_stream_server",
                                streamServer)
                        .putString(
                                "xtream_username",
                                username)
                        .putString(
                                "xtream_password",
                                password)
                        .putString(
                                "xtream_allowed_formats",
                                allowedFormatsCsv)
                        .remove("playlist_url")
                        .apply();

                runOnUiThread(() -> {
                    Toast.makeText(
                            this,
                            parsed.size()
                                    + " Xtream channels imported.",
                            Toast.LENGTH_LONG).show();

                    showPlaylists();
                });

            } catch (Exception e) {
                String message =
                        e.getMessage();

                if (message == null
                        || message.trim().isEmpty()) {
                    message =
                            e.getClass()
                                    .getSimpleName();
                }

                final String safeMessage =
                        message;

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Xtream failed: "
                                        + safeMessage,
                                Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void refreshXtreamPlaylist() {
        android.content.SharedPreferences prefs =
                playlistPrefs();

        String server =
                prefs.getString(
                        "xtream_server",
                        "");

        String username =
                prefs.getString(
                        "xtream_username",
                        "");

        String password =
                prefs.getString(
                        "xtream_password",
                        "");

        if (server == null
                || username == null
                || password == null
                || server.trim().isEmpty()
                || username.trim().isEmpty()
                || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Saved Xtream login is incomplete.",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        importXtreamPlaylist(
                server,
                username,
                password);
    }

    private String buildXtreamStreamingServer(
            String fallbackServer,
            JSONObject serverInfo) {

        if (serverInfo == null) {
            return normalizeXtreamServer(fallbackServer);
        }

        try {
            String host =
                    serverInfo.optString(
                            "url",
                            "")
                            .trim();

            if (host.isEmpty()) {
                return normalizeXtreamServer(fallbackServer);
            }

            if (host.startsWith("http://")
                    || host.startsWith("https://")) {
                return normalizeXtreamServer(host);
            }

            String protocol =
                    serverInfo.optString(
                            "server_protocol",
                            "http")
                            .trim();

            if (!protocol.equalsIgnoreCase("https")) {
                protocol = "http";
            } else {
                protocol = "https";
            }

            String port =
                    protocol.equals("https")
                            ? serverInfo.optString(
                                    "https_port",
                                    serverInfo.optString("port", ""))
                            : serverInfo.optString(
                                    "port",
                                    "");

            String result =
                    protocol
                            + "://"
                            + host;

            if (!port.isEmpty()
                    && !host.matches(".*:[0-9]+$")) {
                result += ":" + port;
            }

            return normalizeXtreamServer(result);

        } catch (Exception ignored) {
            return normalizeXtreamServer(fallbackServer);
        }
    }

    private String normalizeXtreamServer(
            String server) {

        String cleaned =
                server == null
                        ? ""
                        : server.trim();

        if (cleaned.isEmpty()) {
            return "";
        }

        if (!cleaned.startsWith("http://")
                && !cleaned.startsWith("https://")) {
            cleaned = "http://" + cleaned;
        }

        try {
            URL parsed = new URL(cleaned);

            String path = parsed.getPath();

            if (path == null) {
                path = "";
            }

            String lowerPath =
                    path.toLowerCase(Locale.US);

            String[] endpoints = {
                    "/player_api.php",
                    "/get.php",
                    "/xmltv.php",
                    "/panel_api.php"
            };

            int cut = -1;

            for (String endpoint : endpoints) {
                int index =
                        lowerPath.indexOf(endpoint);

                if (index >= 0
                        && (cut < 0 || index < cut)) {
                    cut = index;
                }
            }

            if (cut >= 0) {
                path = path.substring(0, cut);
            }

            while (path.endsWith("/")) {
                path =
                        path.substring(
                                0,
                                path.length() - 1);
            }

            return parsed.getProtocol()
                    + "://"
                    + parsed.getAuthority()
                    + path;

        } catch (Exception ignored) {
            int query =
                    cleaned.indexOf("?");

            if (query >= 0) {
                cleaned =
                        cleaned.substring(
                                0,
                                query);
            }

            String lower =
                    cleaned.toLowerCase(Locale.US);

            String[] endpoints = {
                    "/player_api.php",
                    "/get.php",
                    "/xmltv.php",
                    "/panel_api.php"
            };

            for (String endpoint : endpoints) {
                int index =
                        lower.indexOf(endpoint);

                if (index >= 0) {
                    cleaned =
                            cleaned.substring(
                                    0,
                                    index);
                    break;
                }
            }

            while (cleaned.endsWith("/")) {
                cleaned =
                        cleaned.substring(
                                0,
                                cleaned.length() - 1);
            }

            return cleaned;
        }
    }

    private String alternateXtreamProtocol(
            String server) {

        if (server.startsWith("http://")) {
            return "https://"
                    + server.substring(
                            "http://".length());
        }

        if (server.startsWith("https://")) {
            return "http://"
                    + server.substring(
                            "https://".length());
        }

        return server;
    }

    private String buildXtreamStreamUrl(
            String server,
            String username,
            String password,
            String streamId)
            throws Exception {

        String userPath =
                URLEncoder.encode(
                        username,
                        "UTF-8")
                        .replace("+", "%20");

        String passPath =
                URLEncoder.encode(
                        password,
                        "UTF-8")
                        .replace("+", "%20");

        return server
                + "/live/"
                + userPath
                + "/"
                + passPath
                + "/"
                + streamId
                + ".ts";
    }

    private String escapeM3u(
            String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\"", "'")
                .replace("\n", " ")
                .replace("\r", " ");
    }

    private void chooseLocalPlaylist() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_M3U_FILE);
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK) {
                Runnable action = pendingVpnConnectedAction;
                pendingVpnConnectedAction = null;
                connectEmbeddedVpn(true, action);
            } else {
                pendingVpnConnectedAction = null;
                Toast.makeText(this, "Android VPN permission was not granted.", Toast.LENGTH_LONG).show();
            }
            return;
        }

        if (requestCode == PICK_WIREGUARD_CONFIG) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                if (embeddedVpn == null) {
                    embeddedVpn = new EmbeddedWireGuardManager(getApplicationContext());
                }
                boolean installed = embeddedVpn.installPrivateConfig(data.getData());
                Toast.makeText(this,
                        installed ? "Proton WireGuard configuration installed." : "That file is not a valid WireGuard configuration.",
                        Toast.LENGTH_LONG).show();
                if (installed) {
                    showVpnManager();
                }
            }
            return;
        }

        if (requestCode == PICK_M3U_FILE
                && resultCode == RESULT_OK
                && data != null
                && data.getData() != null) {

            Uri uri = data.getData();

            try {
                String text = readTextFromUri(uri);
                ArrayList<Channel> parsed = parseM3U(text);

                if (parsed.size() == 0) {
                    Toast.makeText(
                            this,
                            "No channels were found in that file.",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                savePlaylistText(text);

                importedChannels.clear();
                importedChannels.addAll(parsed);

                String displayName = getDisplayName(uri);

                playlistPrefs()
                        .edit()
                        .putString(
                                "playlist_name",
                                displayName == null
                                        ? "Local Playlist"
                                        : displayName)
                        .putString("playlist_source_type", "LOCAL")
                        .remove("playlist_url")
                        .apply();

                Toast.makeText(
                        this,
                        parsed.size() + " channels imported.",
                        Toast.LENGTH_LONG).show();

                showPlaylists();

            } catch (Exception e) {
                Toast.makeText(
                        this,
                        "Import failed: " + e.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private String readTextFromUri(Uri uri) throws Exception {
        InputStream input =
                getContentResolver()
                        .openInputStream(uri);

        if (input == null) {
            throw new Exception("Could not open file.");
        }

        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                input,
                                "UTF-8"));

        StringBuilder builder = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            builder.append(line).append("\n");
        }

        reader.close();
        return builder.toString();
    }

    private String getDisplayName(Uri uri) {
        Cursor cursor = null;

        try {
            cursor =
                    getContentResolver()
                            .query(
                                    uri,
                                    null,
                                    null,
                                    null,
                                    null);

            if (cursor != null
                    && cursor.moveToFirst()) {

                int index =
                        cursor.getColumnIndex(
                                OpenableColumns.DISPLAY_NAME);

                if (index >= 0) {
                    return cursor.getString(index);
                }
            }

        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        return null;
    }

    private void importPlaylistFromUrl(String playlistUrl) {
        String cleanedUrl = playlistUrl == null
                ? ""
                : playlistUrl.trim();

        if (cleanedUrl.isEmpty()) {
            Toast.makeText(
                    this,
                    "Enter an M3U URL first.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (!cleanedUrl.startsWith("http://")
                && !cleanedUrl.startsWith("https://")) {
            cleanedUrl = "https://" + cleanedUrl;
        }

        final String finalUrl = cleanedUrl;

        Toast.makeText(
                this,
                "Loading playlist...",
                Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            try {
                String text = downloadPlaylistText(finalUrl);

                ArrayList<Channel> parsed = parseM3U(text);

                if (parsed.size() == 0) {
                    String preview = text == null
                            ? ""
                            : text.trim();

                    if (preview.length() > 120) {
                        preview = preview.substring(0, 120);
                    }

                    if (preview.startsWith("<")) {
                        throw new Exception(
                                "Server returned a web page instead of an M3U playlist.");
                    }

                    throw new Exception(
                            "Connected successfully, but no M3U channels were found.");
                }

                savePlaylistText(text);

                importedChannels.clear();
                importedChannels.addAll(parsed);

                playlistPrefs()
                        .edit()
                        .putString(
                                "playlist_name",
                                "URL Playlist")
                        .putString(
                                "playlist_source_type",
                                "URL")
                        .putString(
                                "playlist_url",
                                finalUrl)
                        .apply();

                runOnUiThread(() -> {
                    Toast.makeText(
                            this,
                            parsed.size()
                                    + " channels imported.",
                            Toast.LENGTH_LONG).show();

                    showPlaylists();
                });

            } catch (Exception e) {
                String message = e.getMessage();

                if (message == null
                        || message.trim().isEmpty()) {
                    message = e.getClass().getSimpleName();
                }

                final String safeMessage = message;

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Playlist failed: "
                                        + safeMessage,
                                Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private String downloadPlaylistText(String playlistUrl) throws Exception {
        String currentUrl = playlistUrl;

        for (int redirectCount = 0;
             redirectCount < 6;
             redirectCount++) {

            HttpURLConnection connection = null;

            try {
                URL url = new URL(currentUrl);

                connection =
                        (HttpURLConnection) url.openConnection();

                connection.setConnectTimeout(20000);
                connection.setReadTimeout(30000);
                connection.setInstanceFollowRedirects(false);
                connection.setRequestMethod("GET");
                connection.setUseCaches(false);

                connection.setRequestProperty(
                        "User-Agent",
                        "VLC/3.0.21 LibVLC/3.0.21");

                connection.setRequestProperty(
                        "Accept",
                        "application/x-mpegURL, application/vnd.apple.mpegurl, audio/x-mpegurl, text/plain, */*");

                connection.setRequestProperty(
                        "Accept-Encoding",
                        "identity");

                connection.setRequestProperty(
                        "Connection",
                        "close");

                int status = connection.getResponseCode();

                if (status == HttpURLConnection.HTTP_MOVED_PERM
                        || status == HttpURLConnection.HTTP_MOVED_TEMP
                        || status == HttpURLConnection.HTTP_SEE_OTHER
                        || status == 307
                        || status == 308) {

                    String location =
                            connection.getHeaderField("Location");

                    if (location == null
                            || location.trim().isEmpty()) {
                        throw new Exception(
                                "Server redirected without a destination.");
                    }

                    currentUrl =
                            new URL(
                                    url,
                                    location)
                                    .toString();

                    continue;
                }

                if (status < 200
                        || status >= 300) {

                    String errorText =
                            readConnectionStream(
                                    connection.getErrorStream());

                    String detail =
                            "HTTP "
                                    + status;

                    if (errorText != null
                            && !errorText.trim().isEmpty()) {

                        String clean =
                                errorText
                                        .replace("\n", " ")
                                        .replace("\r", " ")
                                        .trim();

                        if (clean.length() > 100) {
                            clean =
                                    clean.substring(
                                            0,
                                            100);
                        }

                        detail += " - " + clean;
                    }

                    throw new Exception(detail);
                }

                String content =
                        readConnectionStream(
                                connection.getInputStream());

                if (content == null
                        || content.trim().isEmpty()) {
                    throw new Exception(
                            "Server returned an empty response.");
                }

                return content;

            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        throw new Exception(
                "Too many redirects.");
    }

    private String readConnectionStream(InputStream input) throws Exception {
        if (input == null) {
            return "";
        }

        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                input,
                                "UTF-8"));

        StringBuilder builder =
                new StringBuilder();

        String line;

        while ((line = reader.readLine()) != null) {
            builder.append(line).append("\n");
        }

        reader.close();

        return builder.toString();
    }

    private void refreshUrlPlaylist() {
        String url =
                playlistPrefs()
                        .getString(
                                "playlist_url",
                                "");

        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(
                    this,
                    "No URL is saved for this playlist.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        importPlaylistFromUrl(url);
    }

    private void removePlaylist() {
        importedChannels.clear();
        deleteFile(playlistFileName());

        String profileName = getPlaylistProfileName(activePlaylistId);
        playlistPrefs().edit()
                .clear()
                .putString("profile_display_name", profileName)
                .apply();
        resumePrefs().edit().clear().apply();
        mediaFavouritePrefs().edit().clear().apply();
        favouriteChannels.clear();

        if (catalogueDbHelper != null) {
            try { catalogueDbHelper.close(); } catch (Exception ignored) {}
            catalogueDbHelper = null;
        }
        try { deleteDatabase(catalogueDbName()); } catch (Exception ignored) {}

        resetSelectedLiveChannel();
        Toast.makeText(this, "Playlist source removed from this profile.", Toast.LENGTH_SHORT).show();
        showPlaylists();
    }

    private void savePlaylistText(String text) throws Exception {
        FileOutputStream output =
                openFileOutput(
                        playlistFileName(),
                        MODE_PRIVATE);

        OutputStreamWriter writer =
                new OutputStreamWriter(
                        output,
                        "UTF-8");

        writer.write(text);
        writer.close();
    }

    private void loadSavedPlaylist() {
        importedChannels.clear();

        try {
            FileInputStream input =
                    openFileInput(
                            playlistFileName());

            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    input,
                                    "UTF-8"));

            StringBuilder builder =
                    new StringBuilder();

            String line;

            while ((line = reader.readLine()) != null) {
                builder.append(line).append("\n");
            }

            reader.close();

            importedChannels.addAll(
                    parseM3U(
                            builder.toString()));

        } catch (Exception ignored) {
        }
    }

    private ArrayList<Channel> parseM3U(String text) {
        ArrayList<Channel> result =
                new ArrayList<Channel>();

        if (text == null) {
            return result;
        }

        String[] lines =
                text.replace("\r", "")
                        .split("\n");

        String pendingInfo = null;

        for (String rawLine : lines) {
            String line = rawLine.trim();

            if (line.isEmpty()) {
                continue;
            }

            if (line.startsWith("#EXTINF")) {
                pendingInfo = line;
                continue;
            }

            if (line.startsWith("#")) {
                continue;
            }

            if (pendingInfo != null) {
                Channel channel =
                        parseExtInf(
                                pendingInfo,
                                line);

                if (channel != null) {
                    result.add(channel);
                }

                pendingInfo = null;
            }
        }

        return result;
    }

    private Channel parseExtInf(
            String info,
            String streamUrl) {

        try {
            Channel channel = new Channel();

            channel.url = streamUrl.trim();
            channel.streamId = extractXtreamStreamId(channel.url);

            int comma = info.lastIndexOf(",");

            String attributesPart =
                    comma >= 0
                            ? info.substring(0, comma)
                            : info;

            String displayName =
                    comma >= 0
                            ? info.substring(comma + 1).trim()
                            : "Channel";

            Pattern pattern =
                    Pattern.compile(
                            "([A-Za-z0-9_-]+)=\"([^\"]*)\"");

            Matcher matcher =
                    pattern.matcher(
                            attributesPart);

            while (matcher.find()) {
                String key =
                        matcher.group(1);

                String value =
                        matcher.group(2);

                if (key.equalsIgnoreCase("tvg-id")) {
                    channel.tvgId = value;
                } else if (key.equalsIgnoreCase("tvg-name")) {
                    channel.tvgName = value;
                } else if (key.equalsIgnoreCase("tvg-logo")) {
                    channel.logo = value;
                } else if (key.equalsIgnoreCase("group-title")) {
                    channel.group = value;
                }
            }

            if (displayName.isEmpty()) {
                displayName =
                        channel.tvgName == null
                                ? "Channel"
                                : channel.tvgName;
            }

            channel.name = displayName;

            if (channel.group == null
                    || channel.group.trim().isEmpty()) {
                channel.group = "OTHER";
            }

            return channel;

        } catch (Exception ignored) {
            return null;
        }
    }

    // ---------------------------------------------------------------------
    // MOVIES + SERIES (XTREAM)
    // ---------------------------------------------------------------------

    private boolean hasXtreamLogin() {
        android.content.SharedPreferences prefs =
                playlistPrefs();

        String server = prefs.getString("xtream_server", "");
        String username = prefs.getString("xtream_username", "");
        String password = prefs.getString("xtream_password", "");

        return server != null
                && username != null
                && password != null
                && !server.trim().isEmpty()
                && !username.trim().isEmpty()
                && !password.isEmpty();
    }

    private String buildXtreamApiUrl(
            String action,
            String parameterName,
            String parameterValue)
            throws Exception {

        android.content.SharedPreferences prefs =
                playlistPrefs();

        String server = normalizeXtreamServer(
                prefs.getString("xtream_server", ""));

        String username = prefs.getString("xtream_username", "");
        String password = prefs.getString("xtream_password", "");

        if (server.isEmpty()
                || username == null
                || username.isEmpty()
                || password == null
                || password.isEmpty()) {

            throw new Exception(
                    "Xtream login is missing. Open PLAYLISTS and log in again.");
        }

        String url =
                server
                        + "/player_api.php?username="
                        + URLEncoder.encode(username, "UTF-8")
                        + "&password="
                        + URLEncoder.encode(password, "UTF-8")
                        + "&action="
                        + URLEncoder.encode(action, "UTF-8");

        if (parameterName != null
                && !parameterName.isEmpty()
                && parameterValue != null
                && !parameterValue.isEmpty()) {

            url +=
                    "&"
                            + URLEncoder.encode(parameterName, "UTF-8")
                            + "="
                            + URLEncoder.encode(parameterValue, "UTF-8");
        }

        return url;
    }

    private void showXtreamRequiredScreen(String title) {
        releasePlayer();
        onHomeScreen = false;

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20), dp(30), dp(20), dp(30));
        screen.setBackgroundColor(BLACK);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        screen.addView(back);

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        screen.addView(heading);

        TextView message = new TextView(this);
        message.setText(
                "Movies and Series require an Xtream login.\nOpen PLAYLISTS and log in with your server, username and password.");
        message.setTextColor(SILVER);
        message.setTextSize(15);
        message.setPadding(0, dp(15), 0, dp(20));
        screen.addView(message);

        Button playlists = new Button(this);
        playlists.setText("OPEN PLAYLISTS");
        playlists.setTextColor(BLACK);
        playlists.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        playlists.setAllCaps(false);
        playlists.setBackground(makeBackground(GOLD, GOLD, 14));
        playlists.setOnClickListener(v -> showPlaylists());

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(50));

        screen.addView(playlists, params);
        setContentView(screen);
    }

    private void showMovies() {
        showMediaCategories("MOVIES");
    }

    private void showSeries() {
        showMediaCategories("SERIES");
    }

    private void showMediaCategories(String mediaType) {
        releasePlayer();
        closeActiveMediaAdapter();
        onHomeScreen = false;

        if (!hasXtreamLogin()) {
            showXtreamRequiredScreen(mediaType);
            return;
        }

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20), dp(24), dp(20), dp(30));
        screen.setBackgroundColor(BLACK);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        screen.addView(back);

        TextView heading = new TextView(this);
        heading.setText(mediaType);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        screen.addView(heading);

        TextView build = new TextView(this);
        build.setText(BUILD_LABEL + " • XTREAM " + mediaType);
        build.setTextColor(Color.rgb(125, 125, 130));
        build.setTextSize(10);
        build.setPadding(0, dp(5), 0, dp(10));
        screen.addView(build);

        TextView loading = new TextView(this);
        loading.setText("Loading categories...");
        loading.setTextColor(SILVER);
        loading.setTextSize(15);
        loading.setPadding(0, dp(14), 0, 0);
        screen.addView(loading);

        setContentView(screen);

        new Thread(() -> {
            try {
                ArrayList<MediaCategory> categories =
                        MediaCategoryLoader.load(
                                mediaType,
                                action ->
                                        downloadPlaylistText(
                                                buildXtreamApiUrl(
                                                        action,
                                                        null,
                                                        null)));

                runOnUiThread(() -> {
                    renderMediaCategories(
                            mediaType,
                            applyMediaCategoryPreferences(
                                    mediaType,
                                    categories));

                    ensureCatalogueSyncAsync(
                            mediaType,
                            false);
                });

            } catch (Exception e) {
                final String message = safeErrorMessage(e);

                runOnUiThread(() ->
                        showMediaErrorScreen(
                                mediaType,
                                message,
                                () -> showMediaCategories(mediaType)));
            }
        }).start();
    }

    private MediaBrowserLayout.Host mediaBrowserLayoutHost() {
        return new MediaBrowserLayout.Host() {

            public int dp(int value) {
                return MainActivity.this.dp(value);
            }

            public TextView createBackText() {
                return MainActivity.this.createBackText();
            }

            public EditText createSearchBox(
                    String hint) {

                return createMediaSearchBox(
                        hint);
            }

            public void prepareRemote(
                    TextView view) {

                makeTvRemoteReady(
                        view);
            }

            public android.graphics.drawable.GradientDrawable background(
                    int fill,
                    int stroke,
                    int radius) {

                return makeBackground(
                        fill,
                        stroke,
                        radius);
            }
        };
    }

    private LinearLayout mediaSidebar;
    private LinearLayout mediaContentPane;
    private View mediaLastContentFocus;
    private View mediaLastCategoryFocus;

    private boolean isViewInside(View child, View parent) {
        while (child != null) {
            if (child == parent) return true;
            android.view.ViewParent p = child.getParent();
            child = p instanceof View ? (View) p : null;
        }
        return false;
    }

    private View findMediaContentFocus() {
        if (mediaContentPane == null) return null;
        java.util.ArrayList<View> focusables = new java.util.ArrayList<View>();
        mediaContentPane.addFocusables(focusables, View.FOCUS_FORWARD);
        for (View candidate : focusables) {
            if (candidate != mediaContentPane
                    && candidate.isShown()
                    && candidate.isEnabled()) {
                return candidate;
            }
        }
        return null;
    }

    private void setMediaSidebarExpanded(boolean expanded) {
        if (mediaSidebar == null || mediaContentPane == null) return;

        LinearLayout.LayoutParams params =
                (LinearLayout.LayoutParams) mediaSidebar.getLayoutParams();

        params.width = 0;
        // A collapsed sidebar must not reserve an empty strip of screen.
        mediaSidebar.setVisibility(expanded ? View.VISIBLE : View.GONE);
        params.weight = expanded ? 1f : 0f;
        mediaSidebar.setLayoutParams(params);
        mediaSidebar.setTag(Boolean.valueOf(expanded));

        for (int i = 0; i < mediaSidebar.getChildCount(); i++) {
            View child = mediaSidebar.getChildAt(i);
            child.setVisibility(expanded ? View.VISIBLE : View.GONE);
        }

        if (expanded) {
            View target = mediaLastCategoryFocus;
            if (target != null && target.isAttachedToWindow()
                    && target.isShown() && target.isFocusable()) {
                target.requestFocus();
            } else {
                View first = null;
                if (mediaSidebar instanceof android.view.ViewGroup) {
                    java.util.ArrayList<View> choices = new java.util.ArrayList<View>();
                    mediaSidebar.addFocusables(choices, View.FOCUS_FORWARD);
                    for (View choice : choices) {
                        if (choice != mediaSidebar && choice.isShown()
                                && choice.isEnabled()) {
                            first = choice;
                            break;
                        }
                    }
                }
                if (first != null) first.requestFocus();
            }
        }

        if (!expanded) {
            View target = mediaLastContentFocus;
            if (target != null && target.isAttachedToWindow()
                    && target.isShown() && target.isFocusable()) {
                target.requestFocus();
            } else {
                View first = findMediaContentFocus();
                if (first != null) first.requestFocus();
            }
        }
    }

    private void renderMediaCategories(
            String mediaType,
            ArrayList<MediaCategory> categories) {

        onHomeScreen = false;

        MediaBrowserLayout.Result layout =
                MediaBrowserLayout.build(
                        this,
                        mediaType,
                        mediaBrowserLayoutHost(),
                        BLACK,
                        GOLD);

        LinearLayout screen =
                layout.screen;

        TextView back =
                layout.back;

        EditText search =
                layout.search;

        TextView searchAll =
                layout.searchAll;

        LinearLayout categoryList =
                layout.categoryList;

        LinearLayout rightPane =
                layout.rightPane;

        mediaSidebar = layout.leftPane;
        mediaContentPane = rightPane;
        mediaLastContentFocus = null;
        mediaLastCategoryFocus = null;
        mediaSidebar.setTag(Boolean.TRUE);

        back.setOnClickListener(
                v -> showHome());

        searchAll.setOnClickListener(
                v -> {

                    String query =
                            search.getText() == null
                                    ? ""
                                    : search.getText()
                                    .toString()
                                    .trim();

                    if (normalizeSearchText(
                            query)
                            .length() < 2) {

                        Toast.makeText(
                                this,
                                "Enter at least 2 letters.",
                                Toast.LENGTH_SHORT)
                                .show();

                        return;
                    }

                    showUnifiedMediaSearch(
                            mediaType,
                            query);
                });

        final View[] selectedCategoryView =
                {null};

        final ArrayList<View> categoryViews =
                new ArrayList<View>();

        final ArrayList<MediaCategory> visibleCategories =
                new ArrayList<MediaCategory>();

        MediaCategory allCategory =
                new MediaCategory();
        allCategory.id = "";
        allCategory.name = "ALL";
        visibleCategories.add(allCategory);

        MediaCategory continueCategory = new MediaCategory();
        continueCategory.id = "__CONTINUE__";
        continueCategory.name = "CONTINUE WATCHING";
        visibleCategories.add(continueCategory);

        MediaCategory favouritesCategory = new MediaCategory();
        favouritesCategory.id = "__FAVOURITES__";
        favouritesCategory.name = "FAVOURITES";
        visibleCategories.add(favouritesCategory);

        if (categories != null) {
            visibleCategories.addAll(categories);
        }

        for (MediaCategory category : visibleCategories) {
            TextView categoryButton =
                    new TextView(this);

            categoryButton.setText(
                    category.name);

            categoryButton.setTextColor(
                    Color.WHITE);

            categoryButton.setTextSize(
                    13);

            categoryButton.setGravity(
                    Gravity.CENTER_VERTICAL);

            categoryButton.setPadding(
                    dp(12),
                    0,
                    dp(10),
                    0);

            makeTvRemoteReady(
                    categoryButton);

            categoryButton.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(55, 55, 58),
                            10));

            LinearLayout.LayoutParams categoryParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(50));

            categoryParams.setMargins(
                    0,
                    0,
                    0,
                    dp(6));

            categoryList.addView(
                    categoryButton,
                    categoryParams);

            categoryViews.add(
                    categoryButton);

            categoryButton.setOnClickListener(v -> {
                if (selectedCategoryView[0] != null) {
                    selectedCategoryView[0].setBackground(
                            makeBackground(
                                    CHARCOAL,
                                    Color.rgb(55, 55, 58),
                                    10));
                }

                selectedCategoryView[0] =
                        v;
                mediaLastCategoryFocus = v;

                v.setBackground(
                        makeBackground(
                                Color.rgb(38, 32, 20),
                                GOLD,
                                10));

                if (mediaType.equals("MOVIES")) {
                    lastMovieCategoryId =
                            category.id;
                } else {
                    lastSeriesCategoryId =
                            category.id;
                }

                search.setText(
                        "");

                loadMediaCategoryIntoPane(
                        mediaType,
                        category,
                        rightPane);
            });
        }

        // V0522_MAIN_SEARCH_EDITOR
        search.setOnEditorActionListener(
                (v, actionId, event) -> {

                    String query =
                            search.getText() == null
                                    ? ""
                                    : search.getText()
                                    .toString()
                                    .trim();

                    if (normalizeSearchText(
                            query)
                            .length() < 2) {

                        Toast.makeText(
                                this,
                                "Enter at least 2 letters.",
                                Toast.LENGTH_SHORT)
                                .show();
                        return true;
                    }

                    showUnifiedMediaSearch(
                            mediaType,
                            query);

                    return true;
                });

        search.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        refreshActiveMediaBrowseSearch(
                                s == null
                                        ? ""
                                        : s.toString());
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s) {
                    }
                });

        setContentView(
                screen);

        int initialIndex =
                0;

        String wantedCategoryId =
                mediaType.equals("MOVIES")
                        ? lastMovieCategoryId
                        : lastSeriesCategoryId;

        if (wantedCategoryId != null
                && !wantedCategoryId.isEmpty()) {

            for (int i = 0;
                 i < visibleCategories.size();
                 i++) {

                if (wantedCategoryId.equals(
                        visibleCategories
                                .get(i)
                                .id)) {

                    initialIndex =
                            i;

                    break;
                }
            }
        }

        MediaCategory initialCategory =
                visibleCategories.get(
                        initialIndex);

        // Remember the initial category for sidebar focus restoration.
        View initialView =
                categoryViews.get(
                        initialIndex);

        selectedCategoryView[0] =
                initialView;
        mediaLastCategoryFocus = initialView;

        initialView.setBackground(
                makeBackground(
                        Color.rgb(38, 32, 20),
                        GOLD,
                        10));

        if (mediaType.equals("MOVIES")) {
            lastMovieCategoryId =
                    initialCategory.id;
        } else {
            lastSeriesCategoryId =
                    initialCategory.id;
        }

        loadMediaCategoryIntoPane(
                mediaType,
                initialCategory,
                rightPane);

        // Keep the remembered category visible when returning to a long list.
        // A restored selection can be hundreds of rows below the top.
        initialView.post(() -> {
            if (!initialView.isAttachedToWindow() || !initialView.isShown()) {
                return;
            }
            initialView.requestFocus();
            android.graphics.Rect selectedBounds = new android.graphics.Rect();
            initialView.getDrawingRect(selectedBounds);
            categoryList.offsetDescendantRectToMyCoords(initialView, selectedBounds);
            android.view.ViewParent parent = categoryList.getParent();
            if (parent instanceof android.widget.ScrollView) {
                ((android.widget.ScrollView) parent).smoothScrollTo(0,
                        Math.max(0, selectedBounds.top - dp(12)));
            }
        });
    }




    private MediaCategoryProviderLoader.Host mediaCategoryProviderHost() {
        return new MediaCategoryProviderLoader.Host() {

            public String buildUrl(
                    String action,
                    String categoryId) throws Exception {

                return buildXtreamApiUrl(
                        action,
                        "category_id",
                        categoryId);
            }

            public void stream(
                    String url,
                    MediaCategoryProviderLoader.ItemReader itemReader)
                    throws Exception {

                streamJsonArray(
                        url,
                        reader -> itemReader.read(reader));
            }

            public MovieItem readMovie(
                    android.util.JsonReader reader)
                    throws Exception {

                return readMovieItemFromStream(
                        reader);
            }

            public SeriesItem readSeries(
                    android.util.JsonReader reader)
                    throws Exception {

                return readSeriesItemFromStream(
                        reader);
            }

            public String safe(String value) {
                return MainActivity.this.safe(value);
            }

            public void movieFallback(
                    String url,
                    String categoryId,
                    ArrayList<MovieItem> movies)
                    throws Exception {

                loadDirectMovieCategoryFallback(
                        url,
                        categoryId,
                        movies);
            }

            public void seriesFallback(
                    String url,
                    String categoryId,
                    ArrayList<SeriesItem> series)
                    throws Exception {

                loadDirectSeriesCategoryFallback(
                        url,
                        categoryId,
                        series);
            }
        };
    }

    private void loadMediaCategoryIntoPane(
            String mediaType,
            MediaCategory category,
            LinearLayout rightPane) {

        if (category == null) {
            return;
        }

        final int requestToken =
                ++mediaCategoryLoadToken;

        activeMediaCategoryId = safe(category.id);

        if ("__CONTINUE__".equals(category.id)) {
            renderContinueWatchingCategory(mediaType, rightPane);
            return;
        }
        if ("__FAVOURITES__".equals(category.id)) {
            renderMediaFavouritesCategory(mediaType, rightPane);
            return;
        }

        rightPane.removeAllViews();

        TextView loading =
                new TextView(this);

        loading.setText(
                "Loading "
                        + category.name
                        + " from provider...");

        loading.setTextColor(
                SILVER);

        loading.setTextSize(
                15);

        loading.setGravity(
                Gravity.CENTER);

        rightPane.addView(
                loading,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT));

        catalogueExecutor.execute(() -> {
            try {
                MediaCategoryProviderLoader.Result result =
                        MediaCategoryProviderLoader.load(
                                mediaType,
                                category.id,
                                mediaCategoryProviderHost());

                final ArrayList<MovieItem> finalMovies =
                        result.movies;

                final ArrayList<SeriesItem> finalSeries =
                        result.series;

                runOnUiThread(() -> {
                    if (requestToken != mediaCategoryLoadToken
                            || !rightPane.isAttachedToWindow()
                            || rightPane != mediaContentPane) {
                        return;
                    }

                    renderProviderDirectPosterPane(
                            mediaType,
                            category.name,
                            finalMovies,
                            finalSeries,
                            rightPane);
                });

                cacheDirectCategoryAsync(
                        mediaType,
                        finalMovies,
                        finalSeries);

            } catch (Exception e) {
                final String message =
                        safeErrorMessage(
                                e);

                runOnUiThread(() -> {
                    if (requestToken != mediaCategoryLoadToken
                            || !rightPane.isAttachedToWindow()
                            || rightPane != mediaContentPane) {
                        return;
                    }

                    rightPane.removeAllViews();

                    TextView error =
                            new TextView(this);

                    error.setText(
                            "Could not load "
                                    + category.name
                                    + ": "
                                    + message);

                    error.setTextColor(
                            SILVER);

                    error.setTextSize(
                            14);

                    error.setGravity(
                            Gravity.CENTER);

                    rightPane.addView(
                            error,
                            new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.MATCH_PARENT));
                });
            }
        });
    }


    private MediaCategoryFallbackParser.Host mediaFallbackParserHost() {
        return new MediaCategoryFallbackParser.Host() {

            public String download(String url)
                    throws Exception {

                return downloadPlaylistText(url);
            }

            public String safe(String value) {
                return MainActivity.this.safe(value);
            }

            public String sanitizeExtension(
                    String extension) {

                return sanitizeMediaExtension(
                        extension);
            }

            public String firstNonEmpty(
                    String... values) {

                return MainActivity.this.firstNonEmpty(
                        values);
            }
        };
    }

    private void loadDirectMovieCategoryFallback(
            String url,
            String categoryId,
            ArrayList<MovieItem> movies)
            throws Exception {

        MediaCategoryFallbackParser.loadMovies(
                url,
                categoryId,
                movies,
                mediaFallbackParserHost());
    }

    private void loadDirectSeriesCategoryFallback(
            String url,
            String categoryId,
            ArrayList<SeriesItem> seriesList)
            throws Exception {

        MediaCategoryFallbackParser.loadSeries(
                url,
                categoryId,
                seriesList,
                mediaFallbackParserHost());
    }

    private CatalogueCacheCoordinator.Host catalogueCacheHost() {
        return new CatalogueCacheCoordinator.Host() {

            public SQLiteDatabase writableDatabase() {
                return getCatalogueDbHelper()
                        .getWritableDatabase();
            }

            public String providerKey() {
                return getCatalogueProviderKey();
            }

            public void upsertMovie(
                    SQLiteDatabase db,
                    String providerKey,
                    MovieItem movie) {

                upsertMovieCatalogue(
                        db,
                        providerKey,
                        movie,
                        false);
            }

            public void upsertSeries(
                    SQLiteDatabase db,
                    String providerKey,
                    SeriesItem series) {

                upsertSeriesCatalogue(
                        db,
                        providerKey,
                        series);
            }

            public void enrichVisible(
                    String mediaType,
                    ArrayList<MovieItem> movies,
                    ArrayList<SeriesItem> series) {

                enrichVisibleCategoryFromBackend(
                        mediaType,
                        movies,
                        series);
            }
        };
    }

    private void cacheDirectCategoryAsync(
            String mediaType,
            ArrayList<MovieItem> movies,
            ArrayList<SeriesItem> seriesList) {

        CatalogueCacheCoordinator.cacheAsync(
                mediaType,
                movies,
                seriesList,
                catalogueCacheHost());
    }

    private CatalogueDbHelper getCatalogueDbHelper() {
        if (catalogueDbHelper == null) {
            catalogueDbHelper =
                    new CatalogueDbHelper(
                            getApplicationContext());
        }

        return catalogueDbHelper;
    }

    private String getCatalogueProviderKey() {
        android.content.SharedPreferences prefs =
                playlistPrefs();

        String server =
                normalizeXtreamServer(
                        prefs.getString(
                                "xtream_server",
                                ""));

        String username =
                safe(
                        prefs.getString(
                                "xtream_username",
                                ""));

        return Integer.toHexString(
                (server
                        + "|"
                        + username)
                        .hashCode());
    }

    private CatalogueQuerySupport.Host catalogueQueryHost() {
        return new CatalogueQuerySupport.Host() {

            public SQLiteDatabase readableDatabase() {
                return getCatalogueDbHelper()
                        .getReadableDatabase();
            }

            public String providerKey() {
                return getCatalogueProviderKey();
            }

            public String normalize(
                    String value) {

                return normalizeSearchText(
                        value);
            }
        };
    }

    private Cursor queryCatalogueCursor(
            String mediaType,
            String categoryId,
            String query) {

        return CatalogueQuerySupport.query(
                mediaType,
                categoryId,
                query,
                catalogueQueryHost());
    }

    private void renderProviderDirectPosterPane(
            String mediaType,
            String categoryName,
            ArrayList<MovieItem> movies,
            ArrayList<SeriesItem> seriesList,
            LinearLayout rightPane) {

        rightPane.removeAllViews();

        closeActiveMediaAdapter();

        activeMediaBrowseType =
                mediaType;

        LinearLayout header =
                new LinearLayout(this);

        header.setOrientation(
                LinearLayout.HORIZONTAL);

        header.setGravity(
                Gravity.CENTER_VERTICAL);

        TextView title =
                new TextView(this);

        title.setText(
                categoryName);

        title.setTextColor(
                Color.WHITE);

        title.setTextSize(
                18);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        header.addView(
                title,
                new LinearLayout.LayoutParams(
                        0,
                        dp(40),
                        1f));

        TextView count =
                new TextView(this);

        count.setTextColor(
                SILVER);

        count.setTextSize(
                12);

        count.setGravity(
                Gravity.CENTER_VERTICAL
                        | Gravity.END);

        header.addView(
                count,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        dp(40)));

        rightPane.addView(
                header);

        // Wide focus-driven hero. The provider cover is used as a fallback
        // until a verified landscape backdrop URL is available.
        final FrameLayout heroFrame = new FrameLayout(this);
        heroFrame.setBackgroundColor(Color.rgb(18, 18, 21));
        heroFrame.setClipToOutline(true);
        android.graphics.drawable.GradientDrawable heroShape =
                new android.graphics.drawable.GradientDrawable();
        heroShape.setColor(Color.rgb(18, 18, 21));
        heroShape.setCornerRadius(dp(12));
        heroFrame.setBackground(heroShape);

        final ImageView focusArtwork = new ImageView(this);
        focusArtwork.setScaleType(ImageView.ScaleType.CENTER_CROP);
        focusArtwork.setAlpha(0.55f);
        heroFrame.addView(focusArtwork, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        View heroScrim = new View(this);
        heroScrim.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { Color.rgb(18, 18, 21), 0xDD121215, 0x44121215 }));
        heroFrame.addView(heroScrim, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        final LinearLayout focusCopy = new LinearLayout(this);
        focusCopy.setOrientation(LinearLayout.VERTICAL);
        focusCopy.setGravity(Gravity.CENTER_VERTICAL);
        focusCopy.setPadding(dp(22), dp(8), dp(14), dp(8));
        heroFrame.addView(focusCopy, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        final TextView focusedTitle = new TextView(this);
        focusedTitle.setTextColor(Color.WHITE);
        focusedTitle.setTextSize(24);
        focusedTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        focusedTitle.setMaxLines(2);
        focusedTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        focusedTitle.setText("Select a title");
        focusCopy.addView(focusedTitle);

        final TextView focusPosition = new TextView(this);
        focusPosition.setTextColor(GOLD);
        focusPosition.setTextSize(12);
        focusPosition.setText("Use your remote to browse");
        focusCopy.addView(focusPosition);
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(158));
        heroParams.setMargins(0, 0, 0, dp(8));
        rightPane.addView(heroFrame, heroParams);
        final Handler heroHandler = new Handler(Looper.getMainLooper());
        final Runnable[] pendingHeroLoad = new Runnable[1];
        // Cancel queued loads when this browser is detached from the window.
        heroFrame.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { }
            @Override public void onViewDetachedFromWindow(View v) {
                if (pendingHeroLoad[0] != null) {
                    heroHandler.removeCallbacks(pendingHeroLoad[0]);
                    pendingHeroLoad[0] = null;
                }
                focusArtwork.setTag("");
            }
        });

        GridView grid =
                new GridView(this);

        grid.setNumColumns(
                getMediaPosterColumns());

        grid.setStretchMode(
                GridView.STRETCH_COLUMN_WIDTH);

        grid.setHorizontalSpacing(
                dp(7));

        grid.setVerticalSpacing(
                dp(8));

        grid.setGravity(
                Gravity.CENTER);

        grid.setClipToPadding(
                false);

        grid.setPadding(
                0,
                0,
                0,
                dp(8));

        grid.setSelector(
                makeBackground(
                        Color.TRANSPARENT,
                        GOLD,
                        10));

        grid.setDrawSelectorOnTop(
                true);

        grid.setFocusable(
                true);

        grid.setFocusableInTouchMode(
                false);

        MediaGridAdapter adapter =
                new MediaGridAdapter(
                        mediaType,
                        movies,
                        seriesList,
                        "",
                        count);

        grid.setAdapter(
                adapter);
        attachStableMediaGridSelection(grid, adapter);

        grid.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent,
                                       View view, int position, long id) {
                if (position < 0 || position >= adapter.getCount()) {
                    focusedTitle.setText("Select a title");
                    focusPosition.setText("");
                    return;
                }
                Object selected = adapter.getItem(position);
                String name = selected instanceof MovieItem
                        ? ((MovieItem) selected).name
                        : selected instanceof SeriesItem
                        ? ((SeriesItem) selected).name : "";
                if (pendingHeroLoad[0] != null) {
                    heroHandler.removeCallbacks(pendingHeroLoad[0]);
                    pendingHeroLoad[0] = null;
                }
                final String artworkUrl = selected instanceof MovieItem
                        ? safe(((MovieItem) selected).icon).trim()
                        : selected instanceof SeriesItem
                        ? safe(((SeriesItem) selected).cover).trim() : "";
                // Some TV remotes fire repeated selection events for the same
                // item. Keep the displayed image rather than flashing blank.
                Object currentArtworkTag = focusArtwork.getTag();
                boolean artworkUnchanged = !artworkUrl.isEmpty()
                        && artworkUrl.equals(currentArtworkTag);
                if (!artworkUnchanged) {
                    // Invalidates older asynchronous downloads immediately.
                    focusArtwork.setTag("");
                    focusArtwork.setImageDrawable(null);
                    if (artworkUrl.startsWith("https://")
                            || artworkUrl.startsWith("http://")) {
                        pendingHeroLoad[0] = () -> {
                            pendingHeroLoad[0] = null;
                            if (heroFrame.isAttachedToWindow()
                                    && rightPane.isAttachedToWindow()) {
                                loadPosterImage(focusArtwork, artworkUrl);
                            }
                        };
                        heroHandler.postDelayed(pendingHeroLoad[0], 220);
                    }
                }
                focusedTitle.setText(name == null || name.length() == 0
                        ? "Untitled" : name);
                focusPosition.setText((position + 1) + " / " + adapter.getCount()
                        + "  •  " + ("MOVIES".equals(mediaType) ? "MOVIE" : "SERIES"));
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
                if (pendingHeroLoad[0] != null) {
                    heroHandler.removeCallbacks(pendingHeroLoad[0]);
                }
                focusArtwork.setTag("");
                focusArtwork.setImageDrawable(null);
                focusedTitle.setText("Select a title");
                focusPosition.setText("Use your remote to browse");
            }
        });

        grid.setOnItemClickListener(
                (parent,
                 view,
                 position,
                 id) -> {

                    // Provider lists can refresh while a remote click is queued.
                    // Ignore stale positions rather than opening the wrong title.
                    if (position < 0 || position >= adapter.getCount()) {
                        return;
                    }
                    Object item =
                            adapter.getItem(
                                    position);
                    if (item == null) {
                        return;
                    }

                    if (item instanceof MovieItem) {
                        showMovieDetails(
                                (MovieItem) item);

                    } else if (item instanceof SeriesItem) {
                        showSeriesDetails(
                                (SeriesItem) item);
                    }
                });

        rightPane.addView(
                grid,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        activeMediaGridView =
                grid;

        activeMediaAdapter =
                adapter;

        activeMediaBrowseCount =
                count;

        count.setText(
                adapter.getCount()
                        + ("MOVIES".equals(
                        mediaType)
                        ? " movies"
                        : " series"));

        grid.post(
                () -> {
                    if (grid.getCount() > 0) {
                        grid.setSelection(
                                0);
                    }
                });
    }


    private void closeActiveMediaAdapter() {
        if (activeMediaAdapter != null) {
            activeMediaAdapter.close();
            activeMediaAdapter =
                    null;
        }

        activeMediaGridView =
                null;
    }


    private void ensureCatalogueSyncAsync(
            String mediaType,
            boolean force) {

        // Legacy backend sync disabled.
        // Catalogue imports now run manually from Settings.
    }


    private void ensureBackendCastIndexAsync(
            String mediaType,
            
    boolean force) {
        if (localRebuildRunning) return;


        final boolean movies =
                "MOVIES".equals(
                        mediaType);

        if (movies
                ? backendMovieIndexRunning
                : backendSeriesIndexRunning) {
            return;
        }

        android.content.SharedPreferences prefs =
                playlistPrefs();

        String key =
                movies
                        ? "backend_cast_sync_movies_v0534_capture"
                        : "backend_cast_sync_series_v0534_capture";

        long last =
                prefs.getLong(
                        key,
                        0L);

        if (!force
                && last > 0L
                && System.currentTimeMillis() - last
                < CAST_BACKEND_SYNC_MAX_AGE_MS) {
            return;
        }

        if (movies) {
            backendMovieIndexRunning =
                    true;
        } else {
            backendSeriesIndexRunning =
                    true;
        }

        new Thread(() -> {
            boolean completed =
                    false;

            try {
                runBackendCastIndex(
                        mediaType);

                completed =
                        true;

            } catch (Exception ignored) {
                // Enrichment is optional. Provider-direct browsing remains usable.

            } finally {
                if (completed) {
                    prefs.edit()
                            .putLong(
                                    key,
                                    System.currentTimeMillis())
                            .apply();
                }

                if (movies) {
                    backendMovieIndexRunning =
                            false;
                } else {
                    backendSeriesIndexRunning =
                            false;
                }
            }
        }).start();
    }


    private void runLocalCatalogueImport(
            String mediaType,
            String playlistId,
            String providerKey,
            
    String requestUrl,
            long generation) throws Exception {

        if (generation <= 0L) {
            throw new IllegalArgumentException(
                    "Invalid import generation");
        }


        if (!"MOVIES".equals(mediaType)
                && !"SERIES".equals(mediaType)) {
            throw new IllegalArgumentException("Invalid media type");
        }

        if (playlistId == null || providerKey == null
                || requestUrl == null || requestUrl.isEmpty()
                || !playlistId.equals(activePlaylistId)
                || !getPlaylistProfileIds().contains(playlistId)) {
            throw new IllegalStateException("Invalid import context");
        }

        final boolean movies = "MOVIES".equals(mediaType);
        final String dbName = CATALOGUE_DB_PREFIX
                + sanitizePlaylistId(playlistId) + ".db";

        final CatalogueDbHelper helper =
                new CatalogueDbHelper(getApplicationContext(), dbName);

        final long[] stats = new long[5];
        // Seen, stored, dated, raw JSON, invalid IDs

        try {
            final SQLiteDatabase db = helper.getWritableDatabase();

            db.beginTransaction();
            try {
                streamJsonArray(requestUrl, reader -> {
                    if (!playlistId.equals(activePlaylistId)) {
                        throw new IllegalStateException(
                                "Playlist changed during import");
                    }

                    
                    if (localRebuildCancel) {
                        throw new InterruptedException("Import cancelled");
                    }
                    if (!providerKey.equals(getCatalogueProviderKey())) {
                        throw new IllegalStateException("Provider changed");
                    }
                    stats[0]++;

                    if (movies) {
                        MovieItem movie =
                                readMovieItemFromStream(reader);

                        if (safe(movie.streamId).isEmpty()
                                || "null".equals(movie.streamId)) {
                            stats[4]++;
                            return;
                        }

                        if (safe(movie.rawJson).isEmpty()) {
                            throw new IllegalStateException(
                                    "Missing movie raw JSON");
                        }

                        movie.importGeneration = generation;

                        upsertMovieCatalogue(
                                db, providerKey, movie,
                                !safe(movie.cast).isEmpty());

                        if (movie.addedAt > 0L) stats[2]++;
                        stats[3]++;

                    } else {
                        SeriesItem series =
                                readSeriesItemFromStream(reader);

                        if (safe(series.seriesId).isEmpty()
                                || "null".equals(series.seriesId)) {
                            stats[4]++;
                            return;
                        }

                        if (safe(series.rawJson).isEmpty()) {
                            throw new IllegalStateException(
                                    "Missing series raw JSON");
                        }

                        series.importGeneration = generation;

                        upsertSeriesCatalogue(db, providerKey, series);

                        if (series.updatedAt > 0L) stats[2]++;
                        stats[3]++;
                    }

                    stats[1]++;

                    if (stats[1] % 250L == 0L) {
                CatalogueRebuildJournal.progress(
                        db, providerKey, generation,
                        movies ? "MOVIES" : "SERIES",
                        movies ? stats[1] : -1L,
                        movies ? -1L : stats[1]);
                        db.setTransactionSuccessful();
                        
    db.endTransaction();
                        
    final long savedCount = stats[1];
    updateLocalRebuildStatus(mediaType + ": " + savedCount + " saved");
    db.beginTransaction();

                    }
                });

                CatalogueRebuildJournal.progress(
                        db, providerKey, generation,
                        movies ? "MOVIES" : "SERIES",
                        movies ? stats[1] : -1L,
                        movies ? -1L : stats[1]);
                db.setTransactionSuccessful();

            } finally {
                if (db.inTransaction()) {
                    db.endTransaction();
                }
            }

            android.util.Log.i("PP_CATALOGUE",
                    mediaType + " seen=" + stats[0]
                    + " stored=" + stats[1]
                    + " dated=" + stats[2]
                    + " raw=" + stats[3]
                    + " invalid=" + stats[4]);

        } finally {
            helper.close();
        }
    }

    private void runBackendCastIndex(
            String mediaType)
            throws Exception {

        String action =
                "MOVIES".equals(
                        mediaType)
                        ? "get_vod_streams"
                        : "get_series";

        String url =
                buildXtreamApiUrl(
                        action,
                        null,
                        null);

        final String providerKey =
                getCatalogueProviderKey();

        final SQLiteDatabase db =
                getCatalogueDbHelper()
                        .getWritableDatabase();

        final HashSet<String> hiddenIds =
                getHiddenEditorIds(
                        mediaType);

        final HashSet<String> currentIds =
                new HashSet<String>();

        // Phase 1: stream the provider catalogue quickly into the secondary
        // local cache. No backend HTTP calls happen while the provider's
        // response stream is open, which prevents long provider timeouts.
        streamJsonArray(
                url,
                reader -> {
                    if ("MOVIES".equals(
                            mediaType)) {

                        MovieItem movie =
                                readMovieItemFromStream(
                                        reader);

                        if (safe(movie.streamId).isEmpty()
                                || "null".equals(
                                movie.streamId)
                                || hiddenIds.contains(
                                movie.categoryId)) {
                            return;
                        }

                        currentIds.add(
                                movie.streamId);

                        upsertMovieCatalogue(
                                db,
                                providerKey,
                                movie,
                                !safe(movie.cast).isEmpty());

                    } else {
                        SeriesItem series =
                                readSeriesItemFromStream(
                                        reader);

                        if (safe(series.seriesId).isEmpty()
                                || "null".equals(
                                series.seriesId)
                                || hiddenIds.contains(
                                series.categoryId)) {
                            return;
                        }

                        currentIds.add(
                                series.seriesId);

                        upsertSeriesCatalogue(
                                db,
                                providerKey,
                                series);
                    }
                });

        // Phase 2: with the provider stream closed, feed the shared backend
        // from SQLite in very small batches. This can run for a long time
        // without blocking or destabilising Movies/Series browsing.
        Cursor cursor =
                null;

        try {
            if ("MOVIES".equals(
                    mediaType)) {

                cursor =
                        db.query(
                                "catalogue_movies",
                                new String[]{
                                        "stream_id",
                                        "name",
                                        "year",
                                        "cast",
                                        "icon",
                                        "plot"
                                },
                                "provider_key=?",
                                new String[]{
                                        providerKey
                                },
                                null,
                                null,
                                null);

            } else {
                cursor =
                        db.query(
                                "catalogue_series",
                                new String[]{
                                        "series_id",
                                        "name",
                                        "year",
                                        "cast",
                                        "cover",
                                        "plot"
                                },
                                "provider_key=?",
                                new String[]{
                                        providerKey
                                },
                                null,
                                null,
                                null);
            }

            JSONArray batch =
                    new JSONArray();

            while (cursor.moveToNext()) {
                String id =
                        safe(
                                cursor.getString(
                                        0));

                if (id.isEmpty()
                        || !currentIds.contains(
                        id)) {
                    continue;
                }

                JSONObject item =
                        new JSONObject();

                item.put(
                        "client_id",
                        id);
                item.put(
                        "type",
                        "MOVIES".equals(
                                mediaType)
                                ? "movie"
                                : "series");
                item.put(
                        "title",
                        safe(
                                cursor.getString(
                                        1)));
                item.put(
                        "year",
                        safe(
                                cursor.getString(
                                        2)));
                item.put(
                        "cast",
                        safe(
                                cursor.getString(
                                        3)));
                item.put(
                        "overview",
                        safe(
                                cursor.getString(
                                        5)));

                batch.put(
                        item);

                if (batch.length()
                        >= CAST_BACKEND_BATCH_SIZE) {

                    JSONObject response =
                            postCastBackendBatch(
                                    batch);

                    applyBackendEnrichmentResponse(
                            mediaType,
                            response);

                    batch =
                            new JSONArray();

                    try {
                        Thread.sleep(
                                120L);
                    } catch (Exception ignored) {
                    }
                }
            }

            if (batch.length() > 0) {
                JSONObject response =
                        postCastBackendBatch(
                                batch);

                applyBackendEnrichmentResponse(
                        mediaType,
                        response);
            }

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }


    private JSONObject makeBackendMoviePayload(
            MovieItem movie)
            throws Exception {

        JSONObject item =
                new JSONObject();

        item.put(
                "client_id",
                safe(movie.streamId));
        item.put(
                "type",
                "movie");
        item.put(
                "title",
                safe(movie.name));
        item.put(
                "year",
                safe(movie.year));
        item.put(
                "cast",
                safe(movie.cast));
        item.put(
                "overview",
                safe(movie.plot));

        return item;
    }


    private JSONObject makeBackendSeriesPayload(
            SeriesItem series)
            throws Exception {

        JSONObject item =
                new JSONObject();

        item.put(
                "client_id",
                safe(series.seriesId));
        item.put(
                "type",
                "series");
        item.put(
                "title",
                safe(series.name));
        item.put(
                "year",
                safe(series.year));
        item.put(
                "cast",
                safe(series.cast));
        item.put(
                "overview",
                safe(series.plot));

        return item;
    }


    private JSONObject postCastBackendBatch(
            JSONArray items)
            throws Exception {

        return CatalogueBackendTransport.postEnrichmentBatch(
                CAST_BACKEND_BASE_URL,
                CAST_BACKEND_PUBLISHABLE_KEY,
                getCatalogueProviderKey(),
                items);
    }

    private void applyBackendEnrichmentResponse(
            String mediaType,
            JSONObject response) {

        if (response == null) {
            return;
        }

        JSONArray items =
                response.optJSONArray(
                        "items");

        if (items == null) {
            return;
        }

        try {
            SQLiteDatabase db =
                    getCatalogueDbHelper()
                            .getWritableDatabase();

            String providerKey =
                    getCatalogueProviderKey();

            for (int i = 0;
                 i < items.length();
                 i++) {

                JSONObject item =
                        items.optJSONObject(
                                i);

                if (item == null
                        || !"done".equals(
                        item.optString(
                                "status",
                                ""))) {
                    continue;
                }

                String clientId =
                        item.optString(
                                "client_id",
                                "");

                if (clientId.isEmpty()) {
                    continue;
                }

                JSONArray castArray =
                        item.optJSONArray(
                                "cast");

                StringBuilder cast =
                        new StringBuilder();

                if (castArray != null) {
                    for (int c = 0;
                         c < castArray.length();
                         c++) {

                        JSONObject person =
                                castArray.optJSONObject(
                                        c);

                        String name =
                                person == null
                                        ? ""
                                        : person.optString(
                                        "name",
                                        "");

                        if (name.trim().isEmpty()) {
                            continue;
                        }

                        if (cast.length() > 0) {
                            cast.append(
                                    ", ");
                        }

                        cast.append(
                                name.trim());
                    }
                }

                if (cast.length() == 0) {
                    continue;
                }

                ContentValues values =
                        new ContentValues();

                values.put(
                        "cast",
                        cast.toString());
                values.put(
                        "normalized_cast",
                        normalizeSearchText(
                                cast.toString()));

                String overview =
                        item.optString(
                                "overview",
                                "");

                if (!overview.isEmpty()) {
                    values.put(
                            "plot",
                            overview);
                }

                if ("MOVIES".equals(
                        mediaType)) {

                    values.put(
                            "cast_scanned",
                            1);

                    db.update(
                            "catalogue_movies",
                            values,
                            "provider_key=? AND stream_id=?",
                            new String[]{
                                    providerKey,
                                    clientId
                            });

                } else {
                    db.update(
                            "catalogue_series",
                            values,
                            "provider_key=? AND series_id=?",
                            new String[]{
                                    providerKey,
                                    clientId
                            });
                }
            }

        } catch (Exception ignored) {
            // Local cache enrichment is optional.
        }
    }


    private void pullCompletedCastCacheAsync(boolean force) {
        if (!hasXtreamLogin()) {
            return;
        }

        android.content.SharedPreferences prefs =
                playlistPrefs();
        long now = System.currentTimeMillis();
        long last = prefs.getLong("local_cast_cache_pull_last", 0L);

        if (!force && now - last < CAST_LOCAL_PULL_MAX_AGE_MS) {
            return;
        }

        prefs.edit()
                .putLong("local_cast_cache_pull_last", now)
                .apply();

        new Thread(() -> {
            try {
                pullCompletedCastCacheForType("MOVIES");
                pullCompletedCastCacheForType("SERIES");
            } catch (Exception ignored) {
            }
        }, "premium-cast-cache-pull").start();
    }

    private void pullCompletedCastCacheForType(String mediaType)
            throws Exception {

        SQLiteDatabase db =
                getCatalogueDbHelper().getReadableDatabase();
        String providerKey = getCatalogueProviderKey();
        Cursor cursor = null;

        try {
            if ("MOVIES".equals(mediaType)) {
                cursor = db.query(
                        "catalogue_movies",
                        new String[]{"stream_id", "name", "year", "cast", "plot"},
                        "provider_key=? AND (cast IS NULL OR cast='' OR normalized_cast IS NULL OR normalized_cast='')",
                        new String[]{providerKey},
                        null,
                        null,
                        "name COLLATE NOCASE ASC",
                        "2500");
            } else {
                cursor = db.query(
                        "catalogue_series",
                        new String[]{"series_id", "name", "year", "cast", "plot"},
                        "provider_key=? AND (cast IS NULL OR cast='' OR normalized_cast IS NULL OR normalized_cast='')",
                        new String[]{providerKey},
                        null,
                        null,
                        "name COLLATE NOCASE ASC",
                        "2500");
            }

            JSONArray batch = new JSONArray();

            while (cursor.moveToNext()) {
                JSONObject item = new JSONObject();
                item.put("client_id", safe(cursor.getString(0)));
                item.put("type", "MOVIES".equals(mediaType) ? "movie" : "series");
                item.put("title", safe(cursor.getString(1)));
                item.put("year", safe(cursor.getString(2)));
                item.put("cast", safe(cursor.getString(3)));
                item.put("overview", safe(cursor.getString(4)));
                batch.put(item);

                if (batch.length() >= CAST_BACKEND_CACHE_PULL_BATCH_SIZE) {
                    JSONObject response = postCastBackendBatch(batch);
                    applyBackendEnrichmentResponse(mediaType, response);
                    batch = new JSONArray();
                }
            }

            if (batch.length() > 0) {
                JSONObject response = postCastBackendBatch(batch);
                applyBackendEnrichmentResponse(mediaType, response);
            }

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private CatalogueEnrichmentCoordinator.Host catalogueEnrichmentHost() {
        return new CatalogueEnrichmentCoordinator.Host() {

            public MovieItem copyMovie(
                    MovieItem movie) {

                return copyMovieItem(
                        movie);
            }

            public SeriesItem copySeries(
                    SeriesItem series) {

                return copySeriesItem(
                        series);
            }

            public JSONObject moviePayload(
                    MovieItem movie)
                    throws Exception {

                return makeBackendMoviePayload(
                        movie);
            }

            public JSONObject seriesPayload(
                    SeriesItem series)
                    throws Exception {

                return makeBackendSeriesPayload(
                        series);
            }

            public JSONObject postBatch(
                    JSONArray batch)
                    throws Exception {

                return postCastBackendBatch(
                        batch);
            }

            public void applyResponse(
                    String mediaType,
                    JSONObject response) {

                applyBackendEnrichmentResponse(
                        mediaType,
                        response);
            }
        };
    }

    private void enrichVisibleCategoryFromBackend(
            String mediaType,
            ArrayList<MovieItem> movies,
            ArrayList<SeriesItem> seriesList) {

        CatalogueEnrichmentCoordinator.enrichAsync(
                mediaType,
                movies,
                seriesList,
                CAST_BACKEND_BATCH_SIZE,
                catalogueEnrichmentHost());
    }

    private CatalogueWriteSupport.Host catalogueWriteHost() {
        return new CatalogueWriteSupport.Host() {

            public String safe(String value) {
                return MainActivity.this.safe(value);
            }

            public String normalize(
                    String value) {

                return normalizeSearchText(
                        value);
            }

            public String sanitizeExtension(
                    String extension) {

                return sanitizeMediaExtension(
                        extension);
            }
        };
    }

    private void upsertMovieCatalogue(
            SQLiteDatabase db,
            String providerKey,
            MovieItem movie,
            boolean castScanned) {

        CatalogueWriteSupport.upsertMovie(
                db,
                providerKey,
                movie,
                castScanned,
                catalogueWriteHost());
    }

    private void upsertMovieIntoCatalogue(
            MovieItem movie,
            boolean castScanned) {

        if (movie == null
                || safe(movie.streamId)
                .isEmpty()) {
            return;
        }

        final MovieItem copy =
                copyMovieItem(
                        movie);

        catalogueExecutor.execute(() -> {
            try {
                SQLiteDatabase db =
                        getCatalogueDbHelper()
                                .getWritableDatabase();

                upsertMovieCatalogue(
                        db,
                        getCatalogueProviderKey(),
                        copy,
                        castScanned);

            } catch (Exception ignored) {
            }
        });
    }


    private void upsertSeriesCatalogue(
            SQLiteDatabase db,
            String providerKey,
            SeriesItem series) {

        CatalogueWriteSupport.upsertSeries(
                db,
                providerKey,
                series,
                catalogueWriteHost());
    }

    private void upsertSeriesIntoCatalogue(
            SeriesItem series) {

        if (series == null
                || safe(series.seriesId)
                .isEmpty()) {
            return;
        }

        final SeriesItem copy =
                copySeriesItem(
                        series);

        catalogueExecutor.execute(() -> {
            try {
                SQLiteDatabase db =
                        getCatalogueDbHelper()
                                .getWritableDatabase();

                upsertSeriesCatalogue(
                        db,
                        getCatalogueProviderKey(),
                        copy);

            } catch (Exception ignored) {
            }
        });
    }



    private MediaItemMapper.CursorHost mediaItemCursorHost() {
        return new MediaItemMapper.CursorHost() {

            public String sanitizeExtension(
                    String extension) {

                return sanitizeMediaExtension(
                        extension);
            }
        };
    }

    private MovieItem copyMovieItem(
            MovieItem source) {

        return MediaItemMapper.copyMovie(
                source);
    }

    private SeriesItem copySeriesItem(
            SeriesItem source) {

        return MediaItemMapper.copySeries(
                source);
    }

    private SeriesItem readSeriesItemFromStream(
            JsonReader reader)
            throws Exception {

        String rawJson = ProviderRawJson.capture(reader);
        reader = new JsonReader(new java.io.StringReader(rawJson));
        SeriesItem series =
                new SeriesItem();
        series.rawJson = rawJson;

        reader.beginObject();

        while (reader.hasNext()) {
            String name =
                    reader.nextName();

            if (name.equals(
                    "name")) {

                series.name =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "category_id")) {

                series.categoryId =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "series_id")) {

                series.seriesId =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "rating")) {

                series.rating =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "year")
                    || name.equals(
                    "releaseDate")) {

                series.year =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "cover")
                    || name.equals(
                    "cover_big")
                    || name.equals(
                    "stream_icon")) {

                series.cover =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "plot")
                    || name.equals(
                    "description")) {

                series.plot =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "cast")
                    || name.equals(
                    "actors")) {

                series.cast =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "director")) {

                series.director =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "genre")) {

                series.genre =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "youtube_trailer")) {

                series.trailer =
                        readJsonString(
                                reader);

            } else if (name.equals("added")) {
                series.addedAt = parseAddedTimestamp(readJsonString(reader));
            } else if (name.equals("last_modified")) {
                series.updatedAt = parseAddedTimestamp(readJsonString(reader));
            } else {
                reader.skipValue();
            }
        }

        reader.endObject();

        return series;
    }

    private void renderMoviePosterPane(
            String categoryName,
            ArrayList<MovieItem> movies,
            LinearLayout rightPane) {

        rightPane.removeAllViews();

        activeMediaBrowseType =
                "MOVIES";

        activeBrowseMovies.clear();
        activeBrowseMovies.addAll(
                movies);

        activeBrowseSeries.clear();

        LinearLayout header =
                new LinearLayout(this);

        header.setOrientation(
                LinearLayout.HORIZONTAL);

        header.setGravity(
                Gravity.CENTER_VERTICAL);

        TextView title =
                new TextView(this);

        title.setText(
                categoryName);

        title.setTextColor(
                Color.WHITE);

        title.setTextSize(
                18);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        header.addView(
                title,
                new LinearLayout.LayoutParams(
                        0,
                        dp(40),
                        1f));

        TextView count =
                new TextView(this);

        count.setText(
                movies.size()
                        + " movies");

        count.setTextColor(
                SILVER);

        count.setTextSize(
                12);

        count.setGravity(
                Gravity.CENTER_VERTICAL
                        | Gravity.END);

        header.addView(
                count,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        dp(40)));

        rightPane.addView(
                header);

        ScrollView posterScroll =
                new ScrollView(this);

        posterScroll.setFillViewport(
                true);

        GridLayout grid =
                new GridLayout(this);

        grid.setColumnCount(
                getMediaPosterColumns());

        grid.setAlignmentMode(
                GridLayout.ALIGN_BOUNDS);

        grid.setUseDefaultMargins(
                false);

        posterScroll.addView(
                grid,
                new ScrollView.LayoutParams(
                        ScrollView.LayoutParams.MATCH_PARENT,
                        ScrollView.LayoutParams.WRAP_CONTENT));

        rightPane.addView(
                posterScroll,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        activeMediaBrowseGrid =
                grid;

        activeMediaBrowseCount =
                count;

        renderMoviePosterGrid(
                grid,
                movies,
                "",
                count);
    }


    private void renderSeriesPosterPane(
            String categoryName,
            ArrayList<SeriesItem> seriesList,
            LinearLayout rightPane) {

        rightPane.removeAllViews();

        activeMediaBrowseType =
                "SERIES";

        activeBrowseSeries.clear();
        activeBrowseSeries.addAll(
                seriesList);

        activeBrowseMovies.clear();

        LinearLayout header =
                new LinearLayout(this);

        header.setOrientation(
                LinearLayout.HORIZONTAL);

        header.setGravity(
                Gravity.CENTER_VERTICAL);

        TextView title =
                new TextView(this);

        title.setText(
                categoryName);

        title.setTextColor(
                Color.WHITE);

        title.setTextSize(
                18);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        header.addView(
                title,
                new LinearLayout.LayoutParams(
                        0,
                        dp(40),
                        1f));

        TextView count =
                new TextView(this);

        count.setText(
                seriesList.size()
                        + " series");

        count.setTextColor(
                SILVER);

        count.setTextSize(
                12);

        count.setGravity(
                Gravity.CENTER_VERTICAL
                        | Gravity.END);

        header.addView(
                count,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        dp(40)));

        rightPane.addView(
                header);

        ScrollView posterScroll =
                new ScrollView(this);

        posterScroll.setFillViewport(
                true);

        GridLayout grid =
                new GridLayout(this);

        grid.setColumnCount(
                getMediaPosterColumns());

        grid.setAlignmentMode(
                GridLayout.ALIGN_BOUNDS);

        grid.setUseDefaultMargins(
                false);

        posterScroll.addView(
                grid,
                new ScrollView.LayoutParams(
                        ScrollView.LayoutParams.MATCH_PARENT,
                        ScrollView.LayoutParams.WRAP_CONTENT));

        rightPane.addView(
                posterScroll,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        activeMediaBrowseGrid =
                grid;

        activeMediaBrowseCount =
                count;

        renderSeriesPosterGrid(
                grid,
                seriesList,
                "",
                count);
    }


    private MediaCollectionSupport.Host mediaCollectionHost() {
        return new MediaCollectionSupport.Host() {

            public String safe(String value) {
                return MainActivity.this.safe(value);
            }

            public String sanitizeExtension(
                    String extension) {

                return sanitizeMediaExtension(
                        extension);
            }
        };
    }

    private void renderContinueWatchingCategory(
            String mediaType,
            LinearLayout rightPane) {

        ArrayList<ResumeHomeItem> recent =
                getRecentResumeItems();

        if ("MOVIES".equals(mediaType)) {

            renderMoviePosterPane(
                    "CONTINUE WATCHING",
                    MediaCollectionSupport.recentMovies(
                            recent,
                            mediaCollectionHost()),
                    rightPane);

        } else {

            renderSeriesPosterPane(
                    "CONTINUE WATCHING",
                    MediaCollectionSupport.recentSeries(
                            recent,
                            mediaCollectionHost()),
                    rightPane);
        }
    }

    private android.content.SharedPreferences mediaFavouritePrefs() {
        return getSharedPreferences(
                "premium_media_favourites_"
                        + sanitizePlaylistId(
                                activePlaylistId),
                MODE_PRIVATE);
    }

    private boolean isMovieFavourite(
            String id) {

        return MediaCollectionSupport.isMovieFavourite(
                mediaFavouritePrefs(),
                id,
                mediaCollectionHost());
    }

    private boolean isSeriesFavourite(
            String id) {

        return MediaCollectionSupport.isSeriesFavourite(
                mediaFavouritePrefs(),
                id,
                mediaCollectionHost());
    }

    private void toggleMovieFavourite(
            MovieItem movie) {

        MediaCollectionSupport.toggleMovieFavourite(
                mediaFavouritePrefs(),
                movie,
                mediaCollectionHost());
    }

    private void toggleSeriesFavourite(
            SeriesItem series) {

        MediaCollectionSupport.toggleSeriesFavourite(
                mediaFavouritePrefs(),
                series,
                mediaCollectionHost());
    }

    private void renderMediaFavouritesCategory(
            String mediaType,
            LinearLayout rightPane) {

        Map<String, ?> all =
                mediaFavouritePrefs()
                        .getAll();

        if ("MOVIES".equals(mediaType)) {

            renderMoviePosterPane(
                    "FAVOURITES",
                    MediaCollectionSupport.favouriteMovies(
                            all),
                    rightPane);

        } else {

            renderSeriesPosterPane(
                    "FAVOURITES",
                    MediaCollectionSupport.favouriteSeries(
                            all),
                    rightPane);
        }
    }

    private int getMediaPosterColumns() {
        int width =
                getResources()
                        .getDisplayMetrics()
                        .widthPixels;

        if (width >= 3000) {
            return 8;
        }

        if (width >= 2400) {
            return 7;
        }

        if (width >= 1800) {
            return 6;
        }

        if (width >= 1350) {
            return 5;
        }

        if (width >= 1000) {
            return 4;
        }

        return 3;
    }


    private int getMediaPosterCardWidth() {
        int screenWidth =
                getResources()
                        .getDisplayMetrics()
                        .widthPixels;

        int columns =
                getMediaPosterColumns();

        // Right pane occupies 75% of the browser, minus margins/padding.
        int usablePosterWidth =
                (int) (
                        screenWidth
                                * 0.70f);

        int totalGaps =
                dp(7)
                        * Math.max(
                                0,
                                columns - 1);

        return Math.max(
                1,
                (usablePosterWidth
                        - totalGaps)
                        / Math.max(
                                1,
                                columns));
    }

    private int getMediaPosterCardHeight(
            int cardWidth) {

        return (int) (
                cardWidth
                        * 1.48f)
                + dp(48);
    }



    private void renderMoviePosterGrid(
            GridLayout grid,
            ArrayList<MovieItem> movies,
            String query,
            TextView countView) {

        grid.removeAllViews();

        ArrayList<MovieItem> matches =
                new ArrayList<MovieItem>();

        for (MovieItem movie : movies) {
            if (searchMatches(
                    query,
                    movie.name,
                    movie.year,
                    movie.rating,
                    movie.cast,
                    movie.genre)) {

                matches.add(
                        movie);
            }
        }

        countView.setText(
                query == null
                        || query.trim().isEmpty()
                        ? movies.size()
                        + " movies"
                        : matches.size()
                        + " matching movies");

        int limit =
                Math.min(
                        matches.size(),
                        36);

        final int columns =
                getMediaPosterColumns();

        final int estimatedWidth =
                getMediaPosterCardWidth();

        grid.setColumnCount(
                columns);

        for (int i = 0;
             i < limit;
             i++) {

            MovieItem movie =
                    matches.get(
                            i);

            LinearLayout card =
                    createPosterCard(
                            movie.name,
                            movie.icon,
                            estimatedWidth);

            card.setOnClickListener(
                    v -> showMovieDetails(
                            movie));

            int row =
                    i / columns;

            int column =
                    i % columns;

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams(
                            GridLayout.spec(
                                    row),
                            GridLayout.spec(
                                    column,
                                    1f));

            params.width =
                    0;

            params.height =
                    getMediaPosterCardHeight(
                            estimatedWidth);

            params.setGravity(
                    Gravity.FILL_HORIZONTAL);

            params.setMargins(
                    0,
                    0,
                    column == columns - 1
                            ? 0
                            : dp(7),
                    dp(8));

            grid.addView(
                    card,
                    params);
        }

        if (matches.size()
                > limit) {

            TextView more =
                    new TextView(this);

            more.setText(
                    "Showing "
                            + limit
                            + " of "
                            + matches.size()
                            + " titles. Use the search bar above to narrow the list.");

            more.setTextColor(
                    SILVER);

            more.setTextSize(
                    12);

            int row =
                    (limit
                            + columns
                            - 1)
                            / columns;

            GridLayout.LayoutParams moreParams =
                    new GridLayout.LayoutParams(
                            GridLayout.spec(
                                    row),
                            GridLayout.spec(
                                    0,
                                    columns));

            moreParams.width =
                    GridLayout.LayoutParams.MATCH_PARENT;

            moreParams.setMargins(
                    dp(6),
                    dp(10),
                    dp(6),
                    dp(14));

            grid.addView(
                    more,
                    moreParams);
        }
    }



    private void renderSeriesPosterGrid(
            GridLayout grid,
            ArrayList<SeriesItem> seriesList,
            String query,
            TextView countView) {

        grid.removeAllViews();

        ArrayList<SeriesItem> matches =
                new ArrayList<SeriesItem>();

        for (SeriesItem series : seriesList) {
            if (searchMatches(
                    query,
                    series.name,
                    series.year,
                    series.rating,
                    series.plot,
                    series.cast,
                    series.genre)) {

                matches.add(
                        series);
            }
        }

        countView.setText(
                query == null
                        || query.trim().isEmpty()
                        ? seriesList.size()
                        + " series"
                        : matches.size()
                        + " matching series");

        int limit =
                Math.min(
                        matches.size(),
                        36);

        final int columns =
                getMediaPosterColumns();

        final int estimatedWidth =
                getMediaPosterCardWidth();

        grid.setColumnCount(
                columns);

        for (int i = 0;
             i < limit;
             i++) {

            SeriesItem series =
                    matches.get(
                            i);

            LinearLayout card =
                    createPosterCard(
                            series.name,
                            series.cover,
                            estimatedWidth);

            card.setOnClickListener(
                    v -> showSeriesDetails(
                            series));

            int row =
                    i / columns;

            int column =
                    i % columns;

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams(
                            GridLayout.spec(
                                    row),
                            GridLayout.spec(
                                    column,
                                    1f));

            params.width =
                    0;

            params.height =
                    getMediaPosterCardHeight(
                            estimatedWidth);

            params.setGravity(
                    Gravity.FILL_HORIZONTAL);

            params.setMargins(
                    0,
                    0,
                    column == columns - 1
                            ? 0
                            : dp(7),
                    dp(8));

            grid.addView(
                    card,
                    params);
        }

        if (matches.size()
                > limit) {

            TextView more =
                    new TextView(this);

            more.setText(
                    "Showing "
                            + limit
                            + " of "
                            + matches.size()
                            + " titles. Use the search bar above to narrow the list.");

            more.setTextColor(
                    SILVER);

            more.setTextSize(
                    12);

            int row =
                    (limit
                            + columns
                            - 1)
                            / columns;

            GridLayout.LayoutParams moreParams =
                    new GridLayout.LayoutParams(
                            GridLayout.spec(
                                    row),
                            GridLayout.spec(
                                    0,
                                    columns));

            moreParams.width =
                    GridLayout.LayoutParams.MATCH_PARENT;

            moreParams.setMargins(
                    dp(6),
                    dp(10),
                    dp(6),
                    dp(14));

            grid.addView(
                    more,
                    moreParams);
        }
    }




    private void refreshActiveMediaBrowseSearch(
            String query) {

        if (activeMediaAdapter == null) {
            return;
        }

        activeMediaAdapter.setQuery(
                query == null
                        ? ""
                        : query);
    }


    private MediaDetailLoader.Host mediaDetailLoaderHost() {
        return new MediaDetailLoader.Host() {

            public String download(
                    String action,
                    String key,
                    String value)
                    throws Exception {

                return downloadPlaylistText(
                        buildXtreamApiUrl(
                                action,
                                key,
                                value));
            }

            public String firstNonEmpty(
                    String... values) {

                return MainActivity.this.firstNonEmpty(
                        values);
            }
        };
    }

    private void showMovieDetails(
            MovieItem movie) {

        if (movie == null) {
            return;
        }

        closeActiveMediaAdapter();

        // Open immediately using the metadata already returned by get_vod_streams.
        renderMovieDetailScreen(
                movie);

        if (movie.detailsLoaded
                || movie.detailsLoading) {
            return;
        }

        movie.detailsLoading =
                true;

        final int token =
                ++mediaDetailLoadToken;

        new Thread(() -> {
            try {
                MediaDetailLoader.loadMovie(
                        movie,
                        mediaDetailLoaderHost());

                saveMovieToCastIndex(
                        movie);

                markMovieCastScanned(
                        movie.streamId);

                upsertMovieIntoCatalogue(
                        movie,
                        true);

            } catch (Exception ignored) {
                // The fast detail page remains usable even if the provider
                // does not return extended VOD metadata.
                movie.detailsLoaded =
                        true;

            } finally {
                movie.detailsLoading =
                        false;
            }

            runOnUiThread(() -> {
                if (token
                        != mediaDetailLoadToken) {
                    return;
                }

                // Only refresh if the user is still looking at this movie.
                if ("MOVIE_DETAIL".equals(
                        selectedReturnScreen)
                        && safe(movie.streamId).equals(
                                selectedStreamId)) {

                    renderMovieDetailScreen(
                            movie);
                }
            });
        }).start();
    }


    private void renderMovieDetailScreen(
            MovieItem movie) {

        releasePlayer();
        onHomeScreen = false;

        selectedReturnScreen =
                "MOVIE_DETAIL";

        selectedStreamId =
                safe(movie.streamId);

        LinearLayout screen =
                new LinearLayout(this);

        screen.setOrientation(
                LinearLayout.VERTICAL);

        screen.setPadding(
                dp(18),
                dp(14),
                dp(18),
                dp(18));

        screen.setBackgroundColor(
                BLACK);

        TextView back =
                createBackText();

        back.setText(
                "<  MOVIES");

        back.setOnClickListener(
                v -> showMovies());

        screen.addView(
                back,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(48)));

        LinearLayout content =
                new LinearLayout(this);

        content.setOrientation(
                LinearLayout.HORIZONTAL);

        screen.addView(
                content,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        LinearLayout coverPane =
                new LinearLayout(this);

        coverPane.setOrientation(
                LinearLayout.VERTICAL);

        coverPane.setGravity(
                Gravity.TOP
                        | Gravity.CENTER_HORIZONTAL);

        ImageView cover =
                new ImageView(this);

        cover.setScaleType(
                ImageView.ScaleType.CENTER_CROP);

        cover.setBackgroundColor(
                Color.rgb(
                        28,
                        28,
                        31));

        if (!safe(movie.icon).isEmpty()) {
            loadPosterImage(
                    cover,
                    movie.icon);
        }

        coverPane.addView(
                cover,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        LinearLayout.LayoutParams coverParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0.32f);

        coverParams.setMargins(
                0,
                0,
                dp(18),
                0);

        content.addView(
                coverPane,
                coverParams);

        ScrollView infoScroll =
                new ScrollView(this);

        LinearLayout info =
                new LinearLayout(this);

        info.setOrientation(
                LinearLayout.VERTICAL);

        info.setPadding(
                dp(8),
                dp(4),
                dp(8),
                dp(8));

        infoScroll.addView(
                info);

        content.addView(
                infoScroll,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0.68f));

        TextView title =
                new TextView(this);

        title.setText(
                movie.name);

        title.setTextColor(
                Color.WHITE);

        title.setTextSize(
                30);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        info.addView(
                title);

        addMediaDetailFacts(
                info,
                movie.year,
                movie.rating,
                movie.genre,
                movie.duration);

        addClickableCastMembers(
                info,
                movie.cast);

        addMediaDetailText(
                info,
                "Director",
                movie.director);

        if (!safe(movie.plot).isEmpty()) {
            TextView plot =
                    new TextView(this);

            plot.setText(
                    movie.plot);

            plot.setTextColor(
                    SILVER);

            plot.setTextSize(
                    14);

            plot.setPadding(
                    0,
                    dp(14),
                    0,
                    dp(18));

            info.addView(
                    plot);

        } else if (!movie.detailsLoaded) {
            TextView loadingDetails =
                    new TextView(this);

            loadingDetails.setText(
                    "Loading cast, description and trailer details...");

            loadingDetails.setTextColor(
                    Color.rgb(
                            135,
                            135,
                            140));

            loadingDetails.setTextSize(
                    12);

            loadingDetails.setPadding(
                    0,
                    dp(12),
                    0,
                    dp(14));

            info.addView(
                    loadingDetails);
        }

        long resumePosition =
                getSavedResumePosition(
                        buildResumeKey(
                                "MOVIE",
                                movie.streamId));

        Button favouriteButton = makeSmallButton(isMovieFavourite(movie.streamId) ? "★  FAVOURITE" : "☆  ADD TO FAVOURITES");
        favouriteButton.setTextSize(13);
        favouriteButton.setOnClickListener(v -> {
            toggleMovieFavourite(movie);
            favouriteButton.setText(isMovieFavourite(movie.streamId) ? "★  FAVOURITE" : "☆  ADD TO FAVOURITES");
        });
        info.addView(favouriteButton, mediaDetailButtonParams());

        Button play =
                makeSmallButton(
                        resumePosition >= 30000L
                                ? "▶  PLAY / RESUME"
                                : "▶  PLAY MOVIE");

        play.setTextSize(
                14);

        play.setBackground(
                makeBackground(
                        GOLD,
                        GOLD,
                        12));

        play.setTextColor(
                BLACK);

        play.setOnClickListener(
                v -> playMovie(
                        movie));

        info.addView(
                play,
                mediaDetailButtonParams());

        if (!safe(movie.trailer).isEmpty()) {
            Button trailer =
                    makeSmallButton(
                            "▶  TRAILER");

            trailer.setTextSize(
                    14);

            trailer.setOnClickListener(
                    v -> openYoutubeTrailer(
                            movie.trailer));

            info.addView(
                    trailer,
                    mediaDetailButtonParams());
        }

        setContentView(
                screen);

        play.post(
                () -> play.requestFocus());
    }


    private void showSeriesDetails(
            SeriesItem series) {

        if (series == null) {
            return;
        }

        closeActiveMediaAdapter();

        // Open immediately with metadata already available from get_series.
        renderSeriesDetailScreen(
                series);

        if (series.detailsLoaded
                || series.detailsLoading) {
            return;
        }

        series.detailsLoading =
                true;

        final int token =
                ++mediaDetailLoadToken;

        new Thread(() -> {
            try {
                MediaDetailLoader.loadSeries(
                        series,
                        mediaDetailLoaderHost());

                upsertSeriesIntoCatalogue(
                        series);

            } catch (Exception ignored) {
                series.detailsLoaded =
                        true;

            } finally {
                series.detailsLoading =
                        false;
            }

            runOnUiThread(() -> {
                if (token
                        != mediaDetailLoadToken) {
                    return;
                }

                if ("SERIES_DETAIL".equals(
                        selectedReturnScreen)
                        && safe(series.seriesId).equals(
                                selectedStreamId)) {

                    renderSeriesDetailScreen(
                            series);
                }
            });
        }).start();
    }


    private void renderSeriesDetailScreen(
            SeriesItem series) {

        releasePlayer();
        onHomeScreen = false;

        selectedReturnScreen =
                "SERIES_DETAIL";

        selectedStreamId =
                safe(series.seriesId);

        LinearLayout screen =
                new LinearLayout(this);

        screen.setOrientation(
                LinearLayout.VERTICAL);

        screen.setPadding(
                dp(18),
                dp(14),
                dp(18),
                dp(18));

        screen.setBackgroundColor(
                BLACK);

        TextView back =
                createBackText();

        back.setText(
                "<  SERIES");

        back.setOnClickListener(
                v -> showSeries());

        screen.addView(
                back,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(48)));

        LinearLayout content =
                new LinearLayout(this);

        content.setOrientation(
                LinearLayout.HORIZONTAL);

        screen.addView(
                content,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        LinearLayout coverPane =
                new LinearLayout(this);

        coverPane.setOrientation(
                LinearLayout.VERTICAL);

        coverPane.setGravity(
                Gravity.TOP
                        | Gravity.CENTER_HORIZONTAL);

        ImageView cover =
                new ImageView(this);

        cover.setScaleType(
                ImageView.ScaleType.CENTER_CROP);

        cover.setBackgroundColor(
                Color.rgb(
                        28,
                        28,
                        31));

        if (!safe(series.cover).isEmpty()) {
            loadPosterImage(
                    cover,
                    series.cover);
        }

        coverPane.addView(
                cover,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        LinearLayout.LayoutParams coverParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0.32f);

        coverParams.setMargins(
                0,
                0,
                dp(18),
                0);

        content.addView(
                coverPane,
                coverParams);

        ScrollView infoScroll =
                new ScrollView(this);

        LinearLayout info =
                new LinearLayout(this);

        info.setOrientation(
                LinearLayout.VERTICAL);

        info.setPadding(
                dp(8),
                dp(4),
                dp(8),
                dp(8));

        infoScroll.addView(
                info);

        content.addView(
                infoScroll,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0.68f));

        TextView title =
                new TextView(this);

        title.setText(
                series.name);

        title.setTextColor(
                Color.WHITE);

        title.setTextSize(
                30);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        info.addView(
                title);

        addMediaDetailFacts(
                info,
                series.year,
                series.rating,
                series.genre,
                "");

        addClickableCastMembers(
                info,
                series.cast);

        addMediaDetailText(
                info,
                "Director",
                series.director);

        if (!safe(series.plot).isEmpty()) {
            TextView plot =
                    new TextView(this);

            plot.setText(
                    series.plot);

            plot.setTextColor(
                    SILVER);

            plot.setTextSize(
                    14);

            plot.setPadding(
                    0,
                    dp(14),
                    0,
                    dp(18));

            info.addView(
                    plot);

        } else if (!series.detailsLoaded) {
            TextView loadingDetails =
                    new TextView(this);

            loadingDetails.setText(
                    "Loading cast, description and trailer details...");

            loadingDetails.setTextColor(
                    Color.rgb(
                            135,
                            135,
                            140));

            loadingDetails.setTextSize(
                    12);

            loadingDetails.setPadding(
                    0,
                    dp(12),
                    0,
                    dp(14));

            info.addView(
                    loadingDetails);
        }

        Button favouriteButton = makeSmallButton(isSeriesFavourite(series.seriesId) ? "★  FAVOURITE" : "☆  ADD TO FAVOURITES");
        favouriteButton.setTextSize(13);
        favouriteButton.setOnClickListener(v -> {
            toggleSeriesFavourite(series);
            favouriteButton.setText(isSeriesFavourite(series.seriesId) ? "★  FAVOURITE" : "☆  ADD TO FAVOURITES");
        });
        info.addView(favouriteButton, mediaDetailButtonParams());

        Button episodes =
                makeSmallButton(
                        "▶  EPISODES");

        episodes.setTextSize(
                14);

        episodes.setBackground(
                makeBackground(
                        GOLD,
                        GOLD,
                        12));

        episodes.setTextColor(
                BLACK);

        episodes.setOnClickListener(
                v -> showSeriesEpisodes(
                        series));

        info.addView(
                episodes,
                mediaDetailButtonParams());

        if (!safe(series.trailer).isEmpty()) {
            Button trailer =
                    makeSmallButton(
                            "▶  TRAILER");

            trailer.setTextSize(
                    14);

            trailer.setOnClickListener(
                    v -> openYoutubeTrailer(
                            series.trailer));

            info.addView(
                    trailer,
                    mediaDetailButtonParams());
        }

        setContentView(
                screen);

        episodes.post(
                () -> episodes.requestFocus());
    }


    private void addMediaDetailFacts(
            LinearLayout info,
            String year,
            String rating,
            String genre,
            String duration) {

        StringBuilder facts =
                new StringBuilder();

        String[] values = {
                safe(year),
                safe(rating).isEmpty()
                        ? ""
                        : "Rating " + safe(rating),
                safe(genre),
                safe(duration)
        };

        for (String value : values) {
            if (value == null
                    || value.trim().isEmpty()) {
                continue;
            }

            if (facts.length() > 0) {
                facts.append(
                        "   •   ");
            }

            facts.append(
                    value.trim());
        }

        if (facts.length() == 0) {
            return;
        }

        TextView factsView =
                new TextView(this);

        factsView.setText(
                facts.toString());

        factsView.setTextColor(
                GOLD);

        factsView.setTextSize(
                13);

        factsView.setPadding(
                0,
                dp(6),
                0,
                dp(8));

        info.addView(
                factsView);
    }


    private void addClickableCastMembers(
            LinearLayout info,
            String castText) {

        String cast =
                safe(castText)
                        .trim();

        if (cast.isEmpty()) {
            return;
        }

        TextView label =
                new TextView(this);

        label.setText(
                "CAST");

        label.setTextColor(
                GOLD);

        label.setTextSize(
                11);

        label.setLetterSpacing(
                0.10f);

        label.setPadding(
                0,
                dp(8),
                0,
                dp(5));

        info.addView(
                label);

        HorizontalScrollView scroll =
                new HorizontalScrollView(this);

        scroll.setHorizontalScrollBarEnabled(
                false);

        LinearLayout castRow =
                new LinearLayout(this);

        castRow.setOrientation(
                LinearLayout.HORIZONTAL);

        scroll.addView(
                castRow);

        String[] names =
                cast.split(
                        "\\s*[,;|]\\s*");

        int added =
                0;

        HashSet<String> seen =
                new HashSet<String>();

        for (String rawName : names) {
            String name =
                    safe(rawName)
                            .trim();

            String normalized =
                    normalizeSearchText(
                            name);

            if (name.length() < 2
                    || normalized.isEmpty()
                    || seen.contains(
                            normalized)) {
                continue;
            }

            seen.add(
                    normalized);

            TextView chip =
                    new TextView(this);

            chip.setText(
                    "👤  "
                            + name);

            chip.setTextColor(
                    Color.WHITE);

            chip.setTextSize(
                    12);

            chip.setGravity(
                    Gravity.CENTER);

            chip.setPadding(
                    dp(12),
                    0,
                    dp(12),
                    0);

            makeTvRemoteReady(
                    chip);

            chip.setBackground(
                    makeBackground(
                            CHARCOAL,
                            GOLD,
                            18));

            chip.setOnClickListener(
                    v -> showUnifiedMediaSearch(
                            "MOVIES",
                            name));

            LinearLayout.LayoutParams chipParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            dp(40));

            chipParams.setMargins(
                    0,
                    0,
                    dp(8),
                    0);

            castRow.addView(
                    chip,
                    chipParams);

            added++;

            if (added >= 18) {
                break;
            }
        }

        if (added > 0) {
            LinearLayout.LayoutParams scrollParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(46));

            scrollParams.setMargins(
                    0,
                    0,
                    0,
                    dp(8));

            info.addView(
                    scroll,
                    scrollParams);
        }
    }

    private void showCastSearch(
            String initialCast) {
        if (!actorSearchEnabled()) {
            showActorSearchDisabledMessage();
            return;
        }

        releasePlayer();
        onHomeScreen = false;
        pullCompletedCastCacheAsync(false);

        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setBackgroundColor(
                BLACK);

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                dp(20),
                dp(20),
                dp(20),
                dp(28));

        scrollView.addView(
                root);

        TextView back =
                createBackText();

        back.setText(
                "<  MOVIES");

        back.setOnClickListener(
                v -> showMovies());

        root.addView(
                back);

        TextView heading =
                new TextView(this);

        heading.setText(
                "CAST SEARCH");

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(
                28);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        root.addView(
                heading);

        TextView help =
                new TextView(this);

        help.setText(
                "Search movies in your provider library by actor/cast member. "
                        + "PREMIUM PLAYER now builds the cast index automatically in the background using the shared server cache. "
                        + "REFRESH INDEX only retries the background sync; it does not scan movie details one-by-one.");

        help.setTextColor(
                SILVER);

        help.setTextSize(
                13);

        help.setPadding(
                0,
                dp(7),
                0,
                dp(14));

        root.addView(
                help);

        EditText search =
                createMediaSearchBox(
                        "Enter a cast member");

        search.setText(
                safe(initialCast));

        root.addView(
                search,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(52)));

        LinearLayout actions =
                new LinearLayout(this);

        actions.setOrientation(
                LinearLayout.HORIZONTAL);

        Button searchButton =
                makeSmallButton(
                        "SEARCH CAST");

        searchButton.setBackground(
                makeBackground(
                        GOLD,
                        GOLD,
                        12));

        searchButton.setTextColor(
                BLACK);

        Button updateIndex =
                makeSmallButton(
                        "REFRESH INDEX");

        LinearLayout.LayoutParams left =
                new LinearLayout.LayoutParams(
                        0,
                        dp(52),
                        1f);

        left.setMargins(
                0,
                dp(10),
                dp(5),
                dp(10));

        LinearLayout.LayoutParams right =
                new LinearLayout.LayoutParams(
                        0,
                        dp(52),
                        1f);

        right.setMargins(
                dp(5),
                dp(10),
                0,
                dp(10));

        actions.addView(
                searchButton,
                left);

        actions.addView(
                updateIndex,
                right);

        root.addView(
                actions);

        TextView status =
                new TextView(this);

        status.setTextColor(
                SILVER);

        status.setTextSize(
                13);

        status.setPadding(
                0,
                dp(2),
                0,
                dp(12));

        root.addView(
                status);

        updateCastIndexStatusText(
                status);

        LinearLayout results =
                new LinearLayout(this);

        results.setOrientation(
                LinearLayout.VERTICAL);

        root.addView(
                results);

        View.OnClickListener runSearch =
                v -> {

                    String query =
                            search.getText() == null
                                    ? ""
                                    : search
                                    .getText()
                                    .toString();

                    if (normalizeSearchText(
                            query)
                            .length() < 2) {

                        status.setText(
                                "Enter at least 2 letters.");
                        return;
                    }

                    performCastSearch(
                            query,
                            status,
                            results,
                            searchButton);
                };

        searchButton.setOnClickListener(
                runSearch);

        search.setOnEditorActionListener(
                (v, actionId, event) -> {
                    runSearch.onClick(
                            v);

                    return true;
                });

        updateIndex.setOnClickListener(
                v -> {
                    pullCompletedCastCacheAsync(true);
                    ensureBackendCastIndexAsync(
                            "MOVIES",
                            true);

                    status.setText(
                            "Refreshing cast data from the shared index and checking the provider catalogue.");
                });

        setContentView(
                scrollView);

        if (!safe(initialCast)
                .trim()
                .isEmpty()) {

            search.post(
                    () -> runSearch.onClick(
                            search));
        } else {
            search.post(
                    () -> search.requestFocus());
        }
    }

    private void performCastSearch(
            String castQuery,
            TextView status,
            LinearLayout results,
            Button searchButton) {

        searchButton.setEnabled(
                false);

        results.removeAllViews();

        status.setText(
                "Searching local cast index...");

        new Thread(() -> {
            ArrayList<MovieItem> matches =
                    searchMovieCastIndex(
                            castQuery);

            runOnUiThread(() -> {
                searchButton.setEnabled(
                        true);

                renderCastSearchResults(
                        results,
                        matches,
                        castQuery);

                if (matches.isEmpty()) {
                    status.setText(
                            "No indexed movies found for "
                                    + castQuery
                                    + ". The server index may still be filling in the background; try REFRESH INDEX if needed.");
                } else {
                    status.setText(
                            matches.size()
                                    + " indexed movie"
                                    + (matches.size() == 1
                                    ? ""
                                    : "s")
                                    + " found for "
                                    + castQuery
                                    + ".");
                }
            });
        }).start();
    }

    private void renderCastSearchResults(
            LinearLayout results,
            ArrayList<MovieItem> movies,
            String castQuery) {

        results.removeAllViews();

        int limit =
                Math.min(
                        60,
                        movies.size());

        for (int i = 0;
             i < limit;
             i++) {

            MovieItem movie =
                    movies.get(
                            i);

            LinearLayout card =
                    new LinearLayout(this);

            card.setOrientation(
                    LinearLayout.HORIZONTAL);

            card.setGravity(
                    Gravity.CENTER_VERTICAL);

            card.setPadding(
                    dp(8),
                    dp(8),
                    dp(12),
                    dp(8));

            makeTvRemoteReady(
                    card);

            card.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(
                                    55,
                                    55,
                                    58),
                            12));

            ImageView poster =
                    new ImageView(this);

            poster.setScaleType(
                    ImageView.ScaleType.CENTER_CROP);

            poster.setBackgroundColor(
                    Color.rgb(
                            28,
                            28,
                            31));

            card.addView(
                    poster,
                    new LinearLayout.LayoutParams(
                            dp(74),
                            dp(108)));

            if (!safe(movie.icon)
                    .isEmpty()) {

                loadPosterImage(
                        poster,
                        movie.icon);
            }

            LinearLayout text =
                    new LinearLayout(this);

            text.setOrientation(
                    LinearLayout.VERTICAL);

            text.setPadding(
                    dp(14),
                    0,
                    0,
                    0);

            TextView title =
                    new TextView(this);

            title.setText(
                    movie.name);

            title.setTextColor(
                    Color.WHITE);

            title.setTextSize(
                    17);

            title.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD);

            text.addView(
                    title);

            TextView facts =
                    new TextView(this);

            String detail =
                    safe(movie.year);

            if (!safe(movie.rating)
                    .isEmpty()) {

                if (!detail.isEmpty()) {
                    detail +=
                            "   •   ";
                }

                detail +=
                        "Rating "
                                + movie.rating;
            }

            if (detail.isEmpty()) {
                detail =
                        "Movie";
            }

            facts.setText(
                    detail);

            facts.setTextColor(
                    GOLD);

            facts.setTextSize(
                    12);

            facts.setPadding(
                    0,
                    dp(4),
                    0,
                    dp(4));

            text.addView(
                    facts);

            TextView cast =
                    new TextView(this);

            cast.setText(
                    "Cast: "
                            + safe(movie.cast));

            cast.setTextColor(
                    SILVER);

            cast.setTextSize(
                    12);

            cast.setMaxLines(
                    2);

            text.addView(
                    cast);

            card.addView(
                    text,
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            1f));

            card.setOnClickListener(
                    v -> showMovieDetails(
                            movie));

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(126));

            params.setMargins(
                    0,
                    0,
                    0,
                    dp(8));

            results.addView(
                    card,
                    params);
        }

        if (movies.size()
                > limit) {

            TextView more =
                    new TextView(this);

            more.setText(
                    "Showing first "
                            + limit
                            + " of "
                            + movies.size()
                            + " indexed matches.");

            more.setTextColor(
                    SILVER);

            more.setTextSize(
                    12);

            more.setGravity(
                    Gravity.CENTER);

            more.setPadding(
                    0,
                    dp(10),
                    0,
                    dp(10));

            results.addView(
                    more);
        }
    }

    private ArrayList<MovieItem> searchMovieCastIndex(
            String castQuery) {

        ArrayList<MovieItem> matches =
                new ArrayList<MovieItem>();

        String query =
                normalizeSearchText(
                        castQuery);

        if (query.isEmpty()) {
            return matches;
        }

        HashSet<String> seenIds =
                new HashSet<String>();

        Cursor cursor =
                null;

        try {
            SQLiteDatabase db =
                    getCatalogueDbHelper()
                            .getReadableDatabase();

            cursor =
                    db.query(
                            "catalogue_movies",
                            new String[]{
                                    "stream_id",
                                    "name",
                                    "category_id",
                                    "extension",
                                    "direct_source",
                                    "rating",
                                    "year",
                                    "icon",
                                    "plot",
                                    "cast",
                                    "director",
                                    "genre",
                                    "trailer",
                                    "duration"
                            },
                            "provider_key=? AND normalized_cast LIKE ?",
                            new String[]{
                                    getCatalogueProviderKey(),
                                    "%"
                                            + query
                                            + "%"
                            },
                            null,
                            null,
                            "name COLLATE NOCASE ASC",
                            "200");

            while (cursor.moveToNext()) {

                MovieItem movie =
                        MediaItemMapper.movieFromCursor(
                                cursor,
                                mediaItemCursorHost());

                movie.detailsLoaded =
                        true;

                if (movie.streamId != null
                        && movie.streamId.isEmpty() == false
                        && seenIds.add(movie.streamId)) {

                    matches.add(movie);
                }
            }

        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        if (matches.size()
                < 100) {

            File file =
                    new File(
                            getFilesDir(),
                            CAST_INDEX_FILE);

            if (file.exists()) {
                synchronized (castIndexLock) {
                    BufferedReader reader =
                            null;

                    try {
                        reader =
                                new BufferedReader(
                                        new InputStreamReader(
                                                new FileInputStream(
                                                        file),
                                                "UTF-8"));

                        String line;

                        while ((line =
                                reader.readLine())
                                != null
                                && matches.size()
                                < 100) {

                            line =
                                    line.trim();

                            if (line.isEmpty()) {
                                continue;
                            }

                            JSONObject item =
                                    new JSONObject(
                                            line);

                            MovieItem movie =
                                    movieFromCastIndexJson(
                                            item);

                            if (movie.streamId.isEmpty()
                                    || seenIds.contains(
                                    movie.streamId)) {
                                continue;
                            }

                            if (castMatches(
                                    movie.cast,
                                    query)) {

                                seenIds.add(
                                        movie.streamId);

                                matches.add(
                                        movie);
                            }
                        }

                    } catch (Exception ignored) {
                    } finally {
                        if (reader != null) {
                            try {
                                reader.close();
                            } catch (Exception ignored) {
                            }
                        }
                    }
                }
            }
        }

        Collections.sort(
                matches,
                new Comparator<MovieItem>() {
                    @Override
                    public int compare(
                            MovieItem a,
                            MovieItem b) {

                        return safe(a.name)
                                .compareToIgnoreCase(
                                        safe(b.name));
                    }
                });

        return matches;
    }


    private boolean castMatches(
            String castText,
            String normalizedQuery) {

        String cast =
                normalizeSearchText(
                        castText);

        if (cast.isEmpty()
                || normalizedQuery == null
                || normalizedQuery.isEmpty()) {
            return false;
        }

        return cast.contains(
                normalizedQuery);
    }

    private void saveMovieToCastIndex(
            MovieItem movie) {

        if (movie == null
                || safe(movie.streamId).isEmpty()
                || safe(movie.cast).isEmpty()) {
            return;
        }

        synchronized (castIndexLock) {
            FileOutputStream output =
                    null;

            try {
                File file =
                        new File(
                                getFilesDir(),
                                CAST_INDEX_FILE);

                output =
                        new FileOutputStream(
                                file,
                                true);

                String line =
                        movieToCastIndexJson(
                                movie)
                                .toString()
                                + "\n";

                output.write(
                        line.getBytes(
                                "UTF-8"));

                output.flush();

            } catch (Exception ignored) {
            } finally {
                if (output != null) {
                    try {
                        output.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    private JSONObject movieToCastIndexJson(
            MovieItem movie)
            throws Exception {

        JSONObject object =
                new JSONObject();

        object.put(
                "stream_id",
                safe(movie.streamId));

        object.put(
                "name",
                safe(movie.name));

        object.put(
                "category_id",
                safe(movie.categoryId));

        object.put(
                "extension",
                safe(movie.extension));

        object.put(
                "direct_source",
                safe(movie.directSource));

        object.put(
                "rating",
                safe(movie.rating));

        object.put(
                "year",
                safe(movie.year));

        object.put(
                "icon",
                safe(movie.icon));

        object.put(
                "plot",
                safe(movie.plot));

        object.put(
                "cast",
                safe(movie.cast));

        object.put(
                "director",
                safe(movie.director));

        object.put(
                "genre",
                safe(movie.genre));

        object.put(
                "trailer",
                safe(movie.trailer));

        object.put(
                "duration",
                safe(movie.duration));

        return object;
    }

    private MovieItem movieFromCastIndexJson(
            JSONObject item) {

        MovieItem movie =
                new MovieItem();

        movie.streamId =
                item.optString(
                        "stream_id",
                        "");

        movie.name =
                item.optString(
                        "name",
                        "Movie");

        movie.categoryId =
                item.optString(
                        "category_id",
                        "");

        movie.extension =
                sanitizeMediaExtension(
                        item.optString(
                                "extension",
                                "mp4"));

        movie.directSource =
                item.optString(
                        "direct_source",
                        "");

        movie.rating =
                item.optString(
                        "rating",
                        "");

        movie.year =
                item.optString(
                        "year",
                        "");

        movie.icon =
                item.optString(
                        "icon",
                        "");

        movie.plot =
                item.optString(
                        "plot",
                        "");

        movie.cast =
                item.optString(
                        "cast",
                        "");

        movie.director =
                item.optString(
                        "director",
                        "");

        movie.genre =
                item.optString(
                        "genre",
                        "");

        movie.trailer =
                item.optString(
                        "trailer",
                        "");

        movie.duration =
                item.optString(
                        "duration",
                        "");

        movie.detailsLoaded =
                true;

        return movie;
    }

    private HashSet<String> loadCastScannedIds() {
        HashSet<String> ids =
                new HashSet<String>();

        File file =
                new File(
                        getFilesDir(),
                        CAST_SCANNED_FILE);

        if (!file.exists()) {
            return ids;
        }

        synchronized (castIndexLock) {
            BufferedReader reader =
                    null;

            try {
                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        new FileInputStream(
                                                file),
                                        "UTF-8"));

                String line;

                while ((line =
                        reader.readLine())
                        != null) {

                    String id =
                            line.trim();

                    if (!id.isEmpty()) {
                        ids.add(
                                id);
                    }
                }

            } catch (Exception ignored) {
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        return ids;
    }

    private void markMovieCastScanned(
            String streamId) {

        String id =
                safe(streamId)
                        .trim();

        if (id.isEmpty()) {
            return;
        }

        synchronized (castIndexLock) {
            HashSet<String> ids =
                    loadCastScannedIds();

            if (ids.contains(
                    id)) {
                return;
            }

            FileOutputStream output =
                    null;

            try {
                File file =
                        new File(
                                getFilesDir(),
                                CAST_SCANNED_FILE);

                output =
                        new FileOutputStream(
                                file,
                                true);

                output.write(
                        (id + "\n")
                                .getBytes(
                                        "UTF-8"));

                output.flush();

            } catch (Exception ignored) {
            } finally {
                if (output != null) {
                    try {
                        output.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    private static long parseAddedTimestamp(String raw) {
        try {
            long value = Long.parseLong(raw.trim());
            if (value > 9999999999L) value /= 1000L;
            return Math.max(0L, value);
        } catch (Exception e) {
            return 0L;
        }
    }

    private MovieItem readMovieItemFromStream(
            JsonReader reader)
            throws Exception {

        String rawJson = ProviderRawJson.capture(reader);
        reader = new JsonReader(new java.io.StringReader(rawJson));
        MovieItem movie =
                new MovieItem();
        movie.rawJson = rawJson;

        reader.beginObject();

        while (reader.hasNext()) {
            String name =
                    reader.nextName();

            if (name.equals(
                    "name")) {

                movie.name =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "category_id")) {

                movie.categoryId =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "stream_id")) {

                movie.streamId =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "container_extension")) {

                movie.extension =
                        sanitizeMediaExtension(
                                readJsonString(
                                        reader));

            } else if (name.equals(
                    "direct_source")) {

                movie.directSource =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "rating")) {

                movie.rating =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "year")) {

                movie.year =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "stream_icon")
                    || name.equals(
                    "movie_image")
                    || name.equals(
                    "cover_big")) {

                movie.icon =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "plot")
                    || name.equals(
                    "description")) {

                movie.plot =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "cast")
                    || name.equals(
                    "actors")) {

                movie.cast =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "director")) {

                movie.director =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "genre")) {

                movie.genre =
                        readJsonString(
                                reader);

            } else if (name.equals(
                    "youtube_trailer")) {

                movie.trailer =
                        readJsonString(
                                reader);

            } else if (name.equals("added")) {
                movie.addedAt = parseAddedTimestamp(readJsonString(reader));
            } else {
                reader.skipValue();
            }
        }

        reader.endObject();

        return movie;
    }

    private void fillMovieFromDetailInfo(
            MovieItem movie,
            JSONObject info) {

        if (movie == null
                || info == null) {
            return;
        }

        movie.icon =
                firstNonEmpty(
                        info.optString(
                                "movie_image",
                                ""),
                        info.optString(
                                "cover_big",
                                ""),
                        info.optString(
                                "stream_icon",
                                ""),
                        movie.icon);

        movie.plot =
                firstNonEmpty(
                        info.optString(
                                "plot",
                                ""),
                        info.optString(
                                "description",
                                ""),
                        movie.plot);

        movie.cast =
                firstNonEmpty(
                        info.optString(
                                "cast",
                                ""),
                        info.optString(
                                "actors",
                                ""),
                        movie.cast);

        movie.director =
                firstNonEmpty(
                        info.optString(
                                "director",
                                ""),
                        movie.director);

        movie.genre =
                firstNonEmpty(
                        info.optString(
                                "genre",
                                ""),
                        movie.genre);

        movie.trailer =
                firstNonEmpty(
                        info.optString(
                                "youtube_trailer",
                                ""),
                        movie.trailer);

        movie.rating =
                firstNonEmpty(
                        info.optString(
                                "rating",
                                ""),
                        movie.rating);

        movie.year =
                firstNonEmpty(
                        info.optString(
                                "releasedate",
                                ""),
                        info.optString(
                                "release_date",
                                ""),
                        info.optString(
                                "year",
                                ""),
                        movie.year);

        movie.duration =
                firstNonEmpty(
                        info.optString(
                                "duration",
                                ""),
                        movie.duration);
    }

    private void appendScannedMovieId(
            String streamId) {

        String id =
                safe(streamId)
                        .trim();

        if (id.isEmpty()) {
            return;
        }

        synchronized (castIndexLock) {
            FileOutputStream output =
                    null;

            try {
                File file =
                        new File(
                                getFilesDir(),
                                CAST_SCANNED_FILE);

                output =
                        new FileOutputStream(
                                file,
                                true);

                output.write(
                        (id + "\n")
                                .getBytes(
                                        "UTF-8"));

                output.flush();

            } catch (Exception ignored) {
            } finally {
                if (output != null) {
                    try {
                        output.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    private HashSet<String> loadIndexedMovieIds() {
        HashSet<String> ids =
                new HashSet<String>();

        File file =
                new File(
                        getFilesDir(),
                        CAST_INDEX_FILE);

        if (!file.exists()) {
            return ids;
        }

        synchronized (castIndexLock) {
            BufferedReader reader =
                    null;

            try {
                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        new FileInputStream(
                                                file),
                                        "UTF-8"));

                String line;

                while ((line =
                        reader.readLine())
                        != null) {

                    line =
                            line.trim();

                    if (line.isEmpty()) {
                        continue;
                    }

                    JSONObject object =
                            new JSONObject(
                                    line);

                    String id =
                            object.optString(
                                    "stream_id",
                                    "");

                    if (!id.isEmpty()) {
                        ids.add(
                                id);
                    }
                }

            } catch (Exception ignored) {
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        return ids;
    }

    private void updateCastIndexStatusText(
            TextView status) {

        if (status == null) {
            return;
        }

        new Thread(() -> {
            int indexed =
                    loadIndexedMovieIds()
                            .size();

            int scanned =
                    loadCastScannedIds()
                            .size();

            runOnUiThread(() ->
                    status.setText(
                            "Cast index: "
                                    + indexed
                                    + " movies with cast metadata • "
                                    + scanned
                                    + " provider titles scanned."));
        }).start();
    }

    private void addMediaDetailText(
            LinearLayout info,
            String label,
            String value) {

        if (value == null
                || value.trim().isEmpty()) {
            return;
        }

        TextView view =
                new TextView(this);

        view.setText(
                label
                        + ": "
                        + value.trim());

        view.setTextColor(
                Color.WHITE);

        view.setTextSize(
                13);

        view.setPadding(
                0,
                dp(4),
                0,
                dp(4));

        info.addView(
                view);
    }

    private LinearLayout.LayoutParams mediaDetailButtonParams() {
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(52));

        params.setMargins(
                0,
                0,
                0,
                dp(10));

        return params;
    }

    private LinearLayout createPosterCard(
            String titleText,
            String imageUrl,
            int cardWidth) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL);

        card.setPadding(
                dp(5),
                dp(5),
                dp(5),
                dp(7));

        makeTvRemoteReady(
                card);

        card.setBackground(
                makeBackground(
                        CHARCOAL,
                        Color.rgb(55, 55, 58),
                        10));

        ImageView poster =
                new ImageView(this);

        poster.setScaleType(
                ImageView.ScaleType.CENTER_CROP);

        poster.setBackgroundColor(
                Color.rgb(
                        28,
                        28,
                        31));

        int posterHeight =
                Math.max(
                        1,
                        (int) (
                                cardWidth
                                        * 1.48f));

        card.addView(
                poster,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        posterHeight));

        if (imageUrl != null
                && !imageUrl.trim().isEmpty()) {

            loadPosterImage(
                    poster,
                    imageUrl);
        }

        TextView title =
                new TextView(this);

        title.setText(
                titleText);

        title.setTextColor(
                Color.WHITE);

        title.setTextSize(
                12);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        title.setGravity(
                Gravity.CENTER);

        title.setMaxLines(
                2);

        title.setPadding(
                dp(3),
                dp(6),
                dp(3),
                0);

        card.addView(
                title,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        return card;
    }

    private void loadPosterImage(
            ImageView imageView,
            String rawUrl) {

        if (imageView == null) {
            return;
        }

        final String imageUrl =
                safe(rawUrl)
                        .trim();

        if (imageUrl.isEmpty()) {
            return;
        }

        imageView.setTag(
                imageUrl);

        Bitmap cached;

        synchronized (posterCache) {
            cached =
                    posterCache.get(
                            imageUrl);
        }

        if (cached != null
                && !cached.isRecycled()) {

            imageView.setImageBitmap(
                    cached);

            return;
        }

        posterImageExecutor.execute(() -> {
            HttpURLConnection connection =
                    null;

            InputStream input =
                    null;

            try {
                URL url =
                        new URL(
                                imageUrl);

                connection =
                        (HttpURLConnection)
                                url.openConnection();

                connection.setConnectTimeout(
                        6000);

                connection.setReadTimeout(
                        6000);

                connection.setInstanceFollowRedirects(
                        true);

                connection.setRequestProperty(
                        "User-Agent",
                        "PREMIUM-PLAYER");

                input =
                        connection.getInputStream();

                BitmapFactory.Options options =
                        new BitmapFactory.Options();

                // Provider artwork is often far larger than a TV poster card.
                // Quarter-resolution decode sharply reduces memory use.
                options.inSampleSize =
                        4;

                Bitmap bitmap =
                        BitmapFactory.decodeStream(
                                input,
                                null,
                                options);

                if (bitmap == null) {
                    return;
                }

                synchronized (posterCache) {
                    if (posterCache.size()
                            >= 48) {

                        Iterator<String> keys =
                                posterCache
                                        .keySet()
                                        .iterator();

                        int removeCount =
                                12;

                        while (keys.hasNext()
                                && removeCount > 0) {

                            String key =
                                    keys.next();

                            Bitmap old =
                                    posterCache.get(
                                            key);

                            keys.remove();

                            removeCount--;
                        }
                    }

                    posterCache.put(
                            imageUrl,
                            bitmap);
                }

                runOnUiThread(() -> {
                    Object tag =
                            imageView.getTag();

                    if (tag != null
                            && imageUrl.equals(
                                    tag.toString())
                            && !bitmap.isRecycled()) {

                        imageView.setImageBitmap(
                                bitmap);
                    }
                });

            } catch (Exception ignored) {
            } finally {
                try {
                    if (input != null) {
                        input.close();
                    }
                } catch (Exception ignored) {
                }

                if (connection != null) {
                    connection.disconnect();
                }
            }
        });
    }


    private void renderMediaDetailContent(
            LinearLayout detailHost,
            String title,
            String year,
            String rating,
            String genre,
            String director,
            String cast,
            String plot,
            String trailer,
            long resumePosition) {

        detailHost.removeAllViews();

        LinearLayout titleRow =
                new LinearLayout(this);

        titleRow.setOrientation(
                LinearLayout.HORIZONTAL);

        titleRow.setGravity(
                Gravity.CENTER_VERTICAL);

        TextView titleView =
                new TextView(this);

        titleView.setText(
                title);

        titleView.setTextColor(
                Color.WHITE);

        titleView.setTextSize(
                17);

        titleView.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        titleRow.addView(
                titleView,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1f));

        if (trailer != null
                && !trailer.trim().isEmpty()) {

            TextView trailerButton =
                    new TextView(this);

            trailerButton.setText(
                    "▶  TRAILER");

            trailerButton.setTextColor(
                    BLACK);

            trailerButton.setTextSize(
                    12);

            trailerButton.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD);

            trailerButton.setGravity(
                    Gravity.CENTER);

            makeTvRemoteReady(
                    trailerButton);

            trailerButton.setBackground(
                    makeBackground(
                            GOLD,
                            GOLD,
                            9));

            trailerButton.setOnClickListener(
                    v -> openYoutubeTrailer(
                            trailer));

            titleRow.addView(
                    trailerButton,
                    new LinearLayout.LayoutParams(
                            dp(110),
                            dp(38)));
        }

        detailHost.addView(
                titleRow);

        StringBuilder facts =
                new StringBuilder();

        if (year != null
                && !year.trim().isEmpty()) {
            facts.append(
                    year.trim());
        }

        if (rating != null
                && !rating.trim().isEmpty()) {
            if (facts.length() > 0) {
                facts.append(
                        "   •   ");
            }

            facts.append(
                    "Rating ")
                    .append(
                            rating.trim());
        }

        if (genre != null
                && !genre.trim().isEmpty()) {
            if (facts.length() > 0) {
                facts.append(
                        "   •   ");
            }

            facts.append(
                    genre.trim());
        }

        if (resumePosition
                >= 30000L) {
            if (facts.length() > 0) {
                facts.append(
                        "   •   ");
            }

            facts.append(
                    "Resume ")
                    .append(
                            formatPlaybackTime(
                                    resumePosition));
        }

        if (facts.length() > 0) {
            TextView factsView =
                    new TextView(this);

            factsView.setText(
                    facts.toString());

            factsView.setTextColor(
                    GOLD);

            factsView.setTextSize(
                    11);

            factsView.setSingleLine(
                    true);

            detailHost.addView(
                    factsView);
        }

        if (cast != null
                && !cast.trim().isEmpty()) {

            TextView castView =
                    new TextView(this);

            castView.setText(
                    "Cast: "
                            + cast.trim());

            castView.setTextColor(
                    Color.WHITE);

            castView.setTextSize(
                    11);

            castView.setMaxLines(
                    2);

            castView.setPadding(
                    0,
                    dp(3),
                    0,
                    0);

            detailHost.addView(
                    castView);
        }

        if (director != null
                && !director.trim().isEmpty()) {

            TextView directorView =
                    new TextView(this);

            directorView.setText(
                    "Director: "
                            + director.trim());

            directorView.setTextColor(
                    SILVER);

            directorView.setTextSize(
                    10);

            directorView.setSingleLine(
                    true);

            detailHost.addView(
                    directorView);
        }

        if (plot != null
                && !plot.trim().isEmpty()) {

            TextView plotView =
                    new TextView(this);

            plotView.setText(
                    plot.trim());

            plotView.setTextColor(
                    SILVER);

            plotView.setTextSize(
                    10);

            plotView.setMaxLines(
                    2);

            plotView.setPadding(
                    0,
                    dp(3),
                    0,
                    0);

            detailHost.addView(
                    plotView);
        }
    }

    private void openYoutubeTrailer(
            String trailerValue) {

        String value =
                safe(
                        trailerValue)
                        .trim();

        if (value.isEmpty()) {
            return;
        }

        String url;

        if (value.startsWith(
                "http://")
                || value.startsWith(
                "https://")) {

            url =
                    value;

        } else {
            url =
                    "https://www.youtube.com/watch?v="
                            + value;
        }

        try {
            Intent intent =
                    new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(
                                    url));

            intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(
                    intent);

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "YouTube trailer could not be opened.",
                    Toast.LENGTH_LONG)
                    .show();
        }
    }

    private String firstNonEmpty(
            String... values) {

        if (values == null) {
            return "";
        }

        for (String value : values) {
            if (value != null
                    && !value.trim().isEmpty()
                    && !"null".equalsIgnoreCase(
                            value.trim())) {

                return value.trim();
            }
        }

        return "";
    }

    private JSONObject postMediaSearch(JSONObject body) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(CAST_BACKEND_BASE_URL + "/media-search");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(30000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("apikey", CAST_BACKEND_PUBLISHABLE_KEY);

            OutputStream output = connection.getOutputStream();
            output.write(body.toString().getBytes("UTF-8"));
            output.flush();
            output.close();

            int code = connection.getResponseCode();
            InputStream input = code >= 200 && code < 300
                    ? connection.getInputStream()
                    : connection.getErrorStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line);
            reader.close();
            if (code < 200 || code >= 300) throw new Exception("Media search HTTP " + code);
            return new JSONObject(text.toString());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void updateUnifiedPeopleRow(
            String mediaType,
            String query,
            LinearLayout peopleRow) {

        peopleRow.removeAllViews();

        TextView loading = new TextView(this);
        loading.setText("Searching people...");
        loading.setTextColor(SILVER);
        loading.setTextSize(12);
        loading.setPadding(dp(6), dp(8), dp(12), dp(8));
        peopleRow.addView(loading);

        new Thread(() -> {
            try {
                JSONObject request = new JSONObject();
                request.put("mode", "search");
                request.put("query", query);
                request.put("section", mediaType);
                JSONObject response = postMediaSearch(request);
                JSONArray people = response.optJSONArray("people");

                runOnUiThread(() -> {
                    peopleRow.removeAllViews();
                    int added = 0;
                    if (people != null) {
                        for (int i = 0; i < people.length() && added < 12; i++) {
                            JSONObject person = people.optJSONObject(i);
                            if (person == null) continue;
                            JSONArray credits = "SERIES".equals(mediaType)
                                    ? person.optJSONArray("series")
                                    : person.optJSONArray("movies");
                            if (credits == null || credits.length() == 0) continue;

                            final long personId = person.optLong("id", 0L);
                            final String personName = person.optString("name", "Unknown");
                            final String profileUrl = person.optString("profile_url", "");

                            LinearLayout card = new LinearLayout(this);
                            card.setOrientation(LinearLayout.VERTICAL);
                            card.setGravity(Gravity.CENTER_HORIZONTAL);
                            card.setPadding(dp(6), dp(6), dp(6), dp(6));
                            makeTvRemoteReady(card);
                            card.setBackground(makeBackground(CHARCOAL, Color.rgb(55,55,58), 12));

                            ImageView photo = new ImageView(this);
                            photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
                            photo.setBackgroundColor(Color.rgb(28,28,31));
                            card.addView(photo, new LinearLayout.LayoutParams(dp(96), dp(108)));
                            if (!profileUrl.isEmpty()) loadPosterImage(photo, profileUrl);

                            TextView name = new TextView(this);
                            name.setText(personName);
                            name.setTextColor(Color.WHITE);
                            name.setTextSize(12);
                            name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                            name.setGravity(Gravity.CENTER);
                            name.setMaxLines(2);
                            name.setPadding(0, dp(5), 0, 0);
                            card.addView(name, new LinearLayout.LayoutParams(dp(112), dp(42)));

                            card.setOnClickListener(v -> showPersonProfile(personId, mediaType));
                            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(dp(124), dp(166));
                            cardParams.setMargins(0, 0, dp(8), 0);
                            peopleRow.addView(card, cardParams);
                            added++;
                        }
                    }

                    if (added == 0) {
                        TextView none = new TextView(this);
                        none.setText("No matching people with indexed " + mediaType.toLowerCase(Locale.US) + " credits yet.");
                        none.setTextColor(Color.rgb(135,135,140));
                        none.setTextSize(12);
                        none.setPadding(dp(6), dp(10), dp(12), dp(10));
                        peopleRow.addView(none);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    peopleRow.removeAllViews();
                    TextView unavailable = new TextView(this);
                    unavailable.setText("People search unavailable. Title search still works.");
                    unavailable.setTextColor(Color.rgb(135,135,140));
                    unavailable.setTextSize(12);
                    unavailable.setPadding(dp(6), dp(10), dp(12), dp(10));
                    peopleRow.addView(unavailable);
                });
            }
        }).start();
    }

    private void showPersonProfile(long personId, String returnMediaType) {
        releasePlayer();
        closeActiveMediaAdapter();
        onHomeScreen = false;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(16), dp(20), dp(30));
        scroll.addView(root);

        TextView back = createBackText();
        back.setText("<  SEARCH " + returnMediaType);
        back.setOnClickListener(v -> showMediaCategories(returnMediaType));
        root.addView(back);

        TextView loading = new TextView(this);
        loading.setText("Loading actor profile...");
        loading.setTextColor(SILVER);
        loading.setTextSize(15);
        loading.setPadding(0, dp(20), 0, dp(20));
        root.addView(loading);
        setContentView(scroll);

        new Thread(() -> {
            try {
                JSONObject request = new JSONObject();
                request.put("mode", "profile");
                request.put("person_id", personId);
                JSONObject response = postMediaSearch(request);
                JSONObject person = response.optJSONObject("person");
                if (person == null) throw new Exception("Profile missing");

                runOnUiThread(() -> {
                    root.removeView(loading);

                    LinearLayout hero = new LinearLayout(this);
                    hero.setOrientation(LinearLayout.HORIZONTAL);
                    hero.setGravity(Gravity.TOP);

                    ImageView photo = new ImageView(this);
                    photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    photo.setBackgroundColor(Color.rgb(28,28,31));
                    hero.addView(photo, new LinearLayout.LayoutParams(dp(170), dp(240)));
                    String profileUrl = person.optString("profile_url", "");
                    if (!profileUrl.isEmpty()) loadPosterImage(photo, profileUrl);

                    LinearLayout info = new LinearLayout(this);
                    info.setOrientation(LinearLayout.VERTICAL);
                    info.setPadding(dp(20), 0, 0, 0);

                    TextView name = new TextView(this);
                    name.setText(person.optString("name", "Actor"));
                    name.setTextColor(Color.WHITE);
                    name.setTextSize(30);
                    name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                    info.addView(name);

                    String born = person.optString("birthday", "");
                    String died = person.optString("deathday", "");
                    if (!born.isEmpty() || !died.isEmpty()) {
                        TextView dates = new TextView(this);
                        String text = born.isEmpty() ? "" : "Born " + born;
                        if (!died.isEmpty()) text += (text.isEmpty() ? "" : "   â¢   ") + "Died " + died;
                        dates.setText(text);
                        dates.setTextColor(GOLD);
                        dates.setTextSize(13);
                        dates.setPadding(0, dp(7), 0, dp(8));
                        info.addView(dates);
                    }

                    TextView bio = new TextView(this);
                    String biography = person.optString("biography", "").trim();
                    bio.setText(biography.isEmpty() ? "Biography is not available yet." : biography);
                    bio.setTextColor(SILVER);
                    bio.setTextSize(13);
                    bio.setMaxLines(10);
                    info.addView(bio);
                    hero.addView(info, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

                    LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);
                    heroParams.setMargins(0, dp(12), 0, dp(22));
                    root.addView(hero, heroParams);

                    addProfileMediaRow(root, "MOVIES", person.optJSONArray("movies"), "MOVIES");
                    addProfileMediaRow(root, "SERIES", person.optJSONArray("series"), "SERIES");
                });
            } catch (Exception e) {
                runOnUiThread(() -> loading.setText("Unable to load this actor profile right now."));
            }
        }).start();
    }

    private void addProfileMediaRow(
            LinearLayout root,
            String headingText,
            JSONArray items,
            String mediaType) {

        if (items == null || items.length() == 0) return;

        TextView heading = new TextView(this);
        heading.setText(headingText);
        heading.setTextColor(GOLD);
        heading.setTextSize(16);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setPadding(0, dp(12), 0, dp(10));
        root.addView(heading);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(row);

        int limit = Math.min(40, items.length());
        for (int i = 0; i < limit; i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;
            final String title = "MOVIES".equals(mediaType)
                    ? item.optString("title", "")
                    : item.optString("name", "");
            if (title.isEmpty()) continue;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(5), dp(5), dp(5), dp(5));
            makeTvRemoteReady(card);
            card.setBackground(makeBackground(CHARCOAL, Color.rgb(55,55,58), 12));

            ImageView poster = new ImageView(this);
            poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
            poster.setBackgroundColor(Color.rgb(28,28,31));
            card.addView(poster, new LinearLayout.LayoutParams(dp(126), dp(180)));
            String posterUrl = item.optString("poster_url", "");
            if (!posterUrl.isEmpty()) loadPosterImage(poster, posterUrl);

            TextView titleView = new TextView(this);
            titleView.setText(title);
            titleView.setTextColor(Color.WHITE);
            titleView.setTextSize(12);
            titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            titleView.setMaxLines(2);
            titleView.setGravity(Gravity.CENTER);
            card.addView(titleView, new LinearLayout.LayoutParams(dp(126), dp(42)));

            int year = item.optInt("year", 0);
            if (year > 0) {
                TextView yearView = new TextView(this);
                yearView.setText(String.valueOf(year));
                yearView.setTextColor(SILVER);
                yearView.setTextSize(11);
                yearView.setGravity(Gravity.CENTER);
                card.addView(yearView);
            }

            card.setOnClickListener(v -> openProviderTitleFromProfile(mediaType, title));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(138), dp(250));
            params.setMargins(0, 0, dp(9), 0);
            row.addView(card, params);
        }

        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(258));
        scrollParams.setMargins(0, 0, 0, dp(12));
        root.addView(scroll, scrollParams);
    }

    private void openProviderTitleFromProfile(String mediaType, String title) {
        if (!hasXtreamLogin()) {
            showXtreamRequiredScreen(mediaType);
            return;
        }

        Toast.makeText(this, "Finding " + title + " in your playlist...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            try {
                final String wanted = normalizeSearchText(title);
                final MovieItem[] movieMatch = new MovieItem[1];
                final SeriesItem[] seriesMatch = new SeriesItem[1];
                String action = "MOVIES".equals(mediaType) ? "get_vod_streams" : "get_series";
                streamJsonArray(buildXtreamApiUrl(action, null, null), reader -> {
                    if ("MOVIES".equals(mediaType)) {
                        MovieItem movie = readMovieItemFromStream(reader);
                        if (movieMatch[0] == null && wanted.equals(normalizeSearchText(movie.name))) movieMatch[0] = movie;
                    } else {
                        SeriesItem series = readSeriesItemFromStream(reader);
                        if (seriesMatch[0] == null && wanted.equals(normalizeSearchText(series.name))) seriesMatch[0] = series;
                    }
                });

                runOnUiThread(() -> {
                    if (movieMatch[0] != null) showMovieDetails(movieMatch[0]);
                    else if (seriesMatch[0] != null) showSeriesDetails(seriesMatch[0]);
                    else Toast.makeText(this, "That title is not available in your current playlist.", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Unable to check your playlist right now.", Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private String unifiedBaseTitle(String value) {
        String normalized = normalizeSearchText(value);
        if (normalized == null) {
            return "";
        }

        int n = normalized.length();
        if (n >= 5 && normalized.charAt(n - 5) == ' ') {
            boolean fourDigits = true;
            for (int i = n - 4; i < n; i++) {
                char c = normalized.charAt(i);
                if (c < '0' || c > '9') {
                    fourDigits = false;
                    break;
                }
            }

            if (fourDigits) {
                try {
                    int year = Integer.parseInt(normalized.substring(n - 4));
                    if (year >= 1900 && year <= 2099) {
                        return normalized.substring(0, n - 5).trim();
                    }
                } catch (Exception ignored) {
                }
            }
        }

        return normalized;
    }

    private boolean unifiedServerTitleMatch(
            String providerTitle,
            HashSet<String> serverTitles) {
        String candidate = unifiedBaseTitle(providerTitle);
        if (candidate.isEmpty() || serverTitles == null || serverTitles.isEmpty()) {
            return false;
        }
        return serverTitles.contains(candidate);
    }

    private void renderUnifiedPeopleCards(
            JSONArray people,
            String mediaType,
            LinearLayout peopleRow) {
        if (!actorSearchEnabled()) {
            return;
        }

        peopleRow.removeAllViews();
        int added = 0;
        if (people != null) {
            for (int i = 0; i < people.length() && added < 12; i++) {
                JSONObject person = people.optJSONObject(i);
                if (person == null) {
                    continue;
                }

                final long personId = person.optLong("id", 0L);
                final String personName = person.optString("name", "Unknown");
                final String profileUrl = person.optString("profile_url", "");
                JSONArray credits = "SERIES".equals(mediaType)
                        ? person.optJSONArray("series")
                        : person.optJSONArray("movies");
                int creditCount = credits == null ? 0 : credits.length();

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setGravity(Gravity.CENTER_HORIZONTAL);
                card.setPadding(dp(6), dp(6), dp(6), dp(6));
                makeTvRemoteReady(card);
                card.setBackground(makeBackground(CHARCOAL, Color.rgb(55, 55, 58), 12));

                ImageView photo = new ImageView(this);
                photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
                photo.setBackgroundColor(Color.rgb(28, 28, 31));
                card.addView(photo, new LinearLayout.LayoutParams(dp(96), dp(108)));
                if (!profileUrl.isEmpty()) {
                    loadPosterImage(photo, profileUrl);
                }

                TextView name = new TextView(this);
                name.setText(personName);
                name.setTextColor(Color.WHITE);
                name.setTextSize(12);
                name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                name.setGravity(Gravity.CENTER);
                name.setMaxLines(2);
                name.setPadding(0, dp(5), 0, 0);
                card.addView(name, new LinearLayout.LayoutParams(dp(112), dp(38)));

                TextView count = new TextView(this);
                count.setText(creditCount + ("SERIES".equals(mediaType) ? " series credits" : " movie credits"));
                count.setTextColor(SILVER);
                count.setTextSize(10);
                count.setGravity(Gravity.CENTER);
                card.addView(count, new LinearLayout.LayoutParams(dp(112), dp(24)));

                card.setOnClickListener(v -> showPersonProfile(personId, mediaType));
                LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(dp(124), dp(190));
                cardParams.setMargins(0, 0, dp(8), 0);
                peopleRow.addView(card, cardParams);
                added++;
            }
        }

        if (added == 0) {
            TextView none = new TextView(this);
            none.setText("No matching people.");
            none.setTextColor(Color.rgb(135, 135, 140));
            none.setTextSize(12);
            none.setPadding(dp(6), dp(10), dp(12), dp(10));
            peopleRow.addView(none);
        }
    }

    // Unified entry point: searches the locally imported catalogue only.
    // Cast names are included in the same title results; no backend calls.
    private void showUnifiedMediaSearch(String mediaType, String rawQuery) {
        showGlobalMediaSearch(mediaType, rawQuery);
    }

    private void showGlobalMediaSearch(String mediaType) {
        showGlobalMediaSearch(mediaType, "");
    }

    private void showGlobalMediaSearch(
            String mediaType, String initialQuery) {

        releasePlayer();
        onHomeScreen =
                false;

        closeActiveMediaAdapter();

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                dp(16),
                dp(14),
                dp(16),
                dp(14));

        root.setBackgroundColor(
                BLACK);

        LinearLayout top =
                new LinearLayout(this);

        top.setOrientation(
                LinearLayout.HORIZONTAL);

        top.setGravity(
                Gravity.CENTER_VERTICAL);

        // Discard results from older searches if a newer query is submitted.
        final java.util.concurrent.atomic.AtomicInteger searchGeneration =
                new java.util.concurrent.atomic.AtomicInteger();

        TextView back =
                createBackText();

        back.setText(
                "<  "
                        + mediaType);

        back.setOnClickListener(v -> {
            searchGeneration.incrementAndGet();
            showMediaCategories(mediaType);
        });

        top.addView(
                back,
                new LinearLayout.LayoutParams(
                        0,
                        dp(50),
                        0.18f));

        TextView heading =
                new TextView(this);

        heading.setText("SEARCH LIBRARY");

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(
                22);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        heading.setGravity(
                Gravity.CENTER_VERTICAL);

        top.addView(
                heading,
                new LinearLayout.LayoutParams(
                        0,
                        dp(50),
                        0.24f));

        EditText search =
                createMediaSearchBox("Search movies, series or cast");

        LinearLayout.LayoutParams searchParams =
                new LinearLayout.LayoutParams(
                        0,
                        dp(50),
                        0.38f);

        searchParams.setMargins(
                dp(8),
                0,
                dp(8),
                0);

        top.addView(
                search,
                searchParams);

        Button searchButton =
                makeSmallButton(
                        "SEARCH");

        searchButton.setBackground(
                makeBackground(
                        GOLD,
                        GOLD,
                        10));

        searchButton.setTextColor(
                BLACK);

        top.addView(
                searchButton,
                new LinearLayout.LayoutParams(
                        0,
                        dp(50),
                        0.20f));

        root.addView(
                top);

        LinearLayout tools =
                new LinearLayout(this);

        tools.setOrientation(
                LinearLayout.HORIZONTAL);

        tools.setGravity(
                Gravity.CENTER_VERTICAL);

        TextView status =
                new TextView(this);

        status.setTextColor(
                SILVER);

        status.setTextSize(
                12);

        status.setText(
                "Search titles and cast in your local catalogue.");

        tools.addView(
                status,
                new LinearLayout.LayoutParams(
                        0,
                        dp(44),
                        1f));

        root.addView(
                tools);

        // Cast matches appear directly among playable titles below.
        // Do not render the legacy People row: it calls Supabase.

        GridView resultsGrid =
                new GridView(this);

        resultsGrid.setNumColumns(
                getMediaPosterColumns());

        resultsGrid.setStretchMode(
                GridView.STRETCH_COLUMN_WIDTH);

        resultsGrid.setHorizontalSpacing(
                dp(7));

        resultsGrid.setVerticalSpacing(
                dp(8));

        resultsGrid.setGravity(
                Gravity.CENTER);

        resultsGrid.setClipToPadding(
                false);

        resultsGrid.setSelector(
                makeBackground(
                        Color.TRANSPARENT,
                        GOLD,
                        10));

        resultsGrid.setDrawSelectorOnTop(
                true);

        root.addView(
                resultsGrid,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        View.OnClickListener runSearch =
                v -> {

                    String query =
                            search.getText() == null
                                    ? ""
                                    : search
                                    .getText()
                                    .toString();

                    if (normalizeSearchText(
                            query)
                            .length() < 2) {

                        searchGeneration.incrementAndGet();
                        searchButton.setEnabled(true);
                        // Never leave results from a previous query visible
                        // after the user submits a different, invalid query.
                        closeActiveMediaAdapter();
                        resultsGrid.setOnItemClickListener(null);
                        resultsGrid.setAdapter(null);
                        status.setText(
                                "Enter at least 2 letters.");

                        return;
                    }

                    final int thisSearch = searchGeneration.incrementAndGet();

                    status.setText(
                            "Searching local catalogue...");

                    searchButton.setEnabled(
                            false);

                    closeActiveMediaAdapter();
                    // Clear previous query results immediately. Otherwise the user
                    // can select a stale title while the new SQLite query runs.
                    resultsGrid.setOnItemClickListener(null);
                    resultsGrid.setAdapter(null);

                    new Thread(() -> {
                        try {
                            ArrayList<MovieItem> movies =
                                    new ArrayList<MovieItem>();

                            ArrayList<SeriesItem> seriesList =
                                    new ArrayList<SeriesItem>();

                            String normalized =
                                    normalizeSearchText(
                                            query);

                            // Search the on-device catalogue, including locally cached cast.
                            // Provider API and backend are not used for this search.
                            SQLiteDatabase localDb = getCatalogueDbHelper().getReadableDatabase();
                            // Capture the provider once so both result sets belong to
                            // the same playlist, even if the user navigates away.
                            final String searchProviderKey = getCatalogueProviderKey();
                            // One SQLite search across both media types. No provider or backend requests.
                            for (int kind = 0; kind < 2; kind++) {
                                // Avoid scanning the second large table for a search
                                // that the user has already cancelled or replaced.
                                if (thisSearch != searchGeneration.get()) return;
                                boolean isMovies = kind == 0;
                                String table = isMovies ? "catalogue_movies" : "catalogue_series";
                                String[] columns = isMovies
                                        ? new String[]{"stream_id", "name", "category_id", "extension", "direct_source", "rating", "year", "icon", "plot", "cast", "director", "genre", "trailer", "duration"}
                                        : new String[]{"series_id", "name", "category_id", "rating", "year", "cover", "plot", "cast", "director", "genre", "trailer"};
                                Cursor localCursor = null;
                                try {
                                    localCursor = localDb.query(
                                            table, columns,
                                            "provider_key=? AND (normalized_name LIKE ? OR normalized_cast LIKE ?)",
                                            new String[]{searchProviderKey, "%" + normalized + "%", "%" + normalized + "%"},
                                            null, null,
                                            "CASE WHEN normalized_name LIKE "
                                                    + android.database.DatabaseUtils.sqlEscapeString("%" + normalized + "%")
                                                    + " THEN 0 ELSE 1 END, name COLLATE NOCASE ASC",
                                            "500");
                                    while (localCursor.moveToNext()) {
                                        if (thisSearch != searchGeneration.get()) return;
                                        if (isMovies) {
                                            movies.add(MediaItemMapper.movieFromCursor(localCursor, mediaItemCursorHost()));
                                        } else {
                                            seriesList.add(MediaItemMapper.seriesFromCursor(localCursor));
                                        }
                                    }
                                } finally {
                                    if (localCursor != null) localCursor.close();
                                }
                            }

                            final ArrayList<MovieItem> finalMovies =
                                    movies;

                            final ArrayList<SeriesItem> finalSeries =
                                    seriesList;

                            runOnUiThread(() -> {
                                if (thisSearch != searchGeneration.get() || root.getParent() == null) return;
                                searchButton.setEnabled(
                                        true);

                                MediaGridAdapter adapter =
                                        new MediaGridAdapter(
                                                "ALL",
                                                finalMovies,
                                                finalSeries,
                                                "",
                                                null);

                                resultsGrid.setAdapter(
                                        adapter);
attachStableMediaGridSelection(resultsGrid, adapter);

                                resultsGrid.setOnItemClickListener(
                                        (parent,
                                         view,
                                         position,
                                         id) -> {

                                            Object item =
                                                    adapter.getItem(
                                                            position);

                                            // Prevent a pending search from repainting this screen
                                            // after a result opens its detail page.
                                            searchGeneration.incrementAndGet();
                                            if (item instanceof MovieItem) {
                                                showMovieDetails(
                                                        (MovieItem) item);

                                            } else if (item instanceof SeriesItem) {
                                                showSeriesDetails(
                                                        (SeriesItem) item);
                                            }
                                        });

                                activeMediaAdapter =
                                        adapter;

                                activeMediaGridView =
                                        resultsGrid;

                                activeMediaBrowseType =
                                        mediaType;

                                activeMediaCategoryId =
                                        "";

                                int matches =
                                        adapter.getCount();

                                status.setText(matches == 0
                                        ? "No matches in your imported local catalogue."
                                        : finalMovies.size() + " movies, " + finalSeries.size()
                                                + " series • local SQLite search (up to 500 each)");

                                if (matches > 0) {
                                    resultsGrid.setSelection(
                                            0);
                                }
                            });

                        } catch (Exception e) {
                            final String message =
                                    safeErrorMessage(
                                            e);

                            runOnUiThread(() -> {
                                if (thisSearch != searchGeneration.get() || root.getParent() == null) return;
                                searchButton.setEnabled(
                                        true);

                                status.setText(
                                        "Search failed: "
                                                + message);
                            });
                        }
                    }).start();
                };

        searchButton.setOnClickListener(
                runSearch);

        search.setOnEditorActionListener(
                (v,
                 actionId,
                 event) -> {

                    runSearch.onClick(
                            v);

                    return true;
                });

        setContentView(
                root);

        // Prepopulate searches launched by selecting a cast member.
        search.setText(safe(initialQuery));
        search.setSelection(search.length());
        search.post(() -> {
            if (normalizeSearchText(initialQuery).length() >= 2) {
                runSearch.onClick(search);
            } else {
                search.requestFocus();
            }
        });
    }



    private MovieSearchResult streamSearchMovies(String query)
            throws Exception {

        String url =
                buildXtreamApiUrl(
                        "get_vod_streams",
                        null,
                        null);

        MovieSearchResult result =
                new MovieSearchResult();

        final String normalizedQuery =
                normalizeSearchText(
                        query);

        final HashSet<String> hiddenCategories =
                getHiddenEditorIds(
                        "MOVIES");

        final int[] scanned =
                {0};

        streamJsonArray(
                url,
                reader -> {

                    scanned[0]++;

                    // Safety guard against pathological provider catalogues.
                    if (scanned[0] > 50000) {
                        reader.skipValue();
                        return;
                    }

                    String movieName =
                            "";

                    String categoryId =
                            "";

                    String streamId =
                            "";

                    String extension =
                            "mp4";

                    String directSource =
                            "";

                    String rating =
                            "";

                    String year =
                            "";

                    String icon =
                            "";

                    reader.beginObject();

                    while (reader.hasNext()) {
                        String field =
                                reader.nextName();

                        if (field.equals(
                                "name")) {

                            movieName =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "category_id")) {

                            categoryId =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "stream_id")) {

                            streamId =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "container_extension")) {

                            extension =
                                    sanitizeMediaExtension(
                                            readJsonString(
                                                    reader));

                        } else if (field.equals(
                                "direct_source")) {

                            directSource =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "rating")) {

                            rating =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "year")) {

                            year =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "stream_icon")) {

                            icon =
                                    readJsonString(
                                            reader);

                        } else {
                            // Skip cast, plot, genre, trailer and every other
                            // heavy field during simple title search.
                            reader.skipValue();
                        }
                    }

                    reader.endObject();

                    if (streamId.isEmpty()
                            || "null".equals(
                            streamId)
                            || hiddenCategories.contains(
                            categoryId)) {

                        return;
                    }

                    if (!normalizeSearchText(
                            movieName)
                            .contains(
                            normalizedQuery)) {

                        return;
                    }

                    result.matchCount++;

                    if (result.items.size()
                            < 30) {

                        MovieItem movie =
                                new MovieItem();

                        movie.name =
                                movieName;

                        movie.categoryId =
                                categoryId;

                        movie.streamId =
                                streamId;

                        movie.extension =
                                extension;

                        movie.directSource =
                                directSource;

                        movie.rating =
                                rating;

                        movie.year =
                                year;

                        movie.icon =
                                icon;

                        result.items.add(
                                movie);
                    }
                });

        return result;
    }




    private SeriesSearchResult streamSearchSeries(String query)
            throws Exception {

        String url =
                buildXtreamApiUrl(
                        "get_series",
                        null,
                        null);

        SeriesSearchResult result =
                new SeriesSearchResult();

        final String normalizedQuery =
                normalizeSearchText(
                        query);

        final HashSet<String> hiddenCategories =
                getHiddenEditorIds(
                        "SERIES");

        final int[] scanned =
                {0};

        streamJsonArray(
                url,
                reader -> {

                    scanned[0]++;

                    if (scanned[0] > 50000) {
                        reader.skipValue();
                        return;
                    }

                    String seriesName =
                            "";

                    String categoryId =
                            "";

                    String seriesId =
                            "";

                    String rating =
                            "";

                    String year =
                            "";

                    String cover =
                            "";

                    reader.beginObject();

                    while (reader.hasNext()) {
                        String field =
                                reader.nextName();

                        if (field.equals(
                                "name")) {

                            seriesName =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "category_id")) {

                            categoryId =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "series_id")) {

                            seriesId =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "rating")) {

                            rating =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "year")
                                || field.equals(
                                "releaseDate")) {

                            year =
                                    readJsonString(
                                            reader);

                        } else if (field.equals(
                                "cover")
                                || field.equals(
                                "cover_big")
                                || field.equals(
                                "stream_icon")) {

                            cover =
                                    readJsonString(
                                            reader);

                        } else {
                            reader.skipValue();
                        }
                    }

                    reader.endObject();

                    if (seriesId.isEmpty()
                            || "null".equals(
                            seriesId)
                            || hiddenCategories.contains(
                            categoryId)) {

                        return;
                    }

                    if (!normalizeSearchText(
                            seriesName)
                            .contains(
                            normalizedQuery)) {

                        return;
                    }

                    result.matchCount++;

                    if (result.items.size()
                            < 30) {

                        SeriesItem series =
                                new SeriesItem();

                        series.name =
                                seriesName;

                        series.categoryId =
                                categoryId;

                        series.seriesId =
                                seriesId;

                        series.rating =
                                rating;

                        series.year =
                                year;

                        series.cover =
                                cover;

                        result.items.add(
                                series);
                    }
                });

        return result;
    }


    private interface JsonArrayItemReader {
        void read(JsonReader reader) throws Exception;
    }

    private void streamJsonArray(
            String requestUrl,
            JsonArrayItemReader itemReader)
            throws Exception {

        XtreamJsonArrayTransport.stream(
                requestUrl,
                reader ->
                        itemReader.read(
                                reader));
    }

    private String readJsonString(JsonReader reader)
            throws Exception {

        JsonToken token = reader.peek();

        if (token == JsonToken.NULL) {
            reader.nextNull();
            return "";
        }

        if (token == JsonToken.STRING
                || token == JsonToken.NUMBER
                || token == JsonToken.BOOLEAN) {
            return reader.nextString();
        }

        reader.skipValue();
        return "";
    }

    private void showMovieCategory(
            String categoryId,
            String categoryName) {

        showMediaLoadingScreen(
                "MOVIES",
                categoryName,
                () -> showMovies());

        new Thread(() -> {
            try {
                String text =
                        downloadPlaylistText(
                                buildXtreamApiUrl(
                                        "get_vod_streams",
                                        "category_id",
                                        categoryId));

                JSONArray array = new JSONArray(text);
                ArrayList<MovieItem> movies =
                        new ArrayList<MovieItem>();

                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);

                    if (item == null) {
                        continue;
                    }

                    MovieItem movie = new MovieItem();
                    movie.name = item.optString("name", "Movie");
                    movie.categoryId = item.optString("category_id", categoryId);
                    movie.streamId = String.valueOf(item.opt("stream_id"));
                    movie.extension = sanitizeMediaExtension(
                            item.optString("container_extension", "mp4"));
                    movie.directSource = item.optString("direct_source", "");
                    movie.rating = item.optString("rating", "");
                    movie.year = item.optString("year", "");
                    movie.icon = firstNonEmpty(
                            item.optString("stream_icon", ""),
                            item.optString("movie_image", ""),
                            item.optString("cover_big", ""));
                    movie.plot = firstNonEmpty(
                            item.optString("plot", ""),
                            item.optString("description", ""));
                    movie.cast = firstNonEmpty(
                            item.optString("cast", ""),
                            item.optString("actors", ""));
                    movie.director = item.optString("director", "");
                    movie.genre = item.optString("genre", "");
                    movie.trailer = item.optString("youtube_trailer", "");

                    if (!movie.streamId.isEmpty()
                            && !"null".equals(movie.streamId)) {
                        movies.add(movie);
                    }
                }

                runOnUiThread(() ->
                        renderMovieCategory(
                                categoryName,
                                movies));

            } catch (Exception e) {
                final String message = safeErrorMessage(e);

                runOnUiThread(() ->
                        showMediaErrorScreen(
                                "MOVIES",
                                message,
                                () -> showMovieCategory(categoryId, categoryName)));
            }
        }).start();
    }

    private void renderMovieCategory(
            String categoryName,
            ArrayList<MovieItem> movies) {

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        scrollView.addView(root);

        TextView back = new TextView(this);
        back.setText("<  MOVIES");
        back.setTextColor(GOLD);
        back.setTextSize(16);
        back.setClickable(true);
        back.setFocusable(true);
        back.setPadding(0, 0, 0, dp(20));
        back.setOnClickListener(v -> showMovies());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText(categoryName);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(26);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        TextView count = new TextView(this);
        count.setText(movies.size() + " movies");
        count.setTextColor(SILVER);
        count.setTextSize(13);
        count.setPadding(0, dp(5), 0, dp(12));
        root.addView(count);

        EditText search =
                createMediaSearchBox(
                        "Search movies — punctuation doesn't matter");

        LinearLayout.LayoutParams searchParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(52));

        searchParams.setMargins(
                0,
                0,
                0,
                dp(16));

        root.addView(search, searchParams);

        LinearLayout movieContainer =
                new LinearLayout(this);

        movieContainer.setOrientation(
                LinearLayout.VERTICAL);

        root.addView(movieContainer);

        renderMovieResults(
                movieContainer,
                movies,
                "",
                count);

        search.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int countValue) {

                        try {
                            renderMovieResults(
                                    movieContainer,
                                    movies,
                                    s == null ? "" : s.toString(),
                                    count);
                        } catch (RuntimeException searchError) {
                            count.setText(
                                    "Search error: "
                                            + safeErrorMessage(searchError));
                        }
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s) {
                    }
                });

        setContentView(scrollView);
    }

    private void renderMovieResults(
            LinearLayout container,
            ArrayList<MovieItem> movies,
            String query,
            TextView countView) {

        container.removeAllViews();

        ArrayList<MovieItem> matches =
                new ArrayList<MovieItem>();

        for (MovieItem movie : movies) {
            if (searchMatches(
                    query,
                    movie.name,
                    movie.year,
                    movie.rating)) {
                matches.add(movie);
            }
        }

        countView.setText(
                query == null || query.trim().isEmpty()
                        ? movies.size() + " movies"
                        : matches.size() + " matching movies");

        int limit =
                Math.min(
                        matches.size(),
                        30);

        for (int i = 0;
             i < limit;
             i++) {

            MovieItem movie =
                    matches.get(i);

            LinearLayout card =
                    new LinearLayout(this);

            card.setOrientation(
                    LinearLayout.VERTICAL);

            card.setPadding(
                    dp(18),
                    dp(14),
                    dp(18),
                    dp(14));

            card.setClickable(true);
            card.setFocusable(true);

            card.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(52, 52, 56),
                            14));

            TextView title =
                    new TextView(this);

            title.setText(movie.name);
            title.setTextColor(Color.WHITE);
            title.setTextSize(16);

            title.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD);

            card.addView(title);

            TextView info =
                    new TextView(this);

            String details = "";

            if (!movie.year.isEmpty()) {
                details = movie.year;
            }

            if (!movie.rating.isEmpty()) {
                if (!details.isEmpty()) {
                    details += "   |   ";
                }

                details +=
                        "Rating "
                                + movie.rating;
            }

            if (details.isEmpty()) {
                details =
                        movie.extension
                                .toUpperCase(Locale.US);
            }

            long movieResumePosition =
                    getSavedResumePosition(
                            buildResumeKey(
                                    "MOVIE",
                                    movie.streamId));

            if (movieResumePosition >= 30000L) {
                details +=
                        "   •   RESUME "
                                + formatPlaybackTime(
                                        movieResumePosition);
            }

            info.setText(details);
            info.setTextColor(SILVER);
            info.setTextSize(12);

            info.setPadding(
                    0,
                    dp(5),
                    0,
                    0);

            card.addView(info);

            card.setOnClickListener(
                    v -> playMovie(movie));

            addFocusStyle(card, 14);

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(84));

            params.setMargins(
                    0,
                    0,
                    0,
                    dp(10));

            container.addView(
                    card,
                    params);
        }

        if (matches.isEmpty()) {
            TextView empty =
                    new TextView(this);

            empty.setText(
                    "No matching movies.");

            empty.setTextColor(SILVER);
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);

            empty.setPadding(
                    dp(12),
                    dp(30),
                    dp(12),
                    dp(30));

            container.addView(empty);
            return;
        }

        if (matches.size() > limit) {
            TextView more =
                    new TextView(this);

            more.setText(
                    "Showing "
                            + limit
                            + " of "
                            + matches.size()
                            + " matching movies.");

            more.setTextColor(SILVER);
            more.setTextSize(12);
            more.setGravity(Gravity.CENTER);

            more.setPadding(
                    0,
                    dp(15),
                    0,
                    dp(10));

            container.addView(more);
        }
    }

    private void playMovie(MovieItem movie) {
        try {
            releasePlayer();

            selectedMediaType = "MOVIE";
            selectedReturnScreen = "MOVIES";
            selectedChannel = movie.name;
            selectedNow = "";
            selectedNext = "";
            selectedGroup = "Movie";
            selectedStreamId = movie.streamId;
            selectedContainerExtension = movie.extension;
            selectedDirectSource = movie.directSource;
            selectedStreamUrl =
                    buildXtreamMediaUrl(
                            "movie",
                            movie.streamId,
                            movie.extension);

            currentResumeKey =
                    buildResumeKey(
                            "MOVIE",
                            movie.streamId);

            saveResumeIdentityForMovie(movie);

            playbackStartPositionMs = 0L;
            handlingPlaybackEnd = false;
            activeEpisodeIndex = -1;

            showPlayerScreen();
            enterPlayerFullScreen();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Movie URL failed: " + safeErrorMessage(e),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void showSeriesCategory(
            String categoryId,
            String categoryName) {

        showMediaLoadingScreen(
                "SERIES",
                categoryName,
                () -> showSeries());

        new Thread(() -> {
            try {
                String text =
                        downloadPlaylistText(
                                buildXtreamApiUrl(
                                        "get_series",
                                        "category_id",
                                        categoryId));

                JSONArray array = new JSONArray(text);
                ArrayList<SeriesItem> seriesList =
                        new ArrayList<SeriesItem>();

                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);

                    if (item == null) {
                        continue;
                    }

                    SeriesItem series = new SeriesItem();
                    series.name = item.optString("name", "Series");
                    series.categoryId = item.optString("category_id", categoryId);
                    series.seriesId = String.valueOf(item.opt("series_id"));
                    series.rating = item.optString("rating", "");
                    series.year = firstNonEmpty(
                            item.optString("year", ""),
                            item.optString("releaseDate", ""));
                    series.plot = firstNonEmpty(
                            item.optString("plot", ""),
                            item.optString("description", ""));
                    series.cover = firstNonEmpty(
                            item.optString("cover", ""),
                            item.optString("cover_big", ""),
                            item.optString("stream_icon", ""));
                    series.cast = firstNonEmpty(
                            item.optString("cast", ""),
                            item.optString("actors", ""));
                    series.director = item.optString("director", "");
                    series.genre = item.optString("genre", "");
                    series.trailer = item.optString("youtube_trailer", "");

                    if (!series.seriesId.isEmpty()
                            && !"null".equals(series.seriesId)) {
                        seriesList.add(series);
                    }
                }

                runOnUiThread(() ->
                        renderSeriesCategory(
                                categoryName,
                                seriesList));

            } catch (Exception e) {
                final String message = safeErrorMessage(e);

                runOnUiThread(() ->
                        showMediaErrorScreen(
                                "SERIES",
                                message,
                                () -> showSeriesCategory(categoryId, categoryName)));
            }
        }).start();
    }

    private void renderSeriesCategory(
            String categoryName,
            ArrayList<SeriesItem> seriesList) {

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        scrollView.addView(root);

        TextView back = new TextView(this);
        back.setText("<  SERIES");
        back.setTextColor(GOLD);
        back.setTextSize(16);
        back.setClickable(true);
        back.setFocusable(true);
        back.setPadding(0, 0, 0, dp(20));
        back.setOnClickListener(v -> showSeries());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText(categoryName);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(26);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        TextView count = new TextView(this);
        count.setText(seriesList.size() + " series");
        count.setTextColor(SILVER);
        count.setTextSize(13);
        count.setPadding(0, dp(5), 0, dp(12));
        root.addView(count);

        EditText search =
                createMediaSearchBox(
                        "Search series — punctuation doesn't matter");

        LinearLayout.LayoutParams searchParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(52));

        searchParams.setMargins(
                0,
                0,
                0,
                dp(16));

        root.addView(search, searchParams);

        LinearLayout seriesContainer =
                new LinearLayout(this);

        seriesContainer.setOrientation(
                LinearLayout.VERTICAL);

        root.addView(seriesContainer);

        renderSeriesResults(
                seriesContainer,
                seriesList,
                "",
                count);

        search.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int countValue) {

                        try {
                            renderSeriesResults(
                                    seriesContainer,
                                    seriesList,
                                    s == null ? "" : s.toString(),
                                    count);
                        } catch (RuntimeException searchError) {
                            count.setText(
                                    "Search error: "
                                            + safeErrorMessage(searchError));
                        }
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s) {
                    }
                });

        setContentView(scrollView);
    }

    private void renderSeriesResults(
            LinearLayout container,
            ArrayList<SeriesItem> seriesList,
            String query,
            TextView countView) {

        container.removeAllViews();

        ArrayList<SeriesItem> matches =
                new ArrayList<SeriesItem>();

        for (SeriesItem series : seriesList) {
            if (searchMatches(
                    query,
                    series.name,
                    series.year,
                    series.rating,
                    series.plot)) {
                matches.add(series);
            }
        }

        countView.setText(
                query == null || query.trim().isEmpty()
                        ? seriesList.size() + " series"
                        : matches.size() + " matching series");

        int limit =
                Math.min(
                        matches.size(),
                        30);

        for (int i = 0;
             i < limit;
             i++) {

            SeriesItem series =
                    matches.get(i);

            LinearLayout card =
                    new LinearLayout(this);

            card.setOrientation(
                    LinearLayout.VERTICAL);

            card.setPadding(
                    dp(18),
                    dp(14),
                    dp(18),
                    dp(14));

            card.setClickable(true);
            card.setFocusable(true);

            card.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(52, 52, 56),
                            14));

            TextView title =
                    new TextView(this);

            title.setText(series.name);
            title.setTextColor(Color.WHITE);
            title.setTextSize(16);

            title.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD);

            card.addView(title);

            TextView info =
                    new TextView(this);

            String details = "";

            if (!series.year.isEmpty()) {
                details = series.year;
            }

            if (!series.rating.isEmpty()) {
                if (!details.isEmpty()) {
                    details += "   |   ";
                }

                details +=
                        "Rating "
                                + series.rating;
            }

            if (details.isEmpty()) {
                details = "Open episodes";
            }

            info.setText(details);
            info.setTextColor(SILVER);
            info.setTextSize(12);

            info.setPadding(
                    0,
                    dp(5),
                    0,
                    0);

            card.addView(info);

            card.setOnClickListener(
                    v -> showSeriesEpisodes(series));

            addFocusStyle(card, 14);

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(84));

            params.setMargins(
                    0,
                    0,
                    0,
                    dp(10));

            container.addView(
                    card,
                    params);
        }

        if (matches.isEmpty()) {
            TextView empty =
                    new TextView(this);

            empty.setText(
                    "No matching series.");

            empty.setTextColor(SILVER);
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);

            empty.setPadding(
                    dp(12),
                    dp(30),
                    dp(12),
                    dp(30));

            container.addView(empty);
            return;
        }

        if (matches.size() > limit) {
            TextView more =
                    new TextView(this);

            more.setText(
                    "Showing "
                            + limit
                            + " of "
                            + matches.size()
                            + " matching series.");

            more.setTextColor(SILVER);
            more.setTextSize(12);
            more.setGravity(Gravity.CENTER);

            more.setPadding(
                    0,
                    dp(15),
                    0,
                    dp(10));

            container.addView(more);
        }
    }

    private void showSeriesEpisodes(SeriesItem series) {
        showMediaLoadingScreen(
                "SERIES",
                series.name,
                () -> showSeries());

        new Thread(() -> {
            try {
                String text =
                        downloadPlaylistText(
                                buildXtreamApiUrl(
                                        "get_series_info",
                                        "series_id",
                                        series.seriesId));

                JSONObject object = new JSONObject(text);
                try {
                    CatalogueDetailStore.save(
                            getCatalogueDbHelper().getWritableDatabase(),
                            getCatalogueProviderKey(),
                            "SERIES", series.seriesId, text);
                } catch (Exception cacheError) {
                    android.util.Log.w("PREMIUM_PLAYER",
                            "Series metadata storage failed", cacheError);
                }

                JSONObject episodesObject = object.optJSONObject("episodes");

                ArrayList<EpisodeItem> episodes =
                        new ArrayList<EpisodeItem>();

                if (episodesObject != null) {
                    Iterator<String> keys = episodesObject.keys();

                    while (keys.hasNext()) {
                        String seasonKey = keys.next();
                        JSONArray episodeArray = episodesObject.optJSONArray(seasonKey);

                        if (episodeArray == null) {
                            continue;
                        }

                        int seasonNumber = parseIntSafe(seasonKey, 0);

                        for (int i = 0; i < episodeArray.length(); i++) {
                            JSONObject item = episodeArray.optJSONObject(i);

                            if (item == null) {
                                continue;
                            }

                            EpisodeItem episode = new EpisodeItem();
                            episode.id = item.optString("id", "");
                            episode.title = item.optString("title", "Episode");
                            episode.episodeNumber = item.optInt("episode_num", i + 1);
                            episode.seasonNumber = seasonNumber;
                            episode.extension = sanitizeMediaExtension(
                                    item.optString("container_extension", "mp4"));
                            episode.directSource = item.optString("direct_source", "");

                            if (!episode.id.isEmpty()) {
                                episodes.add(episode);
                            }
                        }
                    }
                }

                Collections.sort(
                        episodes,
                        new Comparator<EpisodeItem>() {
                            @Override
                            public int compare(
                                    EpisodeItem a,
                                    EpisodeItem b) {

                                if (a.seasonNumber != b.seasonNumber) {
                                    return a.seasonNumber - b.seasonNumber;
                                }

                                return a.episodeNumber - b.episodeNumber;
                            }
                        });

                runOnUiThread(() ->
                        renderSeriesEpisodes(
                                series,
                                episodes));

            } catch (Exception e) {
                final String message = safeErrorMessage(e);

                runOnUiThread(() ->
                        showMediaErrorScreen(
                                "SERIES",
                                message,
                                () -> showSeriesEpisodes(series)));
            }
        }).start();
    }

    private void renderSeriesEpisodes(
            SeriesItem series,
            ArrayList<EpisodeItem> episodes) {

        activeEpisodeSeries = series;

        activeSeriesEpisodes.clear();
        activeSeriesEpisodes.addAll(episodes);
        activeEpisodeIndex = -1;

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        scrollView.addView(root);

        TextView back = new TextView(this);
        back.setText("<  SERIES");
        back.setTextColor(GOLD);
        back.setTextSize(16);
        back.setClickable(true);
        back.setFocusable(true);
        back.setPadding(0, 0, 0, dp(20));
        back.setOnClickListener(v -> showSeries());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText(series.name);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(26);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        if (!series.plot.isEmpty()) {
            TextView plot = new TextView(this);
            plot.setText(series.plot);
            plot.setTextColor(SILVER);
            plot.setTextSize(13);
            plot.setMaxLines(4);
            plot.setPadding(0, dp(8), 0, dp(12));
            root.addView(plot);
        }

        TextView count = new TextView(this);
        count.setText(episodes.size() + " episodes");
        count.setTextColor(SILVER);
        count.setTextSize(13);
        count.setPadding(0, dp(5), 0, dp(12));
        root.addView(count);

        EditText search =
                createMediaSearchBox(
                        "Search episodes — punctuation doesn't matter");

        LinearLayout.LayoutParams searchParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(52));

        searchParams.setMargins(
                0,
                0,
                0,
                dp(16));

        root.addView(search, searchParams);

        LinearLayout episodeContainer =
                new LinearLayout(this);

        episodeContainer.setOrientation(
                LinearLayout.VERTICAL);

        root.addView(episodeContainer);

        renderEpisodeResults(
                episodeContainer,
                episodes,
                "",
                count);

        search.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int countValue) {

                        renderEpisodeResults(
                                episodeContainer,
                                episodes,
                                s == null ? "" : s.toString(),
                                count);
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s) {
                    }
                });

        setContentView(scrollView);
    }

    private void renderEpisodeResults(
            LinearLayout container,
            ArrayList<EpisodeItem> episodes,
            String query,
            TextView countView) {

        container.removeAllViews();

        ArrayList<EpisodeItem> matches =
                new ArrayList<EpisodeItem>();

        for (EpisodeItem episode : episodes) {
            String seasonEpisode =
                    "S"
                            + episode.seasonNumber
                            + " E"
                            + episode.episodeNumber;

            if (searchMatches(
                    query,
                    episode.title,
                    seasonEpisode,
                    String.valueOf(episode.seasonNumber),
                    String.valueOf(episode.episodeNumber))) {
                matches.add(episode);
            }
        }

        countView.setText(
                query == null || query.trim().isEmpty()
                        ? episodes.size() + " episodes"
                        : matches.size() + " matching episodes");

        int limit =
                Math.min(
                        matches.size(),
                        120);

        for (int i = 0;
             i < limit;
             i++) {

            EpisodeItem episode =
                    matches.get(i);

            LinearLayout card =
                    new LinearLayout(this);

            card.setOrientation(
                    LinearLayout.VERTICAL);

            card.setPadding(
                    dp(18),
                    dp(14),
                    dp(18),
                    dp(14));

            card.setClickable(true);
            card.setFocusable(true);

            card.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(52, 52, 56),
                            14));

            TextView title =
                    new TextView(this);

            title.setText(
                    "S"
                            + episode.seasonNumber
                            + " E"
                            + episode.episodeNumber
                            + "  "
                            + episode.title);

            title.setTextColor(Color.WHITE);
            title.setTextSize(15);

            title.setTypeface(
                    Typeface.DEFAULT,
                    Typeface.BOLD);

            card.addView(title);

            TextView info =
                    new TextView(this);

            String episodeInfo =
                    episode.extension
                            .toUpperCase(Locale.US);

            long episodeResumePosition =
                    getSavedResumePosition(
                            buildResumeKey(
                                    "EPISODE",
                                    episode.id));

            if (episodeResumePosition >= 30000L) {
                episodeInfo +=
                        "   •   RESUME "
                                + formatPlaybackTime(
                                        episodeResumePosition);
            }

            info.setText(episodeInfo);

            info.setTextColor(SILVER);
            info.setTextSize(11);

            info.setPadding(
                    0,
                    dp(5),
                    0,
                    0);

            card.addView(info);

            card.setOnClickListener(
                    v -> playEpisode(
                            findSeriesForEpisodeFallback(),
                            episode));

            // Override click below if we still have the real series object
            // supplied by the parent renderer. This view is rebuilt inside
            // renderSeriesEpisodes(), so tag it with the episode only.
            card.setTag(episode);

            addFocusStyle(card, 14);

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(82));

            params.setMargins(
                    0,
                    0,
                    0,
                    dp(10));

            container.addView(
                    card,
                    params);
        }

        if (matches.isEmpty()) {
            TextView empty =
                    new TextView(this);

            empty.setText(
                    "No matching episodes.");

            empty.setTextColor(SILVER);
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);

            empty.setPadding(
                    dp(12),
                    dp(30),
                    dp(12),
                    dp(30));

            container.addView(empty);
        }
    }

    private SeriesItem findSeriesForEpisodeFallback() {
        if (activeEpisodeSeries != null) {
            return activeEpisodeSeries;
        }

        SeriesItem fallback =
                new SeriesItem();

        fallback.name =
                selectedChannel == null
                        ? "Series"
                        : selectedChannel;

        return fallback;
    }

    private void playEpisode(
            SeriesItem series,
            EpisodeItem episode) {

        try {
            releasePlayer();

            activeEpisodeSeries = series;
            activeEpisodeIndex =
                    findEpisodeIndex(
                            episode.id);

            selectedMediaType = "EPISODE";
            selectedReturnScreen = "SERIES";
            selectedChannel =
                    series.name
                            + " - S"
                            + episode.seasonNumber
                            + " E"
                            + episode.episodeNumber;
            selectedNow = episode.title;
            selectedNext = "";
            selectedGroup = "Series";
            selectedStreamId = episode.id;
            selectedContainerExtension = episode.extension;
            selectedDirectSource = episode.directSource;
            selectedStreamUrl =
                    buildXtreamMediaUrl(
                            "series",
                            episode.id,
                            episode.extension);

            currentResumeKey =
                    buildResumeKey(
                            "EPISODE",
                            episode.id);

            saveResumeIdentityForEpisode(series, episode);

            playbackStartPositionMs = 0L;
            handlingPlaybackEnd = false;

            showPlayerScreen();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Episode URL failed: " + safeErrorMessage(e),
                    Toast.LENGTH_LONG).show();
        }
    }

    private int findEpisodeIndex(
            String episodeId) {

        if (episodeId == null
                || episodeId.isEmpty()) {
            return -1;
        }

        for (int i = 0;
             i < activeSeriesEpisodes.size();
             i++) {

            EpisodeItem episode =
                    activeSeriesEpisodes.get(i);

            if (episodeId.equals(
                    episode.id)) {
                return i;
            }
        }

        return -1;
    }

    private void autoPlayNextEpisode() {
        if (!"EPISODE".equals(
                selectedMediaType)) {
            return;
        }

        int nextIndex =
                activeEpisodeIndex + 1;

        if (activeEpisodeSeries == null
                || activeEpisodeIndex < 0
                || nextIndex < 0
                || nextIndex >= activeSeriesEpisodes.size()) {

            setPlaybackKeepAwake(false);

            if (activePlaybackStatus != null) {
                activePlaybackStatus.setText(
                        "Episode finished • no next episode available.");
            }
            return;
        }

        EpisodeItem nextEpisode =
                activeSeriesEpisodes.get(
                        nextIndex);

        Toast.makeText(
                this,
                "Playing next: S"
                        + nextEpisode.seasonNumber
                        + " E"
                        + nextEpisode.episodeNumber
                        + " "
                        + nextEpisode.title,
                Toast.LENGTH_SHORT).show();

        playEpisode(
                activeEpisodeSeries,
                nextEpisode);
    }

    private void showMediaLoadingScreen(
            String section,
            String title,
            Runnable backAction) {

        releasePlayer();
        onHomeScreen = false;

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20), dp(24), dp(20), dp(30));
        screen.setBackgroundColor(BLACK);

        TextView back = new TextView(this);
        back.setText("<  " + section);
        back.setTextColor(GOLD);
        back.setTextSize(16);
        back.setClickable(true);
        back.setFocusable(true);
        back.setPadding(0, 0, 0, dp(20));
        back.setOnClickListener(v -> backAction.run());
        screen.addView(back);

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(26);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        screen.addView(heading);

        TextView loading = new TextView(this);
        loading.setText("Loading...");
        loading.setTextColor(SILVER);
        loading.setTextSize(14);
        loading.setPadding(0, dp(15), 0, 0);
        screen.addView(loading);

        setContentView(screen);
    }

    private void showMediaErrorScreen(
            String section,
            String message,
            Runnable retryAction) {

        releasePlayer();
        onHomeScreen = false;

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20), dp(24), dp(20), dp(30));
        screen.setBackgroundColor(BLACK);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        screen.addView(back);

        TextView heading = new TextView(this);
        heading.setText(section);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        screen.addView(heading);

        TextView error = new TextView(this);
        error.setText("Could not load this section:\n" + message);
        error.setTextColor(SILVER);
        error.setTextSize(14);
        error.setPadding(0, dp(15), 0, dp(20));
        screen.addView(error);

        Button retry = new Button(this);
        retry.setText("RETRY");
        retry.setTextColor(BLACK);
        retry.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        retry.setAllCaps(false);
        retry.setBackground(makeBackground(GOLD, GOLD, 14));
        retry.setOnClickListener(v -> retryAction.run());

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(50));

        screen.addView(retry, params);
        setContentView(screen);
    }

    private void addFocusStyle(
            View view,
            int radius) {

        view.setOnFocusChangeListener(
                (focusedView, focused) -> {
                    if (focused) {
                        focusedView.setBackground(
                                makeBackground(
                                        Color.rgb(35, 31, 23),
                                        GOLD,
                                        radius));
                    } else {
                        focusedView.setBackground(
                                makeBackground(
                                        CHARCOAL,
                                        Color.rgb(52, 52, 56),
                                        radius));
                    }
                });
    }

    private String buildXtreamMediaUrl(
            String mediaPath,
            String streamId,
            String extension)
            throws Exception {

        android.content.SharedPreferences prefs =
                playlistPrefs();

        String server = normalizeXtreamServer(
                prefs.getString(
                        "xtream_stream_server",
                        prefs.getString("xtream_server", "")));

        String username = prefs.getString("xtream_username", "");
        String password = prefs.getString("xtream_password", "");

        String userPath =
                URLEncoder.encode(username, "UTF-8")
                        .replace("+", "%20");

        String passPath =
                URLEncoder.encode(password, "UTF-8")
                        .replace("+", "%20");

        return server
                + "/"
                + mediaPath
                + "/"
                + userPath
                + "/"
                + passPath
                + "/"
                + streamId
                + "."
                + sanitizeMediaExtension(extension);
    }

    private String sanitizeMediaExtension(String extension) {
        String value =
                extension == null
                        ? ""
                        : extension.trim().toLowerCase(Locale.US);

        while (value.startsWith(".")) {
            value = value.substring(1);
        }

        if (value.equals("mp4")
                || value.equals("mkv")
                || value.equals("avi")
                || value.equals("m4v")
                || value.equals("mov")
                || value.equals("ts")
                || value.equals("webm")
                || value.equals("3gp")) {

            return value;
        }

        return "mp4";
    }

    private int parseIntSafe(
            String value,
            int fallback) {

        try {
            return Integer.parseInt(value);
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private String safeErrorMessage(Exception error) {
        if (error == null) {
            return "Unknown error";
        }

        String message = error.getMessage();

        if (message == null
                || message.trim().isEmpty()) {
            return error.getClass().getSimpleName();
        }

        return message;
    }


    // ---------------------------------------------------------------------
    // LIVE TV
    // ---------------------------------------------------------------------

    private void showLiveTv(String initialFilter) {
        releasePlayer();
        onHomeScreen = false;
        liveBrowserMode = true;
        lastLiveChannelPressKey = "";

        activeLiveFilter =
                initialFilter == null
                        || initialFilter.trim().isEmpty()
                        ? "ALL"
                        : initialFilter;

        restoreLastLiveChannelSelection();
        ensureSelectedChannel();

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setBackgroundColor(
                BLACK);

        LinearLayout topBar =
                new LinearLayout(this);

        topBar.setOrientation(
                LinearLayout.HORIZONTAL);

        topBar.setGravity(
                Gravity.CENTER_VERTICAL);

        topBar.setPadding(
                dp(14),
                dp(8),
                dp(14),
                dp(8));

        TextView back =
                createBackText();

        back.setText(
                "<  HOME");

        back.setPadding(
                0,
                0,
                dp(18),
                0);

        back.setOnClickListener(v -> {
            liveBrowserMode = false;
            releasePlayer();
            showHome();
        });

        topBar.addView(
                back,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        dp(44)));

        TextView heading =
                new TextView(this);

        heading.setText(
                "LIVE TV");

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(
                24);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        topBar.addView(
                heading,
                new LinearLayout.LayoutParams(
                        0,
                        dp(44),
                        1f));

        TextView hint =
                new TextView(this);

        hint.setText(
                "OK: tune   •   double OK: fullscreen");

        hint.setTextColor(
                SILVER);

        hint.setTextSize(
                11);

        hint.setGravity(
                Gravity.CENTER_VERTICAL
                        | Gravity.END);

        topBar.addView(
                hint,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        dp(44)));

        root.addView(
                topBar,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(60)));

        LinearLayout panes =
                new LinearLayout(this);

        panes.setOrientation(
                LinearLayout.HORIZONTAL);

        panes.setPadding(
                dp(8),
                0,
                dp(8),
                dp(8));

        root.addView(
                panes,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        // -------------------------------------------------------------
        // LEFT 25% — CATEGORIES
        // -------------------------------------------------------------
        LinearLayout categoryPane =
                new LinearLayout(this);

        categoryPane.setOrientation(
                LinearLayout.VERTICAL);

        categoryPane.setPadding(
                dp(10),
                dp(10),
                dp(8),
                dp(10));

        categoryPane.setBackground(
                makeBackground(
                        Color.rgb(15, 15, 17),
                        Color.rgb(45, 45, 48),
                        12));

        LinearLayout.LayoutParams categoryPaneParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1f);

        categoryPaneParams.setMargins(
                0,
                0,
                dp(5),
                0);

        panes.addView(
                categoryPane,
                categoryPaneParams);

        TextView categoryHeading =
                new TextView(this);

        categoryHeading.setText(
                "CATEGORIES");

        categoryHeading.setTextColor(
                GOLD);

        categoryHeading.setTextSize(
                12);

        categoryHeading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        categoryHeading.setPadding(
                dp(4),
                0,
                0,
                dp(8));

        categoryPane.addView(
                categoryHeading);

        ScrollView categoryScroll =
                new ScrollView(this);

        categoryScroll.setFillViewport(
                true);

        LinearLayout categoryContainer =
                new LinearLayout(this);

        categoryContainer.setOrientation(
                LinearLayout.VERTICAL);

        categoryScroll.addView(
                categoryContainer);

        categoryPane.addView(
                categoryScroll,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        // -------------------------------------------------------------
        // MIDDLE 25% — CHANNELS
        // -------------------------------------------------------------
        LinearLayout channelPane =
                new LinearLayout(this);

        channelPane.setOrientation(
                LinearLayout.VERTICAL);

        channelPane.setPadding(
                dp(8),
                dp(10),
                dp(8),
                dp(10));

        channelPane.setBackground(
                makeBackground(
                        Color.rgb(15, 15, 17),
                        Color.rgb(45, 45, 48),
                        12));

        LinearLayout.LayoutParams channelPaneParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1f);

        channelPaneParams.setMargins(
                dp(5),
                0,
                dp(5),
                0);

        panes.addView(
                channelPane,
                channelPaneParams);

        TextView channelHeading =
                new TextView(this);

        channelHeading.setText(
                "CHANNELS");

        channelHeading.setTextColor(
                GOLD);

        channelHeading.setTextSize(
                12);

        channelHeading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        channelHeading.setPadding(
                dp(4),
                0,
                0,
                dp(8));

        channelPane.addView(
                channelHeading);

        EditText search =
                new EditText(this);

        search.setHint(
                "Search channels");

        search.setHintTextColor(
                Color.rgb(
                        115,
                        115,
                        120));

        search.setTextColor(
                Color.WHITE);

        search.setTextSize(
                13);

        search.setSingleLine(
                true);

        prepareTvTextInput(
                search,
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
                EditorInfo.IME_ACTION_DONE);

        search.setPadding(
                dp(10),
                dp(8),
                dp(10),
                dp(8));

        search.setBackground(
                makeBackground(
                        CHARCOAL,
                        Color.rgb(
                                55,
                                55,
                                58),
                        10));

        LinearLayout.LayoutParams searchParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(46));

        searchParams.setMargins(
                0,
                0,
                0,
                dp(8));

        channelPane.addView(
                search,
                searchParams);

        ScrollView channelScroll =
                new ScrollView(this);

        channelScroll.setFillViewport(
                true);

        LinearLayout channelContainer =
                new LinearLayout(this);

        channelContainer.setOrientation(
                LinearLayout.VERTICAL);

        channelScroll.addView(
                channelContainer);

        channelPane.addView(
                channelScroll,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        // -------------------------------------------------------------
        // RIGHT 50% — LIVE PREVIEW PLAYER
        // -------------------------------------------------------------
        LinearLayout playerPane =
                new LinearLayout(this);

        playerPane.setOrientation(
                LinearLayout.VERTICAL);

        playerPane.setPadding(
                dp(10),
                dp(10),
                dp(10),
                dp(10));

        playerPane.setBackground(
                makeBackground(
                        Color.rgb(12, 12, 14),
                        Color.rgb(55, 55, 58),
                        12));

        LinearLayout.LayoutParams playerPaneParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        2f);

        playerPaneParams.setMargins(
                dp(5),
                0,
                0,
                0);

        panes.addView(
                playerPane,
                playerPaneParams);

        PlayerView playerView =
                new PlayerView(this);

        playerView.setUseController(
                true);

        playerView.setControllerAutoShow(
                false);

        playerView.setBackgroundColor(
                Color.BLACK);

        playerView.setFocusable(
                true);

        attachTrackControlsOverlay(
                playerView);

        playerPane.addView(
                playerView,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f));

        TextView previewTitle =
                new TextView(this);

        previewTitle.setText(
                selectedChannel);

        previewTitle.setTextColor(
                Color.WHITE);

        previewTitle.setTextSize(
                20);

        previewTitle.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        previewTitle.setPadding(
                dp(4),
                dp(9),
                dp(4),
                0);

        playerPane.addView(
                previewTitle);

        TextView previewNow =
                new TextView(this);

        previewNow.setTextColor(
                SILVER);

        previewNow.setTextSize(
                13);

        previewNow.setPadding(
                dp(4),
                dp(4),
                dp(4),
                0);

        playerPane.addView(
                previewNow);

        TextView previewNext =
                new TextView(this);

        previewNext.setTextColor(
                Color.rgb(
                        135,
                        135,
                        140));

        previewNext.setTextSize(
                12);

        previewNext.setPadding(
                dp(4),
                dp(3),
                dp(4),
                0);

        playerPane.addView(
                previewNext);

        TextView previewStatus =
                new TextView(this);

        previewStatus.setTextColor(
                GOLD);

        previewStatus.setTextSize(
                11);

        previewStatus.setPadding(
                dp(4),
                dp(4),
                dp(4),
                0);

        playerPane.addView(
                previewStatus);

        final String[] activeFilter =
                {activeLiveFilter};

        final String[] activeQuery =
                {""};

        ArrayList<String> categoryNames =
                getCategoryNames();

        View firstCategoryToFocus =
                null;

        for (String category : categoryNames) {
            TextView item =
                    createLiveBrowserCategoryItem(
                            category,
                            category.equals(
                                    activeFilter[0]));

            categoryContainer.addView(
                    item,
                    liveBrowserListParams(
                            dp(48)));

            if (category.equals(
                    activeFilter[0])) {
                firstCategoryToFocus =
                        item;
            }

            item.setOnClickListener(v -> {
                activeFilter[0] =
                        category;

                activeLiveFilter =
                        category;

                playlistPrefs()
                        .edit()
                        .putString(
                                "last_live_filter",
                                category)
                        .apply();

                updateLiveBrowserCategoryHighlight(
                        categoryContainer,
                        category);

                refreshLiveBrowserChannels(
                        channelContainer,
                        category,
                        activeQuery[0],
                        playerView,
                        previewTitle,
                        previewNow,
                        previewNext,
                        previewStatus);
            });
        }

        search.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        activeQuery[0] =
                                s == null
                                        ? ""
                                        : s.toString();

                        refreshLiveBrowserChannels(
                                channelContainer,
                                activeFilter[0],
                                activeQuery[0],
                                playerView,
                                previewTitle,
                                previewNow,
                                previewNext,
                                previewStatus);
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s) {
                    }
                });

        setContentView(
                root);

        livePreviewPlayerView =
                playerView;

        livePreviewTitle =
                previewTitle;

        livePreviewNow =
                previewNow;

        livePreviewNext =
                previewNext;

        livePreviewStatus =
                previewStatus;

        activePlayerView =
                playerView;

        activePlaybackStatus =
                previewStatus;

        refreshLiveBrowserChannels(
                channelContainer,
                activeFilter[0],
                activeQuery[0],
                playerView,
                previewTitle,
                previewNow,
                previewNext,
                previewStatus);

        Channel selected =
                findSelectedChannel();

        if (selected != null) {
            startInlineLivePreview(
                    selected,
                    playerView,
                    previewTitle,
                    previewNow,
                    previewNext,
                    previewStatus);
        } else {
            previewStatus.setText(
                    "No playable Live TV channel is available.");
        }

        final View categoryFocus =
                firstCategoryToFocus;

        if (categoryFocus != null) {
            categoryFocus.post(
                    categoryFocus::requestFocus);
        }
    }


    private LiveTvUiSupport.Host liveTvUiHost() {
        return new LiveTvUiSupport.Host() {
            public int dp(int v) { return MainActivity.this.dp(v); }
            public int gold() { return GOLD; }
            public int charcoal() { return CHARCOAL; }
            public void tvReady(View v) { makeTvRemoteReady(v); }
            public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
            public String safe(String value) { return MainActivity.this.safe(value); }
        };
    }

    private LinearLayout.LayoutParams liveBrowserListParams(int height) {
        return LiveTvUiSupport.listParams(liveTvUiHost(), height);
    }

    private TextView createLiveBrowserCategoryItem(String category, boolean selected) {
        return LiveTvUiSupport.categoryItem(this, liveTvUiHost(), category, selected);
    }

    private void updateLiveBrowserCategoryHighlight(LinearLayout container, String selectedCategory) {
        LiveTvUiSupport.updateCategoryHighlight(liveTvUiHost(), container, selectedCategory);
    }

    private void refreshLiveBrowserChannels(
            LinearLayout container,
            String filter,
            String query,
            PlayerView playerView,
            TextView previewTitle,
            TextView previewNow,
            TextView previewNext,
            TextView previewStatus) {

        container.removeAllViews();

        String cleanQuery =
                normalizeSearchText(
                        query);

        int totalMatches = 0;
        int rendered = 0;

        for (Channel channel : getActiveChannels()) {
            String group =
                    safe(
                            channel.group);

            boolean categoryMatch =
                    "ALL".equals(filter)
                            || filter.equals(
                                    group)
                            || (
                            "FAVOURITES".equals(
                                    filter)
                                    && favouriteChannels.contains(
                                            channel.key())
                    );

            boolean searchMatch =
                    cleanQuery.isEmpty()
                            || searchMatches(
                                    cleanQuery,
                                    safe(channel.name),
                                    group,
                                    safe(channel.tvgName));

            if (!categoryMatch
                    || !searchMatch) {
                continue;
            }

            totalMatches++;

            if (rendered >= MAX_CHANNEL_CARDS) {
                continue;
            }

            LinearLayout row =
                    new LinearLayout(this);

            row.setOrientation(
                    LinearLayout.HORIZONTAL);

            row.setGravity(
                    Gravity.CENTER_VERTICAL);

            row.setPadding(
                    dp(10),
                    dp(6),
                    dp(6),
                    dp(6));

            row.setTag(
                    channel.key());

            makeTvRemoteReady(
                    row);

            TextView name =
                    new TextView(this);

            name.setText(
                    channel.name);

            name.setTextColor(
                    Color.WHITE);

            name.setTextSize(
                    13);

            name.setSingleLine(
                    true);

            name.setGravity(
                    Gravity.CENTER_VERTICAL);

            row.addView(
                    name,
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            1f));

            TextView favourite =
                    new TextView(this);

            favourite.setText(
                    favouriteChannels.contains(
                            channel.key())
                            ? "\u2605"
                            : "\u2606");

            favourite.setTextColor(
                    favouriteChannels.contains(
                            channel.key())
                            ? GOLD
                            : SILVER);

            favourite.setTextSize(
                    20);

            favourite.setGravity(
                    Gravity.CENTER);

            makeTvRemoteReady(
                    favourite);

            row.addView(
                    favourite,
                    new LinearLayout.LayoutParams(
                            dp(38),
                            LinearLayout.LayoutParams.MATCH_PARENT));

            boolean selected =
                    isCurrentLiveChannel(
                            channel);

            row.setBackground(
                    makeBackground(
                            selected
                                    ? Color.rgb(
                                            35,
                                            31,
                                            23)
                                    : CHARCOAL,
                            selected
                                    ? GOLD
                                    : Color.rgb(
                                            52,
                                            52,
                                            56),
                            10));

            container.addView(
                    row,
                    liveBrowserListParams(
                            dp(52)));

            row.setOnClickListener(v ->
                    handleLiveBrowserChannelPress(
                            channel,
                            container,
                            playerView,
                            previewTitle,
                            previewNow,
                            previewNext,
                            previewStatus));

            favourite.setOnClickListener(v -> {
                String key =
                        channel.key();

                if (favouriteChannels.contains(
                        key)) {

                    favouriteChannels.remove(
                            key);

                    favourite.setText(
                            "\u2606");

                    favourite.setTextColor(
                            SILVER);

                } else {

                    favouriteChannels.add(
                            key);

                    favourite.setText(
                            "\u2605");

                    favourite.setTextColor(
                            GOLD);
                }

                saveFavourites();
            });

            rendered++;
        }

        if (totalMatches == 0) {
            TextView empty =
                    new TextView(this);

            empty.setText(
                    "No matching channels.");

            empty.setTextColor(
                    SILVER);

            empty.setTextSize(
                    13);

            empty.setGravity(
                    Gravity.CENTER);

            empty.setPadding(
                    dp(10),
                    dp(25),
                    dp(10),
                    dp(25));

            container.addView(
                    empty);

        } else if (totalMatches > rendered) {
            TextView notice =
                    new TextView(this);

            notice.setText(
                    "Showing "
                            + rendered
                            + " of "
                            + totalMatches
                            + ". Use Search to narrow the list.");

            notice.setTextColor(
                    Color.rgb(
                            125,
                            125,
                            130));

            notice.setTextSize(
                    11);

            notice.setGravity(
                    Gravity.CENTER);

            notice.setPadding(
                    dp(6),
                    dp(10),
                    dp(6),
                    dp(10));

            container.addView(
                    notice);
        }
    }

    private boolean isCurrentLiveChannel(
            Channel channel) {

        if (channel == null) {
            return false;
        }

        if (!selectedStreamUrl.isEmpty()
                && selectedStreamUrl.equals(
                        safe(channel.url))) {
            return true;
        }

        if (!selectedStreamId.isEmpty()
                && selectedStreamId.equals(
                        safe(channel.streamId))) {
            return true;
        }

        return selectedChannel.equals(
                safe(channel.name));
    }

    private void updateLiveBrowserChannelHighlight(
            LinearLayout container) {

        for (int i = 0;
             i < container.getChildCount();
             i++) {

            View child =
                    container.getChildAt(i);

            Object tag =
                    child.getTag();

            if (tag == null) {
                continue;
            }

            boolean selected =
                    safe(
                            String.valueOf(
                                    tag))
                            .equals(
                                    getLastLiveChannelKey());

            child.setBackground(
                    makeBackground(
                            selected
                                    ? Color.rgb(
                                            35,
                                            31,
                                            23)
                                    : CHARCOAL,
                            selected
                                    ? GOLD
                                    : Color.rgb(
                                            52,
                                            52,
                                            56),
                            10));
        }
    }

    private void handleLiveBrowserChannelPress(
            Channel channel,
            LinearLayout channelContainer,
            PlayerView playerView,
            TextView previewTitle,
            TextView previewNow,
            TextView previewNext,
            TextView previewStatus) {

        LiveTvPressHandler.handle(
                new LiveTvPressHandler.Host() {
                    public String lastKey() { return lastLiveChannelPressKey; }
                    public long lastPressedAt() { return lastLiveChannelPressAt; }
                    public void setLastKey(String key) { lastLiveChannelPressKey = key; }
                    public void setLastPressedAt(long time) { lastLiveChannelPressAt = time; }
                    public long doublePressWindow() { return LIVE_DOUBLE_OK_WINDOW_MS; }
                    public void select(Channel c) { selectChannelInternal(c); }
                    public void updateHighlight(LinearLayout c) { updateLiveBrowserChannelHighlight(c); }
                    public void openFullscreen() { openCurrentLiveFullscreen(); }
                    public void startPreview(Channel c, PlayerView pv, TextView t, TextView n, TextView nx, TextView s) {
                        startInlineLivePreview(c, pv, t, n, nx, s);
                    }
                },
                channel,
                channelContainer,
                playerView,
                previewTitle,
                previewNow,
                previewNext,
                previewStatus);
    }

    private void startInlineLivePreview(
            Channel channel,
            PlayerView playerView,
            TextView previewTitle,
            TextView previewNow,
            TextView previewNext,
            TextView previewStatus) {

        LiveTvPreviewController.start(
                new LiveTvPreviewController.Host() {
                    public void releasePlayer() { MainActivity.this.releasePlayer(); }
                    public void setLiveBrowserMode(boolean enabled) { liveBrowserMode = enabled; }
                    public void select(Channel c) { selectChannelInternal(c); }

                    public void prepareState(PlayerView pv, TextView title, TextView now, TextView next, TextView status) {
                        currentResumeKey = "";
                        playbackStartPositionMs = 0L;
                        activeEpisodeIndex = -1;
                        handlingPlaybackEnd = false;
                        activePlayerView = pv;
                        activePlaybackStatus = status;
                        activePlayerScreen = null;
                        playerFullScreen = false;
                        livePreviewPlayerView = pv;
                        livePreviewTitle = title;
                        livePreviewNow = now;
                        livePreviewNext = next;
                        livePreviewStatus = status;
                    }

                    public String selectedChannel() { return selectedChannel; }
                    public String selectedNow() { return selectedNow; }
                    public String selectedGroup() { return selectedGroup; }
                    public String selectedNext() { return selectedNext; }

                    public boolean xtreamEpgAvailable() {
                        return isXtreamSource() && !selectedStreamId.isEmpty();
                    }

                    public Channel findSelectedChannel() { return MainActivity.this.findSelectedChannel(); }

                    public void loadShortEpg(Channel c, TextView now, TextView next) {
                        MainActivity.this.loadShortEpg(c, now, next, null, null);
                    }

                    public void buildPlaybackCandidates() { MainActivity.this.buildPlaybackCandidates(); }
                    public boolean hasPlaybackCandidates() { return !playbackCandidates.isEmpty(); }
                    public void resetPlaybackCandidateIndex() { playbackCandidateIndex = 0; }
                    public String preferredAudioLanguage() { return getPreferredAudioLanguage(); }
                    public void playCurrentCandidate(String language) { MainActivity.this.playCurrentCandidate(language); }
                },
                channel,
                playerView,
                previewTitle,
                previewNow,
                previewNext,
                previewStatus);
    }

    private void openCurrentLiveFullscreen() {
        LiveTvFullscreenController.open(
                new LiveTvFullscreenController.Host() {
                    public void setLiveBrowserMode(boolean enabled) { liveBrowserMode = enabled; }
                    public void showPlayerScreen() { MainActivity.this.showPlayerScreen(); }
                    public boolean hasActivePlayerScreen() { return activePlayerScreen != null; }
                    public void postToPlayerScreen(Runnable action, long delayMs) {
                        activePlayerScreen.postDelayed(action, delayMs);
                    }
                    public boolean shouldEnterFullscreen() {
                        return activePlayerView != null && playerFullScreen == false;
                    }
                    public void enterFullscreen() { MainActivity.this.enterPlayerFullScreen(); }
                });
    }

    private String getLastLiveChannelKey() {
        return playlistPrefs()
                .getString(
                        "last_live_channel_key",
                        "");
    }

    private LiveTvBrowserData.Host liveTvBrowserDataHost() {
        return new LiveTvBrowserData.Host() {
            public java.util.ArrayList<Channel> channels() { return getActiveChannels(); }
            public void select(Channel channel) { selectChannelInternal(channel); }
            public String safe(String value) { return MainActivity.this.safe(value); }
            public java.util.HashSet<String> hiddenCategories() { return getHiddenEditorIds("LIVE"); }
            public java.util.ArrayList<String> topCategoryOrder() { return getTopEditorOrder("LIVE"); }
            public boolean hasImportedChannels() { return importedChannels.size() > 0; }
            public String selectedNow() { return MainActivity.this.selectedNow; }
            public String selectedNext() { return MainActivity.this.selectedNext; }
            public String selectedGroup() { return MainActivity.this.selectedGroup; }
        };
    }

    private void restoreLastLiveChannelSelection() {
        LiveTvBrowserData.restoreLastChannel(
                liveTvBrowserDataHost(),
                getLastLiveChannelKey());
    }

    private void updateProgrammeLabel(TextView programme) {
        LiveTvBrowserData.updateProgrammeLabel(
                liveTvBrowserDataHost(),
                programme);
    }

    private void updateNextLabel(TextView nextProgramme) {
        LiveTvBrowserData.updateNextLabel(
                liveTvBrowserDataHost(),
                nextProgramme);
    }

    private ArrayList<String> getCategoryNames() {
        return LiveTvBrowserData.categoryNames(
                liveTvBrowserDataHost());
    }

    private LiveTvChannelSource.Host liveTvChannelSourceHost() {
        return new LiveTvChannelSource.Host() {
            public java.util.ArrayList<Channel> importedChannels() { return importedChannels; }
            public java.util.HashSet<String> hiddenChannels() { return getHiddenEditorIds("CHANNELS"); }
            public java.util.HashSet<String> hiddenCategories() { return getHiddenEditorIds("LIVE"); }
            public java.util.ArrayList<String> topChannelOrder() { return getTopEditorOrder("CHANNELS"); }
            public String safe(String value) { return MainActivity.this.safe(value); }
        };
    }

    private ArrayList<Channel> getRawChannels() {
        return LiveTvChannelSource.raw(
                liveTvChannelSourceHost());
    }

    private ArrayList<Channel> getActiveChannels() {
        return LiveTvChannelSource.active(
                liveTvChannelSourceHost());
    }

    private String hiddenEditorPrefKey(
            String type) {
        return "editor_hidden_"
                + safe(type)
                .toLowerCase(Locale.US);
    }

    private String topEditorPrefKey(
            String type) {
        return "editor_top_"
                + safe(type)
                .toLowerCase(Locale.US);
    }

    private HashSet<String> getHiddenEditorIds(
            String type) {

        android.content.SharedPreferences prefs =
                playlistPrefs();

        java.util.Set<String> stored =
                prefs.getStringSet(
                        hiddenEditorPrefKey(type),
                        new HashSet<String>());

        return stored == null
                ? new HashSet<String>()
                : new HashSet<String>(stored);
    }

    private void saveHiddenEditorIds(
            String type,
            HashSet<String> ids) {

        playlistPrefs()
                .edit()
                .putStringSet(
                        hiddenEditorPrefKey(type),
                        new HashSet<String>(ids))
                .apply();
    }

    private ArrayList<String> getTopEditorOrder(
            String type) {

        ArrayList<String> result =
                new ArrayList<String>();

        String json =
                playlistPrefs()
                        .getString(
                                topEditorPrefKey(type),
                                "[]");

        try {
            JSONArray array =
                    new JSONArray(json);

            for (int i = 0;
                 i < array.length();
                 i++) {

                String value =
                        array.optString(i, "");

                if (!value.isEmpty()) {
                    result.add(value);
                }
            }

        } catch (Exception ignored) {
        }

        return result;
    }

    private void saveTopEditorOrder(
            String type,
            ArrayList<String> ids) {

        JSONArray array =
                new JSONArray();

        for (String id : ids) {
            if (id != null
                    && !id.isEmpty()) {
                array.put(id);
            }
        }

        playlistPrefs()
                .edit()
                .putString(
                        topEditorPrefKey(type),
                        array.toString())
                .apply();
    }

    private HashMap<String, Integer> buildOrderRank(
            ArrayList<String> order) {

        HashMap<String, Integer> rank =
                new HashMap<String, Integer>();

        for (int i = 0;
             i < order.size();
             i++) {

            if (!rank.containsKey(
                    order.get(i))) {

                rank.put(
                        order.get(i),
                        i);
            }
        }

        return rank;
    }

    private ArrayList<MediaCategory> applyMediaCategoryPreferences(
            String mediaType,
            ArrayList<MediaCategory> categories) {

        ArrayList<MediaCategory> visible =
                new ArrayList<MediaCategory>();

        HashSet<String> hidden =
                getHiddenEditorIds(
                        mediaType);

        for (MediaCategory category : categories) {
            if (category != null
                    && !hidden.contains(
                            category.id)) {

                visible.add(category);
            }
        }

        final HashMap<String, Integer> rank =
                buildOrderRank(
                        getTopEditorOrder(
                                mediaType));

        Collections.sort(
                visible,
                (left, right) -> {

                    Integer l =
                            rank.get(left.id);

                    Integer r =
                            rank.get(right.id);

                    if (l == null && r == null) {
                        return 0;
                    }

                    if (l == null) {
                        return 1;
                    }

                    if (r == null) {
                        return -1;
                    }

                    return l.compareTo(r);
                });

        return visible;
    }

    private ArrayList<MediaCategory> getRawLiveCategoryItems() {

        LinkedHashSet<String> names =
                new LinkedHashSet<String>();

        for (Channel channel : getRawChannels()) {
            String group =
                    safe(channel.group).trim();

            if (!group.isEmpty()) {
                names.add(group);
            }
        }

        ArrayList<MediaCategory> categories =
                new ArrayList<MediaCategory>();

        for (String name : names) {
            MediaCategory category =
                    new MediaCategory();

            category.id = name;
            category.name = name;
            categories.add(category);
        }

        return categories;
    }

    private void showCategoryManager(
            String mediaType) {

        releasePlayer();
        onHomeScreen = false;

        if (mediaType.equals("LIVE")) {
            renderCategoryManager(
                    mediaType,
                    getRawLiveCategoryItems());
            return;
        }

        if (!hasXtreamLogin()) {
            showXtreamRequiredScreen(
                    mediaType);
            return;
        }

        LinearLayout loadingScreen =
                new LinearLayout(this);

        loadingScreen.setOrientation(
                LinearLayout.VERTICAL);

        loadingScreen.setPadding(
                dp(20),
                dp(24),
                dp(20),
                dp(30));

        loadingScreen.setBackgroundColor(
                BLACK);

        TextView back =
                createBackText();

        back.setText("<  SETTINGS");
        back.setOnClickListener(
                v -> showSettings());

        loadingScreen.addView(back);

        TextView heading =
                new TextView(this);

        heading.setText(
                mediaType
                        + " CATEGORY MANAGER");

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(28);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        loadingScreen.addView(
                heading);

        TextView loading =
                new TextView(this);

        loading.setText(
                "Loading every category from your provider...");

        loading.setTextColor(
                SILVER);

        loading.setTextSize(14);

        loading.setPadding(
                0,
                dp(18),
                0,
                0);

        loadingScreen.addView(
                loading);

        setContentView(
                loadingScreen);

        new Thread(() -> {
            try {
                String action =
                        mediaType.equals("MOVIES")
                                ? "get_vod_categories"
                                : "get_series_categories";

                String text =
                        downloadPlaylistText(
                                buildXtreamApiUrl(
                                        action,
                                        null,
                                        null));

                JSONArray array =
                        new JSONArray(text);

                ArrayList<MediaCategory> categories =
                        new ArrayList<MediaCategory>();

                for (int i = 0;
                     i < array.length();
                     i++) {

                    JSONObject item =
                            array.optJSONObject(i);

                    if (item == null) {
                        continue;
                    }

                    MediaCategory category =
                            new MediaCategory();

                    category.id =
                            item.optString(
                                    "category_id",
                                    "");

                    category.name =
                            item.optString(
                                    "category_name",
                                    "OTHER");

                    if (!category.id.isEmpty()) {
                        categories.add(
                                category);
                    }
                }

                runOnUiThread(() ->
                        renderCategoryManager(
                                mediaType,
                                categories));

            } catch (Exception e) {
                final String message =
                        safeErrorMessage(e);

                runOnUiThread(() -> {
                    Toast.makeText(
                            this,
                            "Could not load categories: "
                                    + message,
                            Toast.LENGTH_LONG)
                            .show();

                    showSettings();
                });
            }
        }).start();
    }

    private void renderCategoryManager(
            String mediaType,
            ArrayList<MediaCategory> categories) {

        final HashSet<String> selected =
                new HashSet<String>();

        renderCategoryManagerScreen(
                mediaType,
                categories,
                selected);
    }

    private void renderCategoryManagerScreen(
            String mediaType,
            ArrayList<MediaCategory> categories,
            HashSet<String> selected) {

        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setBackgroundColor(
                BLACK);

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                dp(20),
                dp(24),
                dp(20),
                dp(30));

        scrollView.addView(root);

        TextView back =
                createBackText();

        back.setText("<  SETTINGS");
        back.setOnClickListener(
                v -> showSettings());

        root.addView(back);

        TextView heading =
                new TextView(this);

        heading.setText(
                mediaType.equals("LIVE")
                        ? "LIVE TV CATEGORY MANAGER"
                        : mediaType
                                + " CATEGORY MANAGER");

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(28);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        root.addView(heading);

        TextView help =
                new TextView(this);

        help.setText(
                "Press OK to check categories. "
                        + "Use HIDE or MOVE TO TOP at the bottom.");

        help.setTextColor(
                SILVER);

        help.setTextSize(13);

        help.setPadding(
                0,
                dp(6),
                0,
                dp(14));

        root.addView(help);

        TextView selectionCount =
                new TextView(this);

        GridLayout grid =
                new GridLayout(this);

        grid.setColumnCount(3);
        grid.setUseDefaultMargins(false);
        grid.setAlignmentMode(
                GridLayout.ALIGN_BOUNDS);

        HashSet<String> hidden =
                getHiddenEditorIds(
                        mediaType);

        HashSet<String> top =
                new HashSet<String>(
                        getTopEditorOrder(
                                mediaType));

        for (MediaCategory category : categories) {
            final String id =
                    category.id;

            final String name =
                    category.name;

            TextView cell =
                    new TextView(this);

            updateEditorCellText(
                    cell,
                    selected.contains(id),
                    name,
                    hidden.contains(id),
                    top.contains(id));

            cell.setTextColor(
                    Color.WHITE);

            cell.setTextSize(13);

            cell.setGravity(
                    Gravity.CENTER_VERTICAL);

            cell.setPadding(
                    dp(14),
                    dp(12),
                    dp(14),
                    dp(12));

            cell.setFocusable(true);
            cell.setClickable(true);

            cell.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(
                                    52,
                                    52,
                                    56),
                            12));

            cell.setOnClickListener(v -> {
                if (selected.contains(id)) {
                    selected.remove(id);
                } else {
                    selected.add(id);
                }

                updateEditorCellText(
                        cell,
                        selected.contains(id),
                        name,
                        hidden.contains(id),
                        top.contains(id));

                selectionCount.setText(
                        selected.size()
                                + " selected");
            });

            addFocusStyle(
                    cell,
                    12);

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams();

            params.width = 0;
            params.height = dp(66);
            params.columnSpec =
                    GridLayout.spec(
                            GridLayout.UNDEFINED,
                            1f);

            params.setMargins(
                    dp(4),
                    dp(4),
                    dp(4),
                    dp(4));

            grid.addView(
                    cell,
                    params);
        }

        root.addView(grid);

        selectionCount.setText(
                selected.size()
                        + " selected");

        selectionCount.setTextColor(
                SILVER);

        selectionCount.setTextSize(12);

        selectionCount.setPadding(
                0,
                dp(16),
                0,
                dp(8));

        root.addView(
                selectionCount);

        LinearLayout actions =
                new LinearLayout(this);

        actions.setOrientation(
                LinearLayout.HORIZONTAL);

        Button hideButton =
                makeSmallButton(
                        "HIDE");

        Button topButton =
                makeSmallButton(
                        "MOVE TO TOP");

        hideButton.setOnClickListener(v -> {
            if (selected.isEmpty()) {
                Toast.makeText(
                        this,
                        "Check at least one category first.",
                        Toast.LENGTH_SHORT)
                        .show();
                return;
            }

            HashSet<String> hiddenIds =
                    getHiddenEditorIds(
                            mediaType);

            boolean allHidden =
                    true;

            for (String id : selected) {
                if (!hiddenIds.contains(id)) {
                    allHidden = false;
                    break;
                }
            }

            if (allHidden) {
                hiddenIds.removeAll(
                        selected);
            } else {
                hiddenIds.addAll(
                        selected);
            }

            saveHiddenEditorIds(
                    mediaType,
                    hiddenIds);

            selected.clear();

            Toast.makeText(
                    this,
                    allHidden
                            ? "Selected categories are visible again."
                            : "Selected categories hidden.",
                    Toast.LENGTH_SHORT)
                    .show();

            renderCategoryManagerScreen(
                    mediaType,
                    categories,
                    selected);
        });

        topButton.setOnClickListener(v -> {
            if (selected.isEmpty()) {
                Toast.makeText(
                        this,
                        "Check at least one category first.",
                        Toast.LENGTH_SHORT)
                        .show();
                return;
            }

            ArrayList<EditorItem> ordered =
                    buildOrderEditorItems(
                            mediaType,
                            categories,
                            selected);

            showOrderEditor(
                    mediaType,
                    mediaType.equals("LIVE")
                            ? "LIVE TV CATEGORY ORDER"
                            : mediaType
                                    + " CATEGORY ORDER",
                    ordered,
                    () -> showCategoryManager(
                            mediaType));
        });

        LinearLayout.LayoutParams actionParams =
                new LinearLayout.LayoutParams(
                        0,
                        dp(54),
                        1f);

        actionParams.setMargins(
                dp(4),
                dp(4),
                dp(4),
                dp(4));

        actions.addView(
                hideButton,
                actionParams);

        actions.addView(
                topButton,
                actionParams);

        root.addView(
                actions);

        setContentView(
                scrollView);
    }

    private void updateEditorCellText(
            TextView cell,
            boolean selected,
            String name,
            boolean hidden,
            boolean top) {

        StringBuilder text =
                new StringBuilder();

        text.append(
                selected
                        ? "\u2611  "
                        : "\u2610  ");

        text.append(
                safe(name));

        if (hidden) {
            text.append(
                    "\nHIDDEN");
        } else if (top) {
            text.append(
                    "\nTOP");
        }

        cell.setText(
                text.toString());
    }

    private ArrayList<EditorItem> buildOrderEditorItems(
            String type,
            ArrayList<MediaCategory> categories,
            HashSet<String> selected) {

        HashMap<String, String> labels =
                new HashMap<String, String>();

        for (MediaCategory category : categories) {
            labels.put(
                    category.id,
                    category.name);
        }

        LinkedHashSet<String> ids =
                new LinkedHashSet<String>();

        for (String id : getTopEditorOrder(type)) {
            if (labels.containsKey(id)) {
                ids.add(id);
            }
        }

        for (MediaCategory category : categories) {
            if (selected.contains(
                    category.id)) {
                ids.add(
                        category.id);
            }
        }

        ArrayList<EditorItem> items =
                new ArrayList<EditorItem>();

        for (String id : ids) {
            items.add(
                    new EditorItem(
                            id,
                            labels.get(id)));
        }

        return items;
    }

    private void showChannelEditor() {

        releasePlayer();
        onHomeScreen = false;

        final HashSet<String> selected =
                new HashSet<String>();

        renderChannelEditor(
                0,
                "",
                selected);
    }

    private ArrayList<Channel> getEditorChannelMatches(
            String query) {

        ArrayList<Channel> result =
                new ArrayList<Channel>();

        String clean =
                normalizeSearchText(
                        query);

        for (Channel channel : getRawChannels()) {
            if (clean.isEmpty()
                    || searchMatches(
                            clean,
                            channel.name,
                            channel.group,
                            channel.tvgName)) {

                result.add(channel);
            }
        }

        return result;
    }

    private void renderChannelEditor(
            int requestedPage,
            String currentQuery,
            HashSet<String> selected) {

        final int pageSize = 60;

        ArrayList<Channel> matches =
                getEditorChannelMatches(
                        currentQuery);

        int maxPage =
                Math.max(
                        0,
                        (matches.size() - 1)
                                / pageSize);

        final int page =
                Math.max(
                        0,
                        Math.min(
                                requestedPage,
                                maxPage));

        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setBackgroundColor(
                BLACK);

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                dp(20),
                dp(24),
                dp(20),
                dp(30));

        scrollView.addView(root);

        TextView back =
                createBackText();

        back.setText("<  SETTINGS");
        back.setOnClickListener(
                v -> showSettings());

        root.addView(back);

        TextView heading =
                new TextView(this);

        heading.setText(
                "CHANNEL EDITOR");

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(28);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        root.addView(
                heading);

        TextView help =
                new TextView(this);

        help.setText(
                "Press OK to check channels. "
                        + "Search or move through pages, then use HIDE or MOVE TO TOP.");

        help.setTextColor(
                SILVER);

        help.setTextSize(13);

        help.setPadding(
                0,
                dp(6),
                0,
                dp(12));

        root.addView(help);

        EditText search =
                new EditText(this);

        search.setHint(
                "Search all channels");

        search.setHintTextColor(
                Color.rgb(
                        120,
                        120,
                        125));

        search.setTextColor(
                Color.WHITE);

        search.setSingleLine(
                true);

        search.setText(
                currentQuery);

        prepareTvTextInput(
                search,
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
                EditorInfo.IME_ACTION_DONE);

        search.setBackground(
                makeBackground(
                        CHARCOAL,
                        Color.rgb(
                                55,
                                55,
                                58),
                        12));

        search.setPadding(
                dp(14),
                dp(10),
                dp(14),
                dp(10));

        root.addView(
                search,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(50)));

        TextView pageInfo =
                new TextView(this);

        int first =
                matches.isEmpty()
                        ? 0
                        : page * pageSize + 1;

        int last =
                Math.min(
                        matches.size(),
                        (page + 1) * pageSize);

        pageInfo.setText(
                "Channels "
                        + first
                        + "-"
                        + last
                        + " of "
                        + matches.size()
                        + "   •   "
                        + selected.size()
                        + " checked");

        pageInfo.setTextColor(
                SILVER);

        pageInfo.setTextSize(12);

        pageInfo.setPadding(
                0,
                dp(10),
                0,
                dp(8));

        root.addView(
                pageInfo);

        GridLayout grid =
                new GridLayout(this);

        grid.setColumnCount(3);

        HashSet<String> hidden =
                getHiddenEditorIds(
                        "CHANNELS");

        HashSet<String> top =
                new HashSet<String>(
                        getTopEditorOrder(
                                "CHANNELS"));

        for (int index = first == 0
                ? 0
                : first - 1;
             index < last;
             index++) {

            Channel channel =
                    matches.get(index);

            final String key =
                    channel.key();

            final String label =
                    channel.name;

            TextView cell =
                    new TextView(this);

            updateEditorCellText(
                    cell,
                    selected.contains(key),
                    label,
                    hidden.contains(key),
                    top.contains(key));

            cell.setTextColor(
                    Color.WHITE);

            cell.setTextSize(12);

            cell.setGravity(
                    Gravity.CENTER_VERTICAL);

            cell.setPadding(
                    dp(12),
                    dp(10),
                    dp(12),
                    dp(10));

            cell.setFocusable(true);
            cell.setClickable(true);

            cell.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(
                                    52,
                                    52,
                                    56),
                            12));

            cell.setOnClickListener(v -> {
                if (selected.contains(key)) {
                    selected.remove(key);
                } else {
                    selected.add(key);
                }

                updateEditorCellText(
                        cell,
                        selected.contains(key),
                        label,
                        hidden.contains(key),
                        top.contains(key));

                pageInfo.setText(
                        "Channels "
                                + first
                                + "-"
                                + last
                                + " of "
                                + matches.size()
                                + "   •   "
                                + selected.size()
                                + " checked");
            });

            addFocusStyle(
                    cell,
                    12);

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams();

            params.width = 0;
            params.height = dp(62);

            params.columnSpec =
                    GridLayout.spec(
                            GridLayout.UNDEFINED,
                            1f);

            params.setMargins(
                    dp(4),
                    dp(4),
                    dp(4),
                    dp(4));

            grid.addView(
                    cell,
                    params);
        }

        root.addView(
                grid);

        LinearLayout paging =
                new LinearLayout(this);

        paging.setOrientation(
                LinearLayout.HORIZONTAL);

        Button previous =
                makeSmallButton(
                        "PREVIOUS");

        Button next =
                makeSmallButton(
                        "NEXT");

        previous.setEnabled(
                page > 0);

        next.setEnabled(
                page < maxPage);

        previous.setOnClickListener(v ->
                renderChannelEditor(
                        page - 1,
                        currentQuery,
                        selected));

        next.setOnClickListener(v ->
                renderChannelEditor(
                        page + 1,
                        currentQuery,
                        selected));

        LinearLayout.LayoutParams half =
                new LinearLayout.LayoutParams(
                        0,
                        dp(50),
                        1f);

        half.setMargins(
                dp(4),
                dp(8),
                dp(4),
                dp(4));

        paging.addView(
                previous,
                half);

        paging.addView(
                next,
                half);

        root.addView(
                paging);

        LinearLayout actions =
                new LinearLayout(this);

        actions.setOrientation(
                LinearLayout.HORIZONTAL);

        Button hide =
                makeSmallButton(
                        "HIDE");

        Button moveTop =
                makeSmallButton(
                        "MOVE TO TOP");

        hide.setOnClickListener(v -> {
            if (selected.isEmpty()) {
                Toast.makeText(
                        this,
                        "Check at least one channel first.",
                        Toast.LENGTH_SHORT)
                        .show();
                return;
            }

            HashSet<String> hiddenIds =
                    getHiddenEditorIds(
                            "CHANNELS");

            boolean allHidden =
                    true;

            for (String id : selected) {
                if (!hiddenIds.contains(id)) {
                    allHidden = false;
                    break;
                }
            }

            if (allHidden) {
                hiddenIds.removeAll(
                        selected);
            } else {
                hiddenIds.addAll(
                        selected);
            }

            saveHiddenEditorIds(
                    "CHANNELS",
                    hiddenIds);

            selected.clear();

            Toast.makeText(
                    this,
                    allHidden
                            ? "Selected channels are visible again."
                            : "Selected channels hidden.",
                    Toast.LENGTH_SHORT)
                    .show();

            renderChannelEditor(
                    page,
                    currentQuery,
                    selected);
        });

        moveTop.setOnClickListener(v -> {
            if (selected.isEmpty()) {
                Toast.makeText(
                        this,
                        "Check at least one channel first.",
                        Toast.LENGTH_SHORT)
                        .show();
                return;
            }

            ArrayList<EditorItem> items =
                    buildChannelOrderEditorItems(
                            selected);

            showOrderEditor(
                    "CHANNELS",
                    "CHANNEL ORDER",
                    items,
                    () -> showChannelEditor());
        });

        actions.addView(
                hide,
                half);

        actions.addView(
                moveTop,
                half);

        root.addView(
                actions);

        search.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        final String value =
                                s == null
                                        ? ""
                                        : s.toString();

                        search.postDelayed(
                                () -> {
                                    if (search.hasFocus()
                                            && value.equals(
                                                    search.getText().toString())) {

                                        renderChannelEditor(
                                                0,
                                                value,
                                                selected);
                                    }
                                },
                                250);
                    }

                    @Override
                    public void afterTextChanged(
                            android.text.Editable s) {
                    }
                });

        setContentView(
                scrollView);
    }

    private ArrayList<EditorItem> buildChannelOrderEditorItems(
            HashSet<String> selected) {

        HashMap<String, String> labels =
                new HashMap<String, String>();

        for (Channel channel : getRawChannels()) {
            labels.put(
                    channel.key(),
                    channel.name);
        }

        LinkedHashSet<String> ids =
                new LinkedHashSet<String>();

        for (String id : getTopEditorOrder("CHANNELS")) {
            if (labels.containsKey(id)) {
                ids.add(id);
            }
        }

        for (Channel channel : getRawChannels()) {
            String id =
                    channel.key();

            if (selected.contains(id)) {
                ids.add(id);
            }
        }

        ArrayList<EditorItem> items =
                new ArrayList<EditorItem>();

        for (String id : ids) {
            items.add(
                    new EditorItem(
                            id,
                            labels.get(id)));
        }

        return items;
    }

    private void showOrderEditor(
            String type,
            String title,
            ArrayList<EditorItem> items,
            Runnable onDone) {

        final int[] selectedIndex =
                {items.isEmpty() ? -1 : 0};

        renderOrderEditor(
                type,
                title,
                items,
                selectedIndex,
                onDone);
    }

    private void renderOrderEditor(
            String type,
            String title,
            ArrayList<EditorItem> items,
            int[] selectedIndex,
            Runnable onDone) {

        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setBackgroundColor(
                BLACK);

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                dp(20),
                dp(24),
                dp(20),
                dp(30));

        scrollView.addView(root);

        TextView back =
                createBackText();

        back.setText("<  CANCEL");
        back.setOnClickListener(
                v -> onDone.run());

        root.addView(
                back);

        TextView heading =
                new TextView(this);

        heading.setText(
                title);

        heading.setTextColor(
                Color.WHITE);

        heading.setTextSize(28);

        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        root.addView(
                heading);

        TextView help =
                new TextView(this);

        help.setText(
                "Choose an item, then use MOVE UP or MOVE DOWN. "
                        + "The saved order becomes the order at the top of the list.");

        help.setTextColor(
                SILVER);

        help.setTextSize(13);

        help.setPadding(
                0,
                dp(6),
                0,
                dp(12));

        root.addView(help);

        LinearLayout rows =
                new LinearLayout(this);

        rows.setOrientation(
                LinearLayout.VERTICAL);

        for (int i = 0;
             i < items.size();
             i++) {

            final int index = i;

            TextView row =
                    new TextView(this);

            row.setText(
                    (i + 1)
                            + ".  "
                            + items.get(i).name);

            row.setTextColor(
                    Color.WHITE);

            row.setTextSize(14);

            row.setGravity(
                    Gravity.CENTER_VERTICAL);

            row.setPadding(
                    dp(16),
                    dp(10),
                    dp(16),
                    dp(10));

            row.setFocusable(true);
            row.setClickable(true);

            if (i == selectedIndex[0]) {
                row.setBackground(
                        makeBackground(
                                Color.rgb(
                                        35,
                                        31,
                                        23),
                                GOLD,
                                12));
            } else {
                row.setBackground(
                        makeBackground(
                                CHARCOAL,
                                Color.rgb(
                                        52,
                                        52,
                                        56),
                                12));
            }

            row.setOnClickListener(v -> {
                selectedIndex[0] =
                        index;

                renderOrderEditor(
                        type,
                        title,
                        items,
                        selectedIndex,
                        onDone);
            });

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(50));

            params.setMargins(
                    0,
                    0,
                    0,
                    dp(6));

            rows.addView(
                    row,
                    params);
        }

        root.addView(
                rows);

        LinearLayout moves =
                new LinearLayout(this);

        moves.setOrientation(
                LinearLayout.HORIZONTAL);

        Button moveUp =
                makeSmallButton(
                        "MOVE UP");

        Button moveDown =
                makeSmallButton(
                        "MOVE DOWN");

        moveUp.setOnClickListener(v -> {
            int index =
                    selectedIndex[0];

            if (index > 0
                    && index < items.size()) {

                Collections.swap(
                        items,
                        index,
                        index - 1);

                selectedIndex[0] =
                        index - 1;

                renderOrderEditor(
                        type,
                        title,
                        items,
                        selectedIndex,
                        onDone);
            }
        });

        moveDown.setOnClickListener(v -> {
            int index =
                    selectedIndex[0];

            if (index >= 0
                    && index
                            < items.size() - 1) {

                Collections.swap(
                        items,
                        index,
                        index + 1);

                selectedIndex[0] =
                        index + 1;

                renderOrderEditor(
                        type,
                        title,
                        items,
                        selectedIndex,
                        onDone);
            }
        });

        LinearLayout.LayoutParams half =
                new LinearLayout.LayoutParams(
                        0,
                        dp(52),
                        1f);

        half.setMargins(
                dp(4),
                dp(8),
                dp(4),
                dp(4));

        moves.addView(
                moveUp,
                half);

        moves.addView(
                moveDown,
                half);

        root.addView(
                moves);

        Button save =
                makeSmallButton(
                        "SAVE ORDER");

        save.setTextSize(
                13);

        save.setOnClickListener(v -> {
            ArrayList<String> order =
                    new ArrayList<String>();

            for (EditorItem item : items) {
                order.add(
                        item.id);
            }

            saveTopEditorOrder(
                    type,
                    order);

            Toast.makeText(
                    this,
                    "Top order saved.",
                    Toast.LENGTH_SHORT)
                    .show();

            onDone.run();
        });

        LinearLayout.LayoutParams saveParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(54));

        saveParams.setMargins(
                dp(4),
                dp(6),
                dp(4),
                0);

        root.addView(
                save,
                saveParams);

        setContentView(
                scrollView);
    }

    // ---------------------------------------------------------------------
    // SETTINGS
    // ---------------------------------------------------------------------

    private static final class CatalogueProbeStop extends Exception {}

    private String probeCatalogueBatch(
            SQLiteDatabase db, String type, String url,
            String playlistId, String providerKey) throws Exception {

        final boolean movies = "MOVIES".equals(type);
        final int[] count = new int[5];
        final ArrayList<String[]> saved = new ArrayList<>();

        try {
            streamJsonArray(url, reader -> {
                if (count[0] >= 20) throw new CatalogueProbeStop();

                if (!playlistId.equals(activePlaylistId)
                        || !getPlaylistProfileIds().contains(playlistId)
                        || !providerKey.equals(getCatalogueProviderKey())) {
                    throw new IllegalStateException("Playlist changed");
                }

                count[0]++;

                if (movies) {
                    MovieItem item = readMovieItemFromStream(reader);
                    String id = safe(item.streamId);
                    if (id.isEmpty() || "null".equals(id)) {
                        count[4]++;
                        return;
                    }
                    if (safe(item.rawJson).isEmpty()) {
                        throw new IllegalStateException("Movie JSON missing");
                    }
                    upsertMovieCatalogue(db, providerKey, item,
                            !safe(item.cast).isEmpty());
                    saved.add(new String[]{id, item.rawJson});
                    if (item.addedAt > 0) count[2]++;
                    if (safe(item.name).startsWith("EN - ")) count[3]++;
                } else {
                    SeriesItem item = readSeriesItemFromStream(reader);
                    String id = safe(item.seriesId);
                    if (id.isEmpty() || "null".equals(id)) {
                        count[4]++;
                        return;
                    }
                    if (safe(item.rawJson).isEmpty()) {
                        throw new IllegalStateException("Series JSON missing");
                    }
                    upsertSeriesCatalogue(db, providerKey, item);
                    saved.add(new String[]{id, item.rawJson});
                    if (item.addedAt > 0) count[2]++;
                    if (safe(item.name).startsWith("EN - ")) count[3]++;
                }
                count[1]++;
            });
        } catch (CatalogueProbeStop expected) {
            // Sample limit reached. The transport closes the connection.
        }
        int verified = 0;
        String table = movies ? "catalogue_movies" : "catalogue_series";
        String idColumn = movies ? "stream_id" : "series_id";

        for (String[] record : saved) {
            Cursor cursor = db.query(
                    table, new String[]{"raw_json"},
                    "provider_key=? AND " + idColumn + "=?",
                    new String[]{providerKey, record[0]},
                    null, null, null);
            try {
                if (cursor.moveToFirst()
                        && record[1].equals(cursor.getString(0))) {
                    verified++;
                }
            } finally {
                cursor.close();
            }
        }

        return type + ": seen=" + count[0]
                + ", stored=" + count[1]
                + ", JSON verified=" + verified
                + ", dated=" + count[2]
                + ", EN-prefix=" + count[3]
                + ", invalid IDs=" + count[4];
    }

    private void startCatalogueSampleProbe() {
        final String playlistId = activePlaylistId;
        final String providerKey = getCatalogueProviderKey();
        final String movieUrl;
        final String seriesUrl;

        try {
            movieUrl = buildXtreamApiUrl(
                    "get_vod_streams", null, null);
            seriesUrl = buildXtreamApiUrl(
                    "get_series", null, null);
        } catch (Exception e) {
            Toast.makeText(this, "Provider URL unavailable",
                    Toast.LENGTH_LONG).show();
            return;
        }

        Toast.makeText(this, "Testing 20 movies and 20 series",
                Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            String report;
            CatalogueDbHelper helper = new CatalogueDbHelper(
                    getApplicationContext(),
                    CATALOGUE_DB_PREFIX
                            + sanitizePlaylistId(playlistId) + ".db");
            try {
                SQLiteDatabase db = helper.getWritableDatabase();
                String a = probeCatalogueBatch(
                        db, "MOVIES", movieUrl, playlistId, providerKey);
                String b = probeCatalogueBatch(
                        db, "SERIES", seriesUrl, playlistId, providerKey);
                StringBuilder dates =
                        new StringBuilder("SERIES PROVIDER DATE FIELDS:");

                Cursor samples = db.rawQuery(
                        "SELECT raw_json FROM catalogue_series "
                        + "WHERE provider_key=? AND raw_json IS NOT NULL "
                        + "AND LENGTH(raw_json)>0 "
                        + "ORDER BY rowid DESC LIMIT 3",
                        new String[]{providerKey});

                try {
                    int sampleNumber = 0;

                    while (samples.moveToNext()) {
                        sampleNumber++;
                        JSONObject raw =
                                new JSONObject(samples.getString(0));

                        dates.append("\nSample ").append(sampleNumber).append(": ");

                        java.util.Iterator<String> keys = raw.keys();
                        boolean found = false;

                        while (keys.hasNext()) {
                            String key = keys.next();
                            String lower = key.toLowerCase(java.util.Locale.US);

                            if (lower.contains("add")
                                    || lower.contains("modif")
                                    || lower.contains("update")
                                    || lower.contains("date")
                                    || lower.contains("time")) {
                                dates.append("\n")
                                        .append(key)
                                        .append("=")
                                        .append(raw.optString(key, "null"));
                                found = true;
                            }
                        }

                        if (!found) {
                            dates.append("No date-like fields");
                        }

                        if (sampleNumber == 1) {
                            dates.append("\nAll keys: ");
                            dates.append(raw.names());
                        }
                    }
                } finally {
                    samples.close();
                }

                report = a + "\n\n" + b + "\n\n" + dates.toString();
            } catch (Exception e) {
                report = "Test failed: "
                        + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            } finally {
                helper.close();
            }

            final String result = report;
            runOnUiThread(() ->
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("Catalogue sample results")
                            .setMessage(result)
                            .setPositiveButton("OK", null)
                            .show());
        }).start();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                    | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private volatile boolean localRebuildRunning = false;
    private volatile boolean localRebuildCancel = false;
    private android.app.AlertDialog localRebuildDialog;

    private void updateLocalRebuildStatus(String message) {
        runOnUiThread(() -> {
            if (localRebuildDialog != null
                    && !isFinishing() && !isDestroyed()) {
                localRebuildDialog.setMessage(message);
            }
        });
    }

    private void confirmLocalCatalogueRebuild() {
        if (localRebuildRunning) {
            Toast.makeText(this, "Catalogue import already running",
                    Toast.LENGTH_LONG).show();
            return;
        }

        new android.app.AlertDialog.Builder(this)
                .setTitle("Rebuild local catalogue")
                .setMessage("Import all movies and series from this playlist. "
                        + "Existing catalogue records will NOT be deleted. "
                        + "Keep this playlist selected until the import finishes.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Start import",
                        (dialog, which) -> startLocalCatalogueRebuild())
                .show();
    }

    private void startLocalCatalogueRebuild() {
        if (localRebuildRunning || backendMovieIndexRunning
                || backendSeriesIndexRunning) {
            Toast.makeText(this, "Another catalogue job is running",
                    Toast.LENGTH_LONG).show();
            return;
        }

        final String playlistId = activePlaylistId;
        final String providerKey = getCatalogueProviderKey();
        final String movieUrl;
        final String seriesUrl;

        try {
            movieUrl = buildXtreamApiUrl(
                    "get_vod_streams", null, null);
            seriesUrl = buildXtreamApiUrl(
                    "get_series", null, null);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot create provider requests",
                    Toast.LENGTH_LONG).show();
            return;
        }

        localRebuildCancel = false;
        localRebuildRunning = true;

        getWindow().addFlags(
                android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        localRebuildDialog =
                new android.app.AlertDialog.Builder(this)
                        .setTitle("Local catalogue import")
                        .setMessage("Preparing... No catalogue entries will be deleted.")
                        .setCancelable(false)
                        .setNegativeButton("Cancel import", null)
                        .create();

        localRebuildDialog.show();

        localRebuildDialog.getButton(
                android.app.AlertDialog.BUTTON_NEGATIVE)
                .setOnClickListener(v -> {
                    localRebuildCancel = true;
                    updateLocalRebuildStatus(
                            "Cancellation requested. Stopping safely...");
                });

        new Thread(() -> {
            CatalogueDbHelper helper = null;
            SQLiteDatabase db = null;
            long generation = 0L;
            String report = "Import interrupted";

            try {
                if (!playlistId.equals(activePlaylistId)
                        || !providerKey.equals(getCatalogueProviderKey())
                        || !getPlaylistProfileIds().contains(playlistId)) {
                    throw new IllegalStateException("Playlist changed");
                }

                helper = new CatalogueDbHelper(
                        getApplicationContext(),
                        CATALOGUE_DB_PREFIX
                                + sanitizePlaylistId(playlistId) + ".db");

                db = helper.getWritableDatabase();

                long previousMovies =
                        android.database.DatabaseUtils.longForQuery(
                                db,
                                "SELECT COUNT(*) FROM catalogue_movies WHERE provider_key=?",
                                new String[]{providerKey});

                long previousSeries =
                        android.database.DatabaseUtils.longForQuery(
                                db,
                                "SELECT COUNT(*) FROM catalogue_series WHERE provider_key=?",
                                new String[]{providerKey});

                generation = CatalogueRebuildJournal.start(
                        db, providerKey);

                updateLocalRebuildStatus("Importing movies...");

                runLocalCatalogueImport(
                        "MOVIES", playlistId,
                        providerKey, movieUrl, generation);

                if (localRebuildCancel) {
                    throw new InterruptedException("Cancelled");
                }

                CatalogueRebuildJournal.progress(
                        db, providerKey, generation,
                        "SERIES", -1L, -1L);

                updateLocalRebuildStatus(
                        "Movies complete. Importing series...");

                runLocalCatalogueImport(
                        "SERIES", playlistId,
                        providerKey, seriesUrl, generation);

                if (localRebuildCancel) {
                    throw new InterruptedException("Cancelled");
                }

                if (!playlistId.equals(activePlaylistId)
                        || !providerKey.equals(getCatalogueProviderKey())) {
                    throw new IllegalStateException("Playlist changed");
                }

                updateLocalRebuildStatus("Validating catalogue...");

                CatalogueRebuildValidator.Result result =
                        CatalogueRebuildValidator.verify(
                                db, providerKey, generation,
                                previousMovies, previousSeries);

                CatalogueRebuildJournal.progress(
                        db, providerKey, generation,
                        result.acceptable ? "VALIDATED" : "REVIEW_REQUIRED",
                        -1L, -1L);

                report = result.summary()
                        + "\n\nExisting catalogue entries remain intact.";

            } catch (Exception error) {
                if (db != null && generation > 0L) {
                    try {
                        if (localRebuildCancel
                                || error instanceof InterruptedException) {
                            CatalogueRebuildJournal.progress(
                                    db, providerKey, generation,
                                    "CANCELLED", -1L, -1L);
                        } else {
                            CatalogueRebuildJournal.failed(
                                    db, providerKey, generation, error);
                        }
                    } catch (Exception ignored) {
                    }
                }

                report = localRebuildCancel
                        ? "Import cancelled."
                        : "Import failed: "
                                + error.getClass().getSimpleName();

                report += "\nPrevious catalogue records were not deleted.";

            } finally {
                if (helper != null) {
                    try {
                        helper.close();
                    } catch (Exception ignored) {
                    }
                }
                localRebuildRunning = false;
            }

            final String finalReport = report;

            runOnUiThread(() -> {
                getWindow().clearFlags(
                        android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

                if (localRebuildDialog != null) {
                    localRebuildDialog.dismiss();
                    localRebuildDialog = null;
                }

                if (!isFinishing() && !isDestroyed()) {
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("Catalogue rebuild results")
                            .setMessage(finalReport)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });

        }, "pp-local-catalogue-import").start();
    }

    private void showCatalogueGenerationAudit() {
        if (localRebuildRunning) {
            Toast.makeText(this, "Import still running",
                    Toast.LENGTH_LONG).show();
            return;
        }

        final String playlistId = activePlaylistId;
        final String providerKey = getCatalogueProviderKey();

        new Thread(() -> {
            String report;
            CatalogueDbHelper helper = null;

            try {
                if (!playlistId.equals(activePlaylistId)
                        || !getPlaylistProfileIds().contains(playlistId)
                        || !providerKey.equals(getCatalogueProviderKey())) {
                    throw new IllegalStateException("Playlist changed");
                }

                helper = new CatalogueDbHelper(
                        getApplicationContext(),
                        CATALOGUE_DB_PREFIX
                                + sanitizePlaylistId(playlistId) + ".db");

                report = CatalogueGenerationAudit.report(
                        helper.getReadableDatabase(), providerKey);

            } catch (Exception e) {
                report = "Audit failed: "
                        + e.getClass().getSimpleName()
                        + ": " + String.valueOf(e.getMessage());
            } finally {
                if (helper != null) {
                    try {
                        helper.close();
                    } catch (Exception ignored) {}
                }
            }

            final String result = report;
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()
                        && playlistId.equals(activePlaylistId)) {
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("Catalogue cleanup audit")
                            .setMessage(result)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        }, "pp-catalogue-audit").start();
    }

    private volatile boolean oldCatalogueCleanupRunning = false;

    private void confirmOldCatalogueCleanup() {
        if (localRebuildRunning || oldCatalogueCleanupRunning
                || backendMovieIndexRunning || backendSeriesIndexRunning) {
            Toast.makeText(this, "Catalogue job running",
                    Toast.LENGTH_LONG).show();
            return;
        }

        final String playlistId = activePlaylistId;
        final String providerKey = getCatalogueProviderKey();

        new android.app.AlertDialog.Builder(this)
                .setTitle("Remove obsolete catalogue records")
                .setMessage("Remove only records outside the validated "
                        + "rebuild generation. The current catalogue, "
                        + "details and viewing history will be retained.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove old records", (d, w) -> {
                    oldCatalogueCleanupRunning = true;

                    android.app.AlertDialog busy =
                            new android.app.AlertDialog.Builder(this)
                                    .setTitle("Catalogue cleanup")
                                    .setMessage("Checking and removing obsolete records...")
                                    .create();
                    busy.setCancelable(false);
                    busy.show();

                    new Thread(() -> {
                        String result;
                        CatalogueDbHelper helper = null;
                        try {
                            if (!playlistId.equals(activePlaylistId)
                                    || !getPlaylistProfileIds().contains(playlistId)
                                    || !providerKey.equals(getCatalogueProviderKey())) {
                                throw new IllegalStateException("Playlist changed");
                            }

                            helper = new CatalogueDbHelper(
                                    getApplicationContext(),
                                    CATALOGUE_DB_PREFIX
                                            + sanitizePlaylistId(playlistId) + ".db");

                            result = CatalogueOldGenerationCleanup.execute(
                                    helper.getWritableDatabase(), providerKey);
                        } catch (Exception error) {
                            result = "Cleanup stopped: "
                                    + error.getClass().getSimpleName()
                                    + ": " + String.valueOf(error.getMessage())
                                    + "\n\nNo deletion was committed if the transaction failed.";
                        } finally {
                            if (helper != null) {
                                try { helper.close(); } catch (Exception ignored) {}
                            }
                            oldCatalogueCleanupRunning = false;
                        }

                        final String report = result;
                        runOnUiThread(() -> {
                            busy.dismiss();
                            if (!isFinishing() && !isDestroyed()) {
                                new android.app.AlertDialog.Builder(MainActivity.this)
                                        .setTitle("Catalogue cleanup result")
                                        .setMessage(report)
                                        .setPositiveButton("OK", null)
                                        .show();
                            }
                        });
                    }, "pp-old-catalogue-cleanup").start();
                })
                .show();
    }

    private volatile boolean cataloguePreviewRunning = false;
    private volatile boolean cataloguePreviewCancel = false;

    private void previewCatalogueChanges() {
        if (cataloguePreviewRunning || localRebuildRunning
                || oldCatalogueCleanupRunning
                || backendMovieIndexRunning
                || backendSeriesIndexRunning) {
            Toast.makeText(this, "Catalogue job already running",
                    Toast.LENGTH_LONG).show();
            return;
        }

        final String playlistId = activePlaylistId;
        final String providerKey = getCatalogueProviderKey();
        final String movieUrl;
        final String seriesUrl;

        try {
            movieUrl = buildXtreamApiUrl(
                    "get_vod_streams", null, null);
            seriesUrl = buildXtreamApiUrl(
                    "get_series", null, null);
        } catch (Exception error) {
            Toast.makeText(this, "Provider request unavailable",
                    Toast.LENGTH_LONG).show();
            return;
        }

        cataloguePreviewCancel = false;
        cataloguePreviewRunning = true;

        final android.app.AlertDialog dialog =
                new android.app.AlertDialog.Builder(this)
                        .setTitle("Catalogue refresh preview")
                        .setMessage("Preparing read-only scan...")
                        .setNegativeButton("Cancel scan", null)
                        .setCancelable(false)
                        .create();

        dialog.show();
        dialog.getButton(
                android.app.AlertDialog.BUTTON_NEGATIVE)
                .setOnClickListener(v -> cataloguePreviewCancel = true);

        new Thread(() -> {
            CatalogueDbHelper helper = null;
            String report;

            try {
                helper = new CatalogueDbHelper(
                        getApplicationContext(),
                        CATALOGUE_DB_PREFIX
                                + sanitizePlaylistId(playlistId) + ".db");

                SQLiteDatabase db = helper.getReadableDatabase();

                CatalogueRefreshPreview.Guard guard = () -> {
                    if (cataloguePreviewCancel) {
                        throw new InterruptedException("Scan cancelled");
                    }
                    if (!playlistId.equals(activePlaylistId)
                            || !getPlaylistProfileIds().contains(playlistId)
                            || !providerKey.equals(getCatalogueProviderKey())) {
                        throw new IllegalStateException("Playlist changed");
                    }
                };

                CatalogueRefreshPreview.Progress progress =
                        (type, seen) -> runOnUiThread(() -> {
                            if (!cataloguePreviewCancel) {
                                dialog.setMessage(
                                        type + ": " + seen
                                        + " records checked...");
                            }
                        });

                guard.check();

                CatalogueRefreshPreview.Stats movies =
                        CatalogueRefreshPreview.scan(
                                db, providerKey, "MOVIES",
                                movieUrl, guard, progress);

                guard.check();

                CatalogueRefreshPreview.Stats series =
                        CatalogueRefreshPreview.scan(
                                db, providerKey, "SERIES",
                                seriesUrl, guard, progress);

                guard.check();

                report = movies.report("MOVIES")
                        + "\n\n" + series.report("SERIES")
                        + "\n\nRead-only scan. No records changed.";

            } catch (Exception error) {
                report = cataloguePreviewCancel
                        ? "Catalogue scan cancelled. No records changed."
                        : "Scan failed: "
                                + error.getClass().getSimpleName()
                                + "\nNo catalogue records changed.";
            } finally {
                if (helper != null) {
                    try { helper.close(); } catch (Exception ignored) {}
                }
                cataloguePreviewRunning = false;
            }

            final String result = report;

            runOnUiThread(() -> {
                dialog.dismiss();
                if (!isFinishing() && !isDestroyed()) {
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("Catalogue refresh analysis")
                            .setMessage(result)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        }, "pp-refresh-preview").start();
    }

    private volatile boolean catalogueDifferenceProbeRunning = false;

    private void sampleCatalogueDifferenceFields() {
        if (catalogueDifferenceProbeRunning
                || cataloguePreviewRunning
                || localRebuildRunning) {
            Toast.makeText(this, "Catalogue job running",
                    Toast.LENGTH_LONG).show();
            return;
        }

        final String playlistId = activePlaylistId;
        final String providerKey = getCatalogueProviderKey();
        final String movieUrl;
        final String seriesUrl;

        try {
            movieUrl = buildXtreamApiUrl(
                    "get_vod_streams", null, null);
            seriesUrl = buildXtreamApiUrl(
                    "get_series", null, null);
        } catch (Exception error) {
            Toast.makeText(this, "Provider URL unavailable",
                    Toast.LENGTH_LONG).show();
            return;
        }

        catalogueDifferenceProbeRunning = true;

        Toast.makeText(this, "Checking 10 movies and 10 series",
                Toast.LENGTH_LONG).show();

        new Thread(() -> {
            String report;
            CatalogueDbHelper helper = null;

            try {
                if (!playlistId.equals(activePlaylistId)
                        || !getPlaylistProfileIds().contains(playlistId)
                        || !providerKey.equals(getCatalogueProviderKey())) {
                    throw new IllegalStateException("Playlist changed");
                }

                helper = new CatalogueDbHelper(
                        getApplicationContext(),
                        CATALOGUE_DB_PREFIX
                                + sanitizePlaylistId(playlistId) + ".db");

                SQLiteDatabase db = helper.getReadableDatabase();

                String movies = CatalogueDifferenceSample.scan(
                        db, providerKey, movieUrl, true);

                if (!playlistId.equals(activePlaylistId)) {
                    throw new IllegalStateException("Playlist changed");
                }

                String series = CatalogueDifferenceSample.scan(
                        db, providerKey, seriesUrl, false);

                report = movies + "\n\n" + series
                        + "\n\nRead-only. No records modified.";

            } catch (Exception error) {
                report = "Diagnostic failed: "
                        + error.getClass().getSimpleName();
            } finally {
                if (helper != null) {
                    try { helper.close(); } catch (Exception ignored) {}
                }
                catalogueDifferenceProbeRunning = false;
            }

            final String result = report;
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()
                        && playlistId.equals(activePlaylistId)) {
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("Catalogue field differences")
                            .setMessage(result)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        }, "pp-difference-sample").start();
    }

    private volatile boolean smartRefreshRunning = false;
    private volatile boolean smartRefreshCancel = false;

    private void ppPutIfPresent(
            android.content.ContentValues values,
            String column,
            String value) {
        if (value != null && !value.isEmpty()) {
            values.put(column, value);
        }
    }

    private void writeSmartRefreshEntry(
            SQLiteDatabase db,
            String providerKey,
            CatalogueRefreshBatch.Entry entry,
            long generation) throws Exception {

        JsonReader reader = new JsonReader(
                new java.io.StringReader(entry.json));

        try {
            if (entry.movie) {
                MovieItem movie = readMovieItemFromStream(reader);

                if (!entry.id.equals(safe(movie.streamId))) {
                    throw new IllegalStateException("Movie ID mismatch");
                }

                if (entry.isNew) {
                    movie.importGeneration = generation;
                    upsertMovieCatalogue(
                            db, providerKey, movie,
                            !safe(movie.cast).isEmpty());
                    return;
                }

                android.content.ContentValues v =
                        new android.content.ContentValues();

                v.put("raw_json", entry.json);

                ppPutIfPresent(v, "category_id", movie.categoryId);
                ppPutIfPresent(v, "name", movie.name);
                ppPutIfPresent(v, "rating", movie.rating);
                ppPutIfPresent(v, "year", movie.year);
                ppPutIfPresent(v, "icon", movie.icon);
                ppPutIfPresent(v, "plot", movie.plot);
                ppPutIfPresent(v, "cast", movie.cast);
                ppPutIfPresent(v, "director", movie.director);
                ppPutIfPresent(v, "genre", movie.genre);
                ppPutIfPresent(v, "trailer", movie.trailer);
                ppPutIfPresent(v, "direct_source", movie.directSource);

                if (!safe(movie.extension).isEmpty()) {
                    v.put("extension",
                            sanitizeMediaExtension(movie.extension));
                }
                if (!safe(movie.name).isEmpty()) {
                    v.put("normalized_name",
                            normalizeSearchText(movie.name));
                }
                if (!safe(movie.cast).isEmpty()) {
                    v.put("normalized_cast",
                            normalizeSearchText(movie.cast));
                }
                if (movie.addedAt > 0L) {
                    v.put("added_at", movie.addedAt);
                }

                if (db.update("catalogue_movies", v,
                        "pk=? AND provider_key=?",
                        new String[]{providerKey + "|" + entry.id,
                                providerKey}) != 1) {
                    throw new IllegalStateException("Movie update failed");
                }

            } else {
                SeriesItem series = readSeriesItemFromStream(reader);

                if (!entry.id.equals(safe(series.seriesId))) {
                    throw new IllegalStateException("Series ID mismatch");
                }

                if (entry.isNew) {
                    series.importGeneration = generation;
                    upsertSeriesCatalogue(db, providerKey, series);
                    return;
                }

                android.content.ContentValues v =
                        new android.content.ContentValues();

                v.put("raw_json", entry.json);

                ppPutIfPresent(v, "category_id", series.categoryId);
                ppPutIfPresent(v, "name", series.name);
                ppPutIfPresent(v, "rating", series.rating);
                ppPutIfPresent(v, "year", series.year);
                ppPutIfPresent(v, "cover", series.cover);
                ppPutIfPresent(v, "plot", series.plot);
                ppPutIfPresent(v, "cast", series.cast);
                ppPutIfPresent(v, "director", series.director);
                ppPutIfPresent(v, "genre", series.genre);
                ppPutIfPresent(v, "trailer", series.trailer);

                if (!safe(series.name).isEmpty()) {
                    v.put("normalized_name",
                            normalizeSearchText(series.name));
                }
                if (!safe(series.cast).isEmpty()) {
                    v.put("normalized_cast",
                            normalizeSearchText(series.cast));
                }
                if (series.addedAt > 0L) {
                    v.put("added_at", series.addedAt);
                }
                if (series.updatedAt > 0L) {
                    v.put("updated_at", series.updatedAt);
                }

                if (db.update("catalogue_series", v,
                        "pk=? AND provider_key=?",
                        new String[]{providerKey + "|" + entry.id,
                                providerKey}) != 1) {
                    throw new IllegalStateException("Series update failed");
                }
            }

        } finally {
            reader.close();
        }
    }

    private void startSmartCatalogueRefresh() {
        if (smartRefreshRunning || localRebuildRunning
                || cataloguePreviewRunning
                || catalogueDifferenceProbeRunning
                || oldCatalogueCleanupRunning
                || backendMovieIndexRunning
                || backendSeriesIndexRunning) {
            Toast.makeText(this, "Catalogue job running",
                    Toast.LENGTH_LONG).show();
            return;
        }

        final String playlistId = activePlaylistId;
        final String providerKey = getCatalogueProviderKey();
        final String movieUrl;
        final String seriesUrl;

        try {
            movieUrl = buildXtreamApiUrl(
                    "get_vod_streams", null, null);
            seriesUrl = buildXtreamApiUrl(
                    "get_series", null, null);
        } catch (Exception e) {
            Toast.makeText(this, "Provider URL unavailable",
                    Toast.LENGTH_LONG).show();
            return;
        }

        smartRefreshCancel = false;
        smartRefreshRunning = true;

        android.app.AlertDialog dialog =
                new android.app.AlertDialog.Builder(this)
                        .setTitle("Smart catalogue refresh")
                        .setMessage("Checking provider catalogue...")
                        .setNegativeButton("Cancel", null)
                        .setCancelable(false)
                        .create();

        dialog.show();

        dialog.getButton(
                android.app.AlertDialog.BUTTON_NEGATIVE)
                .setOnClickListener(v -> {
                    smartRefreshCancel = true;
                    dialog.setMessage("Cancellation requested...");
                });

        new Thread(() -> {
            CatalogueDbHelper helper = null;
            String report;

            try {
                helper = new CatalogueDbHelper(
                        getApplicationContext(),
                        CATALOGUE_DB_PREFIX
                                + sanitizePlaylistId(playlistId) + ".db");

                SQLiteDatabase db = helper.getWritableDatabase();

                CatalogueRefreshBatch.Guard guard = () -> {
                    if (smartRefreshCancel) {
                        throw new InterruptedException("Refresh cancelled");
                    }

                    if (!playlistId.equals(activePlaylistId)
                            || !getPlaylistProfileIds().contains(playlistId)
                            || !providerKey.equals(getCatalogueProviderKey())) {
                        throw new IllegalStateException("Playlist changed");
                    }
                };

                guard.check();

                CatalogueRefreshBatch batch =
                        CatalogueRefreshBatch.prepare(
                                db, providerKey, movieUrl, seriesUrl,
                                guard,
                                (type, seen) -> runOnUiThread(() -> {
                                    if (!smartRefreshCancel) {
                                        dialog.setMessage(
                                                type + ": " + seen + " checked");
                                    }
                                }));

                guard.check();

                runOnUiThread(() ->
                        dialog.setMessage("Applying "
                                + batch.entries.size()
                                + " selected changes..."));

                CatalogueRefreshCommit.Result result =
                        CatalogueRefreshCommit.apply(
                                db, providerKey, batch,
                                guard::check,
                                (entry, generation) ->
                                        writeSmartRefreshEntry(
                                                db, providerKey,
                                                entry, generation));

                report = result.summary()
                        + "\n\n"
                        + batch.summary()
                        + "\n\nNo missing titles deleted.";

            } catch (Exception error) {
                report = smartRefreshCancel
                        ? "Refresh cancelled. Uncommitted changes rolled back."
                        : "Refresh failed: "
                                + error.getClass().getSimpleName()
                                + ": " + String.valueOf(error.getMessage());
            } finally {
                if (helper != null) {
                    try { helper.close(); } catch (Exception ignored) {}
                }
                smartRefreshRunning = false;
            }

            final String finalReport = report;

            runOnUiThread(() -> {
                dialog.dismiss();

                if (!isFinishing() && !isDestroyed()) {
                    new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("Smart refresh results")
                            .setMessage(finalReport)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        }, "pp-smart-refresh").start();
    }

    private void showSettings() {
        releasePlayer();
        onHomeScreen = false;

        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setBackgroundColor(BLACK);

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                dp(20),
                dp(24),
                dp(20),
                dp(30));

        scrollView.addView(root);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        root.addView(back);

        TextView heading =
                new TextView(this);

        heading.setText("SETTINGS");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        




root.addView(heading);

        Button refreshButton =
                makeSmallButton("APPLY SMART CATALOGUE REFRESH");
        refreshButton.setOnClickListener(
                v -> startSmartCatalogueRefresh());
        root.addView(refreshButton);


        Button differenceButton =
                makeSmallButton("SAMPLE JSON DIFFERENCES (10+10)");
        differenceButton.setOnClickListener(
                v -> sampleCatalogueDifferenceFields());
        root.addView(differenceButton);


        Button previewButton =
                makeSmallButton("PREVIEW CATALOGUE REFRESH");
        previewButton.setOnClickListener(
                v -> previewCatalogueChanges());
        root.addView(previewButton);


        Button cleanupButton =
                makeSmallButton("REMOVE OBSOLETE CATALOGUE RECORDS");
        cleanupButton.setOnClickListener(
                v -> confirmOldCatalogueCleanup());
        root.addView(cleanupButton);


        Button rebuildButton =
                makeSmallButton("REBUILD LOCAL CATALOGUE");
        rebuildButton.setOnClickListener(
                v -> confirmLocalCatalogueRebuild());
        root.addView(rebuildButton);

        Button catalogueProbe = makeSmallButton("AUDIT CATALOGUE (READ-ONLY)");
        catalogueProbe.setOnClickListener(v -> showCatalogueGenerationAudit());
        root.addView(catalogueProbe);

        SettingsTopSection.add(
                this,
                new SettingsTopSection.Host() {
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public void showHomeSettings() { showHomeScreenSettings(); }
                    public void showSportsSettings() { showSportsPreferences(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                },
                root);
        SettingsAudioSection.add(
                this,
                new SettingsAudioSection.Host() {
                    public android.content.SharedPreferences prefs() { return playlistPrefs(); }
                    public String preferredLanguage() { return getPreferredAudioLanguage(); }
                    public String languageName(String code) { return getAudioLanguageName(code); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public void refreshSettings() { showSettings(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                    public int charcoal() { return CHARCOAL; }
                },
                root);
        SettingsContentSection.add(
                this,
                new SettingsContentSection.Host() {
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public void showChannelEditor() { MainActivity.this.showChannelEditor(); }
                    public void showCategoryManager(String type) { MainActivity.this.showCategoryManager(type); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                },
                root);
        SettingsVpnSection.add(
                this,
                new SettingsVpnSection.Host() {
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public void showVpn() { showVpnManager(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                },
                root);
        setContentView(scrollView);
    }

    private void showHomeScreenSettings() {
        releasePlayer();
        onHomeScreen = false;

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scrollView.addView(root);

        TextView back = createBackText();
        back.setText("<  SETTINGS");
        back.setOnClickListener(v -> showSettings());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText("HOME SCREEN SETTINGS");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(28);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        HomeSettingsThemeSection.add(
                this,
                new HomeSettingsThemeSection.Host() {
                    public String currentTheme() { return getVisualThemeName(); }
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public void selectTheme(String theme) {
                        playlistPrefs().edit().putString("home_colour_theme", theme).apply();
                        loadVisualTheme();
                        getWindow().setStatusBarColor(BLACK);
                        getWindow().setNavigationBarColor(BLACK);
                        showHomeScreenSettings();
                    }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                    public int charcoal() { return CHARCOAL; }
                },
                root);
        HomeSettingsTilesStartupSection.add(
                this,
                new HomeSettingsTilesStartupSection.Host() {
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public void showEditHome() { MainActivity.this.showEditHome(); }
                    public String startupDestination() { return getStartupDestination(); }
                    public String startupLabel(String destination) { return getStartupDestinationLabel(destination); }
                    public void addStartupButton(LinearLayout r, String label, String destination) {
                        addStartupDestinationButton(r, label, destination);
                    }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                },
                root);
        HomeSettingsResumeSection.add(
                this,
                new HomeSettingsResumeSection.Host() {
                    public Button smallButton(String text) { return makeSmallButton(text); }
                    public android.graphics.drawable.Drawable background(int f, int b, int r) { return makeBackground(f, b, r); }
                    public boolean isEnabled(int slot) { return isHomeResumeSlotEnabled(slot); }
                    public void setEnabled(int slot, boolean enabled) { setHomeResumeSlotEnabled(slot, enabled); }
                    public void refresh() { showHomeScreenSettings(); }
                    public void showHome() { MainActivity.this.showHome(); }
                    public int dp(int v) { return MainActivity.this.dp(v); }
                    public int gold() { return GOLD; }
                    public int silver() { return SILVER; }
                    public int black() { return BLACK; }
                    public int charcoal() { return CHARCOAL; }
                },
                root);
        setContentView(scrollView);
    }

    private interface VpnIpCallback {
        void onResult(String ip, String error);
    }

    private boolean isEmbeddedVpnEnabled() {
        return playlistPrefs()
                .getBoolean("embedded_vpn_enabled", false);
    }

    private boolean isEmbeddedVpnAutoReconnect() {
        return playlistPrefs()
                .getBoolean("embedded_vpn_auto_reconnect", true);
    }

    private boolean isEmbeddedVpnPlaybackBlockEnabled() {
        return playlistPrefs()
                .getBoolean("embedded_vpn_block_playback", false);
    }

    private void setEmbeddedVpnPref(String key, boolean value) {
        playlistPrefs()
                .edit()
                .putBoolean(key, value)
                .apply();
    }

    private boolean isEmbeddedVpnConnected() {
        return embeddedVpn != null && embeddedVpn.isConnected();
    }

    private boolean isEmbeddedVpnConfigured() {
        return embeddedVpn != null && embeddedVpn.isConfigured();
    }

    private void showVpnManager() {
        releasePlayer();
        onHomeScreen = false;

        if (embeddedVpn == null) {
            embeddedVpn = new EmbeddedWireGuardManager(getApplicationContext());
        }

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scrollView.addView(root);

        TextView back = createBackText();
        back.setText("<  SETTINGS");
        back.setOnClickListener(v -> showSettings());
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText("VPN");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(heading);

        TextView explanation = new TextView(this);
        explanation.setText(
                "WireGuard now runs inside PREMIUM PLAYER. No Proton app, WireGuard app, "
                        + "or OpenVPN app is needed. Only PREMIUM PLAYER is routed through the tunnel.\n\n"
                        + "Android will show its own VPN permission window once on each device. "
                        + "That system permission cannot be bypassed by an app.");
        explanation.setTextColor(SILVER);
        explanation.setTextSize(13);
        explanation.setPadding(0, dp(8), 0, dp(18));
        root.addView(explanation);

        TextView vpnState = new TextView(this);
        vpnState.setTextColor(Color.WHITE);
        vpnState.setTextSize(17);
        vpnState.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        vpnState.setPadding(dp(14), dp(14), dp(14), dp(14));
        vpnState.setBackground(makeBackground(CHARCOAL, Color.rgb(55, 55, 58), 12));
        root.addView(vpnState);

        TextView configState = new TextView(this);
        configState.setTextColor(SILVER);
        configState.setTextSize(13);
        configState.setPadding(0, dp(12), 0, dp(4));
        root.addView(configState);

        TextView ipStatus = new TextView(this);
        ipStatus.setTextColor(SILVER);
        ipStatus.setTextSize(13);
        ipStatus.setPadding(0, dp(4), 0, dp(16));
        root.addView(ipStatus);

        updateEmbeddedVpnStatusLabels(vpnState, configState, ipStatus);

        TextView setupTitle = new TextView(this);
        setupTitle.setText("CONFIGURATION");
        setupTitle.setTextColor(GOLD);
        setupTitle.setTextSize(12);
        setupTitle.setPadding(0, dp(12), 0, dp(8));
        root.addView(setupTitle);

        Button importConfig = makeSmallButton("IMPORT PROTON WIREGUARD .CONF");
        importConfig.setOnClickListener(v -> chooseWireGuardConfig());
        addVpnButton(root, importConfig);

        TextView importHelp = new TextView(this);
        importHelp.setText(
                "For your family APK, put the same Proton configuration in assets/proton_wireguard.conf "
                        + "before building. The Import button is useful for testing on this device.");
        importHelp.setTextColor(Color.rgb(135, 135, 140));
        importHelp.setTextSize(12);
        importHelp.setPadding(0, 0, 0, dp(12));
        root.addView(importHelp);

        TextView optionsTitle = new TextView(this);
        optionsTitle.setText("VPN OPTIONS");
        optionsTitle.setTextColor(GOLD);
        optionsTitle.setTextSize(12);
        optionsTitle.setPadding(0, dp(10), 0, dp(8));
        root.addView(optionsTitle);

        Button enabled = makeSmallButton(
                "VPN FOR PREMIUM PLAYER   •   " + (isEmbeddedVpnEnabled() ? "ON" : "OFF"));
        enabled.setOnClickListener(v -> {
            boolean next = !isEmbeddedVpnEnabled();
            setEmbeddedVpnPref("embedded_vpn_enabled", next);
            if (next) {
                connectEmbeddedVpn(true, null);
            } else if (embeddedVpn != null) {
                embeddedVpn.disconnectAsync((success, message) -> runOnUiThread(this::showVpnManager));
            }
            if (!next) {
                showVpnManager();
            }
        });
        addVpnButton(root, enabled);

        Button reconnect = makeSmallButton(
                "AUTO RECONNECT   •   " + (isEmbeddedVpnAutoReconnect() ? "ON" : "OFF"));
        reconnect.setOnClickListener(v -> {
            setEmbeddedVpnPref("embedded_vpn_auto_reconnect", !isEmbeddedVpnAutoReconnect());
            showVpnManager();
        });
        addVpnButton(root, reconnect);

        Button playbackBlock = makeSmallButton(
                "BLOCK PLAYBACK IF VPN DROPS   •   "
                        + (isEmbeddedVpnPlaybackBlockEnabled() ? "ON" : "OFF"));
        playbackBlock.setOnClickListener(v -> {
            setEmbeddedVpnPref("embedded_vpn_block_playback", !isEmbeddedVpnPlaybackBlockEnabled());
            showVpnManager();
        });
        addVpnButton(root, playbackBlock);

        TextView controlTitle = new TextView(this);
        controlTitle.setText("VPN CONTROL");
        controlTitle.setTextColor(GOLD);
        controlTitle.setTextSize(12);
        controlTitle.setPadding(0, dp(20), 0, dp(8));
        root.addView(controlTitle);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);

        Button connect = makeSmallButton("CONNECT");
        connect.setOnClickListener(v -> {
            setEmbeddedVpnPref("embedded_vpn_enabled", true);
            connectEmbeddedVpn(true, () -> showVpnManager());
        });

        Button disconnect = makeSmallButton("DISCONNECT");
        disconnect.setOnClickListener(v -> {
            setEmbeddedVpnPref("embedded_vpn_enabled", false);
            if (embeddedVpn == null) return;
            embeddedVpn.disconnectAsync((success, message) -> runOnUiThread(() -> {
                if (!success) {
                    Toast.makeText(this, "VPN disconnect failed: " + message, Toast.LENGTH_LONG).show();
                }
                showVpnManager();
            }));
        });

        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(52), 1f);
        half.setMargins(0, 0, dp(5), dp(9));
        controls.addView(connect, half);

        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        half2.setMargins(dp(5), 0, 0, dp(9));
        controls.addView(disconnect, half2);
        root.addView(controls);

        Button captureHomeIp = makeSmallButton("CAPTURE HOME IP");
        captureHomeIp.setOnClickListener(v -> {
            if (isEmbeddedVpnConnected()) {
                Toast.makeText(this, "Disconnect PREMIUM PLAYER VPN first.", Toast.LENGTH_LONG).show();
                return;
            }
            ipStatus.setText("Checking your normal public IP...");
            fetchPublicIp((ip, error) -> {
                if (error != null) {
                    ipStatus.setText("Home IP check failed: " + error);
                    return;
                }
                playlistPrefs()
                        .edit().putString("vpn_baseline_ip", ip).apply();
                updateEmbeddedVpnStatusLabels(vpnState, configState, ipStatus);
                Toast.makeText(this, "Home IP saved.", Toast.LENGTH_SHORT).show();
            });
        });
        addVpnButton(root, captureHomeIp);

        Button verify = makeSmallButton("VERIFY VPN");
        verify.setBackground(makeBackground(GOLD, GOLD, 12));
        verify.setTextColor(BLACK);
        verify.setOnClickListener(v -> verifyEmbeddedVpnConnection(vpnState, ipStatus));
        addVpnButton(root, verify);

        TextView verifyHelp = new TextView(this);
        verifyHelp.setText(
                "VPN VERIFIED means PREMIUM PLAYER's embedded WireGuard tunnel is connected "
                        + "and its public IP differs from the saved home IP. Because this is split tunnelling, "
                        + "a browser on the same device should continue to use the normal home IP.");
        verifyHelp.setTextColor(Color.rgb(135, 135, 140));
        verifyHelp.setTextSize(12);
        verifyHelp.setPadding(0, dp(12), 0, dp(8));
        root.addView(verifyHelp);

        setContentView(scrollView);
    }

    private void addVpnButton(LinearLayout root, Button button) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        params.setMargins(0, 0, 0, dp(9));
        root.addView(button, params);
    }

    private void chooseWireGuardConfig() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_WIREGUARD_CONFIG);
    }

    private EmbeddedVpnConnectionCoordinator.Host embeddedVpnConnectionHost() {
        return new EmbeddedVpnConnectionCoordinator.Host() {

            public void ensureManager() {
                if (embeddedVpn == null) {
                    embeddedVpn =
                            new EmbeddedWireGuardManager(
                                    getApplicationContext());
                }
            }

            public boolean isConfigured() {
                return embeddedVpn != null
                        && embeddedVpn.isConfigured();
            }

            public Intent preparePermission() {
                return android.net.VpnService.prepare(
                        MainActivity.this);
            }

            public void setPendingAction(
                    Runnable action) {

                pendingVpnConnectedAction =
                        action;
            }

            public void launchPermission(
                    Intent permission)
                    throws Exception {

                startActivityForResult(
                        permission,
                        VPN_PERMISSION_REQUEST);
            }

            public void connect(
                    EmbeddedVpnConnectionCoordinator.Completion completion) {

                embeddedVpn.connectAsync(
                        (success, message) ->
                                completion.complete(
                                        success,
                                        message));
            }

            public void runUi(
                    Runnable action) {

                runOnUiThread(
                        action);
            }

            public void setEnabled(
                    boolean enabled) {

                setEmbeddedVpnPref(
                        "embedded_vpn_enabled",
                        enabled);
            }

            public void showMessage(
                    String message) {

                Toast.makeText(
                        MainActivity.this,
                        message,
                        Toast.LENGTH_LONG)
                        .show();
            }

            public String errorMessage(
                    Exception error) {

                return safeErrorMessage(
                        error);
            }
        };
    }

    private void connectEmbeddedVpn(
            boolean showErrors,
            Runnable onConnected) {

        EmbeddedVpnConnectionCoordinator.connect(
                showErrors,
                onConnected,
                embeddedVpnConnectionHost());
    }

    private EmbeddedVpnHealthCoordinator.Host embeddedVpnHealthHost() {
        return new EmbeddedVpnHealthCoordinator.Host() {

            public boolean wantsVpn() {
                return isEmbeddedVpnEnabled();
            }

            public boolean autoReconnect() {
                return isEmbeddedVpnAutoReconnect();
            }

            public boolean connected() {
                return isEmbeddedVpnConnected();
            }

            public boolean managerReady() {
                return embeddedVpn != null;
            }

            public boolean managerBusy() {
                return embeddedVpn != null
                        && embeddedVpn.isBusy();
            }

            public boolean managerConfigured() {
                return embeddedVpn != null
                        && embeddedVpn.isConfigured();
            }

            public boolean permissionGranted() {
                return android.net.VpnService.prepare(
                        MainActivity.this) == null;
            }

            public void connect() {
                connectEmbeddedVpn(
                        false,
                        null);
            }

            public boolean playbackBlockEnabled() {
                return isEmbeddedVpnPlaybackBlockEnabled();
            }

            public boolean hasPlayer() {
                return exoPlayer != null;
            }

            public boolean playerIsPlaying() {
                return exoPlayer != null
                        && exoPlayer.getPlayWhenReady();
            }

            public void setPlayerPlaying(
                    boolean playing) {

                if (exoPlayer != null) {
                    exoPlayer.setPlayWhenReady(
                            playing);
                }
            }

            public boolean playbackPausedByVpn() {
                return playbackPausedByVpn;
            }

            public void setPlaybackPausedByVpn(
                    boolean paused) {

                playbackPausedByVpn =
                        paused;
            }

            public void setPlaybackStatus(
                    String text) {

                if (activePlaybackStatus != null) {
                    activePlaybackStatus.setText(
                            text);
                }
            }
        };
    }

    private void startEmbeddedVpnHealthMonitor() {
        vpnHealthRunnable =
                EmbeddedVpnHealthCoordinator.start(
                        vpnHealthHandler,
                        vpnHealthRunnable,
                        embeddedVpnHealthHost());
    }

    private boolean shouldBlockPlaybackForVpn() {
        return isEmbeddedVpnEnabled() && isEmbeddedVpnPlaybackBlockEnabled();
    }

    private void updateEmbeddedVpnStatusLabels(TextView vpnState, TextView configState, TextView ipStatus) {
        boolean connected = isEmbeddedVpnConnected();
        boolean configured = isEmbeddedVpnConfigured();

        vpnState.setText(connected
                ? "WIREGUARD STATUS  •  CONNECTED"
                : "WIREGUARD STATUS  •  DISCONNECTED");

        if (configured) {
            configState.setText("Proton WireGuard config: READY"
                    + ((embeddedVpn != null && embeddedVpn.hasPrivateConfig()) ? " (imported on this device)" : " (bundled in app)"));
        } else {
            configState.setText("Proton WireGuard config: NOT INSTALLED");
        }

        String baseline = playlistPrefs()
                .getString("vpn_baseline_ip", "");
        if (baseline.isEmpty()) {
            ipStatus.setText("Home IP: not captured yet");
        } else {
            ipStatus.setText("Saved home IP: " + baseline);
        }
    }

    private void verifyEmbeddedVpnConnection(TextView vpnState, TextView ipStatus) {
        final boolean vpnActive = isEmbeddedVpnConnected();
        final String baseline = playlistPrefs()
                .getString("vpn_baseline_ip", "");

        if (baseline.isEmpty()) {
            Toast.makeText(this, "Capture your HOME IP while disconnected first.", Toast.LENGTH_LONG).show();
            return;
        }

        ipStatus.setText("Checking PREMIUM PLAYER public IP...");
        fetchPublicIp((currentIp, error) -> {
            if (error != null) {
                vpnState.setText(vpnActive ? "WIREGUARD CONNECTED" : "WIREGUARD DISCONNECTED");
                ipStatus.setText("VPN test failed: " + error);
                return;
            }

            boolean ipChanged = !baseline.equals(currentIp);
            if (vpnActive && ipChanged) {
                vpnState.setText("VPN VERIFIED");
                ipStatus.setText("Home IP: " + baseline
                        + "\nVPN IP: " + currentIp
                        + "\nPREMIUM PLAYER traffic is leaving through the WireGuard tunnel.");
            } else if (vpnActive) {
                vpnState.setText("VPN CONNECTED • IP NOT CHANGED");
                ipStatus.setText("Current IP: " + currentIp
                        + "\nWireGuard reports connected, but the exit IP did not change.");
            } else {
                vpnState.setText("VPN NOT ACTIVE");
                ipStatus.setText("Current IP: " + currentIp + "\nConnect WireGuard, then verify again.");
            }
        });
    }

    private VpnPublicIpLookup.Host vpnPublicIpHost() {
        return new VpnPublicIpLookup.Host() {

            public void runUi(
                    Runnable action) {

                runOnUiThread(
                        action);
            }

            public String errorMessage(
                    Exception error) {

                return safeErrorMessage(
                        error);
            }
        };
    }

    private void fetchPublicIp(
            VpnIpCallback callback) {

        VpnPublicIpLookup.fetch(
                vpnPublicIpHost(),
                callback::onResult);
    }

    private String getPreferredAudioLanguage() {
        return playlistPrefs()
                .getString(
                        "preferred_audio_language",
                        "");
    }

    private String getAudioLanguageName(
            String code) {

        if (code == null
                || code.isEmpty()) {
            return "Auto / stream default";
        }

        if (code.equals("en")) return "English";
        if (code.equals("fr")) return "French";
        if (code.equals("es")) return "Spanish";
        if (code.equals("pt")) return "Portuguese";
        if (code.equals("ar")) return "Arabic";
        if (code.equals("de")) return "German";
        if (code.equals("it")) return "Italian";
        if (code.equals("nl")) return "Dutch";
        if (code.equals("sv")) return "Swedish";

        return code;
    }

    // ---------------------------------------------------------------------
    // EPG
    // ---------------------------------------------------------------------

    private void showTvGuide() {
        releasePlayer();
        onHomeScreen = false;
        ensureSelectedChannel();

        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setBackgroundColor(BLACK);

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL);

        root.setPadding(
                dp(20),
                dp(24),
                dp(20),
                dp(30));

        scrollView.addView(root);

        TextView back = createBackText();
        back.setOnClickListener(v -> showHome());
        root.addView(back);

        TextView heading =
                new TextView(this);

        heading.setText("TV GUIDE");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        root.addView(heading);

        TextView help =
                new TextView(this);

        help.setText(
                "Select a channel to load its current and upcoming Xtream EPG.");

        help.setTextColor(SILVER);
        help.setTextSize(13);
        help.setPadding(
                0,
                dp(8),
                0,
                dp(18));

        root.addView(help);

        TextView selectedTitle =
                new TextView(this);

        selectedTitle.setText(
                selectedChannel);

        selectedTitle.setTextColor(GOLD);
        selectedTitle.setTextSize(18);
        selectedTitle.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        root.addView(selectedTitle);

        LinearLayout epgContainer =
                new LinearLayout(this);

        epgContainer.setOrientation(
                LinearLayout.VERTICAL);

        LinearLayout.LayoutParams epgParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);

        epgParams.setMargins(
                0,
                dp(10),
                0,
                dp(24));

        root.addView(
                epgContainer,
                epgParams);

        TextView channelsTitle =
                new TextView(this);

        channelsTitle.setText("CHANNELS");
        channelsTitle.setTextColor(Color.WHITE);
        channelsTitle.setTextSize(18);
        channelsTitle.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD);

        channelsTitle.setPadding(
                0,
                0,
                0,
                dp(10));

        root.addView(channelsTitle);

        ArrayList<Channel> channels =
                getActiveChannels();

        int guideChannelLimit =
                Math.min(
                        40,
                        channels.size());

        for (int i = 0;
             i < guideChannelLimit;
             i++) {

            Channel channel =
                    channels.get(i);

            TextView channelButton =
                    new TextView(this);

            channelButton.setText(
                    channel.name
                            + "   •   "
                            + safe(channel.group));

            channelButton.setTextColor(Color.WHITE);
            channelButton.setTextSize(14);
            channelButton.setGravity(
                    Gravity.CENTER_VERTICAL);

            channelButton.setPadding(
                    dp(16),
                    dp(13),
                    dp(16),
                    dp(13));

            channelButton.setClickable(true);
            channelButton.setFocusable(true);

            channelButton.setBackground(
                    makeBackground(
                            CHARCOAL,
                            Color.rgb(52, 52, 56),
                            12));

            LinearLayout.LayoutParams channelParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            dp(54));

            channelParams.setMargins(
                    0,
                    0,
                    0,
                    dp(8));

            root.addView(
                    channelButton,
                    channelParams);

            channelButton.setOnClickListener(v -> {
                selectChannelInternal(channel);
                selectedTitle.setText(channel.name);
                loadGuideForChannel(
                        channel,
                        epgContainer);
            });
        }

        if (channels.size() > guideChannelLimit) {
            TextView notice =
                    new TextView(this);

            notice.setText(
                    "Showing the first "
                            + guideChannelLimit
                            + " channels in this guide view.");

            notice.setTextColor(
                    Color.rgb(
                            130,
                            130,
                            135));

            notice.setTextSize(12);
            notice.setGravity(Gravity.CENTER);
            notice.setPadding(
                    0,
                    dp(10),
                    0,
                    0);

            root.addView(notice);
        }

        setContentView(scrollView);

        Channel selected =
                findSelectedChannel();

        if (selected != null) {
            loadGuideForChannel(
                    selected,
                    epgContainer);
        }
    }

    private void loadGuideForChannel(
            Channel channel,
            LinearLayout container) {

        container.removeAllViews();

        TextView loading =
                new TextView(this);

        loading.setText("Loading EPG...");
        loading.setTextColor(SILVER);
        loading.setTextSize(13);
        loading.setPadding(
                0,
                dp(8),
                0,
                dp(8));

        container.addView(loading);

        fetchShortEpg(
                channel,
                8,
                (entries, error) -> {

                    container.removeAllViews();

                    if (error != null) {
                        TextView errorText =
                                new TextView(this);

                        errorText.setText(
                                "EPG unavailable: "
                                        + error);

                        errorText.setTextColor(SILVER);
                        errorText.setTextSize(13);
                        container.addView(errorText);
                        return;
                    }

                    if (entries.isEmpty()) {
                        TextView empty =
                                new TextView(this);

                        empty.setText(
                                "No EPG entries were returned.");

                        empty.setTextColor(SILVER);
                        empty.setTextSize(13);
                        container.addView(empty);
                        return;
                    }

                    for (EpgEntry entry : entries) {
                        LinearLayout card =
                                new LinearLayout(this);

                        card.setOrientation(
                                LinearLayout.VERTICAL);

                        card.setPadding(
                                dp(14),
                                dp(12),
                                dp(14),
                                dp(12));

                        if (entry.nowPlaying) {
                            card.setBackground(
                                    makeBackground(
                                            Color.rgb(35, 31, 23),
                                            GOLD,
                                            12));
                        } else {
                            card.setBackground(
                                    makeBackground(
                                            CHARCOAL,
                                            Color.rgb(52, 52, 56),
                                            12));
                        }

                        TextView time =
                                new TextView(this);

                        time.setText(
                                entry.startText
                                        + " - "
                                        + entry.endText
                                        + (entry.nowPlaying
                                        ? "   NOW"
                                        : ""));

                        time.setTextColor(
                                entry.nowPlaying
                                        ? GOLD
                                        : SILVER);

                        time.setTextSize(11);
                        card.addView(time);

                        TextView title =
                                new TextView(this);

                        title.setText(entry.title);
                        title.setTextColor(Color.WHITE);
                        title.setTextSize(15);
                        title.setTypeface(
                                Typeface.DEFAULT,
                                Typeface.BOLD);

                        title.setPadding(
                                0,
                                dp(4),
                                0,
                                0);

                        card.addView(title);

                        if (!entry.description.isEmpty()) {
                            TextView description =
                                    new TextView(this);

                            description.setText(
                                    entry.description);

                            description.setTextColor(
                                    Color.rgb(
                                            150,
                                            150,
                                            155));

                            description.setTextSize(11);
                            description.setPadding(
                                    0,
                                    dp(4),
                                    0,
                                    0);

                            card.addView(description);
                        }

                        LinearLayout.LayoutParams params =
                                new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT);

                        params.setMargins(
                                0,
                                0,
                                0,
                                dp(8));

                        container.addView(
                                card,
                                params);
                    }
                });
    }

    private void loadShortEpg(
            Channel channel,
            TextView programme,
            TextView nextProgramme,
            TextView cardNow,
            TextView cardNext) {

        fetchShortEpg(
                channel,
                4,
                (entries, error) -> {

                    if (error != null
                            || entries.isEmpty()) {

                        if (programme != null
                                && channel.name.equals(
                                        selectedChannel)) {

                            programme.setText(
                                    safe(channel.group));
                        }

                        if (nextProgramme != null
                                && channel.name.equals(
                                        selectedChannel)) {

                            nextProgramme.setText(
                                    "EPG unavailable");
                        }

                        if (cardNext != null) {
                            cardNext.setText(
                                    "EPG unavailable");
                        }

                        return;
                    }

                    int nowIndex = 0;

                    for (int i = 0;
                         i < entries.size();
                         i++) {

                        if (entries.get(i).nowPlaying) {
                            nowIndex = i;
                            break;
                        }
                    }

                    EpgEntry now =
                            entries.get(nowIndex);

                    EpgEntry next =
                            nowIndex + 1 < entries.size()
                                    ? entries.get(nowIndex + 1)
                                    : null;

                    channel.now =
                            now.title;

                    channel.next =
                            next == null
                                    ? ""
                                    : next.title;

                    if (channel.name.equals(
                            selectedChannel)) {

                        selectedNow =
                                channel.now;

                        selectedNext =
                                channel.next;

                        if (programme != null) {
                            programme.setText(
                                    "NOW  "
                                            + selectedNow);
                        }

                        if (nextProgramme != null) {
                            nextProgramme.setText(
                                    selectedNext.isEmpty()
                                            ? "NEXT  No further listing"
                                            : "NEXT  "
                                                    + selectedNext);
                        }
                    }

                    if (cardNow != null) {
                        cardNow.setText(
                                "NOW  "
                                        + channel.now);
                    }

                    if (cardNext != null) {
                        cardNext.setText(
                                channel.next.isEmpty()
                                        ? "NEXT  No further listing"
                                        : "NEXT  "
                                                + channel.next);
                    }
                });
    }

    private void fetchShortEpg(
            Channel channel,
            int limit,
            EpgCallback callback) {

        if (!isXtreamSource()) {
            runOnUiThread(
                    () -> callback.onResult(
                            new ArrayList<EpgEntry>(),
                            "Xtream login required"));

            return;
        }

        android.content.SharedPreferences prefs =
                playlistPrefs();

        String server =
                prefs.getString(
                        "xtream_server",
                        "");

        String username =
                prefs.getString(
                        "xtream_username",
                        "");

        String password =
                prefs.getString(
                        "xtream_password",
                        "");

        String streamId =
                safe(channel.streamId);

        if (streamId.isEmpty()) {
            streamId =
                    extractXtreamStreamId(
                            channel.url);
        }

        if (server == null
                || username == null
                || password == null
                || server.trim().isEmpty()
                || username.trim().isEmpty()
                || password.isEmpty()
                || streamId.isEmpty()) {

            runOnUiThread(
                    () -> callback.onResult(
                            new ArrayList<EpgEntry>(),
                            "Missing Xtream EPG information"));

            return;
        }

        final String finalStreamId =
                streamId;

        new Thread(() -> {
            try {
                String epgUrl =
                        normalizeXtreamServer(server)
                                + "/player_api.php?username="
                                + URLEncoder.encode(
                                        username,
                                        "UTF-8")
                                + "&password="
                                + URLEncoder.encode(
                                        password,
                                        "UTF-8")
                                + "&action=get_short_epg"
                                + "&stream_id="
                                + URLEncoder.encode(
                                        finalStreamId,
                                        "UTF-8")
                                + "&limit="
                                + limit;

                String response =
                        downloadPlaylistText(
                                epgUrl);

                JSONObject root =
                        new JSONObject(
                                response);

                JSONArray listings =
                        root.optJSONArray(
                                "epg_listings");

                ArrayList<EpgEntry> entries =
                        new ArrayList<EpgEntry>();

                if (listings != null) {
                    long nowSeconds =
                            System.currentTimeMillis()
                                    / 1000L;

                    for (int i = 0;
                         i < listings.length();
                         i++) {

                        JSONObject item =
                                listings.getJSONObject(i);

                        EpgEntry entry =
                                new EpgEntry();

                        entry.title =
                                decodeMaybeBase64(
                                        item.optString(
                                                "title",
                                                "Untitled"));

                        entry.description =
                                decodeMaybeBase64(
                                        item.optString(
                                                "description",
                                                ""));

                        entry.category =
                                decodeMaybeBase64(
                                        item.optString(
                                                "category",
                                                ""));

                        entry.startTimestamp =
                                item.optLong(
                                        "start_timestamp",
                                        0L);

                        entry.endTimestamp =
                                item.optLong(
                                        "stop_timestamp",
                                        item.optLong(
                                                "end_timestamp",
                                                0L));

                        entry.startText =
                                formatEpgTime(
                                        entry.startTimestamp,
                                        item.optString(
                                                "start",
                                                ""));

                        entry.endText =
                                formatEpgTime(
                                        entry.endTimestamp,
                                        item.optString(
                                                "end",
                                                ""));

                        entry.nowPlaying =
                                item.optInt(
                                        "now_playing",
                                        0) == 1;

                        if (!entry.nowPlaying
                                && entry.startTimestamp > 0
                                && entry.endTimestamp > 0
                                && nowSeconds >= entry.startTimestamp
                                && nowSeconds < entry.endTimestamp) {

                            entry.nowPlaying = true;
                        }

                        entries.add(entry);
                    }
                }

                runOnUiThread(
                        () -> callback.onResult(
                                entries,
                                null));

            } catch (Exception e) {
                String message =
                        e.getMessage();

                if (message == null
                        || message.trim().isEmpty()) {

                    message =
                            e.getClass()
                                    .getSimpleName();
                }

                final String safeMessage =
                        message;

                runOnUiThread(
                        () -> callback.onResult(
                                new ArrayList<EpgEntry>(),
                                safeMessage));
            }
        }).start();
    }

    private String decodeMaybeBase64(
            String value) {

        if (value == null) {
            return "";
        }

        String trimmed =
                value.trim();

        if (trimmed.isEmpty()) {
            return "";
        }

        try {
            if (!trimmed.matches(
                    "^[A-Za-z0-9+/]+={0,2}$")
                    || trimmed.length() % 4 != 0) {

                return trimmed;
            }

            byte[] decoded =
                    android.util.Base64.decode(
                            trimmed,
                            android.util.Base64.DEFAULT);

            String candidate =
                    new String(
                            decoded,
                            "UTF-8")
                            .trim();

            if (candidate.isEmpty()
                    || candidate.contains("\uFFFD")) {

                return trimmed;
            }

            int printable = 0;

            for (int i = 0;
                 i < candidate.length();
                 i++) {

                char c =
                        candidate.charAt(i);

                if (!Character.isISOControl(c)
                        || c == '\n'
                        || c == '\r'
                        || c == '\t') {

                    printable++;
                }
            }

            if (candidate.length() > 0
                    && printable * 100
                    / candidate.length() >= 90) {

                return candidate;
            }

        } catch (Exception ignored) {
        }

        return trimmed;
    }

    private String formatEpgTime(
            long timestamp,
            String fallback) {

        if (timestamp > 0) {
            SimpleDateFormat format =
                    new SimpleDateFormat(
                            "HH:mm",
                            Locale.getDefault());

            return format.format(
                    new Date(
                            timestamp * 1000L));
        }

        if (fallback != null
                && fallback.length() >= 16) {

            return fallback.substring(
                    11,
                    16);
        }

        return fallback == null
                ? ""
                : fallback;
    }

    private boolean isXtreamSource() {
        String source =
                playlistPrefs()
                        .getString(
                                "playlist_source_type",
                                "");

        return "XTREAM".equals(source);
    }

    private String extractXtreamStreamId(
            String streamUrl) {

        if (streamUrl == null) {
            return "";
        }

        Matcher matcher =
                Pattern.compile(
                        "/([0-9]+)\\.(?:ts|m3u8)(?:\\?.*)?$",
                        Pattern.CASE_INSENSITIVE)
                        .matcher(
                                streamUrl);

        if (matcher.find()) {
            return matcher.group(1);
        }

        return "";
    }

    private LiveTvSelection.Host liveTvSelectionHost() {
        return new LiveTvSelection.Host() {
            public java.util.ArrayList<Channel> channels() {
                return getActiveChannels();
            }

            public String selectedStreamUrl() {
                return MainActivity.this.selectedStreamUrl;
            }

            public String selectedChannel() {
                return MainActivity.this.selectedChannel;
            }

            public String safe(String value) {
                return MainActivity.this.safe(value);
            }

            public String extractStreamId(String url) {
                return extractXtreamStreamId(url);
            }

            public void applySelection(
                    Channel channel,
                    String streamId) {

                MainActivity.this.selectedChannel =
                        MainActivity.this.safe(channel.name);

                selectedGroup =
                        MainActivity.this.safe(channel.group);

                selectedStreamUrl =
                        MainActivity.this.safe(channel.url);

                selectedStreamId = streamId;

                selectedDirectSource =
                        MainActivity.this.safe(channel.directSource);

                selectedContainerExtension = "";
                selectedMediaType = "LIVE";
                selectedReturnScreen = "LIVE";

                selectedNow =
                        MainActivity.this.safe(channel.now);

                selectedNext =
                        MainActivity.this.safe(channel.next);
            }

            public void saveLastChannelKey(String key) {
                playlistPrefs()
                        .edit()
                        .putString("last_live_channel_key", key)
                        .apply();
            }

            public void saveSelectedLiveChannel() {
                MainActivity.this.saveSelectedLiveChannel();
            }
        };
    }

    private Channel findSelectedChannel() {
        return LiveTvSelection.findSelected(
                liveTvSelectionHost());
    }

    private void ensureSelectedChannel() {
        LiveTvSelection.ensureSelected(
                liveTvSelectionHost());
    }

    private void selectChannelInternal(
            Channel channel) {

        LiveTvSelection.select(
                liveTvSelectionHost(),
                channel);
    }

    private void configureLiveChannelTransportControls(
            PlayerView playerView) {

        LiveTvTransportControls.configure(
                this,
                new LiveTvTransportControls.Host() {
                    public boolean isLive() {
                        return "LIVE".equals(selectedMediaType);
                    }

                    public void switchChannel(int direction) {
                        MainActivity.this.switchLiveChannel(direction);
                    }
                },
                playerView);
    }

    private LiveTvNavigation.Host liveTvNavigationHost() {
        return new LiveTvNavigation.Host() {

            public java.util.ArrayList<Channel> channels() {
                return getActiveChannels();
            }

            public java.util.HashSet<String> favourites() {
                return favouriteChannels;
            }

            public String activeFilter() {
                return activeLiveFilter;
            }

            public String safe(String value) {
                return MainActivity.this.safe(value);
            }

            public String selectedStreamUrl() {
                return MainActivity.this.selectedStreamUrl;
            }

            public String selectedStreamId() {
                return MainActivity.this.selectedStreamId;
            }

            public String selectedChannel() {
                return MainActivity.this.selectedChannel;
            }
        };
    }

    private void switchLiveChannel(
            int direction) {

        if ("LIVE".equals(selectedMediaType) == false) {
            return;
        }

        Channel target =
                LiveTvNavigation.target(
                        liveTvNavigationHost(),
                        direction);

        if (target == null) {
            Toast.makeText(
                    this,
                    "No visible channels are available.",
                    Toast.LENGTH_SHORT)
                    .show();
            return;
        }

        selectChannelInternal(target);

        if (liveBrowserMode
                && livePreviewPlayerView != null
                && livePreviewTitle != null
                && livePreviewNow != null
                && livePreviewNext != null
                && livePreviewStatus != null) {

            startInlineLivePreview(
                    target,
                    livePreviewPlayerView,
                    livePreviewTitle,
                    livePreviewNow,
                    livePreviewNext,
                    livePreviewStatus);

        } else {
            showPlayerScreen();
        }
    }

    private void setPlaybackKeepAwake(
            boolean keepAwake) {

        if (keepAwake) {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            if (activePlayerView != null) {
                activePlayerView.setKeepScreenOn(
                        true);
            }

        } else {
            getWindow().clearFlags(
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            if (activePlayerView != null) {
                activePlayerView.setKeepScreenOn(
                        false);
            }
        }
    }

    private String buildResumeKey(
            String mediaType,
            String mediaId) {

        return "resume_"
                + safe(mediaType)
                + "_"
                + safe(mediaId);
    }

    private long getSavedResumePosition(
            String resumeKey) {

        if (resumeKey == null
                || resumeKey.isEmpty()) {
            return 0L;
        }

        return resumePrefs()
                .getLong(
                        resumeKey + "_position",
                        0L);
    }

    private PlaybackResumeStore.Host playbackResumeStoreHost() {
        return new PlaybackResumeStore.Host() {

            public SimpleExoPlayer player() {
                return exoPlayer;
            }

            public String resumeKey() {
                return currentResumeKey;
            }

            public boolean isLive() {
                return "LIVE".equals(selectedMediaType);
            }

            public android.content.SharedPreferences prefs() {
                return resumePrefs();
            }

            public String title() {
                return selectedChannel;
            }

            public void clear(String key) {
                clearResumePosition(key);
            }
        };
    }

    private void saveCurrentResumePosition() {
        PlaybackResumeStore.save(
                playbackResumeStoreHost());
    }

    private void clearResumePosition(
            String resumeKey) {

        if (resumeKey == null
                || resumeKey.isEmpty()) {
            return;
        }

        resumePrefs()
                .edit()
                .remove(
                        resumeKey + "_position")
                .remove(
                        resumeKey + "_duration")
                .remove(
                        resumeKey + "_title")
                .remove(resumeKey + "_last_watched")
                .remove(resumeKey + "_media_type")
                .remove(resumeKey + "_media_id")
                .remove(resumeKey + "_cover")
                .remove(resumeKey + "_extension")
                .remove(resumeKey + "_direct_source")
                .remove(resumeKey + "_series_id")
                .remove(resumeKey + "_series_name")
                .remove(resumeKey + "_episode_title")
                .remove(resumeKey + "_season")
                .remove(resumeKey + "_episode")
                .apply();
    }

    private String formatPlaybackTime(
            long positionMs) {

        long totalSeconds =
                Math.max(
                        0L,
                        positionMs / 1000L);

        long hours =
                totalSeconds / 3600L;

        long minutes =
                (totalSeconds % 3600L)
                        / 60L;

        long seconds =
                totalSeconds % 60L;

        if (hours > 0L) {
            return String.format(
                    Locale.US,
                    "%d:%02d:%02d",
                    hours,
                    minutes,
                    seconds);
        }

        return String.format(
                Locale.US,
                "%d:%02d",
                minutes,
                seconds);
    }

    private PlaybackResumeScheduler.Host playbackResumeSchedulerHost() {
        return new PlaybackResumeScheduler.Host() {

            public void savePosition() {
                saveCurrentResumePosition();
            }

            public boolean shouldContinue() {
                return exoPlayer != null
                        && "LIVE".equals(selectedMediaType) == false
                        && currentResumeKey != null
                        && currentResumeKey.isEmpty() == false;
            }
        };
    }

    private void startResumeProgressSaving() {
        resumeSaveRunnable =
                PlaybackResumeScheduler.start(
                        resumeHandler,
                        resumeSaveRunnable,
                        playbackResumeSchedulerHost());
    }

    private void stopResumeProgressSaving() {
        resumeSaveRunnable =
                PlaybackResumeScheduler.stop(
                        resumeHandler,
                        resumeSaveRunnable);
    }

    private PlaybackReleaseCoordinator.Host playbackReleaseHost() {
        return new PlaybackReleaseCoordinator.Host() {

            public void saveResumePosition() {
                saveCurrentResumePosition();
            }

            public void stopResumeSaving() {
                stopResumeProgressSaving();
            }

            public boolean isFullScreen() {
                return playerFullScreen;
            }

            public void restoreWindowLayout() {
                restorePlayerWindowLayout();
            }

            public void setFullScreen(boolean value) {
                playerFullScreen = value;
            }

            public void restoreOrientation() {
                setRequestedOrientation(
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            public void showSystemBars() {
                MainActivity.this.showSystemBars();
            }

            public void setKeepAwake(boolean keepAwake) {
                setPlaybackKeepAwake(keepAwake);
            }

            public void releaseEngine() {
                if (exoPlayer != null) {
                    try {
                        exoPlayer.stop();
                        exoPlayer.release();
                    } catch (Exception ignored) {
                    }

                    exoPlayer = null;
                    activeTrackSelector = null;
                }
            }
        };
    }

    private void releasePlayer() {
        PlaybackReleaseCoordinator.release(
                playbackReleaseHost());
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (isEmbeddedVpnEnabled()
                && isEmbeddedVpnAutoReconnect()
                && embeddedVpn != null
                && embeddedVpn.isConfigured()
                && !embeddedVpn.isConnected()
                && android.net.VpnService.prepare(this) == null) {
            connectEmbeddedVpn(false, null);
        }

        if (liveBrowserMode
                && livePreviewPlayerView != null
                && livePreviewTitle != null
                && livePreviewNow != null
                && livePreviewNext != null
                && livePreviewStatus != null
                && exoPlayer == null) {

            Channel channel =
                    findSelectedChannel();

            if (channel != null) {
                livePreviewPlayerView.postDelayed(
                        () -> {
                            if (liveBrowserMode
                                    && exoPlayer == null) {
                                startInlineLivePreview(
                                        channel,
                                        livePreviewPlayerView,
                                        livePreviewTitle,
                                        livePreviewNow,
                                        livePreviewNext,
                                        livePreviewStatus);
                            }
                        },
                        250);
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        releasePlayer();
    }

    private interface EpgCallback {
        void onResult(
                ArrayList<EpgEntry> entries,
                String error);
    }


    // ---------------------------------------------------------------------
    // PLAYER
    // ---------------------------------------------------------------------

    private PlayerScreenLayout.Host playerScreenLayoutHost() {
        return new PlayerScreenLayout.Host() {

            public int dp(int value) {
                return MainActivity.this.dp(value);
            }

            public GradientDrawable background(
                    int fill,
                    int stroke,
                    int radius) {

                return makeBackground(
                        fill,
                        stroke,
                        radius);
            }

            public void attachTrackControls(PlayerView playerView) {
                attachTrackControlsOverlay(playerView);
            }

            public void goBack(String mediaType) {
                if ("MOVIE".equals(mediaType)) {
                    showMovies();
                } else if ("EPISODE".equals(mediaType)) {
                    showSeries();
                } else {
                    showLiveTv(activeLiveFilter);
                }
            }

            public void enterFullscreen() {
                enterPlayerFullScreen();
            }

            public String audioLanguageName(String language) {
                return getAudioLanguageName(language);
            }
        };
    }

    private void showPlayerScreen() {
        releasePlayer();
        onHomeScreen = false;
        liveBrowserMode = false;

        if ("LIVE".equals(selectedMediaType)) {
            ensureSelectedChannel();
            saveSelectedLiveChannel();
            currentResumeKey = "";
            playbackStartPositionMs = 0L;
            activeEpisodeIndex = -1;
        }

        String preferredLanguage =
                getPreferredAudioLanguage();

        PlayerScreenLayout.Views views =
                PlayerScreenLayout.create(
                        this,
                        playerScreenLayoutHost(),
                        selectedMediaType,
                        selectedChannel,
                        selectedGroup,
                        selectedNow,
                        selectedNext,
                        selectedContainerExtension,
                        preferredLanguage,
                        BLACK,
                        GOLD,
                        SILVER);

        LinearLayout screen =
                views.screen;

        PlayerView playerView =
                views.playerView;

        TextView nowText =
                views.nowText;

        TextView nextText =
                views.nextText;

        TextView status =
                views.status;

                // PP_VOD_FULLSCREEN_LAYOUT
        boolean vodFullscreenOnEntry = true;

        if (vodFullscreenOnEntry) {
            screen.setPadding(0, 0, 0, 0);

            for (int i = 0; i < screen.getChildCount(); i++) {
                View child = screen.getChildAt(i);
                if (child != playerView) {
                    child.setVisibility(View.GONE);
                }
            }

            playerView.setLayoutParams(
                    new LinearLayout.LayoutParams(-1, -1));
        }

        setContentView(screen);
        activePlayerScreen = screen;
        playerFullScreen = vodFullscreenOnEntry;

        if (vodFullscreenOnEntry) {
            hideSystemBars();
        } else {
            showSystemBars();
        }


        if ("LIVE".equals(selectedMediaType)) {
            Channel selected =
                    findSelectedChannel();

            if (selected != null
                    && isXtreamSource()
                    && !safe(selected.streamId).isEmpty()) {

                loadShortEpg(
                        selected,
                        nowText,
                        nextText,
                        null,
                        null);
            }
        }

        activePlayerView = playerView;
        activePlaybackStatus = status;

        if ("MOVIE".equals(selectedMediaType)
                || "EPISODE".equals(selectedMediaType)) {
            playerFullScreen = true;
            applyPlayerFullScreenLayout();
        }

        if ("LIVE".equals(selectedMediaType)) {
            configureLiveChannelTransportControls(
                    playerView);
        }

        buildPlaybackCandidates();

        if (playbackCandidates.isEmpty()) {
            status.setText(
                    "No playable stream URL is available for this item.");
            return;
        }

        playbackCandidateIndex = 0;
        startPlaybackWithResumeChoice(
                preferredLanguage);

        if ("MOVIE".equals(selectedMediaType) || "EPISODE".equals(selectedMediaType)) {
            enterPlayerFullScreen();
        }
    }

    private PlaybackResumeChoice.Host playbackResumeChoiceHost() {
        return new PlaybackResumeChoice.Host() {

            public boolean isLive() {
                return "LIVE".equals(selectedMediaType);
            }

            public String resumeKey() {
                return currentResumeKey;
            }

            public long savedPosition(String key) {
                return getSavedResumePosition(key);
            }

            public String title() {
                return selectedChannel;
            }

            public String formatTime(long position) {
                return formatPlaybackTime(position);
            }

            public void clearResume(String key) {
                clearResumePosition(key);
            }

            public void setStartPosition(long position) {
                playbackStartPositionMs = position;
            }

            public void play(String preferredLanguage) {
                playCurrentCandidate(preferredLanguage);
            }
        };
    }

    private void startPlaybackWithResumeChoice(
            String preferredLanguage) {

        PlaybackResumeChoice.start(
                this,
                playbackResumeChoiceHost(),
                preferredLanguage);
    }

    private PlayerTrackOverlay.Host playerTrackOverlayHost() {
        return new PlayerTrackOverlay.Host() {

            public int dp(int value) {
                return MainActivity.this.dp(value);
            }

            public GradientDrawable background(
                    int fill,
                    int stroke,
                    int radius) {

                return makeBackground(
                        fill,
                        stroke,
                        radius);
            }

            public void prepareButton(TextView button) {
                makeTvRemoteReady(button);
            }

            public void addFocusStyle(
                    TextView button,
                    int radius) {

                MainActivity.this.addFocusStyle(
                        button,
                        radius);
            }

            public void showAudioTracks() {
                showTrackSelectionDialog(
                        C.TRACK_TYPE_AUDIO,
                        "Audio tracks");
            }

            public void showSubtitleTracks() {
                showTrackSelectionDialog(
                        C.TRACK_TYPE_TEXT,
                        "Subtitles");
            }
        };
    }

    private void attachTrackControlsOverlay(
            PlayerView playerView) {

        PlayerTrackOverlay.attach(
                playerView,
                playerTrackOverlayHost(),
                GOLD);
    }

    private void showTrackSelectionDialog(
            int trackType,
            String title) {

        if (exoPlayer == null
                || activeTrackSelector == null) {
            Toast.makeText(
                    this,
                    "Start playback first.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        MappingTrackSelector.MappedTrackInfo mappedTrackInfo =
                activeTrackSelector.getCurrentMappedTrackInfo();

        if (mappedTrackInfo == null) {
            Toast.makeText(
                    this,
                    "Tracks are still loading.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        int rendererIndex =
                findRendererIndex(
                        mappedTrackInfo,
                        trackType);

        if (rendererIndex < 0) {
            String message =
                    trackType == C.TRACK_TYPE_AUDIO
                            ? "No selectable audio tracks were found."
                            : "No subtitle tracks were found.";
            Toast.makeText(
                    this,
                    message,
                    Toast.LENGTH_LONG).show();
            return;
        }

        try {
            TrackSelectionDialogBuilder builder =
                    new TrackSelectionDialogBuilder(
                            this,
                            title,
                            activeTrackSelector,
                            rendererIndex);

            builder.setAllowAdaptiveSelections(false);
            builder.setAllowMultipleOverrides(false);
            builder.setShowDisableOption(
                    trackType == C.TRACK_TYPE_TEXT);
            builder.build().show();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Could not open track options: "
                            + safeErrorMessage(e),
                    Toast.LENGTH_LONG).show();
        }
    }

    private int findRendererIndex(
            MappingTrackSelector.MappedTrackInfo mappedTrackInfo,
            int trackType) {

        for (int i = 0;
             i < mappedTrackInfo.getRendererCount();
             i++) {
            if (mappedTrackInfo.getRendererType(i)
                    == trackType) {
                return i;
            }
        }
        return -1;
    }

    private void enterPlayerFullScreen() {
        if (activePlayerView == null
                || activePlayerScreen == null
                || playerFullScreen) {
            return;
        }

        playerFullScreen = true;

        applyPlayerFullScreenLayout();

        activePlayerScreen.postDelayed(
                () -> {
                    if (playerFullScreen) {
                        applyPlayerFullScreenLayout();
                    }
                },
                150);
    }

    private void applyPlayerFullScreenLayout() {
        PlayerFullscreenLayout.apply(
                this,
                activePlayerScreen,
                activePlayerView);
    }

    private void exitPlayerFullScreen() {
        if (!playerFullScreen) {
            return;
        }

        playerFullScreen = false;

        restorePlayerWindowLayout();

        setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        getWindow()
                .getDecorView()
                .postDelayed(
                        this::showSystemBars,
                        150);
    }

    private void restorePlayerWindowLayout() {
        PlayerFullscreenLayout.restore(
                this,
                activePlayerScreen,
                activePlayerView,
                dp(16),
                dp(18),
                dp(16),
                dp(24),
                dp(230),
                BLACK);
    }

    @Override
    public void onConfigurationChanged(
            Configuration newConfig) {

        super.onConfigurationChanged(
                newConfig);

        if (playerFullScreen) {
            if (activePlayerScreen != null) {
                activePlayerScreen.post(
                        this::applyPlayerFullScreenLayout);
            } else {
                hideSystemBars();
            }
        } else {
            showSystemBars();
        }
    }

    private void hideSystemBars() {
        PlayerFullscreenLayout.hideSystemBars(
                this);
    }

    private void showSystemBars() {
        PlayerFullscreenLayout.showSystemBars(
                this,
                BLACK);
    }

    private void buildPlaybackCandidates() {
        playbackCandidates.clear();

        if (!selectedDirectSource.trim().isEmpty()) {
            addPlaybackCandidate(selectedDirectSource);
        }

        if ("LIVE".equals(selectedMediaType)
                && isXtreamSource()
                && !selectedStreamId.isEmpty()) {

            try {
                android.content.SharedPreferences prefs =
                        playlistPrefs();

                String apiServer = normalizeXtreamServer(
                        prefs.getString("xtream_server", ""));

                String streamServer = normalizeXtreamServer(
                        prefs.getString(
                                "xtream_stream_server",
                                apiServer));

                String username = prefs.getString("xtream_username", "");
                String password = prefs.getString("xtream_password", "");
                String allowed = prefs.getString("xtream_allowed_formats", "");

                boolean prefersM3u8 =
                        allowed != null
                                && allowed.toLowerCase(Locale.US).contains("m3u8");

                if (prefersM3u8) {
                    addPlaybackCandidate(
                            buildXtreamLiveUrl(
                                    streamServer,
                                    username,
                                    password,
                                    selectedStreamId,
                                    "m3u8"));
                }

                addPlaybackCandidate(
                        buildXtreamLiveUrl(
                                streamServer,
                                username,
                                password,
                                selectedStreamId,
                                "ts"));

                if (!prefersM3u8) {
                    addPlaybackCandidate(
                            buildXtreamLiveUrl(
                                    streamServer,
                                    username,
                                    password,
                                    selectedStreamId,
                                    "m3u8"));
                }

                if (!apiServer.equals(streamServer)) {
                    if (prefersM3u8) {
                        addPlaybackCandidate(
                                buildXtreamLiveUrl(
                                        apiServer,
                                        username,
                                        password,
                                        selectedStreamId,
                                        "m3u8"));
                    }

                    addPlaybackCandidate(
                            buildXtreamLiveUrl(
                                    apiServer,
                                    username,
                                    password,
                                    selectedStreamId,
                                    "ts"));

                    if (!prefersM3u8) {
                        addPlaybackCandidate(
                                buildXtreamLiveUrl(
                                        apiServer,
                                        username,
                                        password,
                                        selectedStreamId,
                                        "m3u8"));
                    }
                }

                String userPath =
                        URLEncoder.encode(username, "UTF-8")
                                .replace("+", "%20");

                String passPath =
                        URLEncoder.encode(password, "UTF-8")
                                .replace("+", "%20");

                addPlaybackCandidate(
                        streamServer
                                + "/"
                                + userPath
                                + "/"
                                + passPath
                                + "/"
                                + selectedStreamId);

            } catch (Exception ignored) {
            }
        }

        addPlaybackCandidate(selectedStreamUrl);
        addResumeMediaFallbackCandidatesV051();
    }

    private void addPlaybackCandidate(String candidate) {
        if (candidate == null) {
            return;
        }

        String value = candidate.trim();

        if (value.isEmpty()) {
            return;
        }

        if (!playbackCandidates.contains(value)) {
            playbackCandidates.add(value);
        }
    }

    private String buildXtreamLiveUrl(
            String server,
            String username,
            String password,
            String streamId,
            String extension)
            throws Exception {

        String userPath =
                URLEncoder.encode(username, "UTF-8")
                        .replace("+", "%20");

        String passPath =
                URLEncoder.encode(password, "UTF-8")
                        .replace("+", "%20");

        return server
                + "/live/"
                + userPath
                + "/"
                + passPath
                + "/"
                + streamId
                + "."
                + extension;
    }

    private void playCurrentCandidate(
            String preferredLanguage) {

        if (shouldBlockPlaybackForVpn() && !isEmbeddedVpnConnected()) {
            if (activePlaybackStatus != null) {
                activePlaybackStatus.setText(
                        "Waiting for PREMIUM PLAYER VPN before playback...");
            }
            connectEmbeddedVpn(
                    true,
                    () -> playCurrentCandidate(preferredLanguage));
            return;
        }

        if (playbackCandidateIndex < 0
                || playbackCandidateIndex >= playbackCandidates.size()) {

            if (activePlaybackStatus != null) {
                activePlaybackStatus.setText(
                        "Playback failed for every source. "
                                + "If this channel plays in another app, use the diagnostics shown here to identify the provider response.");
            }
            return;
        }

        releasePlayer();

        final String candidate =
                playbackCandidates.get(playbackCandidateIndex);

        if (activePlaybackStatus != null) {
            activePlaybackStatus.setText(
                    "Testing source "
                            + (playbackCandidateIndex + 1)
                            + " of "
                            + playbackCandidates.size()
                            + "...");
        }

        new Thread(() -> {
            PlaybackProbe probe = probePlaybackCandidate(candidate);

            runOnUiThread(() -> {
                if (probe.ok) {
                    startProbedCandidate(
                            probe,
                            preferredLanguage);
                } else {
                    if (activePlaybackStatus != null) {
                        activePlaybackStatus.setText(
                                "Source "
                                        + (playbackCandidateIndex + 1)
                                        + " failed: "
                                        + probe.message);
                    }

                    if (playbackCandidateIndex + 1
                            < playbackCandidates.size()) {
                        playbackCandidateIndex++;
                        playCurrentCandidate(preferredLanguage);
                    } else {
                        setPlaybackKeepAwake(
                                false);

                        if (activePlaybackStatus != null) {
                            activePlaybackStatus.setText(
                                    "Playback failed. Last source response: "
                                            + probe.message);
                        }
                    }
                }
            });
        }).start();
    }

    private PlaybackProbe probePlaybackCandidate(String candidate) {
        String current = candidate;

        for (int redirectCount = 0;
             redirectCount < 6;
             redirectCount++) {

            HttpURLConnection connection = null;

            try {
                URL url = new URL(current);
                connection = (HttpURLConnection) url.openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setRequestMethod("GET");
                connection.setUseCaches(false);
                connection.setRequestProperty(
                        "User-Agent",
                        "VLC/3.0.21 LibVLC/3.0.21");
                connection.setRequestProperty("Accept", "*/*");
                connection.setRequestProperty("Connection", "close");

                int status = connection.getResponseCode();

                if (status == HttpURLConnection.HTTP_MOVED_PERM
                        || status == HttpURLConnection.HTTP_MOVED_TEMP
                        || status == HttpURLConnection.HTTP_SEE_OTHER
                        || status == 307
                        || status == 308) {

                    String location = connection.getHeaderField("Location");

                    if (location == null || location.trim().isEmpty()) {
                        return PlaybackProbe.fail(
                                "HTTP " + status + " redirect without Location");
                    }

                    current = new URL(url, location).toString();
                    continue;
                }

                if (status < 200 || status >= 300) {
                    return PlaybackProbe.fail("HTTP " + status);
                }

                String contentType = safe(connection.getContentType()).toLowerCase(Locale.US);
                InputStream input = connection.getInputStream();
                byte[] sample = new byte[512];
                int read = input.read(sample);
                input.close();

                String firstText = "";
                if (read > 0) {
                    try {
                        firstText = new String(sample, 0, read, "UTF-8").trim();
                    } catch (Exception ignored) {
                    }
                }

                boolean looksHls =
                        contentType.contains("mpegurl")
                                || contentType.contains("m3u8")
                                || current.toLowerCase(Locale.US).contains(".m3u8")
                                || firstText.startsWith("#EXTM3U");

                boolean looksHtml =
                        contentType.contains("text/html")
                                || firstText.startsWith("<html")
                                || firstText.startsWith("<!DOCTYPE html")
                                || firstText.startsWith("<!doctype html");

                if (looksHtml) {
                    return PlaybackProbe.fail(
                            "HTTP 200 but server returned HTML instead of video");
                }

                return PlaybackProbe.ok(
                        current,
                        looksHls,
                        contentType.isEmpty() ? "unknown content type" : contentType);

            } catch (Exception e) {
                return PlaybackProbe.fail(safeErrorMessage(e));

            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        return PlaybackProbe.fail("Too many redirects");
    }

    private PlaybackEventHandler.Host playbackEventHandlerHost() {
        return new PlaybackEventHandler.Host() {

            public void setKeepAwake(boolean keepAwake) {
                setPlaybackKeepAwake(keepAwake);
            }

            public boolean isLive() {
                return "LIVE".equals(selectedMediaType);
            }

            public void configureLiveControls() {
                if (activePlayerView != null) {
                    configureLiveChannelTransportControls(
                            activePlayerView);
                }
            }

            public void startResumeSaving() {
                startResumeProgressSaving();
            }

            public void stopResumeSaving() {
                stopResumeProgressSaving();
            }

            public long resumeStartPosition() {
                return playbackStartPositionMs;
            }

            public String formatPlaybackTime(long position) {
                return MainActivity.this.formatPlaybackTime(position);
            }

            public void setStatus(String text) {
                if (activePlaybackStatus != null) {
                    activePlaybackStatus.setText(text);
                }
            }

            public boolean handlingPlaybackEnd() {
                return MainActivity.this.handlingPlaybackEnd;
            }

            public void setHandlingPlaybackEnd(boolean value) {
                MainActivity.this.handlingPlaybackEnd = value;
            }

            public String currentResumeKey() {
                return MainActivity.this.currentResumeKey;
            }

            public void clearResumePosition(String key) {
                MainActivity.this.clearResumePosition(key);
            }

            public boolean isEpisode() {
                return "EPISODE".equals(selectedMediaType);
            }

            public void autoPlayNextEpisode() {
                MainActivity.this.autoPlayNextEpisode();
            }

            public int candidateIndex() {
                return playbackCandidateIndex;
            }

            public int candidateCount() {
                return playbackCandidates.size();
            }

            public void incrementCandidateIndex() {
                playbackCandidateIndex++;
            }

            public void retry(String preferredLanguage) {
                playCurrentCandidate(preferredLanguage);
            }

            public String errorMessage(Exception error) {
                return safeErrorMessage(error);
            }
        };
    }

    private PlaybackStartCoordinator.Host playbackStartCoordinatorHost() {
        return new PlaybackStartCoordinator.Host() {

            public void releasePlayer() {
                MainActivity.this.releasePlayer();
            }

            public void setKeepAwake(boolean keepAwake) {
                setPlaybackKeepAwake(keepAwake);
            }

            public void bindEngine(
                    PlaybackEngineFactory.Result engine) {

                activeTrackSelector =
                        engine.trackSelector;

                exoPlayer =
                        engine.player;

                if (activePlayerView != null) {
                    activePlayerView.setPlayer(
                            exoPlayer);
                }
            }

            public void attachEvents(
                    SimpleExoPlayer player,
                    PlaybackProbe probe,
                    String preferredLanguage) {

                PlaybackEventHandler.attach(
                        player,
                        playbackEventHandlerHost(),
                        probe,
                        preferredLanguage);
            }

            public long resumeStartPosition() {
                return playbackStartPositionMs;
            }

            public int candidateIndex() {
                return playbackCandidateIndex;
            }

            public int candidateCount() {
                return playbackCandidates.size();
            }

            public void incrementCandidateIndex() {
                playbackCandidateIndex++;
            }

            public void retry(String preferredLanguage) {
                playCurrentCandidate(preferredLanguage);
            }

            public void setStatus(String text) {
                if (activePlaybackStatus != null) {
                    activePlaybackStatus.setText(text);
                }
            }

            public String errorMessage(Exception error) {
                return safeErrorMessage(error);
            }
        };
    }

    private void startProbedCandidate(
            PlaybackProbe probe,
            String preferredLanguage) {

        PlaybackStartCoordinator.start(
                this,
                playbackStartCoordinatorHost(),
                probe,
                preferredLanguage);
    }

    private String normalizeSearchText(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }

        String decomposed =
                Normalizer.normalize(
                        value,
                        Normalizer.Form.NFD)
                        .toLowerCase(Locale.US);

        StringBuilder builder =
                new StringBuilder();

        for (int i = 0;
             i < decomposed.length();
             i++) {

            char character =
                    decomposed.charAt(i);

            int type =
                    Character.getType(
                            character);

            if (type == Character.NON_SPACING_MARK
                    || type == Character.COMBINING_SPACING_MARK
                    || type == Character.ENCLOSING_MARK) {
                continue;
            }

            // Keep letters and numbers only.
            // This deliberately ignores spaces and punctuation:
            // "Don't Stop!", "dont stop" and "DON’T-STOP"
            // all normalize to "dontstop".
            if (Character.isLetterOrDigit(character)) {
                builder.append(character);
            }
        }

        return builder.toString();
    }

    private boolean searchMatches(
            String query,
            String... values) {

        String normalizedQuery =
                normalizeSearchText(query);

        if (normalizedQuery.isEmpty()) {
            return true;
        }

        StringBuilder searchable =
                new StringBuilder();

        if (values != null) {
            for (String value : values) {
                searchable.append(
                        normalizeSearchText(value));
            }
        }

        return searchable
                .toString()
                .contains(normalizedQuery);
    }

    private EditText createMediaSearchBox(
            String hint) {

        EditText search =
                new EditText(this);

        search.setHint(hint);
        search.setHintTextColor(
                Color.rgb(120, 120, 125));

        search.setTextColor(Color.WHITE);
        search.setTextSize(14);
        search.setSingleLine(true);

        prepareTvTextInput(
                search,
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
                EditorInfo.IME_ACTION_SEARCH);

        search.setPadding(
                dp(16),
                dp(12),
                dp(16),
                dp(12));

        search.setBackground(
                makeBackground(
                        CHARCOAL,
                        Color.rgb(55, 55, 58),
                        14));

        return search;
    }

    private String safe(String value) {
        return value == null
                ? ""
                : value;
    }

    private void prepareTvTextInput(
            EditText input,
            int inputType,
            int imeOptions) {

        if (input == null) {
            return;
        }

        input.setInputType(inputType);
        input.setImeOptions(imeOptions);
        input.setFocusable(true);
        input.setFocusableInTouchMode(true);
        input.setClickable(true);
        input.setAlpha(0.94f);

        input.setOnClickListener(
                v -> showTvKeyboard(input));

        input.setOnKeyListener(
                (v, keyCode, event) -> {
                    if (event != null
                            && event.getAction() == KeyEvent.ACTION_UP
                            && isTvSelectKey(keyCode)) {
                        showTvKeyboard(input);
                        return true;
                    }
                    return false;
                });
    }

    private void showTvKeyboard(
            EditText input) {

        if (input == null) {
            return;
        }

        input.requestFocus();

        input.postDelayed(
                () -> {
                    InputMethodManager keyboard =
                            (InputMethodManager) getSystemService(
                                    Context.INPUT_METHOD_SERVICE);

                    if (keyboard != null) {
                        keyboard.showSoftInput(
                                input,
                                InputMethodManager.SHOW_IMPLICIT);
                    }
                },
                120);
    }

    private void hideTvKeyboard(
            View view) {

        if (view == null) {
            return;
        }

        InputMethodManager keyboard =
                (InputMethodManager) getSystemService(
                        Context.INPUT_METHOD_SERVICE);

        if (keyboard != null) {
            keyboard.hideSoftInputFromWindow(
                    view.getWindowToken(),
                    0);
        }
    }

    private void showQrXtreamLogin() {
        releasePlayer();
        onHomeScreen = false;
        stopQrPairingServer();

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(18), dp(24), dp(24));
        scrollView.addView(root);

        TextView back = createBackText();
        back.setText("<  PLAYLISTS");
        back.setOnClickListener(v -> {
            stopQrPairingServer();
            showPlaylists();
        });
        root.addView(back);

        TextView heading = new TextView(this);
        heading.setText("LOGIN WITH PHONE");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(28);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);

        TextView help = new TextView(this);
        help.setText(
                "Scan the QR code with your phone while the phone and TV are on the same Wi-Fi/LAN. "
                        + "Enter the Xtream server, username and password on your phone. The QR itself does not contain your password.");
        help.setTextColor(SILVER);
        help.setTextSize(13);
        help.setGravity(Gravity.CENTER);
        help.setPadding(0, dp(8), 0, dp(14));
        root.addView(help);

        TextView status = new TextView(this);
        status.setText("Starting pairing session...");
        status.setTextColor(GOLD);
        status.setTextSize(13);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(8), 0, dp(10));

        String pairingUrl = startQrPairingServer(status);

        if (pairingUrl != null) {
            try {
                Bitmap qrBitmap = createQrBitmap(pairingUrl, 420);
                ImageView qrImage = new ImageView(this);
                qrImage.setImageBitmap(qrBitmap);
                qrImage.setAdjustViewBounds(true);
                qrImage.setPadding(dp(8), dp(8), dp(8), dp(8));

                LinearLayout.LayoutParams qrParams =
                        new LinearLayout.LayoutParams(
                                dp(310),
                                dp(310));

                root.addView(qrImage, qrParams);

                TextView urlText = new TextView(this);
                urlText.setText(
                        "If scanning is unavailable, open this address on your phone:\n"
                                + pairingUrl);
                urlText.setTextColor(SILVER);
                urlText.setTextSize(11);
                urlText.setGravity(Gravity.CENTER);
                urlText.setPadding(0, dp(10), 0, dp(8));
                root.addView(urlText);

                status.setText(
                        "Waiting for phone login • expires in 5 minutes");
            } catch (Exception e) {
                status.setText(
                        "Could not create QR code: "
                                + safeErrorMessage(e));
            }
        } else {
            status.setText(
                    "Could not start phone pairing. Make sure the TV is connected to your home network.");
        }

        root.addView(status);

        TextView privacy = new TextView(this);
        privacy.setText(
                "Prototype pairing uses your local network only. Use it on a trusted home network. A production release should use encrypted HTTPS/cloud pairing.");
        privacy.setTextColor(Color.rgb(125, 125, 130));
        privacy.setTextSize(10);
        privacy.setGravity(Gravity.CENTER);
        privacy.setPadding(0, dp(12), 0, 0);
        root.addView(privacy);

        setContentView(scrollView);
    }

    private String startQrPairingServer(
            TextView statusView) {

        try {
            String localIp = getLocalIpv4Address();

            if (localIp == null || localIp.isEmpty()) {
                return null;
            }

            qrPairingToken = createPairingToken();
            qrPairingExpiresAt =
                    System.currentTimeMillis()
                            + QR_PAIRING_WINDOW_MS;

            qrPairingServerSocket =
                    new ServerSocket(0);

            qrPairingServerSocket.setSoTimeout(1000);
            qrPairingActive = true;

            int port =
                    qrPairingServerSocket.getLocalPort();

            String pairingUrl =
                    "http://"
                            + localIp
                            + ":"
                            + port
                            + "/?token="
                            + qrPairingToken;

            new Thread(
                    () -> runQrPairingServer(statusView),
                    "premium-player-pairing")
                    .start();

            return pairingUrl;

        } catch (Exception e) {
            stopQrPairingServer();
            return null;
        }
    }

    private void runQrPairingServer(
            TextView statusView) {

        while (qrPairingActive
                && System.currentTimeMillis()
                        < qrPairingExpiresAt) {

            try {
                Socket client =
                        qrPairingServerSocket.accept();

                handleQrPairingClient(
                        client,
                        statusView);

            } catch (SocketTimeoutException ignored) {
                // Allows the five-minute expiry to be checked.
            } catch (Exception e) {
                if (qrPairingActive) {
                    final String message = safeErrorMessage(e);
                    runOnUiThread(
                            () -> {
                                if (statusView != null) {
                                    statusView.setText(
                                            "Pairing error: "
                                                    + message);
                                }
                            });
                }
            }
        }

        stopQrPairingServer();

        runOnUiThread(
                () -> {
                    if (statusView != null
                            && System.currentTimeMillis()
                                    >= qrPairingExpiresAt) {
                        statusView.setText(
                                "Pairing session expired. Go back and open QR login again.");
                    }
                });
    }

    private void handleQrPairingClient(
            Socket client,
            TextView statusView) {

        try {
            client.setSoTimeout(5000);

            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    client.getInputStream(),
                                    "UTF-8"));

            String requestLine = reader.readLine();

            if (requestLine == null) {
                return;
            }

            int contentLength = 0;
            String line;

            while ((line = reader.readLine()) != null
                    && !line.isEmpty()) {

                String lower =
                        line.toLowerCase(Locale.US);

                if (lower.startsWith("content-length:")) {
                    try {
                        contentLength =
                                Integer.parseInt(
                                        line.substring(
                                                line.indexOf(':') + 1)
                                                .trim());
                    } catch (Exception ignored) {
                    }
                }
            }

            if (requestLine.startsWith("GET ")) {
                String path = requestLine.split(" ")[1];
                Map<String, String> query = parseQueryString(path);

                if (!qrPairingToken.equals(query.get("token"))) {
                    sendPairingHtml(
                            client,
                            403,
                            "Pairing denied",
                            "<h2>Invalid or expired pairing code.</h2>");
                    return;
                }

                String page =
                        "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                                + "<title>PREMIUM PLAYER</title><style>body{font-family:sans-serif;background:#111;color:#fff;max-width:620px;margin:30px auto;padding:18px}"
                                + "h1{color:#d8bd73}label{display:block;margin-top:14px}input{width:100%;box-sizing:border-box;padding:14px;margin-top:6px;border-radius:8px;border:1px solid #555;background:#222;color:#fff;font-size:16px}"
                                + "button{width:100%;margin-top:20px;padding:15px;background:#d8bd73;color:#111;border:0;border-radius:8px;font-weight:bold;font-size:16px}</style></head><body>"
                                + "<h1>PREMIUM PLAYER</h1><p>Enter your Xtream account. This form sends the details directly to the TV on your local network.</p>"
                                + "<form method='POST' action='/login'>"
                                + "<input type='hidden' name='token' value='"
                                + htmlEscape(qrPairingToken)
                                + "'>"
                                + "<label>Server URL</label><input name='server' type='url' placeholder='http://provider:port' required>"
                                + "<label>Username</label><input name='username' autocomplete='username' required>"
                                + "<label>Password</label><input name='password' type='password' autocomplete='current-password' required>"
                                + "<button type='submit'>SEND TO TV & LOGIN</button></form></body></html>";

                sendPairingHtml(
                        client,
                        200,
                        "PREMIUM PLAYER",
                        page);
                return;
            }

            if (requestLine.startsWith("POST /login")) {
                char[] bodyChars = new char[Math.max(0, contentLength)];
                int read = 0;

                while (read < bodyChars.length) {
                    int amount =
                            reader.read(
                                    bodyChars,
                                    read,
                                    bodyChars.length - read);

                    if (amount < 0) {
                        break;
                    }

                    read += amount;
                }

                String body =
                        new String(
                                bodyChars,
                                0,
                                read);

                Map<String, String> form =
                        parseFormBody(body);

                String token = safe(form.get("token"));
                String server = safe(form.get("server")).trim();
                String username = safe(form.get("username")).trim();
                String password = safe(form.get("password"));

                if (!qrPairingToken.equals(token)
                        || System.currentTimeMillis()
                                > qrPairingExpiresAt) {
                    sendPairingHtml(
                            client,
                            403,
                            "Pairing expired",
                            "<h2>This pairing session has expired.</h2>");
                    return;
                }

                if (server.isEmpty()
                        || username.isEmpty()
                        || password.isEmpty()) {
                    sendPairingHtml(
                            client,
                            400,
                            "Missing details",
                            "<h2>Server, username and password are required.</h2>");
                    return;
                }

                sendPairingHtml(
                        client,
                        200,
                        "Sent to TV",
                        "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                                + "<style>body{font-family:sans-serif;background:#111;color:#fff;text-align:center;padding:40px}h2{color:#d8bd73}</style>"
                                + "</head><body><h2>Details sent to PREMIUM PLAYER</h2><p>You can return to the TV.</p></body></html>");

                qrPairingActive = false;

                runOnUiThread(
                        () -> {
                            if (statusView != null) {
                                statusView.setText(
                                        "Phone details received. Logging in...");
                            }

                            Toast.makeText(
                                    this,
                                    "Phone login received.",
                                    Toast.LENGTH_SHORT).show();

                            importXtreamPlaylist(
                                    server,
                                    username,
                                    password);
                        });
            }

        } catch (Exception ignored) {
        } finally {
            try {
                client.close();
            } catch (Exception ignored) {
            }
        }
    }

    private void sendPairingHtml(
            Socket client,
            int statusCode,
            String statusText,
            String html) throws Exception {

        byte[] data =
                html.getBytes("UTF-8");

        OutputStream output =
                client.getOutputStream();

        String header =
                "HTTP/1.1 "
                        + statusCode
                        + " "
                        + statusText
                        + "\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: "
                        + data.length
                        + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";

        output.write(
                header.getBytes("UTF-8"));
        output.write(data);
        output.flush();
    }

    private Map<String, String> parseQueryString(
            String path) {

        int question =
                path.indexOf('?');

        if (question < 0
                || question >= path.length() - 1) {
            return new HashMap<String, String>();
        }

        return parseFormBody(
                path.substring(question + 1));
    }

    private Map<String, String> parseFormBody(
            String body) {

        Map<String, String> values =
                new HashMap<String, String>();

        if (body == null || body.isEmpty()) {
            return values;
        }

        String[] pairs = body.split("&");

        for (String pair : pairs) {
            String[] parts = pair.split("=", 2);

            try {
                String key =
                        URLDecoder.decode(
                                parts[0],
                                "UTF-8");

                String value =
                        parts.length > 1
                                ? URLDecoder.decode(
                                        parts[1],
                                        "UTF-8")
                                : "";

                values.put(key, value);
            } catch (Exception ignored) {
            }
        }

        return values;
    }

    private String htmlEscape(
            String value) {

        return safe(value)
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    private String createPairingToken() {
        SecureRandom random =
                new SecureRandom();

        StringBuilder token =
                new StringBuilder();

        for (int i = 0; i < 24; i++) {
            int value = random.nextInt(36);
            token.append(
                    Character.forDigit(
                            value,
                            36));
        }

        return token.toString();
    }

    private String getLocalIpv4Address() {
        try {
            Enumeration<NetworkInterface> interfaces =
                    NetworkInterface.getNetworkInterfaces();

            String fallback = null;

            while (interfaces != null
                    && interfaces.hasMoreElements()) {

                NetworkInterface network =
                        interfaces.nextElement();

                if (!network.isUp()
                        || network.isLoopback()) {
                    continue;
                }

                Enumeration<InetAddress> addresses =
                        network.getInetAddresses();

                while (addresses.hasMoreElements()) {
                    InetAddress address =
                            addresses.nextElement();

                    if (!(address instanceof Inet4Address)
                            || address.isLoopbackAddress()) {
                        continue;
                    }

                    String host =
                            address.getHostAddress();

                    if (address.isSiteLocalAddress()) {
                        return host;
                    }

                    fallback = host;
                }
            }

            return fallback;

        } catch (Exception e) {
            return null;
        }
    }

    private Bitmap createQrBitmap(
            String content,
            int size) throws Exception {

        BitMatrix matrix =
                new MultiFormatWriter()
                        .encode(
                                content,
                                BarcodeFormat.QR_CODE,
                                size,
                                size);

        Bitmap bitmap =
                Bitmap.createBitmap(
                        size,
                        size,
                        Bitmap.Config.RGB_565);

        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                bitmap.setPixel(
                        x,
                        y,
                        matrix.get(x, y)
                                ? Color.BLACK
                                : Color.WHITE);
            }
        }

        return bitmap;
    }

    private void stopQrPairingServer() {
        qrPairingActive = false;

        ServerSocket socket =
                qrPairingServerSocket;

        qrPairingServerSocket = null;

        if (socket != null) {
            try {
                socket.close();
            } catch (Exception ignored) {
            }
        }
    }

    private void installTvFocusHighlighter() {
        final View decorView =
                getWindow()
                        .getDecorView();

        if (decorView == null) {
            return;
        }

        if (tvFocusListener != null) {
            try {
                decorView
                        .getViewTreeObserver()
                        .removeOnGlobalFocusChangeListener(
                                tvFocusListener);
            } catch (Exception ignored) {
            }
        }

        tvFocusListener =
                (oldFocus, newFocus) ->
                        updateTvFocusHighlight(
                                oldFocus,
                                newFocus);

        decorView
                .getViewTreeObserver()
                .addOnGlobalFocusChangeListener(
                        tvFocusListener);

        decorView.post(() ->
                updateTvFocusHighlight(
                        null,
                        getCurrentFocus()));
    }

    private void updateTvFocusHighlight(
            View oldFocus,
            View newFocus) {

        if (oldFocus != null
                && oldFocus != newFocus) {
            clearTvFocusHighlight(
                    oldFocus);
        }

        if (lastTvFocusedView != null
                && lastTvFocusedView != newFocus
                && lastTvFocusedView != oldFocus) {

            clearTvFocusHighlight(
                    lastTvFocusedView);
        }

        lastTvFocusedView =
                newFocus;

        if (newFocus == null
                || !newFocus.isFocusable()) {
            return;
        }

        GradientDrawable focusRing =
                new GradientDrawable();

        focusRing.setColor(
                Color.TRANSPARENT);

        focusRing.setCornerRadius(
                dp(14));

        focusRing.setStroke(
                dp(3),
                GOLD);

        newFocus.setForeground(
                focusRing);

        newFocus.setPivotX(
                newFocus.getWidth() / 2f);

        newFocus.setPivotY(
                newFocus.getHeight() / 2f);

        newFocus.animate()
                .scaleX(1.045f)
                .scaleY(1.045f)
                .setDuration(90)
                .start();

        newFocus.setAlpha(
                1.0f);

        // Keep the selected TV control visible while moving through lists.
        newFocus.post(() -> {
            try {
                newFocus.requestRectangleOnScreen(
                        new android.graphics.Rect(
                                0,
                                0,
                                newFocus.getWidth(),
                                newFocus.getHeight()),
                        false);
            } catch (Exception ignored) {
            }
        });
    }

    private void clearTvFocusHighlight(
            View view) {

        if (view == null) {
            return;
        }

        try {
            view.setForeground(
                    null);

            view.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .setDuration(90)
                    .start();

            view.setAlpha(
                    0.94f);

        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean dispatchKeyEvent(
            KeyEvent event) {

        // Let ExoPlayer handle D-pad controls while the player is fullscreen.
        if (playerFullScreen
                && activePlayerView != null
                && activePlayerView.dispatchKeyEvent(event)) {
            return true;
        }

        if (event != null
                && event.getAction() == KeyEvent.ACTION_UP
                && isTvSelectKey(event.getKeyCode())) {

            View focused =
                    getCurrentFocus();

            if (focused instanceof EditText) {
                showTvKeyboard((EditText) focused);
                return true;
            }

            if (focused != null
                    && focused.isEnabled()
                    && focused.isClickable()) {

                focused.performClick();
                return true;
            }
        }

        if (event != null && event.getAction() == KeyEvent.ACTION_DOWN
                && !playerFullScreen && mediaSidebar != null
                && mediaContentPane != null
                && mediaSidebar.isAttachedToWindow()) {
            int key = event.getKeyCode();
            View focused = getCurrentFocus();
            boolean inSidebar = focused != null
                    && isViewInside(focused, mediaSidebar);
            boolean inContent = focused != null
                    && isViewInside(focused, mediaContentPane);
            if (key == KeyEvent.KEYCODE_DPAD_RIGHT && inSidebar) {
                // Never strand remote focus on an empty/loading content pane.
                if (findMediaContentFocus() != null) {
                    mediaLastCategoryFocus = focused;
                    setMediaSidebarExpanded(false);
                    return true;
                }
            }
            if (key == KeyEvent.KEYCODE_BACK && inContent) {
                mediaLastContentFocus = focused;
                setMediaSidebarExpanded(true);
                return true;
            }
            if (inContent) mediaLastContentFocus = focused;
        }

        return super.dispatchKeyEvent(event);
    }

    // V05341_STABILITY_HOTFIX
    // Actor/person search is deliberately disabled until the unified-search
    // path can be reintroduced with stronger lifecycle and memory safety.
    private boolean actorSearchEnabled() {
        return false;
    }

    private void showActorSearchDisabledMessage() {
        Toast.makeText(
                this,
                "Actor search is temporarily disabled for stability. Title search is still available.",
                Toast.LENGTH_SHORT)
                .show();
    }

    // GridView's normal item-click dispatch can be inconsistent with DPAD_CENTER
    // on some Android TV builds. Keep OnItemClick for touch and add a direct
    // select-key path for the currently highlighted Movie/Series item.
    // V05342_POSTER_FOCUS_FIX
    // Keep the existing per-poster GridView selector, but suppress Android TV's
    // default focus halo around the GridView container itself. OK/Enter opens
    // exactly the item already highlighted by the GridView selection.
    private void attachStableMediaGridSelection(
            final GridView grid,
            final MediaGridAdapter adapter) {

        if (grid == null || adapter == null) {
            return;
        }

        if (android.os.Build.VERSION.SDK_INT
                >= android.os.Build.VERSION_CODES.O) {
            grid.setDefaultFocusHighlightEnabled(false);
        }

        grid.setOnKeyListener(
                (v, keyCode, event) -> {
                    if (event == null
                            || event.getAction() != KeyEvent.ACTION_DOWN
                            || event.getRepeatCount() != 0
                            || !isTvSelectKey(keyCode)) {
                        return false;
                    }

                    int position = grid.getSelectedItemPosition();
                    if (position < 0 && grid.getCount() > 0) {
                        position = grid.getFirstVisiblePosition();
                    }
                    if (position < 0 && grid.getCount() > 0) {
                        position = 0;
                    }

                    // Empty or changing provider lists must not dispatch an invalid item.
                    if (position < 0 || position >= adapter.getCount()) {
                        return false;
                    }
                    Object item = adapter.getItem(position);
                    if (item instanceof MovieItem) {
                        showMovieDetails((MovieItem) item);
                        return true;
                    }

                    if (item instanceof SeriesItem) {
                        showSeriesDetails((SeriesItem) item);
                        return true;
                    }

                    return false;
                });
    }

    private boolean isTvSelectKey(
            int keyCode) {

        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER
                || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER
                || keyCode == KeyEvent.KEYCODE_BUTTON_A
                || keyCode == KeyEvent.KEYCODE_SPACE;
    }

    private void makeTvRemoteReady(
            View view) {

        if (view == null) {
            return;
        }

        view.setFocusable(true);
        view.setFocusableInTouchMode(false);
        view.setClickable(true);
        view.setAlpha(0.94f);

        view.setOnKeyListener(
                (v, keyCode, event) -> {

                    if (event != null
                            && event.getAction()
                                    == KeyEvent.ACTION_UP
                            && isTvSelectKey(
                                    keyCode)) {

                        v.performClick();
                        return true;
                    }

                    return false;
                });
    }

    private void addTvFocusScale(
            View view) {

        if (view == null) {
            return;
        }

        view.setOnFocusChangeListener(
                (v, hasFocus) -> {

                    float scale =
                            hasFocus
                                    ? 1.04f
                                    : 1.0f;

                    v.animate()
                            .scaleX(scale)
                            .scaleY(scale)
                            .setDuration(100)
                            .start();

                    v.setAlpha(
                            hasFocus
                                    ? 1.0f
                                    : 0.92f);
                });
    }

    @Override
    public void onBackPressed() {
        if (playerFullScreen) {
            if ("MOVIE".equals(selectedMediaType)
                    || "EPISODE".equals(selectedMediaType)) {
                releasePlayer();
                if ("MOVIE".equals(selectedMediaType)) {
                    showMovies();
                } else {
                    showSeries();
                }
            } else {
                showLiveTv(activeLiveFilter);
            }
            return;
        }

        if (mediaSidebar != null
                && mediaSidebar.isAttachedToWindow()
                && Boolean.FALSE.equals(mediaSidebar.getTag())) {
            View focused = getCurrentFocus();
            if (focused != null && isViewInside(focused, mediaContentPane)) {
                mediaLastContentFocus = focused;
            }
            setMediaSidebarExpanded(true);
            return;
        }

        if (!onHomeScreen) {
            releasePlayer();
            showSystemBars();
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    private GradientDrawable makeBackground(
            int backgroundColor,
            int borderColor,
            int radius) {

        GradientDrawable drawable =
                new GradientDrawable();

        drawable.setColor(backgroundColor);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(
                dp(1),
                borderColor);

        return drawable;
    }

    private int dp(int value) {
        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return (int) (value * density);
    }


    private class MediaGridAdapter
            extends BaseAdapter {

        private final String mediaType;
        private final String categoryId;
        private final TextView countView;
        private String query;
        private Cursor cursor;

        private final boolean directMode;
        private final ArrayList<MovieItem> directMovies;
        private final ArrayList<SeriesItem> directSeries;
        private final ArrayList<MovieItem> filteredMovies =
                new ArrayList<MovieItem>();
        private final ArrayList<SeriesItem> filteredSeries =
                new ArrayList<SeriesItem>();

        MediaGridAdapter(
                String mediaType,
                String categoryId,
                String query,
                TextView countView) {

            this.mediaType =
                    mediaType;

            this.categoryId =
                    categoryId == null
                            ? ""
                            : categoryId;

            this.query =
                    query == null
                            ? ""
                            : query;

            this.countView =
                    countView;

            this.directMode =
                    false;

            this.directMovies =
                    null;

            this.directSeries =
                    null;

            reload();
        }

        MediaGridAdapter(
                String mediaType,
                ArrayList<MovieItem> movies,
                ArrayList<SeriesItem> seriesList,
                String query,
                TextView countView) {

            this.mediaType =
                    mediaType;

            this.categoryId =
                    "";

            this.query =
                    query == null
                            ? ""
                            : query;

            this.countView =
                    countView;

            this.directMode =
                    true;

            this.directMovies =
                    movies == null
                            ? new ArrayList<MovieItem>()
                            : movies;

            this.directSeries =
                    seriesList == null
                            ? new ArrayList<SeriesItem>()
                            : seriesList;

            reload();
        }

        void setQuery(
                String query) {

            this.query =
                    query == null
                            ? ""
                            : query;

            reload();
        }

        void reload() {
            if (directMode) {
                reloadDirect();
                return;
            }

            Cursor next =
                    null;

            try {
                next =
                        queryCatalogueCursor(
                                mediaType,
                                categoryId,
                                query);

            } catch (Exception ignored) {
            }

            Cursor old =
                    cursor;

            cursor =
                    next;

            if (old != null) {
                try {
                    old.close();
                } catch (Exception ignored) {
                }
            }

            notifyDataSetChanged();

            updateCountView();
        }

        private void reloadDirect() {
            filteredMovies.clear();
            filteredSeries.clear();

            String normalized =
                    normalizeSearchText(
                            query);

            if (!"SERIES".equals(mediaType)) {

                for (MovieItem movie : directMovies) {
                    if (normalized.isEmpty()
                            || searchMatches(
                            query,
                            movie.name,
                            movie.year,
                            movie.rating)) {

                        filteredMovies.add(
                                movie);
                    }
                }

            }
            if (!"MOVIES".equals(mediaType)) {
                for (SeriesItem series : directSeries) {
                    if (normalized.isEmpty()
                            || searchMatches(
                            query,
                            series.name,
                            series.year,
                            series.rating,
                            series.plot)) {

                        filteredSeries.add(
                                series);
                    }
                }
            }

            notifyDataSetChanged();

            updateCountView();
        }

        private void updateCountView() {
            if (countView == null) {
                return;
            }

            int count =
                    getCount();

            String normalized =
                    normalizeSearchText(
                            query);

            countView.setText(
                    count
                            + ("MOVIES".equals(
                            mediaType)
                            ? " movies"
                            : " series")
                            + (normalized.isEmpty()
                            ? ""
                            : " matching"));
        }

        void close() {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception ignored) {
                }

                cursor =
                        null;
            }
        }

        @Override
        public int getCount() {
            if (directMode) {
                if ("ALL".equals(mediaType)) {
                    return filteredMovies.size() + filteredSeries.size();
                }
                return "MOVIES".equals(mediaType)
                        ? filteredMovies.size() : filteredSeries.size();
            }

            return cursor == null
                    || cursor.isClosed()
                    ? 0
                    : cursor.getCount();
        }

        @Override
        public Object getItem(
                int position) {

            if (directMode) {
                if ("ALL".equals(mediaType)) {
                    if (position < 0) return null;
                    if (position < filteredMovies.size()) return filteredMovies.get(position);
                    int seriesPosition = position - filteredMovies.size();
                    return seriesPosition < filteredSeries.size()
                            ? filteredSeries.get(seriesPosition) : null;
                }
                if ("MOVIES".equals(
                        mediaType)) {

                    if (position < 0
                            || position >= filteredMovies.size()) {
                        return null;
                    }

                    return filteredMovies.get(
                            position);
                }

                if (position < 0
                        || position >= filteredSeries.size()) {
                    return null;
                }

                return filteredSeries.get(
                        position);
            }

            if (cursor == null
                    || cursor.isClosed()
                    || !cursor.moveToPosition(
                    position)) {
                return null;
            }

            if ("MOVIES".equals(
                    mediaType)) {

                return MediaItemMapper.movieFromCursor(
                        cursor,
                        mediaItemCursorHost());
            }

            return MediaItemMapper.seriesFromCursor(
                    cursor);
        }

        @Override
        public long getItemId(
                int position) {

            Object item =
                    getItem(
                            position);

            if (item instanceof MovieItem) {
                return safe(
                        ((MovieItem) item)
                                .streamId)
                        .hashCode();
            }

            if (item instanceof SeriesItem) {
                return safe(
                        ((SeriesItem) item)
                                .seriesId)
                        .hashCode();
            }

            return position;
        }

        @Override
        public View getView(
                int position,
                View convertView,
                ViewGroup parent) {

            PosterCellHolder holder;

            if (convertView == null) {
                LinearLayout card =
                        new LinearLayout(
                                MainActivity.this);

                card.setOrientation(
                        LinearLayout.VERTICAL);

                card.setPadding(
                        dp(5),
                        dp(5),
                        dp(5),
                        dp(7));

                card.setBackground(
                        makeBackground(
                                CHARCOAL,
                                Color.rgb(
                                        55,
                                        55,
                                        58),
                                10));

                ImageView poster =
                        new ImageView(
                                MainActivity.this);

                poster.setScaleType(
                        ImageView.ScaleType.CENTER_CROP);

                poster.setBackgroundColor(
                        Color.rgb(
                                28,
                                28,
                                31));

                int estimatedWidth =
                        getMediaPosterCardWidth();

                int posterHeight =
                        Math.max(
                                dp(120),
                                (int) (
                                        estimatedWidth
                                                * 1.48f));

                card.addView(
                        poster,
                        new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                posterHeight));

                TextView title =
                        new TextView(
                                MainActivity.this);

                title.setTextColor(
                        Color.WHITE);

                title.setTextSize(
                        12);

                title.setTypeface(
                        Typeface.DEFAULT,
                        Typeface.BOLD);

                title.setGravity(
                        Gravity.CENTER);

                title.setMaxLines(
                        2);

                title.setPadding(
                        dp(3),
                        dp(6),
                        dp(3),
                        0);

                card.addView(
                        title,
                        new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                0,
                                1f));

                int cardHeight =
                        posterHeight
                                + dp(52);

                card.setLayoutParams(
                        new AbsListView.LayoutParams(
                                AbsListView.LayoutParams.MATCH_PARENT,
                                cardHeight));

                holder =
                        new PosterCellHolder();

                holder.poster =
                        poster;

                holder.title =
                        title;

                card.setTag(
                        holder);

                convertView =
                        card;

            } else {
                holder =
                        (PosterCellHolder)
                                convertView
                                        .getTag();
            }

            Object item =
                    getItem(
                            position);

            String titleText =
                    "";

            String imageUrl =
                    "";

            if (item instanceof MovieItem) {
                MovieItem movie =
                        (MovieItem) item;

                titleText =
                        safe(movie.name);

                imageUrl =
                        safe(movie.icon);

            } else if (item instanceof SeriesItem) {
                SeriesItem series =
                        (SeriesItem) item;

                titleText =
                        safe(series.name);

                imageUrl =
                        safe(series.cover);
            }

            holder.title.setText(
                    titleText);

            holder.poster.setImageDrawable(
                    null);

            holder.poster.setTag(
                    imageUrl);

            if (!imageUrl.isEmpty()) {
                loadPosterImage(
                        holder.poster,
                        imageUrl);
            }

            return convertView;
        }
    }



    private class CatalogueDbHelper
            extends SQLiteOpenHelper {

        private void addRawMetadataColumns(SQLiteDatabase db) {
            db.execSQL("ALTER TABLE catalogue_movies ADD COLUMN raw_json TEXT");
            db.execSQL("ALTER TABLE catalogue_series ADD COLUMN raw_json TEXT");
        }

        private void addRecentlyAddedColumns(SQLiteDatabase db) {
            db.execSQL("ALTER TABLE catalogue_movies ADD COLUMN added_at INTEGER DEFAULT 0");
            db.execSQL("ALTER TABLE catalogue_movies ADD COLUMN audio_language TEXT");
            db.execSQL("ALTER TABLE catalogue_series ADD COLUMN added_at INTEGER DEFAULT 0");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_recent_movies ON catalogue_movies(provider_key, audio_language, added_at DESC)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_recent_series ON catalogue_series(provider_key, added_at DESC)");
        }

        CatalogueDbHelper(
                Context context) {

            super(
                    context,
                    catalogueDbName(),
                    null,
                    CATALOGUE_DB_VERSION);

            setWriteAheadLoggingEnabled(
                    true);
        }

        CatalogueDbHelper(Context context, String databaseName) {
            super(context, databaseName, null, CATALOGUE_DB_VERSION);
            setWriteAheadLoggingEnabled(true);
        }

        @Override
        public void onCreate(
                SQLiteDatabase db) {

            db.execSQL(
                    "CREATE TABLE catalogue_movies ("
                            + "pk TEXT PRIMARY KEY,"
                            + "provider_key TEXT NOT NULL,"
                            + "stream_id TEXT NOT NULL,"
                            + "category_id TEXT DEFAULT '',"
                            + "name TEXT DEFAULT '',"
                            + "normalized_name TEXT DEFAULT '',"
                            + "extension TEXT DEFAULT 'mp4',"
                            + "direct_source TEXT DEFAULT '',"
                            + "rating TEXT DEFAULT '',"
                            + "year TEXT DEFAULT '',"
                            + "icon TEXT DEFAULT '',"
                            + "plot TEXT DEFAULT '',"
                            + "cast TEXT DEFAULT '',"
                            + "normalized_cast TEXT DEFAULT '',"
                            + "director TEXT DEFAULT '',"
                            + "genre TEXT DEFAULT '',"
                            + "trailer TEXT DEFAULT '',"
                            + "duration TEXT DEFAULT '',"
                            + "cast_scanned INTEGER DEFAULT 0"
                            + ")");

            db.execSQL(
                    "CREATE INDEX idx_movies_provider_category "
                            + "ON catalogue_movies(provider_key, category_id)");

            db.execSQL(
                    "CREATE INDEX idx_movies_provider_name "
                            + "ON catalogue_movies(provider_key, normalized_name)");

            db.execSQL(
                    "CREATE INDEX idx_movies_provider_cast "
                            + "ON catalogue_movies(provider_key, normalized_cast)");

            db.execSQL(
                    "CREATE TABLE catalogue_series ("
                            + "pk TEXT PRIMARY KEY,"
                            + "provider_key TEXT NOT NULL,"
                            + "series_id TEXT NOT NULL,"
                            + "category_id TEXT DEFAULT '',"
                            + "name TEXT DEFAULT '',"
                            + "normalized_name TEXT DEFAULT '',"
                            + "rating TEXT DEFAULT '',"
                            + "year TEXT DEFAULT '',"
                            + "cover TEXT DEFAULT '',"
                            + "plot TEXT DEFAULT '',"
                            + "cast TEXT DEFAULT '',"
                            + "normalized_cast TEXT DEFAULT '',"
                            + "director TEXT DEFAULT '',"
                            + "genre TEXT DEFAULT '',"
                            + "trailer TEXT DEFAULT ''"
                            + ")");

            db.execSQL(
                    "CREATE INDEX idx_series_provider_category "
                            + "ON catalogue_series(provider_key, category_id)");

            db.execSQL(
                    "CREATE INDEX idx_series_provider_name "
                            + "ON catalogue_series(provider_key, normalized_name)");

            addRecentlyAddedColumns(db);
            addRawMetadataColumns(db);
            CatalogueDetailStore.createTable(db);
            CatalogueSchemaRepair.ensure(db);
        }

        // Repair older catalogue schemas before queries use updated_at.
        // CatalogueSchemaRepair also maintains the existing updated-series index;
        // avoid creating a second, redundant index on the same columns.
        @Override
        public void onOpen(SQLiteDatabase db) {
            super.onOpen(db);
            if (!db.isReadOnly()) {
                CatalogueSchemaRepair.ensure(db);
            }
        }

        @Override
        public void onUpgrade(
                SQLiteDatabase db,
                int oldVersion,
                int newVersion) {
            CatalogueDetailStore.createTable(db);

            
    CatalogueSchemaRepair.ensure(db);

        }
    }

    // ---------------------------------------------------------------------
    // MOVIE / SERIES MODELS
    // ---------------------------------------------------------------------








    // ---------------------------------------------------------------------
    // CHANNEL MODEL
    // ---------------------------------------------------------------------

}
