package com.premiumplayer.app;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;

final class PlaybackEventHandler {

    interface Host {
        void setKeepAwake(boolean keepAwake);

        boolean isLive();
        void configureLiveControls();

        void startResumeSaving();
        void stopResumeSaving();

        long resumeStartPosition();
        String formatPlaybackTime(long position);

        void setStatus(String text);

        boolean handlingPlaybackEnd();
        void setHandlingPlaybackEnd(boolean value);

        String currentResumeKey();
        void clearResumePosition(String key);

        boolean isEpisode();
        void autoPlayNextEpisode();

        int candidateIndex();
        int candidateCount();
        void incrementCandidateIndex();

        void retry(String preferredLanguage);

        String errorMessage(Exception error);
    }

    static void attach(
            SimpleExoPlayer player,
            Host host,
            PlaybackProbe probe,
            String preferredLanguage) {

        player.addListener(
                new Player.EventListener() {

                    @Override
                    public void onPlayerStateChanged(
                            boolean playWhenReady,
                            int playbackState) {

                        if (playbackState == Player.STATE_READY) {

                            host.setKeepAwake(true);

                            if (host.isLive()) {
                                host.configureLiveControls();
                            }

                            host.startResumeSaving();

                            String resumedText =
                                    host.resumeStartPosition() >= 30000L
                                            ? " • resumed "
                                            + host.formatPlaybackTime(
                                                    host.resumeStartPosition())
                                            : "";

                            host.setStatus(
                                    "Playing • "
                                            + (probe.hls
                                            ? "HLS"
                                            : "direct stream")
                                            + " • "
                                            + probe.contentType
                                            + resumedText);
                        }

                        if (playbackState == Player.STATE_ENDED
                                && host.handlingPlaybackEnd() == false) {

                            host.setHandlingPlaybackEnd(true);

                            host.stopResumeSaving();

                            String resumeKey =
                                    host.currentResumeKey();

                            if (resumeKey != null
                                    && resumeKey.isEmpty() == false) {

                                host.clearResumePosition(
                                        resumeKey);
                            }

                            if (host.isEpisode()) {

                                host.autoPlayNextEpisode();

                            } else {

                                host.setKeepAwake(false);

                                host.setStatus(
                                        "Playback finished.");
                            }
                        }
                    }

                    @Override
                    public void onPlayerError(
                            ExoPlaybackException error) {

                        if (host.candidateIndex() + 1
                                < host.candidateCount()) {

                            host.incrementCandidateIndex();

                            host.setStatus(
                                    "Player rejected this source. "
                                            + "Trying the next one...");

                            host.retry(
                                    preferredLanguage);

                        } else {

                            host.setKeepAwake(false);

                            host.setStatus(
                                    "Player source error: "
                                            + host.errorMessage(error));
                        }
                    }
                });
    }
}
