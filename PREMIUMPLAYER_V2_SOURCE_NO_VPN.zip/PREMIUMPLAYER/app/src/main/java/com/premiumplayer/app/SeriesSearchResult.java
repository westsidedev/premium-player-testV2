package com.premiumplayer.app;

import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

    class SeriesSearchResult {
        final ArrayList<SeriesItem> items = new ArrayList<SeriesItem>();
        int matchCount = 0;
    }
