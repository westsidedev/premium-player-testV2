package com.premiumplayer.app;

import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;
import java.util.ArrayList;

final class CatalogueRefreshBatch {

    private static final int MAX_WRITES = 500;
    private static final long MAX_BYTES = 12L * 1024L * 1024L;

    interface Guard {
        void check() throws Exception;
    }

    interface Progress {
        void update(String type, long checked);
    }

    static final class Entry {
        final boolean movie;
        final String id;
        final String json;
        final boolean isNew;

        Entry(boolean movie, String id,
              String json, boolean isNew) {
            this.movie = movie;
            this.id = id;
            this.json = json;
            this.isNew = isNew;
        }
    }

    static final class Stats {
        long seen;
        long added;
        long changed;
        long unchanged;
        long positionOnly;
        long invalid;
    }

    final ArrayList<Entry> entries = new ArrayList<>();
    final Stats movies = new Stats();
    final Stats series = new Stats();
    private long stagedBytes = 0L;

    private void add(Entry entry) throws Exception {
        long bytes = entry.json.length() * 2L;

        if (entries.size() >= MAX_WRITES
                || stagedBytes + bytes > MAX_BYTES) {
            throw new IllegalStateException(
                    "Refresh exceeds safe change limit");
        }

        entries.add(entry);
        stagedBytes += bytes;
    }

    private void scan(
            SQLiteDatabase db,
            String providerKey,
            String url,
            boolean movie,
            Guard guard,
            Progress progress) throws Exception {

        final Stats stats = movie ? movies : series;
        final String type = movie ? "MOVIES" : "SERIES";
        final String table = movie
                ? "catalogue_movies" : "catalogue_series";

        final long existing = DatabaseUtils.longForQuery(
                db,
                "SELECT COUNT(*) FROM " + table
                        + " WHERE provider_key=?",
                new String[]{providerKey});

        XtreamJsonArrayTransport.stream(url, reader -> {
            guard.check();

            String json = ProviderRawJson.capture(reader);
            JSONObject object = new JSONObject(json);

            String id = object.optString(
                    movie ? "stream_id" : "series_id", "");

            stats.seen++;

            if (id.isEmpty() || "null".equals(id)) {
                stats.invalid++;
                return;
            }

            int result = CatalogueRefreshDiff.compare(
                    db, movie, providerKey, id, json);

            if (result == CatalogueRefreshDiff.NEW) {
                add(new Entry(movie, id, json, true));
                stats.added++;
            } else if (result == CatalogueRefreshDiff.CHANGED) {
                add(new Entry(movie, id, json, false));
                stats.changed++;
            } else if (result ==
                    CatalogueRefreshDiff.LIST_POSITION_ONLY) {
                stats.positionOnly++;
            } else {
                stats.unchanged++;
            }

            if (stats.seen % 2000L == 0L) {
                progress.update(type, stats.seen);
            }
        });

        guard.check();

        if (stats.seen == 0 || stats.invalid != 0
                || (existing > 100
                && stats.seen < existing * 9L / 10L)) {
            throw new IllegalStateException(
                    "Incomplete or invalid " + type
                            + " provider response");
        }
    }

    static CatalogueRefreshBatch prepare(
            SQLiteDatabase db,
            String providerKey,
            String movieUrl,
            String seriesUrl,
            Guard guard,
            Progress progress) throws Exception {

        CatalogueRefreshBatch batch =
                new CatalogueRefreshBatch();

        batch.scan(db, providerKey, movieUrl,
                true, guard, progress);

        batch.scan(db, providerKey, seriesUrl,
                false, guard, progress);

        return batch;
    }

    String summary() {
        return "New movies: " + movies.added
                + "\nChanged movies: " + movies.changed
                + "\nNew series: " + series.added
                + "\nChanged series: " + series.changed
                + "\nWrites staged: " + entries.size()
                + "\n\nPosition-only changes skipped: "
                + (movies.positionOnly + series.positionOnly);
    }
}
