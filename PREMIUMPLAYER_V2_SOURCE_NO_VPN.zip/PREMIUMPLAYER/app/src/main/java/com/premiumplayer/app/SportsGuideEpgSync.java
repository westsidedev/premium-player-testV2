package com.premiumplayer.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

final class SportsGuideEpgSync {

    interface EpgFetcher {
        void fetch(
                Channel channel,
                int limit,
                ResultCallback callback);
    }

    interface ResultCallback {
        void result(
                ArrayList<EpgEntry> entries,
                String error);
    }

    interface EventPoster {
        void post(
                JSONArray events,
                Runnable completion);
    }

    private SportsGuideEpgSync() {}

    static void start(
            ArrayList<Channel> channels,
            EpgFetcher fetcher,
            EventPoster poster,
            Runnable completion) {

        final int limit =
                Math.min(180, channels.size());

        final JSONArray events =
                new JSONArray();

        final int[] next = {0};
        final int[] active = {0};
        final int[] finished = {0};
        final boolean[] posted = {false};

        final Runnable[] pump =
                new Runnable[1];

        pump[0] = () -> {

            while (active[0] < 6
                    && next[0] < limit) {

                final Channel channel =
                        channels.get(next[0]++);

                active[0]++;

                fetcher.fetch(
                        channel,
                        72,
                        (entries, error) -> {

                            active[0]--;
                            finished[0]++;

                            if (error == null) {
                                for (EpgEntry entry : entries) {

                                    if (entry.startTimestamp <= 0)
                                        continue;

                                    try {
                                        JSONObject item =
                                                new JSONObject();

                                        item.put("channel_key", channel.key());
                                        item.put("channel_name", safe(channel.name));
                                        item.put("channel_group", safe(channel.group));
                                        item.put("stream_id", safe(channel.streamId));
                                        item.put("channel_logo", safe(channel.logo));
                                        item.put("title", safe(entry.title));
                                        item.put("description", safe(entry.description));
                                        item.put("category", safe(entry.category));

                                        item.put(
                                                "competition",
                                                !safe(entry.category).isEmpty()
                                                        ? safe(entry.category)
                                                        : safe(channel.name)
                                                        + " "
                                                        + safe(channel.group));

                                        item.put("start_at", entry.startTimestamp);
                                        item.put("end_at", entry.endTimestamp);

                                        events.put(item);

                                    } catch (Exception ignored) {}
                                }
                            }

                            if (finished[0] >= limit
                                    && active[0] == 0
                                    && !posted[0]) {

                                posted[0] = true;

                                poster.post(
                                        events,
                                        completion);

                            } else {
                                pump[0].run();
                            }
                        });
            }
        };

        pump[0].run();
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }
}
