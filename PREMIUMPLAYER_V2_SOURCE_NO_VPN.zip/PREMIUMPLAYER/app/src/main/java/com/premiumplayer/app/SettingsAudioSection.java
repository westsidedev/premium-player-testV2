package com.premiumplayer.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

final class SettingsAudioSection {

    interface Host {
        SharedPreferences prefs();
        String preferredLanguage();
        String languageName(String code);
        Drawable background(int fill, int border, int radius);
        void refreshSettings();
        int dp(int value);
        int gold();
        int silver();
        int charcoal();
    }

    static void add(Context context, Host host, LinearLayout root) {

        TextView section = new TextView(context);
        section.setText("PREFERRED AUDIO LANGUAGE");
        section.setTextColor(host.gold());
        section.setTextSize(12);
        section.setLetterSpacing(0.12f);
        section.setPadding(0, host.dp(24), 0, host.dp(8));
        root.addView(section);

        TextView help = new TextView(context);
        help.setText(
                "When a stream contains a correctly labelled audio track in your preferred language, "
                        + "PREMIUM PLAYER will select it automatically. Otherwise the stream default is used.");
        help.setTextColor(host.silver());
        help.setTextSize(13);
        help.setPadding(0, 0, 0, host.dp(18));
        root.addView(help);

        TextView current = new TextView(context);
        current.setText("Current: " + host.languageName(host.preferredLanguage()));
        current.setTextColor(Color.WHITE);
        current.setTextSize(16);
        current.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        current.setPadding(0, 0, 0, host.dp(12));
        root.addView(current);

        String[][] languages = {
                {"AUTO / STREAM DEFAULT", ""},
                {"ENGLISH", "en"},
                {"FRENCH", "fr"},
                {"SPANISH", "es"},
                {"PORTUGUESE", "pt"},
                {"ARABIC", "ar"},
                {"GERMAN", "de"},
                {"ITALIAN", "it"},
                {"DUTCH", "nl"},
                {"SWEDISH", "sv"}
        };

        for (String[] language : languages) {
            final String languageName = language[0];
            final String languageCode = language[1];

            Button button = new Button(context);
            button.setText(languageName);
            button.setTextColor(Color.WHITE);
            button.setTextSize(13);
            button.setAllCaps(false);

            boolean selected =
                    host.preferredLanguage().equals(languageCode);

            if (selected) {
                button.setBackground(
                        host.background(
                                Color.rgb(35, 31, 23),
                                host.gold(),
                                14));
            } else {
                button.setBackground(
                        host.background(
                                host.charcoal(),
                                Color.rgb(55, 55, 58),
                                14));
            }

            button.setOnClickListener(v -> {
                host.prefs()
                        .edit()
                        .putString(
                                "preferred_audio_language",
                                languageCode)
                        .apply();

                current.setText(
                        "Current: "
                                + host.languageName(languageCode));

                Toast.makeText(
                        context,
                        "Preferred audio set to "
                                + host.languageName(languageCode),
                        Toast.LENGTH_SHORT)
                        .show();

                host.refreshSettings();
            });

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            host.dp(50));

            params.setMargins(
                    0,
                    0,
                    0,
                    host.dp(9));

            root.addView(button, params);
        }
    }
}
