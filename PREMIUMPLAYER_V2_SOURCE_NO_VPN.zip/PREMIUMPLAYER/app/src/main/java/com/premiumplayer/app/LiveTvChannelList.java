package com.premiumplayer.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.exoplayer2.ui.PlayerView;

import java.util.ArrayList;
import java.util.HashSet;

final class LiveTvChannelList {

    interface Host {
        ArrayList<Channel> channels();
        HashSet<String> favourites();

        String safe(String value);
        String normalize(String value);

        boolean searchMatches(
                String query,
                String name,
                String group,
                String tvgName);

        boolean current(Channel channel);
        boolean selectedKey(String key);

        void tvReady(View view);
        void saveFavourites();

        void channelPressed(
                Channel channel,
                LinearLayout container,
                PlayerView playerView,
                TextView title,
                TextView now,
                TextView next,
                TextView status);

        LinearLayout.LayoutParams listParams(int height);

        Drawable background(int fill, int border, int radius);

        int maxCards();
        int dp(int value);
        int gold();
        int silver();
        int charcoal();
    }

    static void refresh(
            Context context,
            Host host,
            LinearLayout container,
            String filter,
            String query,
            PlayerView playerView,
            TextView previewTitle,
            TextView previewNow,
            TextView previewNext,
            TextView previewStatus) {

        container.removeAllViews();

        String cleanQuery = host.normalize(query);

        int totalMatches = 0;
        int rendered = 0;

        for (Channel channel : host.channels()) {

            String group = host.safe(channel.group);

            boolean categoryMatch =
                    "ALL".equals(filter)
                            || filter.equals(group)
                            || ("FAVOURITES".equals(filter)
                            && host.favourites().contains(channel.key()));

            boolean searchMatch =
                    cleanQuery.isEmpty()
                            || host.searchMatches(
                                    cleanQuery,
                                    host.safe(channel.name),
                                    group,
                                    host.safe(channel.tvgName));

            if (!categoryMatch || !searchMatch) {
                continue;
            }

            totalMatches++;

            if (rendered >= host.maxCards()) {
                continue;
            }

            LinearLayout row = new LinearLayout(context);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            row.setPadding(
                    host.dp(10),
                    host.dp(6),
                    host.dp(6),
                    host.dp(6));

            row.setTag(channel.key());
            host.tvReady(row);

            TextView name = new TextView(context);
            name.setText(channel.name);
            name.setTextColor(Color.WHITE);
            name.setTextSize(13);
            name.setSingleLine(true);
            name.setGravity(Gravity.CENTER_VERTICAL);

            row.addView(
                    name,
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            1f));

            TextView favourite = new TextView(context);

            favourite.setText(
                    host.favourites().contains(channel.key())
                            ? "\u2605"
                            : "\u2606");

            favourite.setTextColor(
                    host.favourites().contains(channel.key())
                            ? host.gold()
                            : host.silver());

            favourite.setTextSize(20);
            favourite.setGravity(Gravity.CENTER);
            host.tvReady(favourite);

            row.addView(
                    favourite,
                    new LinearLayout.LayoutParams(
                            host.dp(38),
                            LinearLayout.LayoutParams.MATCH_PARENT));

            boolean selected = host.current(channel);

            row.setBackground(
                    host.background(
                            selected
                                    ? Color.rgb(35, 31, 23)
                                    : host.charcoal(),
                            selected
                                    ? host.gold()
                                    : Color.rgb(52, 52, 56),
                            10));

            container.addView(
                    row,
                    host.listParams(host.dp(52)));

            row.setOnClickListener(v ->
                    host.channelPressed(
                            channel,
                            container,
                            playerView,
                            previewTitle,
                            previewNow,
                            previewNext,
                            previewStatus));

            favourite.setOnClickListener(v -> {

                String key = channel.key();

                if (host.favourites().contains(key)) {

                    host.favourites().remove(key);
                    favourite.setText("\u2606");
                    favourite.setTextColor(host.silver());

                } else {

                    host.favourites().add(key);
                    favourite.setText("\u2605");
                    favourite.setTextColor(host.gold());
                }

                host.saveFavourites();
            });

            rendered++;
        }

        if (totalMatches == 0) {

            TextView empty = new TextView(context);
            empty.setText("No matching channels.");
            empty.setTextColor(host.silver());
            empty.setTextSize(13);
            empty.setGravity(Gravity.CENTER);

            empty.setPadding(
                    host.dp(10),
                    host.dp(25),
                    host.dp(10),
                    host.dp(25));

            container.addView(empty);

        } else if (totalMatches > rendered) {

            TextView notice = new TextView(context);

            notice.setText(
                    "Showing "
                            + rendered
                            + " of "
                            + totalMatches
                            + ". Use Search to narrow the list.");

            notice.setTextColor(
                    Color.rgb(
                            125,
                            125,
                            130));

            notice.setTextSize(11);
            notice.setGravity(Gravity.CENTER);

            notice.setPadding(
                    host.dp(6),
                    host.dp(10),
                    host.dp(6),
                    host.dp(10));

            container.addView(notice);
        }
    }

    static void updateHighlight(
            Host host,
            LinearLayout container) {

        for (int i = 0;
             i < container.getChildCount();
             i++) {

            View child = container.getChildAt(i);

            Object tag = child.getTag();

            if (tag == null) {
                continue;
            }

            boolean selected =
                    host.selectedKey(
                            host.safe(
                                    String.valueOf(tag)));

            child.setBackground(
                    host.background(
                            selected
                                    ? Color.rgb(35, 31, 23)
                                    : host.charcoal(),
                            selected
                                    ? host.gold()
                                    : Color.rgb(52, 52, 56),
                            10));
        }
    }
}
