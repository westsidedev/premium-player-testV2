package com.premiumplayer.app;

import java.util.ArrayList;
import java.util.HashSet;

final class LiveTvNavigation {

    interface Host {
        ArrayList<Channel> channels();
        HashSet<String> favourites();

        String activeFilter();
        String safe(String value);

        String selectedStreamUrl();
        String selectedStreamId();
        String selectedChannel();
    }

    static ArrayList<Channel> channels(
            Host host) {

        ArrayList<Channel> active =
                host.channels();

        if (active.isEmpty()) {
            return active;
        }

        String filter =
                host.activeFilter();

        if (filter == null
                || filter.trim().isEmpty()) {
            filter = "ALL";
        }

        if ("ALL".equals(filter)) {
            return active;
        }

        ArrayList<Channel> filtered =
                new ArrayList<Channel>();

        for (Channel channel : active) {

            if (channel == null) {
                continue;
            }

            if ("FAVOURITES".equals(filter)) {

                if (host.favourites().contains(
                        channel.key())) {

                    filtered.add(channel);
                }

            } else if (filter.equals(
                    host.safe(channel.group))) {

                filtered.add(channel);
            }
        }

        return filtered.isEmpty()
                ? active
                : filtered;
    }

    static Channel target(
            Host host,
            int direction) {

        ArrayList<Channel> channels =
                channels(host);

        if (channels.isEmpty()) {
            return null;
        }

        int currentIndex = -1;

        for (int i = 0;
             i < channels.size();
             i++) {

            Channel channel =
                    channels.get(i);

            boolean streamMatch =
                    !host.selectedStreamUrl().isEmpty()
                            && host.selectedStreamUrl().equals(
                                    host.safe(channel.url));

            boolean idMatch =
                    !host.selectedStreamId().isEmpty()
                            && host.selectedStreamId().equals(
                                    host.safe(channel.streamId));

            boolean nameMatch =
                    host.selectedChannel().equals(
                            host.safe(channel.name));

            if (streamMatch
                    || idMatch
                    || nameMatch) {

                currentIndex = i;
                break;
            }
        }

        int targetIndex;

        if (currentIndex < 0) {

            targetIndex =
                    direction < 0
                            ? channels.size() - 1
                            : 0;

        } else {

            targetIndex =
                    (currentIndex
                            + direction
                            + channels.size())
                            % channels.size();
        }

        return channels.get(targetIndex);
    }
}
