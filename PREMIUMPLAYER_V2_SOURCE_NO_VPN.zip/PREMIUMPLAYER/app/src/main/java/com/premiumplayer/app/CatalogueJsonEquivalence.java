package com.premiumplayer.app;

import org.json.JSONObject;
import org.json.JSONArray;
import java.math.BigDecimal;
import java.util.Iterator;

final class CatalogueJsonEquivalence {

    static boolean equivalent(String oldJson, String newJson) {
        try {
            return equal(
                    new JSONObject(oldJson),
                    new JSONObject(newJson));
        } catch (Exception error) {
            return false;
        }
    }

    private static boolean equal(Object a, Object b) {
        if (a == b) return true;
        if (a == null || b == null) return false;

        if (a == JSONObject.NULL || b == JSONObject.NULL) {
            return a == JSONObject.NULL && b == JSONObject.NULL;
        }

        if (a instanceof JSONObject && b instanceof JSONObject) {
            JSONObject x = (JSONObject) a;
            JSONObject y = (JSONObject) b;
            if (x.length() != y.length()) return false;

            Iterator<String> keys = x.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (!y.has(key) || !equal(x.opt(key), y.opt(key))) {
                    return false;
                }
            }
            return true;
        }

        if (a instanceof JSONArray && b instanceof JSONArray) {
            JSONArray x = (JSONArray) a;
            JSONArray y = (JSONArray) b;
            if (x.length() != y.length()) return false;

            for (int i = 0; i < x.length(); i++) {
                if (!equal(x.opt(i), y.opt(i))) return false;
            }
            return true;
        }

        if (a instanceof Number && b instanceof Number) {
            try {
                return new BigDecimal(a.toString()).compareTo(
                        new BigDecimal(b.toString())) == 0;
            } catch (Exception error) {
                return false;
            }
        }

        return a.equals(b);
    }
}
