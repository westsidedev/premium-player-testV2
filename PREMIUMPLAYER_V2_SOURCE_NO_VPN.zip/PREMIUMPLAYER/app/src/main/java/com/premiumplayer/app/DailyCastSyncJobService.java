package com.premiumplayer.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.JsonReader;
import android.util.JsonToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Build 0.39 daily background discovery.
 *
 * Important privacy boundary:
 * - Xtream server / username / password are read only from on-device SharedPreferences.
 * - They are used only to call the user's provider directly from the device.
 * - Supabase receives title/year/type/local stream id plus provider-supplied metadata.
 * - Stream URLs and IPTV credentials never leave the device.
 *
 * This service deliberately does not decide what appears in Movies/Series. The provider-direct
 * browser remains authoritative even if this background task fails.
 */
public class DailyCastSyncJobService extends JobService {

    private static final int JOB_ID = 8038;
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;
    private static final String PREFS = "premium_player";
    private static final String DB_NAME = "premium_catalogue.db";
    private static final String BACKEND_URL =
            "https://suouvnvtibawqcdimfqb.supabase.co/functions/v1/catalogue-enrich";
    private static final String BACKEND_KEY =
            "sb_publishable_Qbt02WgwSh56h7NntS_gmw_Kk74j5Ld";

    // Backend currently enriches up to five uncached TMDB titles per request.
    // Keeping our batch at five means every newly discovered item gets a chance immediately.
    private static final int BACKEND_BATCH_SIZE = 5;

    public static void schedule(Context context) {
        if (context == null) return;

        try {
            JobScheduler scheduler =
                    (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);

            if (scheduler == null) return;

            JobInfo info =
                    new JobInfo.Builder(
                            JOB_ID,
                            new ComponentName(context, DailyCastSyncJobService.class))
                            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                            .setPersisted(true)
                            .setPeriodic(DAY_MS)
                            .build();

            scheduler.schedule(info);
        } catch (Exception ignored) {
            // App-open fallback in MainActivity still performs the 24h enrichment pass.
        }
    }

    /**
     * Avoids treating the user's already-indexed 0.37 catalogue as "new" after installing 0.38.
     * If the local catalogue is empty we leave the seed flag unset, so the first daily job can
     * discover everything normally.
     */
    public static void seedKnownIdsFromCatalogue(Context context) {
        if (context == null) return;

        SharedPreferences prefs =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        String providerKey = providerKey(prefs);
        if (providerKey.isEmpty()) return;

        String seedKey = "daily_cast_seeded_" + providerKey;
        if (prefs.getBoolean(seedKey, false)) return;

        File dbFile = context.getDatabasePath(DB_NAME);
        if (dbFile == null || !dbFile.exists()) return;

        SQLiteDatabase db = null;
        Cursor cursor = null;
        int count = 0;

        HashSet<String> movieIds = new HashSet<String>();
        HashSet<String> seriesIds = new HashSet<String>();

        try {
            db = SQLiteDatabase.openDatabase(
                    dbFile.getAbsolutePath(),
                    null,
                    SQLiteDatabase.OPEN_READONLY);

            cursor = db.query(
                    "catalogue_movies",
                    new String[]{"stream_id"},
                    "provider_key=?",
                    new String[]{providerKey},
                    null,
                    null,
                    null);

            while (cursor.moveToNext()) {
                String id = safe(cursor.getString(0));
                if (!id.isEmpty()) {
                    movieIds.add(id);
                    count++;
                }
            }

            cursor.close();
            cursor = null;

            cursor = db.query(
                    "catalogue_series",
                    new String[]{"series_id"},
                    "provider_key=?",
                    new String[]{providerKey},
                    null,
                    null,
                    null);

            while (cursor.moveToNext()) {
                String id = safe(cursor.getString(0));
                if (!id.isEmpty()) {
                    seriesIds.add(id);
                    count++;
                }
            }

            if (count > 0) {
                writeKnownSet(context, providerKey, "movies", movieIds);
                writeKnownSet(context, providerKey, "series", seriesIds);
                prefs.edit().putBoolean(seedKey, true).apply();
            }

        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                try { cursor.close(); } catch (Exception ignored) {}
            }
            if (db != null) {
                try { db.close(); } catch (Exception ignored) {}
            }
        }
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(() -> {
            try {
                runDailySync(getApplicationContext());
            } catch (Exception ignored) {
            } finally {
                jobFinished(params, false);
            }
        }, "premium-daily-cast-sync").start();

        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        // Retry later if Android interrupted us (Doze, reboot, battery policy, etc.).
        return true;
    }

    private static void runDailySync(Context context) throws Exception {
        SharedPreferences prefs =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        String server = normalizeServer(prefs.getString("xtream_server", ""));
        String username = safe(prefs.getString("xtream_username", ""));
        String password = safe(prefs.getString("xtream_password", ""));

        if (server.isEmpty() || username.isEmpty() || password.isEmpty()) {
            return;
        }

        String providerKey = providerKey(prefs);

        syncOneType(
                context,
                prefs,
                providerKey,
                server,
                username,
                password,
                true);

        syncOneType(
                context,
                prefs,
                providerKey,
                server,
                username,
                password,
                false);

        prefs.edit()
                .putLong("daily_cast_sync_last", System.currentTimeMillis())
                .apply();
    }

    private static void syncOneType(
            Context context,
            SharedPreferences prefs,
            String providerKey,
            String server,
            String username,
            String password,
            boolean movies)
            throws Exception {

        String typeName = movies ? "movies" : "series";
        String action = movies ? "get_vod_streams" : "get_series";
        String hiddenKey = movies ? "editor_hidden_movies" : "editor_hidden_series";

        Set<String> hiddenStored =
                prefs.getStringSet(hiddenKey, new HashSet<String>());
        HashSet<String> hidden =
                hiddenStored == null
                        ? new HashSet<String>()
                        : new HashSet<String>(hiddenStored);

        HashSet<String> known =
                readKnownSet(context, providerKey, typeName);

        String endpoint =
                server
                        + "/player_api.php?username="
                        + URLEncoder.encode(username, "UTF-8")
                        + "&password="
                        + URLEncoder.encode(password, "UTF-8")
                        + "&action="
                        + URLEncoder.encode(action, "UTF-8");

        File pending =
                new File(
                        context.getCacheDir(),
                        "daily_cast_" + typeName + "_pending.jsonl");

        streamNewItemsToFile(endpoint, movies, hidden, known, pending);

        HashSet<String> newlyKnown = new HashSet<String>();
        BufferedReader reader = null;

        try {
            reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(pending),
                                    "UTF-8"));

            JSONArray batch = new JSONArray();
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                batch.put(new JSONObject(line));

                if (batch.length() >= BACKEND_BATCH_SIZE) {
                    collectAcceptedIds(postBatch(batch), newlyKnown);
                    batch = new JSONArray();
                }
            }

            if (batch.length() > 0) {
                collectAcceptedIds(postBatch(batch), newlyKnown);
            }

        } finally {
            if (reader != null) {
                try { reader.close(); } catch (Exception ignored) {}
            }
            try { pending.delete(); } catch (Exception ignored) {}
        }

        if (!newlyKnown.isEmpty()) {
            known.addAll(newlyKnown);
            writeKnownSet(context, providerKey, typeName, known);
        }
    }

    private static void streamNewItemsToFile(
            String endpoint,
            boolean movies,
            HashSet<String> hidden,
            HashSet<String> known,
            File outputFile)
            throws Exception {

        HttpURLConnection connection = null;
        JsonReader json = null;
        BufferedWriter writer = null;

        try {
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(60000);
            connection.setRequestMethod("GET");
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json, text/plain, */*");
            connection.setRequestProperty("Accept-Encoding", "identity");
            connection.setRequestProperty("Connection", "close");
            connection.setRequestProperty("User-Agent", "VLC/3.0.21 LibVLC/3.0.21");

            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) {
                throw new Exception("Provider HTTP " + code);
            }

            writer =
                    new BufferedWriter(
                            new OutputStreamWriter(
                                    new FileOutputStream(outputFile, false),
                                    "UTF-8"));

            json =
                    new JsonReader(
                            new InputStreamReader(
                                    connection.getInputStream(),
                                    "UTF-8"));

            json.beginArray();

            while (json.hasNext()) {
                LightweightMedia item = readItem(json, movies);

                if (item.id.isEmpty()
                        || known.contains(item.id)
                        || hidden.contains(item.categoryId)) {
                    continue;
                }

                JSONObject payload = new JSONObject();
                payload.put("client_id", item.id);
                payload.put("type", movies ? "movie" : "series");
                payload.put("title", item.title);
                payload.put("year", item.year);
                payload.put("cast", item.cast);
                payload.put("overview", item.overview);

                writer.write(payload.toString());
                writer.newLine();
            }

            json.endArray();
            writer.flush();

        } finally {
            if (json != null) {
                try { json.close(); } catch (Exception ignored) {}
            }
            if (writer != null) {
                try { writer.close(); } catch (Exception ignored) {}
            }
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private static LightweightMedia readItem(JsonReader reader, boolean movies)
            throws Exception {

        LightweightMedia item = new LightweightMedia();
        reader.beginObject();

        while (reader.hasNext()) {
            String key = reader.nextName();

            if ("name".equals(key)) {
                item.title = readString(reader);
            } else if (movies && "stream_id".equals(key)) {
                item.id = readString(reader);
            } else if (!movies && "series_id".equals(key)) {
                item.id = readString(reader);
            } else if ("category_id".equals(key)) {
                item.categoryId = readString(reader);
            } else if ("year".equals(key) || "releaseDate".equals(key)) {
                item.year = readString(reader);
            } else if ("cast".equals(key) || "actors".equals(key)) {
                item.cast = readString(reader);
            } else if ("plot".equals(key) || "description".equals(key)) {
                item.overview = readString(reader);
            } else if (movies && (
                    "stream_icon".equals(key)
                            || "movie_image".equals(key)
                            || "cover_big".equals(key))) {
                String value = readString(reader);
                if (item.poster.isEmpty()) item.poster = value;
            } else if (!movies && (
                    "cover".equals(key)
                            || "cover_big".equals(key)
                            || "stream_icon".equals(key))) {
                String value = readString(reader);
                if (item.poster.isEmpty()) item.poster = value;
            } else {
                reader.skipValue();
            }
        }

        reader.endObject();
        return item;
    }

    private static String readString(JsonReader reader) throws Exception {
        JsonToken token = reader.peek();

        if (token == JsonToken.NULL) {
            reader.nextNull();
            return "";
        }

        if (token == JsonToken.STRING
                || token == JsonToken.NUMBER
                || token == JsonToken.BOOLEAN) {
            return safe(reader.nextString());
        }

        reader.skipValue();
        return "";
    }

    private static JSONObject postBatch(JSONArray items) throws Exception {
        HttpURLConnection connection = null;

        try {
            connection = (HttpURLConnection) new URL(BACKEND_URL).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(45000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("apikey", BACKEND_KEY);

            JSONObject body = new JSONObject();
            body.put("items", items);

            OutputStream output = connection.getOutputStream();
            output.write(body.toString().getBytes("UTF-8"));
            output.flush();
            output.close();

            int code = connection.getResponseCode();
            InputStream input =
                    code >= 200 && code < 300
                            ? connection.getInputStream()
                            : connection.getErrorStream();

            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(input, "UTF-8"));
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line);
            reader.close();

            if (code < 200 || code >= 300) {
                throw new Exception("Backend HTTP " + code);
            }

            return new JSONObject(text.toString());

        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static void collectAcceptedIds(
            JSONObject response,
            HashSet<String> accepted) {

        if (response == null) return;
        JSONArray items = response.optJSONArray("items");
        if (items == null) return;

        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;

            String status = safe(item.optString("status", ""));
            String id = safe(item.optString("client_id", ""));

            // done = metadata cached; not_found = a valid lookup was attempted and should not
            // be hammered every day. queued/error stay unmarked and will be retried next day.
            if (!id.isEmpty()
                    && ("done".equals(status) || "not_found".equals(status))) {
                accepted.add(id);
            }
        }
    }

    private static HashSet<String> readKnownSet(
            Context context,
            String providerKey,
            String type) {

        HashSet<String> set = new HashSet<String>();
        File file = knownFile(context, providerKey, type);
        if (!file.exists()) return set;

        BufferedReader reader = null;
        try {
            reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(file),
                                    "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) set.add(line);
            }
        } catch (Exception ignored) {
        } finally {
            if (reader != null) {
                try { reader.close(); } catch (Exception ignored) {}
            }
        }
        return set;
    }

    private static void writeKnownSet(
            Context context,
            String providerKey,
            String type,
            HashSet<String> ids) {

        File file = knownFile(context, providerKey, type);
        BufferedWriter writer = null;

        try {
            writer =
                    new BufferedWriter(
                            new OutputStreamWriter(
                                    new FileOutputStream(file, false),
                                    "UTF-8"));
            for (String id : ids) {
                if (id == null || id.trim().isEmpty()) continue;
                writer.write(id.trim());
                writer.newLine();
            }
            writer.flush();
        } catch (Exception ignored) {
        } finally {
            if (writer != null) {
                try { writer.close(); } catch (Exception ignored) {}
            }
        }
    }

    private static File knownFile(Context context, String providerKey, String type) {
        return new File(
                context.getFilesDir(),
                "daily_cast_known_" + providerKey + "_" + type + ".txt");
    }

    private static String providerKey(SharedPreferences prefs) {
        String server = normalizeServer(prefs.getString("xtream_server", ""));
        String username = safe(prefs.getString("xtream_username", ""));
        if (server.isEmpty() || username.isEmpty()) return "";
        return Integer.toHexString((server + "|" + username).hashCode());
    }

    private static String normalizeServer(String server) {
        String cleaned = safe(server).trim();
        if (cleaned.isEmpty()) return "";
        if (!cleaned.startsWith("http://") && !cleaned.startsWith("https://")) {
            cleaned = "http://" + cleaned;
        }

        try {
            URL parsed = new URL(cleaned);
            String path = parsed.getPath() == null ? "" : parsed.getPath();
            String lower = path.toLowerCase(Locale.US);
            String[] endpoints = {"/player_api.php", "/get.php", "/xmltv.php", "/panel_api.php"};
            int cut = -1;
            for (String endpoint : endpoints) {
                int index = lower.indexOf(endpoint);
                if (index >= 0 && (cut < 0 || index < cut)) cut = index;
            }
            if (cut >= 0) path = path.substring(0, cut);
            while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
            return parsed.getProtocol() + "://" + parsed.getAuthority() + path;
        } catch (Exception ignored) {
            int query = cleaned.indexOf('?');
            if (query >= 0) cleaned = cleaned.substring(0, query);
            while (cleaned.endsWith("/")) cleaned = cleaned.substring(0, cleaned.length() - 1);
            return cleaned;
        }
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private static class LightweightMedia {
        String id = "";
        String title = "";
        String categoryId = "";
        String year = "";
        String cast = "";
        String poster = "";
        String overview = "";
    }
}
