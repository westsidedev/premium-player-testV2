package com.premiumplayer.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

final class LiveTvChannelSource {

    interface Host {
        ArrayList<Channel> importedChannels();
        HashSet<String> hiddenChannels();
        HashSet<String> hiddenCategories();
        ArrayList<String> topChannelOrder();
        String safe(String value);
    }

    static ArrayList<Channel> raw(
            Host host) {

        if (!host.importedChannels().isEmpty()) {
            return host.importedChannels();
        }

        ArrayList<Channel> sample =
                new ArrayList<Channel>();

        sample.add(
                new Channel(
                        "NEWS 24",
                        "",
                        "",
                        "",
                        "NEWS",
                        "Morning News",
                        "World Report"));

        sample.add(
                new Channel(
                        "SPORT ONE",
                        "",
                        "",
                        "",
                        "SPORT",
                        "Football Highlights",
                        "Premier League Preview"));

        sample.add(
                new Channel(
                        "CINEMA ONE",
                        "",
                        "",
                        "",
                        "MOVIES",
                        "Sample Movie",
                        "Evening Premiere"));

        sample.add(
                new Channel(
                        "WORLD NEWS",
                        "",
                        "",
                        "",
                        "NEWS",
                        "International Report",
                        "Business Today"));

        sample.add(
                new Channel(
                        "DOCUMENTARY",
                        "",
                        "",
                        "",
                        "DOCS",
                        "Wild Earth",
                        "Ocean Worlds"));

        sample.add(
                new Channel(
                        "ENTERTAINMENT",
                        "",
                        "",
                        "",
                        "ENTERTAINMENT",
                        "Tonight Show",
                        "Celebrity Interview"));

        return sample;
    }

    static ArrayList<Channel> active(
            Host host) {

        ArrayList<Channel> result =
                new ArrayList<Channel>();

        HashSet<String> hiddenChannels =
                host.hiddenChannels();

        HashSet<String> hiddenCategories =
                host.hiddenCategories();

        for (Channel channel : raw(host)) {

            if (channel == null) {
                continue;
            }

            String key = channel.key();

            String group =
                    host.safe(channel.group).trim();

            if (hiddenChannels.contains(key)
                    || hiddenCategories.contains(group)) {
                continue;
            }

            result.add(channel);
        }

        HashMap<String, Integer> rank =
                new HashMap<String, Integer>();

        ArrayList<String> order =
                host.topChannelOrder();

        for (int i = 0; i < order.size(); i++) {

            if (!rank.containsKey(order.get(i))) {
                rank.put(order.get(i), i);
            }
        }

        Collections.sort(
                result,
                (left, right) -> {

                    Integer l =
                            rank.get(left.key());

                    Integer r =
                            rank.get(right.key());

                    if (l == null && r == null) {
                        return 0;
                    }

                    if (l == null) {
                        return 1;
                    }

                    if (r == null) {
                        return -1;
                    }

                    return l.compareTo(r);
                });

        return result;
    }
}
